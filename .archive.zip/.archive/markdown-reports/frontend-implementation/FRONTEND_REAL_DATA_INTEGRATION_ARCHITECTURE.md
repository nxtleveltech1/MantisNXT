# Frontend Real Data Integration Architecture

## Executive Summary

This document outlines a comprehensive frontend architecture for seamlessly integrating real supplier price list data into the MantisNXT procurement platform, replacing all mock data with live database connections while ensuring optimal performance, accessibility, and user experience.

## Current State Analysis

### Frontend Components Status
- **Dashboard**: Uses hardcoded mock data in `src/app/page.tsx`
- **Supplier Dashboard**: Mix of sample data and basic API calls in `src/components/dashboard/EnhancedSupplierDashboard.tsx`
- **Inventory Dashboard**: Already has some API integration in `src/components/dashboard/InventoryDashboard.tsx`
- **API Endpoints**: Basic CRUD operations exist for suppliers and inventory
- **Hooks**: `useSuppliers` and `useInventory` partially implemented with API calls

### Real Data Sources Available
- Multiple supplier price list files in `K:\00Project\MantisNXT\database\Uploads\drive-download-20250904T012253Z-1-001\`
- Live PostgreSQL database with suppliers and inventory_items tables
- Existing API infrastructure with filtering and pagination

## Proposed Architecture

### 1. Data Layer Enhancement

#### 1.1 API Optimization
```typescript
// Enhanced API layer with real-time data synchronization
interface DataLayer {
  suppliers: {
    fetchAll: () => Promise<Supplier[]>
    fetchMetrics: () => Promise<SupplierMetrics>
    fetchPriceLists: (supplierId: string) => Promise<PriceList[]>
  }
  inventory: {
    fetchAll: () => Promise<InventoryItem[]>
    fetchAnalytics: () => Promise<InventoryAnalytics>
    fetchAlerts: () => Promise<Alert[]>
  }
  realTime: {
    connect: () => WebSocket
    subscribe: (channel: string) => void
    updateCallbacks: Map<string, Function>
  }
}
```

#### 1.2 State Management Architecture
```typescript
// Zustand stores for global state management
interface AppState {
  suppliers: {
    data: Supplier[]
    metrics: SupplierMetrics
    loading: boolean
    error: string | null
    lastUpdated: Date
  }
  inventory: {
    data: InventoryItem[]
    analytics: InventoryAnalytics
    alerts: Alert[]
    loading: boolean
    error: string | null
    lastUpdated: Date
  }
  ui: {
    theme: 'light' | 'dark'
    sidebar: boolean
    notifications: Notification[]
  }
}
```

### 2. Component Data Integration

#### 2.1 Dashboard KPI Integration
```typescript
// Real-time dashboard metrics
interface DashboardMetrics {
  suppliers: {
    total: number
    active: number
    strategic: number
    performance: number
    recentActivity: Activity[]
  }
  inventory: {
    totalValue: number
    totalItems: number
    lowStockAlerts: number
    outOfStockItems: number
    turnoverRate: number
  }
  financial: {
    totalSpend: number
    costSavings: number
    avgContractValue: number
  }
}

// Enhanced Dashboard Component
const RealTimeDashboard = () => {
  const { metrics, loading, error } = useDashboardMetrics()
  const { suppliers } = useSuppliers()
  const { inventory } = useInventory()

  // Real-time updates
  useWebSocket('dashboard-metrics', (data) => {
    updateMetrics(data)
  })

  return (
    <DashboardLayout>
      <MetricCards metrics={metrics} />
      <SupplierPerformanceChart data={suppliers} />
      <InventoryStatusGrid data={inventory} />
      <ActivityFeed realTime />
    </DashboardLayout>
  )
}
```

#### 2.2 Supplier Management Integration
```typescript
// Enhanced supplier component with real data
const EnhancedSupplierManagement = () => {
  const {
    suppliers,
    loading,
    error,
    createSupplier,
    updateSupplier,
    deleteSupplier
  } = useSuppliers({
    autoFetch: true,
    filters: {
      status: ['active', 'preferred'],
      includeMetrics: true
    }
  })

  const { priceLists, loadPriceList } = usePriceLists()

  return (
    <SupplierDashboard>
      <SupplierTable
        data={suppliers}
        onRowClick={(supplier) => loadPriceList(supplier.id)}
      />
      <PriceListViewer
        data={priceLists}
        onImport={handlePriceListImport}
      />
    </SupplierDashboard>
  )
}
```

#### 2.3 Inventory Management Integration
```typescript
// Real inventory data integration
const RealInventoryDashboard = () => {
  const { items, metrics, loading } = useInventory({
    autoFetch: true,
    refreshInterval: 30000 // 30 seconds
  })

  const { alerts } = useInventoryAlerts()
  const { movements } = useStockMovements()

  return (
    <InventoryLayout>
      <InventoryMetrics data={metrics} />
      <StockLevelChart data={items} />
      <AlertPanel alerts={alerts} />
      <MovementHistory movements={movements} />
    </InventoryLayout>
  )
}
```

### 3. Performance Optimization

#### 3.1 Data Caching Strategy
```typescript
// React Query configuration for optimal caching
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
})

// Cached hooks
const useSuppliers = (options = {}) => {
  return useQuery({
    queryKey: ['suppliers', options],
    queryFn: () => supplierApi.fetchAll(options),
    staleTime: 2 * 60 * 1000, // 2 minutes for suppliers
  })
}
```

#### 3.2 Virtual Scrolling for Large Datasets
```typescript
// Virtual scrolling component for price lists
const VirtualizedPriceList = ({ items }: { items: PriceListItem[] }) => {
  const parentRef = useRef<HTMLDivElement>(null)

  const virtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 50,
    overscan: 10,
  })

  return (
    <div ref={parentRef} className="h-400 overflow-auto">
      {virtualizer.getVirtualItems().map((virtualItem) => (
        <PriceListRow
          key={virtualItem.key}
          item={items[virtualItem.index]}
          style={{
            height: virtualItem.size,
            transform: `translateY(${virtualItem.start}px)`,
          }}
        />
      ))}
    </div>
  )
}
```

#### 3.3 Pagination and Infinite Scroll
```typescript
// Infinite scroll hook for large datasets
const useInfiniteSuppliers = (filters = {}) => {
  return useInfiniteQuery({
    queryKey: ['suppliers-infinite', filters],
    queryFn: ({ pageParam = 1 }) =>
      supplierApi.fetchPaginated({
        page: pageParam,
        limit: 20,
        ...filters
      }),
    getNextPageParam: (lastPage) =>
      lastPage.hasNext ? lastPage.page + 1 : undefined,
  })
}
```

### 4. Real-Time Data Synchronization

#### 4.1 WebSocket Integration
```typescript
// Real-time data synchronization
const useRealTimeData = () => {
  const [socket, setSocket] = useState<WebSocket | null>(null)
  const queryClient = useQueryClient()

  useEffect(() => {
    const ws = new WebSocket(process.env.NEXT_PUBLIC_WS_URL!)

    ws.onmessage = (event) => {
      const { type, data } = JSON.parse(event.data)

      switch (type) {
        case 'SUPPLIER_UPDATED':
          queryClient.setQueryData(['suppliers'], (old: Supplier[]) =>
            old?.map(s => s.id === data.id ? { ...s, ...data } : s)
          )
          break

        case 'INVENTORY_ALERT':
          queryClient.setQueryData(['alerts'], (old: Alert[]) =>
            [data, ...(old || [])]
          )
          break

        case 'PRICE_UPDATE':
          queryClient.invalidateQueries(['price-lists'])
          break
      }
    }

    setSocket(ws)
    return () => ws.close()
  }, [queryClient])

  return { socket, isConnected: socket?.readyState === WebSocket.OPEN }
}
```

#### 4.2 Optimistic Updates
```typescript
// Optimistic updates for better UX
const useSupplierMutations = () => {
  const queryClient = useQueryClient()

  const updateSupplier = useMutation({
    mutationFn: supplierApi.update,
    onMutate: async (newSupplier) => {
      await queryClient.cancelQueries(['suppliers'])

      const previousSuppliers = queryClient.getQueryData(['suppliers'])

      queryClient.setQueryData(['suppliers'], (old: Supplier[]) =>
        old?.map(s => s.id === newSupplier.id ?
          { ...s, ...newSupplier } : s
        )
      )

      return { previousSuppliers }
    },
    onError: (err, newSupplier, context) => {
      queryClient.setQueryData(['suppliers'], context?.previousSuppliers)
    },
    onSettled: () => {
      queryClient.invalidateQueries(['suppliers'])
    },
  })

  return { updateSupplier }
}
```

### 5. Enhanced Error Handling

#### 5.1 Error Boundary Implementation
```typescript
// Global error boundary
class DataErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Data loading error:', error, errorInfo)

    // Send to error reporting service
    errorReporter.captureException(error, {
      extra: errorInfo,
      tags: { section: 'data-integration' }
    })
  }

  render() {
    if (this.state.hasError) {
      return (
        <ErrorFallback
          error={this.state.error}
          onRetry={() => this.setState({ hasError: false, error: null })}
        />
      )
    }

    return this.props.children
  }
}
```

#### 5.2 Retry and Fallback Strategies
```typescript
// Retry logic with exponential backoff
const useRetryableQuery = (key: string, queryFn: () => Promise<any>) => {
  return useQuery({
    queryKey: [key],
    queryFn,
    retry: (failureCount, error) => {
      if (failureCount >= 3) return false

      const delay = Math.min(1000 * 2 ** failureCount, 30000)
      setTimeout(() => {}, delay)

      return true
    },
    onError: (error) => {
      console.warn(`Query ${key} failed:`, error)

      // Show user-friendly error message
      toast.error('Failed to load data. Retrying...')
    }
  })
}
```

### 6. Testing Strategy

#### 6.1 Integration Testing
```typescript
// Mock service worker for testing
import { rest } from 'msw'
import { setupServer } from 'msw/node'

const server = setupServer(
  rest.get('/api/suppliers', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        data: mockSuppliers,
        pagination: { page: 1, total: 100 }
      })
    )
  }),

  rest.get('/api/inventory', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        data: mockInventory,
        metrics: mockMetrics
      })
    )
  })
)

// Test real data integration
describe('Real Data Integration', () => {
  it('loads suppliers from API', async () => {
    render(<SupplierDashboard />)

    await waitFor(() => {
      expect(screen.getByText('Loading...')).toBeInTheDocument()
    })

    await waitFor(() => {
      expect(screen.getByText('TechCorp Solutions')).toBeInTheDocument()
    })
  })

  it('handles API errors gracefully', async () => {
    server.use(
      rest.get('/api/suppliers', (req, res, ctx) => {
        return res(ctx.status(500), ctx.json({ error: 'Server error' }))
      })
    )

    render(<SupplierDashboard />)

    await waitFor(() => {
      expect(screen.getByText('Failed to load suppliers')).toBeInTheDocument()
    })
  })
})
```

### 7. Accessibility Enhancements

#### 7.1 Screen Reader Support
```typescript
// Accessible data loading states
const AccessibleDataTable = ({ data, loading, error }: Props) => {
  return (
    <div role="region" aria-label="Supplier data">
      {loading && (
        <div
          role="status"
          aria-live="polite"
          aria-label="Loading supplier data"
        >
          <LoadingSpinner />
          <span className="sr-only">Loading...</span>
        </div>
      )}

      {error && (
        <div
          role="alert"
          aria-live="assertive"
          className="error-message"
        >
          {error}
        </div>
      )}

      {data && (
        <table
          role="table"
          aria-label={`${data.length} suppliers loaded`}
        >
          <thead>
            <tr role="row">
              <th role="columnheader" tabIndex={0}>Name</th>
              <th role="columnheader" tabIndex={0}>Status</th>
              <th role="columnheader" tabIndex={0}>Performance</th>
            </tr>
          </thead>
          <tbody>
            {data.map((supplier, index) => (
              <tr
                key={supplier.id}
                role="row"
                aria-rowindex={index + 1}
              >
                <td role="gridcell">{supplier.name}</td>
                <td role="gridcell">
                  <Badge
                    aria-label={`Status: ${supplier.status}`}
                    className={getStatusColor(supplier.status)}
                  >
                    {supplier.status}
                  </Badge>
                </td>
                <td role="gridcell">
                  <span aria-label={`Performance rating: ${supplier.rating} out of 5`}>
                    {supplier.rating}/5
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}
```

### 8. Implementation Roadmap

#### Phase 1: Foundation (Week 1-2)
- [ ] Set up React Query for data caching
- [ ] Replace mock data in main dashboard
- [ ] Implement error boundaries
- [ ] Create reusable data hooks

#### Phase 2: Core Integration (Week 3-4)
- [ ] Integrate real supplier data
- [ ] Connect inventory management
- [ ] Implement price list integration
- [ ] Add real-time updates

#### Phase 3: Optimization (Week 5-6)
- [ ] Add virtual scrolling
- [ ] Implement infinite scroll
- [ ] Optimize bundle size
- [ ] Performance monitoring

#### Phase 4: Enhancement (Week 7-8)
- [ ] WebSocket real-time features
- [ ] Advanced caching strategies
- [ ] Accessibility audit and fixes
- [ ] Comprehensive testing

### 9. API Enhancement Requirements

#### 9.1 New Endpoints Needed
```typescript
// Additional API endpoints for complete integration
interface RequiredAPIs {
  // Price list management
  '/api/suppliers/:id/pricelists': {
    GET: () => PriceList[]
    POST: (data: PriceListUpload) => PriceList
    PUT: (id: string, data: PriceListUpdate) => PriceList
  }

  // Real-time metrics
  '/api/dashboard/metrics': {
    GET: () => RealTimeMetrics
  }

  // Inventory analytics
  '/api/inventory/analytics': {
    GET: (params: AnalyticsParams) => InventoryAnalytics
  }

  // Stock movements
  '/api/inventory/movements': {
    GET: (params: MovementParams) => StockMovement[]
    POST: (data: MovementData) => StockMovement
  }

  // Alerts and notifications
  '/api/alerts': {
    GET: () => Alert[]
    POST: (data: AlertData) => Alert
    PUT: (id: string, data: AlertUpdate) => Alert
  }
}
```

### 10. Monitoring and Analytics

#### 10.1 Performance Monitoring
```typescript
// Performance monitoring setup
const performanceMonitor = {
  trackApiCall: (endpoint: string, duration: number) => {
    analytics.track('api_call', {
      endpoint,
      duration,
      timestamp: Date.now()
    })
  },

  trackComponentRender: (component: string, renderTime: number) => {
    analytics.track('component_render', {
      component,
      renderTime,
      timestamp: Date.now()
    })
  },

  trackUserAction: (action: string, metadata: any) => {
    analytics.track('user_action', {
      action,
      metadata,
      timestamp: Date.now()
    })
  }
}
```

## Conclusion

This comprehensive frontend architecture provides a robust foundation for integrating real supplier price list data while maintaining optimal performance, accessibility, and user experience. The modular approach allows for incremental implementation and easy maintenance.

Key benefits:
- **Seamless Data Integration**: Replace all mock data with live API connections
- **Performance Optimized**: Virtual scrolling, caching, and lazy loading
- **Real-Time Updates**: WebSocket integration for live data
- **Accessible Design**: WCAG 2.1 AA compliance
- **Scalable Architecture**: Supports future growth and features
- **Developer Experience**: Type-safe, well-documented, and testable

The implementation should be done in phases to ensure stability and allow for testing at each stage.