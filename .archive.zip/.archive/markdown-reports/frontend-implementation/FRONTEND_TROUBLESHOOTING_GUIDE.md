# Frontend Troubleshooting Guide

## 🚨 Quick Problem Solving

### Dashboard Not Loading?

#### 1. Check for Timeout Issues
**Symptoms**: Page loads indefinitely, components showing loading states
**Solutions**:
- Wait 15 seconds (automatic timeout)
- Click "Try Again" button when it appears
- Check system status at `/status`

#### 2. Individual Component Failures
**Symptoms**: Some cards show error states while others work
**Solutions**:
- Each component has its own "Retry" button
- Click the retry button on the failed component
- Check browser console for specific error details

#### 3. Database Connection Problems
**Symptoms**: "Circuit breaker is open" or "Database temporarily unavailable"
**Solutions**:
- Visit `/status` page to check system health
- Wait 60 seconds for circuit breaker to reset
- Contact system administrator if persistent

## 🔍 Diagnostic Tools

### Built-in Health Check
Visit: `http://localhost:3000/status`

**Shows**:
- ✅ Database connection status
- ✅ API endpoint response times
- ✅ System resource usage
- ✅ Automatic recommendations

### Browser Console Debugging
Open browser developer tools (F12) and check console for:

```
🔍 Fetching suppliers from: /api/suppliers
✅ Suppliers loaded: 25 items
❌ Inventory fetch error: Request timed out
```

### API Health Check
Direct API test: `http://localhost:3000/api/health/frontend`

## 🛠️ Common Issues & Solutions

### 1. "Request timed out - server may be overloaded"
**Cause**: API taking longer than 15 seconds
**Fix**:
- Click "Try Again"
- Check `/status` for server performance
- If persistent, restart the application

### 2. "HTTP 500: Internal Server Error"
**Cause**: Server-side processing error
**Fix**:
- Temporary issue - wait and retry
- Check server logs
- Contact administrator if recurring

### 3. "Network Error" or "Failed to fetch"
**Cause**: Connection to server lost
**Fix**:
- Check internet connection
- Verify server is running on localhost:3000
- Restart development server

### 4. Components showing "Error" with alert icon
**Cause**: Individual API endpoint failure
**Fix**:
- Click the "Retry" button on that specific component
- Check if other components are working (indicates partial failure)
- Review network tab in browser dev tools

## 📊 Performance Guidelines

### Expected Response Times
- **Good**: < 1 second (green)
- **Acceptable**: 1-3 seconds (yellow)
- **Poor**: > 3 seconds (red)

### When to Be Concerned
- Multiple components failing simultaneously
- Consistent timeout errors across different endpoints
- Database status showing "unhealthy"
- Memory usage > 90%

## 🎯 Specific Error Messages

### "Circuit breaker is open"
- **Meaning**: Database has failed 5+ times, temporarily blocked
- **Duration**: 60 seconds
- **Action**: Wait for automatic reset, then retry

### "Request timeout"
- **Meaning**: API didn't respond within 15 seconds
- **Action**: Click "Try Again" or wait for auto-retry

### "Invalid query parameters"
- **Meaning**: Frontend sent malformed request
- **Action**: Report as bug, includes technical details for developers

### "Database connection failed"
- **Meaning**: Cannot connect to PostgreSQL database
- **Action**: Check database server status, contact administrator

## 🔧 Developer Debug Mode

### Enable Detailed Logging
1. Open browser console (F12)
2. Look for log messages with emojis:
   - 🔍 = API request start
   - ✅ = Successful response
   - ❌ = Error occurred
   - 🔄 = Retry attempt

### Check Network Activity
1. Open Network tab in dev tools
2. Filter by "XHR" or "Fetch"
3. Look for failed requests (red status)
4. Click on failed request to see details

### Component-Level Debugging
Each component now has isolated error handling:
- Supplier metrics: Independent retry
- Inventory metrics: Independent retry
- Activity feed: Independent retry
- Alerts panel: Independent retry

## 🚀 Performance Optimization Tips

### For Users
1. **Keep status page open** in another tab for monitoring
2. **Use retry buttons** instead of refreshing entire page
3. **Wait for timeouts** - system will auto-recover
4. **Check system status** before reporting issues

### For Administrators
1. **Monitor `/status` page** for early warning signs
2. **Check response times** regularly
3. **Watch memory usage** on status dashboard
4. **Review error patterns** in console logs

## 📞 When to Contact Support

### Immediate Support Needed
- System status shows "unhealthy" for > 5 minutes
- All components showing errors simultaneously
- Database connection consistently failing
- Memory usage > 95%

### Include This Information
1. **Error message** (copy exact text)
2. **Screenshot** of error or status page
3. **Browser type** and version
4. **Steps to reproduce** the issue
5. **Time when issue started**

### Self-Service Options
1. **Status page**: `/status` - real-time health monitoring
2. **Component retry**: Individual "Try Again" buttons
3. **Page refresh**: Last resort for persistent issues
4. **Health check**: `/api/health/frontend` - raw technical data

## 🎉 Success Indicators

### System is Healthy When:
- ✅ All metrics loading in < 3 seconds
- ✅ No error states visible
- ✅ Status page shows all "Healthy" badges
- ✅ Response times in green zone (< 1s)
- ✅ Memory usage < 80%

### Everything Working Correctly:
- Dashboard loads completely within 10 seconds
- Individual components can be retried if needed
- Real-time status indicator shows "Live"
- All metric cards display current data
- Activity feed and alerts populate properly