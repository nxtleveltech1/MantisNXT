# Frontend Real Data Integration Implementation Plan

## Overview

This document provides a detailed implementation plan for integrating real supplier price list data into the MantisNXT frontend, replacing all mock data with live database connections.

## Current Architecture Analysis

### ✅ Already Implemented
- PostgreSQL database with suppliers and inventory_items tables
- Basic API endpoints for suppliers and inventory CRUD operations
- Real-time WebSocket hook infrastructure (`useRealTimeData.ts`)
- Basic React Query setup for data caching
- Component structure ready for data integration

### ❌ Needs Implementation
- Dashboard components still use hardcoded mock data
- No integration with real supplier price list files
- Limited real-time data synchronization
- Missing analytics and metrics API endpoints
- No comprehensive error handling and loading states

## Implementation Strategy

### Phase 1: Foundation Setup (Week 1)

#### 1.1 Install Dependencies
```bash
npm install @tanstack/react-query @tanstack/react-query-devtools
npm install @tanstack/react-virtual # For large dataset handling
npm install react-error-boundary # For robust error handling
npm install date-fns # For date formatting
npm install recharts # Enhanced charts
```

#### 1.2 Setup React Query Provider
```typescript
// src/lib/providers/QueryProvider.tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      retry: 2,
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
    },
    mutations: {
      retry: 1,
    },
  },
})

export const QueryProvider = ({ children }) => (
  <QueryClientProvider client={queryClient}>
    {children}
    <ReactQueryDevtools initialIsOpen={false} />
  </QueryClientProvider>
)
```

#### 1.3 Update Main Layout
```typescript
// src/app/layout.tsx - Add QueryProvider
import { QueryProvider } from '@/lib/providers/QueryProvider'

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <QueryProvider>
          {children}
        </QueryProvider>
      </body>
    </html>
  )
}
```

### Phase 2: API Enhancement (Week 1-2)

#### 2.1 Create Missing API Endpoints

**Dashboard Metrics API**
```typescript
// src/app/api/dashboard/metrics/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { pool } from '@/lib/database/connection'

export async function GET(request: NextRequest) {
  try {
    const [suppliersMetrics, inventoryMetrics, activitiesResult] = await Promise.all([
      // Suppliers metrics query
      pool.query(`
        SELECT
          COUNT(*) as total_suppliers,
          COUNT(*) FILTER (WHERE status = 'active') as active_suppliers,
          COUNT(*) FILTER (WHERE performance_tier = 'strategic') as strategic_partners,
          AVG(CAST(rating AS FLOAT)) as avg_rating
        FROM suppliers
      `),

      // Inventory metrics query
      pool.query(`
        SELECT
          COUNT(*) as total_items,
          SUM(stock_qty * cost_price) as total_value,
          COUNT(*) FILTER (WHERE stock_qty <= reorder_point AND stock_qty > 0) as low_stock,
          COUNT(*) FILTER (WHERE stock_qty = 0) as out_of_stock
        FROM inventory_items
        WHERE status = 'active'
      `),

      // Recent activities
      pool.query(`
        SELECT
          'supplier' as type,
          'Supplier Added' as title,
          'New supplier ' || name || ' was added' as description,
          created_at as timestamp
        FROM suppliers
        WHERE created_at >= NOW() - INTERVAL '24 hours'
        ORDER BY created_at DESC
        LIMIT 10
      `)
    ])

    const supplierMetrics = suppliersMetrics.rows[0]
    const inventoryMetrics = inventoryMetrics.rows[0]

    return NextResponse.json({
      success: true,
      data: {
        suppliers: {
          total: parseInt(supplierMetrics.total_suppliers),
          active: parseInt(supplierMetrics.active_suppliers),
          strategic: parseInt(supplierMetrics.strategic_partners),
          avgRating: parseFloat(supplierMetrics.avg_rating || '0')
        },
        inventory: {
          totalItems: parseInt(inventoryMetrics.total_items),
          totalValue: parseFloat(inventoryMetrics.total_value || '0'),
          lowStock: parseInt(inventoryMetrics.low_stock),
          outOfStock: parseInt(inventoryMetrics.out_of_stock)
        },
        activities: activitiesResult.rows.map(row => ({
          id: Date.now() + Math.random(),
          type: row.type,
          title: row.title,
          description: row.description,
          timestamp: row.timestamp,
          priority: 'medium',
          status: 'completed'
        }))
      },
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('Dashboard metrics error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch dashboard metrics'
    }, { status: 500 })
  }
}
```

**Price Lists API**
```typescript
// src/app/api/suppliers/[id]/pricelists/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { pool } from '@/lib/database/connection'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const supplierId = params.id

    // Query supplier price lists from database
    const priceListQuery = `
      SELECT
        pl.*,
        COUNT(pli.id) as item_count,
        MIN(pli.cost_price) as min_price,
        MAX(pli.cost_price) as max_price,
        AVG(pli.cost_price) as avg_price
      FROM price_lists pl
      LEFT JOIN price_list_items pli ON pl.id = pli.price_list_id
      WHERE pl.supplier_id = $1
        AND pl.status = 'active'
      GROUP BY pl.id
      ORDER BY pl.updated_at DESC
    `

    const result = await pool.query(priceListQuery, [supplierId])

    return NextResponse.json({
      success: true,
      data: result.rows.map(row => ({
        id: row.id,
        supplierId: row.supplier_id,
        name: row.name,
        version: row.version,
        effectiveDate: row.effective_date,
        expiryDate: row.expiry_date,
        currency: row.currency,
        status: row.status,
        itemCount: parseInt(row.item_count),
        priceRange: {
          min: parseFloat(row.min_price || '0'),
          max: parseFloat(row.max_price || '0'),
          avg: parseFloat(row.avg_price || '0')
        },
        createdAt: row.created_at,
        updatedAt: row.updated_at
      }))
    })
  } catch (error) {
    console.error('Price lists fetch error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch price lists'
    }, { status: 500 })
  }
}
```

#### 2.2 Enhanced Inventory Analytics API
```typescript
// src/app/api/inventory/analytics/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { pool } from '@/lib/database/connection'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const days = parseInt(searchParams.get('days') || '30')

    const [overviewResult, categoryResult, movementResult, alertsResult] = await Promise.all([
      // Overview metrics
      pool.query(`
        SELECT
          COUNT(*) as total_items,
          SUM(stock_qty * cost_price) as total_value,
          COUNT(*) FILTER (WHERE stock_qty <= reorder_point AND stock_qty > 0) as low_stock_count,
          COUNT(*) FILTER (WHERE stock_qty = 0) as out_of_stock_count,
          AVG(stock_qty * cost_price) as avg_item_value
        FROM inventory_items
        WHERE status = 'active'
      `),

      // Category breakdown
      pool.query(`
        SELECT
          category,
          COUNT(*) as item_count,
          SUM(stock_qty * cost_price) as category_value,
          AVG(stock_qty) as avg_stock
        FROM inventory_items
        WHERE status = 'active' AND category IS NOT NULL
        GROUP BY category
        ORDER BY category_value DESC
        LIMIT 10
      `),

      // Recent stock movements (mock data for now)
      pool.query(`
        SELECT
          'Receipt' as type,
          name as product,
          50 as quantity,
          updated_at as date
        FROM inventory_items
        WHERE updated_at >= NOW() - INTERVAL '${days} days'
        ORDER BY updated_at DESC
        LIMIT 20
      `),

      // Stock alerts
      pool.query(`
        SELECT
          id,
          name,
          sku,
          stock_qty,
          reorder_point,
          CASE
            WHEN stock_qty = 0 THEN 'out_of_stock'
            WHEN stock_qty <= reorder_point THEN 'low_stock'
            ELSE 'normal'
          END as alert_type
        FROM inventory_items
        WHERE stock_qty <= reorder_point
          AND status = 'active'
        ORDER BY stock_qty ASC
      `)
    ])

    const overview = overviewResult.rows[0]

    return NextResponse.json({
      success: true,
      data: {
        overview: {
          totalItems: parseInt(overview.total_items),
          totalValue: parseFloat(overview.total_value || '0'),
          lowStockCount: parseInt(overview.low_stock_count),
          outOfStockCount: parseInt(overview.out_of_stock_count),
          avgTurnover: 4.2 // Calculate from actual data later
        },
        topCategories: categoryResult.rows.map(row => ({
          name: row.category,
          value: parseFloat(row.category_value),
          count: parseInt(row.item_count),
          avgStock: parseFloat(row.avg_stock)
        })),
        recentMovements: movementResult.rows.map(row => ({
          type: row.type,
          product: row.product,
          quantity: row.quantity,
          date: row.date
        })),
        alerts: alertsResult.rows.map(row => ({
          id: row.id,
          name: row.name,
          sku: row.sku,
          currentStock: row.stock_qty,
          reorderPoint: row.reorder_point,
          type: row.alert_type
        }))
      }
    })
  } catch (error) {
    console.error('Inventory analytics error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch inventory analytics'
    }, { status: 500 })
  }
}
```

### Phase 3: Component Integration (Week 2-3)

#### 3.1 Replace Main Dashboard Mock Data

**Update src/app/page.tsx**
```typescript
"use client";

import React from 'react'
import SelfContainedLayout from '@/components/layout/SelfContainedLayout'
import RealDataDashboard from '@/components/dashboard/RealDataDashboard'

export default function Home() {
  const breadcrumbs = [
    { label: "Real-Time Dashboard" }
  ]

  return (
    <SelfContainedLayout
      title="MantisNXT Dashboard"
      breadcrumbs={breadcrumbs}
    >
      <RealDataDashboard />
    </SelfContainedLayout>
  )
}
```

#### 3.2 Enhanced Supplier Dashboard Integration
```typescript
// src/components/suppliers/EnhancedSupplierDashboard.tsx
import { useRealTimeSuppliers, usePriceLists } from '@/hooks/useRealTimeData'

const EnhancedSupplierDashboard = () => {
  const {
    data: suppliersResponse,
    isLoading,
    error,
    refetch
  } = useRealTimeSuppliers({
    includeMetrics: true,
    status: ['active', 'preferred']
  })

  const suppliers = suppliersResponse?.data || []
  const metrics = suppliersResponse?.metrics

  // Real supplier data integration
  const supplierMetrics = useMemo(() => {
    return {
      total: suppliers.length,
      active: suppliers.filter(s => s.status === 'active').length,
      strategic: suppliers.filter(s => s.performance_tier === 'strategic').length,
      avgRating: suppliers.length > 0
        ? suppliers.reduce((sum, s) => sum + parseFloat(s.rating || '0'), 0) / suppliers.length
        : 0
    }
  }, [suppliers])

  if (isLoading) return <DashboardSkeleton />
  if (error) return <ErrorDisplay error={error} onRetry={refetch} />

  return (
    <div className="space-y-6">
      <MetricsGrid metrics={supplierMetrics} />
      <SuppliersTable data={suppliers} />
      <PerformanceCharts data={suppliers} />
    </div>
  )
}
```

#### 3.3 Enhanced Inventory Dashboard Integration
```typescript
// src/components/inventory/EnhancedInventoryDashboard.tsx
import { useRealTimeInventory } from '@/hooks/useRealTimeData'
import { useQuery } from '@tanstack/react-query'

const EnhancedInventoryDashboard = () => {
  const {
    data: inventoryResponse,
    isLoading: inventoryLoading,
    error: inventoryError
  } = useRealTimeInventory({
    includeMetrics: true,
    includeAlerts: true
  })

  const {
    data: analyticsResponse,
    isLoading: analyticsLoading
  } = useQuery({
    queryKey: ['inventory-analytics'],
    queryFn: async () => {
      const response = await fetch('/api/inventory/analytics')
      if (!response.ok) throw new Error('Failed to fetch analytics')
      return response.json()
    },
    staleTime: 2 * 60 * 1000 // 2 minutes
  })

  const inventory = inventoryResponse?.data || []
  const analytics = analyticsResponse?.data

  if (inventoryLoading || analyticsLoading) return <DashboardSkeleton />
  if (inventoryError) return <ErrorDisplay error={inventoryError} />

  return (
    <div className="space-y-6">
      <InventoryMetricsCards data={analytics?.overview} />
      <InventoryCharts data={analytics} />
      <InventoryTable data={inventory} />
      <StockAlerts alerts={analytics?.alerts} />
    </div>
  )
}
```

### Phase 4: Performance Optimization (Week 3-4)

#### 4.1 Virtual Scrolling for Large Lists
```typescript
// src/components/ui/VirtualizedList.tsx
import { useVirtualizer } from '@tanstack/react-virtual'
import { useRef } from 'react'

interface VirtualizedListProps<T> {
  items: T[]
  renderItem: (item: T, index: number) => React.ReactNode
  estimateSize?: number
  overscan?: number
  className?: string
}

export const VirtualizedList = <T,>({
  items,
  renderItem,
  estimateSize = 50,
  overscan = 5,
  className = "h-400"
}: VirtualizedListProps<T>) => {
  const parentRef = useRef<HTMLDivElement>(null)

  const virtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => estimateSize,
    overscan,
  })

  return (
    <div ref={parentRef} className={`overflow-auto ${className}`}>
      <div
        style={{
          height: virtualizer.getTotalSize(),
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualizer.getVirtualItems().map((virtualItem) => (
          <div
            key={virtualItem.key}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: virtualItem.size,
              transform: `translateY(${virtualItem.start}px)`,
            }}
          >
            {renderItem(items[virtualItem.index], virtualItem.index)}
          </div>
        ))}
      </div>
    </div>
  )
}
```

#### 4.2 Data Prefetching and Caching Strategy
```typescript
// src/lib/prefetch.ts
import { QueryClient } from '@tanstack/react-query'

export const prefetchDashboardData = async (queryClient: QueryClient) => {
  await Promise.all([
    queryClient.prefetchQuery({
      queryKey: ['dashboard-metrics'],
      queryFn: () => fetch('/api/dashboard/metrics').then(r => r.json()),
      staleTime: 60 * 1000
    }),
    queryClient.prefetchQuery({
      queryKey: ['suppliers', { status: ['active'] }],
      queryFn: () => fetch('/api/suppliers?status=active').then(r => r.json()),
      staleTime: 2 * 60 * 1000
    }),
    queryClient.prefetchQuery({
      queryKey: ['inventory', { includeMetrics: true }],
      queryFn: () => fetch('/api/inventory?includeMetrics=true').then(r => r.json()),
      staleTime: 30 * 1000
    })
  ])
}
```

### Phase 5: Real-Time Features (Week 4-5)

#### 5.1 WebSocket Server Setup
```typescript
// src/lib/websocket/server.ts
import { WebSocketServer } from 'ws'
import { pool } from '@/lib/database/connection'

export const setupWebSocketServer = (server: any) => {
  const wss = new WebSocketServer({ server })

  wss.on('connection', (ws, request) => {
    console.log('New WebSocket connection')

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString())

        switch (message.type) {
          case 'SUBSCRIBE':
            // Handle table subscriptions
            ws.subscribe = message.table
            break

          case 'UNSUBSCRIBE':
            ws.subscribe = null
            break
        }
      } catch (error) {
        console.error('WebSocket message error:', error)
      }
    })

    // Send heartbeat
    const heartbeat = setInterval(() => {
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({
          type: 'heartbeat',
          timestamp: new Date().toISOString()
        }))
      }
    }, 30000)

    ws.on('close', () => {
      clearInterval(heartbeat)
    })
  })

  return wss
}
```

#### 5.2 Database Trigger Integration
```sql
-- Database triggers for real-time updates
CREATE OR REPLACE FUNCTION notify_table_changes()
RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'table_changes',
    json_build_object(
      'table', TG_TABLE_NAME,
      'operation', TG_OP,
      'record', row_to_json(NEW)
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to key tables
CREATE TRIGGER suppliers_notify
  AFTER INSERT OR UPDATE OR DELETE ON suppliers
  FOR EACH ROW EXECUTE FUNCTION notify_table_changes();

CREATE TRIGGER inventory_notify
  AFTER INSERT OR UPDATE OR DELETE ON inventory_items
  FOR EACH ROW EXECUTE FUNCTION notify_table_changes();
```

### Phase 6: Testing and Quality Assurance (Week 5-6)

#### 6.1 Integration Tests
```typescript
// tests/integration/dashboard.test.tsx
import { render, screen, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import RealDataDashboard from '@/components/dashboard/RealDataDashboard'

const server = setupServer(
  rest.get('/api/dashboard/metrics', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        data: {
          suppliers: { total: 25, active: 20, strategic: 5 },
          inventory: { totalItems: 150, totalValue: 250000 }
        }
      })
    )
  })
)

beforeAll(() => server.listen())
afterEach(() => server.resetHandlers())
afterAll(() => server.close())

test('displays real dashboard metrics', async () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false }
    }
  })

  render(
    <QueryClientProvider client={queryClient}>
      <RealDataDashboard />
    </QueryClientProvider>
  )

  await waitFor(() => {
    expect(screen.getByText('25')).toBeInTheDocument() // Total suppliers
    expect(screen.getByText('20')).toBeInTheDocument() // Active suppliers
    expect(screen.getByText('150')).toBeInTheDocument() // Total items
  })
})
```

#### 6.2 Performance Tests
```typescript
// tests/performance/data-loading.test.ts
import { measurePerformance } from '@/lib/testing/performance'

test('dashboard loads within performance budget', async () => {
  const metrics = await measurePerformance(async () => {
    // Simulate dashboard load
    const response = await fetch('/api/dashboard/metrics')
    await response.json()
  })

  expect(metrics.duration).toBeLessThan(2000) // 2 seconds max
  expect(metrics.memoryUsed).toBeLessThan(50 * 1024 * 1024) // 50MB max
})
```

### Phase 7: Deployment and Monitoring (Week 6-7)

#### 7.1 Environment Configuration
```typescript
// next.config.js - Production optimizations
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Performance optimizations
  experimental: {
    optimizeCss: true,
    optimizePackageImports: [
      '@tanstack/react-query',
      'lucide-react',
      'recharts'
    ]
  },

  // Bundle analysis
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.resolve.alias['@tanstack/react-query'] = require.resolve('@tanstack/react-query')
    }
    return config
  }
}

module.exports = nextConfig
```

#### 7.2 Monitoring Setup
```typescript
// src/lib/monitoring/performance.ts
export const trackPerformance = (metricName: string, value: number) => {
  // Send to monitoring service
  if (typeof window !== 'undefined' && 'performance' in window) {
    performance.mark(`${metricName}-${Date.now()}`)

    // Send to analytics
    if (process.env.NODE_ENV === 'production') {
      fetch('/api/metrics', {
        method: 'POST',
        body: JSON.stringify({
          metric: metricName,
          value,
          timestamp: Date.now(),
          userAgent: navigator.userAgent
        })
      }).catch(console.error)
    }
  }
}
```

## Success Metrics

### Performance Targets
- **Page Load Time**: < 2 seconds for dashboard
- **Data Fetch Time**: < 500ms for API endpoints
- **Bundle Size**: < 500KB for main bundle
- **Memory Usage**: < 100MB for dashboard components

### Quality Targets
- **Test Coverage**: > 80% for critical components
- **Accessibility**: WCAG 2.1 AA compliance
- **Error Rate**: < 1% for API calls
- **User Experience**: Smooth transitions and loading states

### Business Targets
- **Data Accuracy**: 99.9% consistency with database
- **Real-Time Updates**: < 5 second delay for critical updates
- **User Adoption**: > 90% user acceptance for new interface
- **Performance**: 50% faster than previous mock data version

## Risk Mitigation

### Technical Risks
- **Database Performance**: Implement query optimization and caching
- **WebSocket Reliability**: Fallback to polling for critical updates
- **Memory Leaks**: Proper cleanup in useEffect hooks
- **Bundle Size**: Code splitting and lazy loading

### Business Risks
- **Data Migration**: Gradual rollout with feature flags
- **User Training**: Comprehensive documentation and tutorials
- **Backup Plans**: Rollback capability for critical issues
- **Performance Impact**: Load testing before production deployment

## Timeline Summary

| Phase | Duration | Key Deliverables |
|-------|----------|-----------------|
| Phase 1 | Week 1 | React Query setup, dependencies installed |
| Phase 2 | Week 1-2 | All API endpoints implemented and tested |
| Phase 3 | Week 2-3 | All components using real data |
| Phase 4 | Week 3-4 | Performance optimizations complete |
| Phase 5 | Week 4-5 | Real-time features operational |
| Phase 6 | Week 5-6 | Full test coverage and QA complete |
| Phase 7 | Week 6-7 | Production deployment and monitoring |

**Total Duration**: 7 weeks
**Resources**: 1 senior frontend developer, 0.5 backend developer
**Budget**: Medium complexity project with existing infrastructure

This implementation plan provides a comprehensive roadmap for replacing all mock data with real database connections while maintaining high performance, accessibility, and user experience standards.