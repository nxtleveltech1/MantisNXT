# FRONTEND CLEANUP INVENTORY
**Agent 6: Frontend Asset & Config Cleanup**
**Date:** 2025-10-22
**Project:** MantisNXT - Next.js 15 + React 19
**Phase:** ANALYSIS - Phase 1

---

## EXECUTIVE SUMMARY

### Overview
- **Total App Routes:** 164 files in `src/app/`
- **Total Components:** 136 files in `src/components/`
- **Public Assets:** 2KB (2 favicon files)
- **Test Artifacts:** 2.5MB (playwright-report: 1.4MB, test-results: 1.1MB)
- **Duplicate ESLint Configs:** 2 versions found
- **Legacy Pages Directory:** Detected with 4 files (App Router migration in progress)

### Key Findings
1. **9 backup/old/broken files** in `src/app/` requiring cleanup
2. **Duplicate ESLint configurations** - `.eslintrc.json` vs `.eslintrc.enhanced.json`
3. **Legacy Windsurf AI config** - `.windsurfrules` (20KB, last modified Sep 23)
4. **Pages directory artifacts** - Both `pages/` and `src/pages/` exist
5. **Test artifacts** - 2.5MB of test reports not in .gitignore
6. **API backup files** - Multiple `.backup` files in API routes
7. **Devcontainer active** - Docker-based development environment in use

---

## 1. FRONTEND DIRECTORY ANALYSIS

### 1.1 Public Assets (`/public/`)
**Size:** 2KB
**Status:** ✅ MINIMAL & CLEAN

```
public/
├── favicon.ico     # Referenced in browser defaults
└── favicon.svg     # Modern SVG favicon
```

**Analysis:**
- No unused assets detected
- Both favicons are standard browser assets
- No explicit reference in `src/app/layout.tsx` (relies on Next.js defaults)
- No images, fonts, or other static assets (all handled via CDN/imports)

**Recommendation:** **KEEP AS-IS** - Clean, minimal, appropriate for modern web apps.

---

### 1.2 App Directory (`src/app/`)
**Total Files:** 164 (routes + API)
**Status:** ⚠️ CLEANUP NEEDED

#### Backup/Legacy Files Requiring Cleanup:
```bash
# Main app pages (ARCHIVE - legacy iterations)
src/app/page_old.tsx           # Old dashboard iteration
src/app/page_old2.tsx          # Optimization iteration
src/app/page_old3.tsx          # Viewport optimization iteration
src/app/page_old4.tsx          # Further optimization
src/app/page_original.tsx      # Original page
src/app/page_broken.tsx        # Failed iteration

# Auth module (ARCHIVE - backup/corrupted files)
src/app/auth/verify-email/page.tsx.backup   # Backup of verify email
src/app/auth/verify-email/page.tsx.corrupt  # Corrupted version
src/app/auth/verify-email/page_fixed.tsx    # Fixed version (merged?)

# Supplier module (ARCHIVE - superseded by current)
src/app/suppliers/page_backup.tsx           # Old supplier dashboard

# API routes (ARCHIVE - backup versions)
src/app/api/alerts/route.ts.backup          # Old alerts route
src/app/api/analytics/anomalies/route.ts.backup-1758726346105
src/app/api/analytics/predictions/route.ts.backup-1758726346112
src/app/api/analytics/recommendations/route.ts.backup-1758726346117
src/app/api/ai/suppliers/discover/route.v5.example.ts  # Example file
```

**Impact:** These files are not referenced in active code (verified via grep).

**Recommendation:**
- **ARCHIVE** all backup/old/broken files to `archive/frontend/deprecated-pages/`
- **DELETE** `.corrupt` files (no value in keeping corrupted code)
- **KEEP** only `page.tsx`, `page_fixed.tsx` becomes the canonical `page.tsx`

---

### 1.3 Components Directory (`src/components/`)
**Total Files:** 136 TypeScript/React components
**Status:** ✅ GENERALLY CLEAN (time-limited analysis)

#### Dashboard Component Duplication:
```bash
src/components/dashboard/
├── SupplierDashboard.tsx           # 27KB - Sep 17 (OLD)
├── EnhancedSupplierDashboard.tsx   # 30KB - Oct 7  (USED in page_old.tsx)
├── OptimizedDashboard.tsx          # 15KB - Sep 18 (USED in page_old2.tsx)
├── ViewportOptimizedDashboard.tsx  # 9KB  - Sep 18 (USED in page_old3/4.tsx)
├── RealDataDashboard.tsx           # 27KB - Oct 9  (CURRENT?)
└── RealTimeDashboard.tsx           # 14KB - Oct 13 (CURRENT?)
```

**Analysis:**
- Multiple dashboard iterations preserved across development
- Old dashboards only referenced in `page_old*.tsx` files
- Current pages use `UnifiedSupplierDashboard` and `RealTimeDashboard`

**Recommendation:**
- **ARCHIVE** old dashboard iterations (`SupplierDashboard.tsx`, `EnhancedSupplierDashboard.tsx`, `OptimizedDashboard.tsx`, `ViewportOptimizedDashboard.tsx`)
- **KEEP** active dashboards: `RealDataDashboard.tsx`, `RealTimeDashboard.tsx`
- **VERIFY** if `InventoryDashboard.tsx` is still in use

---

### 1.4 Pages Directory (Legacy)
**Status:** 🚨 MIGRATION IN PROGRESS

```bash
# Root pages directory (Next.js Pages Router - DEPRECATED)
pages/_document.tsx              # Oct 3 - Legacy custom document

# src/pages directory (Duplicate structure)
src/pages/_app.tsx               # Sep 26
src/pages/_document.tsx          # Sep 26
src/pages/_error.tsx             # Sep 26
```

**Analysis:**
- Project is using **App Router** (`src/app/` structure)
- `pages/` directory exists but is NOT referenced in `next.config.ts`
- Duplication between `pages/` and `src/pages/`
- App Router files take precedence

**Recommendation:**
- **ARCHIVE** entire `pages/` and `src/pages/` directories
- These are legacy from Pages Router migration
- No active routes use these files
- Keep in archive for 30 days, then delete

---

## 2. EDITOR & TOOLING CONFIG REVIEW

### 2.1 ESLint Configuration
**Status:** ⚠️ DUPLICATE CONFIGS

#### Files Detected:
```bash
.eslintrc.json              # 914 bytes  - Oct 13 (NEWER)
.eslintrc.enhanced.json     # 1,197 bytes - Oct 10 (OLDER)
```

#### Comparison:

**`.eslintrc.json`** (Current - Recommended):
- Extends: `next/core-web-vitals`, `@typescript-eslint`, `react`, `react-hooks`, `jsx-a11y`
- Comprehensive plugin set
- Accessibility rules included
- React 19 compatible

**`.eslintrc.enhanced.json`** (Enhanced):
- Extends: `next/core-web-vitals` only
- Additional rules: JSX leaked render, no-console, stricter TypeScript
- Test file overrides
- More opinionated

**Recommendation:**
- **CONSOLIDATE** - `.eslintrc.json` is the active config
- **ARCHIVE** `.eslintrc.enhanced.json` with note: "Enhanced ruleset - consider merging stricter rules"
- **ACTION:** Consider adding these rules from enhanced to main config:
  ```json
  "react/jsx-no-leaked-render": ["error", { "validStrategies": ["ternary"] }],
  "no-console": ["warn", { "allow": ["warn", "error"] }],
  "no-var": "error"
  ```

---

### 2.2 Prettier Configuration
**Status:** ✅ ACTIVE & CLEAN

```bash
.prettierrc         # 331 bytes - Oct 13
.prettierignore     # 384 bytes - Oct 13
```

**Analysis:**
- Standard Prettier config with Tailwind CSS plugin
- Properly ignoring build artifacts and node_modules
- Excludes .md files from formatting (preserves documentation)

**Recommendation:** **KEEP AS-IS** - No issues detected.

---

### 2.3 Windsurf AI Config
**Status:** 🚨 LEGACY - ARCHIVE RECOMMENDED

```bash
.windsurfrules      # 20KB - Sep 23, 2025
```

**Analysis:**
- **Last Modified:** September 23, 2025 (2 months old)
- **Size:** 20KB of AI agent rules
- **Content:** Windsurf AI extension design rules (flowbite, neo-brutalism styles, etc.)
- **Current Usage:** No active usage detected (no `.windsurfcache` or recent activity)
- **Alternative:** Project now uses Claude Agent SDK (`.claude/` directory)

**Recommendation:**
- **ARCHIVE** to `.archive/.windsurfrules`
- **REASON:** Superseded by Claude Agent SDK
- **NOTE:** Keep for 60 days in case team wants to restore

---

### 2.4 DevContainer Configuration
**Status:** ✅ ACTIVE - KEEP

```bash
.devcontainer/devcontainer.json     # Oct 3
```

**Analysis:**
- Docker-based development environment
- References `docker-compose.dev.yml`
- VSCode extensions: ESLint, Prettier, Docker
- Node user with npm install post-create command

**Recommendation:** **KEEP** - Active team workflow dependency.

---

### 2.5 Cursor Editor Config
**Status:** ✅ NOT DETECTED

No `.cursor/` directory found in project root.

**Recommendation:** N/A - Not in use.

---

## 3. BUILD ARTIFACT CLEANUP

### 3.1 Next.js Build Cache (`.next/`)
**Status:** ✅ PROPERLY IGNORED

```bash
.next/
├── app-build-manifest.json
├── build-manifest.json
└── [build cache]
```

**Gitignore Status:** ✅ Properly excluded (line 14: `.next/`)

**Recommendation:** **KEEP** - Essential for development. Already in .gitignore.

---

### 3.2 Test Artifacts
**Status:** ⚠️ PARTIALLY IGNORED (2.5MB on disk)

#### Directories:
```bash
playwright-report/      # 1.4MB - HTML reports
test-results/           # 1.1MB - JSON results
validation-reports/     # 12KB  - Validation outputs
```

#### Files Detected:
```bash
playwright-report/index.html
test-results/.last-run.json
test-results/performance-report.json
test-results/performance-results.json
```

**Gitignore Status:**
- ✅ `playwright-report/` (line 9)
- ✅ `test-results/` (line 8)
- ❌ `validation-reports/` NOT in .gitignore

**Recommendation:**
1. **ADD** to `.gitignore`:
   ```
   validation-reports/
   ```
2. **KEEP** recent test results locally (last 7 days for debugging)
3. **DELETE** reports older than 30 days
4. **CI/CD:** Ensure test reports are archived in CI pipeline, not in repo

---

### 3.3 Monitoring & Infrastructure Artifacts
**Status:** 🚨 NOT IN GITIGNORE (61KB on disk)

```bash
monitoring/         # 21KB - System monitoring configs/logs
nginx/              # 28KB - Nginx configuration
```

**Gitignore Status:**
- ✅ `monitoring/` (line 205)
- ✅ `nginx/` (line 211)

**Analysis:**
- These directories exist on disk but are properly gitignored
- Likely deployment artifacts or local development configs

**Recommendation:**
- **VERIFY** if needed locally
- If not used in dev: **DELETE** locally (already gitignored)
- If used: **DOCUMENT** purpose in README

---

## 4. GITIGNORE RECOMMENDATIONS

### 4.1 Current Status
**File:** `.gitignore` (257 lines)
**Status:** ✅ COMPREHENSIVE but needs additions

### 4.2 Recommended Additions

```bash
# Add to .gitignore:

# Validation & Reports (not currently ignored)
validation-reports/

# Editor backup files (pattern matching)
*.backup
*.old
*.corrupt
*_old*
*_broken*
*_fixed*

# Archive directory (if created)
archive/

# Test artifacts (additional patterns)
.playwright/
*.spec.ts.snap
test-results.json
```

### 4.3 Verification Needed

**Currently Ignored Patterns:**
- `*_REPORT.md` - ✅ Good (excludes agent reports)
- `*_SUMMARY.md` - ✅ Good
- `AI_*.md` - ✅ Good
- `AGENT_*.md` - ✅ Good

**Concern:** These patterns might exclude legitimate documentation.

**Recommendation:**
- Move AI-generated reports to `docs/reports/` instead of root
- Update patterns to exclude only `docs/reports/*` instead of root-level wildcards
- This allows team to keep important summary docs in root if needed

---

## 5. DUPLICATE FILE CONSOLIDATION

### 5.1 ESLint Configs
```
KEEP: .eslintrc.json (primary config)
ARCHIVE: .eslintrc.enhanced.json → .archive/.eslintrc.enhanced.json
```

### 5.2 Pages Router Files
```
ARCHIVE:
- pages/ → archive/legacy/pages-router/pages/
- src/pages/ → archive/legacy/pages-router/src-pages/
```

### 5.3 App Page Iterations
```
ARCHIVE:
- src/app/page_old.tsx → archive/frontend/page-iterations/
- src/app/page_old2.tsx → archive/frontend/page-iterations/
- src/app/page_old3.tsx → archive/frontend/page-iterations/
- src/app/page_old4.tsx → archive/frontend/page-iterations/
- src/app/page_original.tsx → archive/frontend/page-iterations/
- src/app/page_broken.tsx → archive/frontend/page-iterations/
```

### 5.4 Auth Page Backups
```
ARCHIVE:
- src/app/auth/verify-email/page.tsx.backup → archive/frontend/auth/
- src/app/auth/verify-email/page_fixed.tsx → archive/frontend/auth/

DELETE:
- src/app/auth/verify-email/page.tsx.corrupt (corrupted, no value)
```

### 5.5 API Route Backups
```
ARCHIVE:
- src/app/api/alerts/route.ts.backup → archive/api/alerts/
- src/app/api/analytics/**/*.backup-* → archive/api/analytics/
- src/app/api/ai/suppliers/discover/route.v5.example.ts → archive/api/examples/
```

### 5.6 Dashboard Components
```
ARCHIVE (if not referenced in active code):
- src/components/dashboard/SupplierDashboard.tsx
- src/components/dashboard/EnhancedSupplierDashboard.tsx
- src/components/dashboard/OptimizedDashboard.tsx
- src/components/dashboard/ViewportOptimizedDashboard.tsx

KEEP (verify usage first):
- src/components/dashboard/RealDataDashboard.tsx
- src/components/dashboard/RealTimeDashboard.tsx
- src/components/dashboard/InventoryDashboard.tsx
```

---

## 6. FRONTEND ASSET INVENTORY

### 6.1 KEEP (Active & Essential)

**Public Assets:**
- ✅ `public/favicon.ico`
- ✅ `public/favicon.svg`

**Active Configs:**
- ✅ `.eslintrc.json` (primary ESLint config)
- ✅ `.prettierrc` (code formatting)
- ✅ `.prettierignore` (formatting exclusions)
- ✅ `.devcontainer/devcontainer.json` (team workflow)

**Build Artifacts (local only):**
- ✅ `.next/` (build cache - gitignored)
- ✅ `node_modules/` (dependencies - gitignored)

**Active App Structure:**
- ✅ `src/app/` (164 files - minus backups)
- ✅ `src/components/` (136 files - minus archived dashboards)

---

### 6.2 ARCHIVE (Historical Value)

**Legacy Configs:**
- 📦 `.eslintrc.enhanced.json` → `.archive/.eslintrc.enhanced.json`
- 📦 `.windsurfrules` → `.archive/.windsurfrules`

**Legacy Router Files:**
- 📦 `pages/` → `archive/legacy/pages-router/`
- 📦 `src/pages/` → `archive/legacy/pages-router/`

**Backup Page Iterations:**
- 📦 `src/app/page_old*.tsx` → `archive/frontend/page-iterations/`
- 📦 `src/app/page_original.tsx` → `archive/frontend/page-iterations/`
- 📦 `src/app/suppliers/page_backup.tsx` → `archive/frontend/suppliers/`
- 📦 `src/app/auth/verify-email/*.backup` → `archive/frontend/auth/`
- 📦 `src/app/auth/verify-email/*_fixed.tsx` → `archive/frontend/auth/`

**API Route Backups:**
- 📦 `src/app/api/**/*.backup` → `archive/api/`
- 📦 `src/app/api/**/*.backup-*` → `archive/api/`
- 📦 `src/app/api/**/*.example.ts` → `archive/api/examples/`

**Dashboard Components:**
- 📦 Old dashboard iterations → `archive/components/dashboards/`

---

### 6.3 DELETE (No Value)

**Corrupted Files:**
- ❌ `src/app/auth/verify-email/page.tsx.corrupt`
- ❌ `src/app/page_broken.tsx` (if truly broken and not historical)

**Test Artifacts (>30 days old):**
- ❌ Old test reports in `playwright-report/`
- ❌ Old test results in `test-results/`
- ❌ Old validation reports in `validation-reports/`

**Temporary Artifacts (if present):**
- ❌ `monitoring/` directory (if not used locally)
- ❌ `nginx/` directory (if not used locally)

---

### 6.4 REVIEW (Team Decision Required)

**Devcontainer:**
- ⚠️ `.devcontainer/` - **KEEP if team uses Docker**, else ARCHIVE

**Test Reports:**
- ⚠️ Recent test artifacts - **KEEP last 7 days** for debugging

**Component Analysis:**
- ⚠️ Full component usage analysis deferred (time-limited)
- ⚠️ Recommend running unused import analysis tool in Phase 2

---

## 7. RECOMMENDED ACTIONS

### Phase 1: Immediate Cleanup (ANALYSIS COMPLETE)
✅ This inventory document created

### Phase 2: Safe Archival (Recommended Next)
1. Create archive structure:
   ```bash
   mkdir -p archive/frontend/{page-iterations,auth,suppliers}
   mkdir -p archive/legacy/pages-router/{pages,src-pages}
   mkdir -p archive/api/{alerts,analytics,examples}
   mkdir -p archive/components/dashboards
   mkdir -p archive/configs
   ```

2. Move backup files:
   ```bash
   # App page iterations
   mv src/app/page_old*.tsx archive/frontend/page-iterations/
   mv src/app/page_original.tsx archive/frontend/page-iterations/

   # Supplier backups
   mv src/app/suppliers/page_backup.tsx archive/frontend/suppliers/

   # Auth backups
   mv src/app/auth/verify-email/*.backup archive/frontend/auth/
   mv src/app/auth/verify-email/*_fixed.tsx archive/frontend/auth/

   # API backups
   mv src/app/api/**/*.backup archive/api/
   mv src/app/api/**/*.backup-* archive/api/

   # Legacy Pages Router
   mv pages/ archive/legacy/pages-router/
   mv src/pages/ archive/legacy/pages-router/

   # Configs
   mv .eslintrc.enhanced.json archive/configs/
   mv .windsurfrules archive/configs/
   ```

3. Delete corrupted files:
   ```bash
   rm src/app/auth/verify-email/page.tsx.corrupt
   ```

### Phase 3: Gitignore Updates
Add to `.gitignore`:
```bash
# Archive directory
archive/

# Validation reports
validation-reports/

# Backup file patterns
*.backup
*.corrupt
*_old*
*_broken*

# Additional test patterns
.playwright/
*.spec.ts.snap
```

### Phase 4: Configuration Consolidation
1. Review `.eslintrc.enhanced.json` rules
2. Merge valuable rules into `.eslintrc.json`
3. Test linting across project
4. Document rationale in `docs/decisions/eslint-config.md`

### Phase 5: Component Analysis (Future)
1. Run `npx depcheck` to find unused dependencies
2. Run `npx ts-unused-exports` to find unused exports
3. Analyze dashboard component usage in detail
4. Create component inventory and usage map

---

## 8. METRICS & IMPACT

### Cleanup Impact Summary

**Files to Archive:** ~20 files
**Files to Delete:** ~5 files
**Configs to Consolidate:** 2 files
**Estimated Disk Space Recovery:** ~100KB (minimal - mostly small files)
**Cognitive Load Reduction:** HIGH (removes confusion from 9 backup/old files)
**Maintenance Improvement:** MEDIUM (cleaner structure, less visual noise)

### Before Cleanup:
- Duplicate ESLint configs causing confusion
- 9 backup/old/broken app files in active src/
- Legacy Pages Router files mixed with App Router
- 20KB legacy AI config file
- Test artifacts not fully gitignored

### After Cleanup:
- Single source of truth for ESLint config
- Clean app directory (only active files)
- Legacy code preserved in archive/
- Updated .gitignore for consistency
- Clear separation of active vs historical code

---

## 9. COORDINATION WITH OTHER AGENTS

### Dependencies:
- **Agent 1 (Root Cleanup):** Coordinate on root-level .md file patterns
- **Agent 2 (Docs):** Coordinate on documentation archival strategy
- **Agent 3 (Database):** No conflicts
- **Agent 4 (Scripts):** Check if any scripts reference archived files
- **Agent 5 (Backend):** No conflicts

### Handoff Notes:
- Archive structure created can be reused by other agents
- .gitignore updates should be consolidated across all agents
- Component analysis deferred to Phase 2 (time constraints)

---

## 10. CONCLUSION

### Summary
The frontend codebase is **generally well-maintained** with a few areas requiring cleanup:

**Strengths:**
- Minimal public assets (no bloat)
- Comprehensive .gitignore
- Active tooling configs (Prettier, ESLint)
- Clean component structure (aside from dashboard iterations)

**Weaknesses:**
- Backup/old files mixed with active code
- Duplicate ESLint configs
- Legacy Pages Router artifacts
- Test artifacts partially ignored
- 20KB legacy Windsurf config

### Risk Assessment
**Risk Level:** LOW
- No breaking changes required
- All cleanup is archival (reversible)
- No dependencies on archived files detected

### Next Steps
1. **Review** this inventory with team
2. **Approve** archival strategy
3. **Execute** Phase 2 cleanup actions
4. **Verify** no broken imports after cleanup
5. **Update** team documentation

---

**Generated by:** Agent 6 - Frontend Cleanup
**Date:** 2025-10-22
**Status:** ANALYSIS COMPLETE - AWAITING PHASE 2 APPROVAL
