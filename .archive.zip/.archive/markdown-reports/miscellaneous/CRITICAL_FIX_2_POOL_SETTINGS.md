# CRITICAL FIX #2: Connection Pool Settings for Neon

## Problem
Current pool settings exceed Neon's connection limits and waste compute resources.

## File to Modify
`.env.local`

## Current Configuration (Lines 15-19)
```env
# ❌ TOO HIGH FOR NEON SERVERLESS
DB_POOL_MIN=5
DB_POOL_MAX=20
DB_POOL_IDLE_TIMEOUT=60000
DB_POOL_CONNECTION_TIMEOUT=15000
DB_POOL_ACQUIRE_TIMEOUT=20000
```

## Why This is Critical
1. **Neon free tier**: Max 10 concurrent connections
2. **Your setting**: Max 20 connections → Will cause "too many connections" errors
3. **Cost impact**: 5 idle connections waste ~$10/month in compute time
4. **Performance**: Long timeouts (60s idle) don't match Neon's serverless model

## Recommended Configuration
```env
# ✅ OPTIMIZED FOR NEON SERVERLESS
DB_POOL_MIN=1           # Neon scales quickly, no need for idle connections
DB_POOL_MAX=8           # Safe limit under Neon's 10 connection max (buffer for other connections)
DB_POOL_IDLE_TIMEOUT=10000    # 10s - release connections quickly to save costs
DB_POOL_CONNECTION_TIMEOUT=5000   # 5s - Neon connects fast via pooler
DB_POOL_ACQUIRE_TIMEOUT=10000     # 10s - sufficient for Neon pooler
```

## Additional Recommended Settings
```env
# Circuit Breaker Configuration
CIRCUIT_BREAKER_THRESHOLD=10
CIRCUIT_BREAKER_RESET_MS=30000

# Query Logging
QUERY_LOG_ENABLED=true
LOG_SLOW_QUERIES=true
SLOW_QUERY_THRESHOLD_MS=1000
LOG_QUERY_TEXT=true
LOG_PARAMETERS=false        # Security: don't log params in production
```

## How to Apply
```bash
# 1. Open .env.local
code .env.local

# 2. Find lines 15-19 and replace with recommended configuration

# 3. Restart the development server
npm run dev:restart

# 4. Verify settings
node -e "
const dotenv = require('dotenv');
dotenv.config({ path: '.env.local' });
console.log('Pool Min:', process.env.DB_POOL_MIN);
console.log('Pool Max:', process.env.DB_POOL_MAX);
console.log('Idle Timeout:', process.env.DB_POOL_IDLE_TIMEOUT);
"
```

## Verification Test
```javascript
// Test that pool respects new settings
const { dbManager } = require('./lib/database/enterprise-connection-manager');

async function testPoolSettings() {
  const status = dbManager.getStatus();
  console.log('Pool Status:', {
    total: status.totalConnections,
    active: status.activeConnections,
    idle: status.idleConnections,
    maxConfigured: process.env.DB_POOL_MAX
  });

  if (status.totalConnections > 8) {
    console.error('❌ Pool exceeded Neon limit!');
  } else {
    console.log('✅ Pool within safe limits');
  }
}

testPoolSettings();
```

## Impact Analysis

### Before (Current Settings)
- **Max Connections**: 20 (exceeds Neon limit)
- **Min Connections**: 5 (wastes compute)
- **Idle Timeout**: 60s (wastes $10/month)
- **Risk**: HIGH - Will cause connection failures under load

### After (Recommended Settings)
- **Max Connections**: 8 (safe buffer under 10)
- **Min Connections**: 1 (scales on demand)
- **Idle Timeout**: 10s (releases quickly)
- **Savings**: ~70% cost reduction (~$7/month)
- **Risk**: NONE - Improves both cost and reliability

## Common Issues After Applying

### "Too many connections" errors gone?
✅ Expected: Should stop seeing these errors

### Response times slower?
❌ Should NOT happen: Neon connects in <100ms
✓ If you see delays: Check circuit breaker state

### Circuit breaker tripping?
🔍 Check status:
```bash
curl http://localhost:3000/api/health/database-connections
```

Expected output:
```json
{
  "pool": {
    "total": 2,
    "active": 1,
    "idle": 1,
    "utilization": "12.5%"
  },
  "circuitBreaker": {
    "state": "closed",
    "failures": 0
  }
}
```

## Rollback Plan
If issues occur:
```env
# Temporary fallback (not recommended long-term)
DB_POOL_MIN=2
DB_POOL_MAX=10
DB_POOL_IDLE_TIMEOUT=30000
```

## Next Steps
After applying this fix:
1. Monitor pool metrics for 1 hour
2. Check for "too many connections" errors (should be 0)
3. Verify cost reduction in Neon dashboard
4. Apply other critical fixes (SSL, security)
