# Inventory Alignment — Legacy Removal (Applied)

## Deletions
- Removed legacy endpoint: `src/app/api/inventory/items/route.ts`.

## Store
- `inventory-store.ts` enforces camelCase-only from `/api/inventory` (display format).
- Removed normalization fallbacks; added runtime assertions.

## De-risking
- Run UI smoke tests; any consumer expecting snake_case will fail fast with explicit error.

