# Quick Integration Guide
## Adding AI Features to MantisNXT Pages

**Time to Integrate**: ~15 minutes
**Difficulty**: Easy

---

## 🚀 Quick Start

### 1. Add AI Widget to Main Dashboard

**File**: `/src/app/page.tsx`

```typescript
// Add import at top
import AIInsightsWidget from '@/components/dashboard/AIInsightsWidget'

// In your dashboard grid (line ~50)
export default function DashboardPage() {
  return (
    <div className="container mx-auto p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Your existing dashboard cards */}

        {/* ADD THIS: AI Insights Widget */}
        <AIInsightsWidget
          maxInsights={5}
          refreshInterval={300000}
          className="lg:col-span-1"
        />
      </div>
    </div>
  )
}
```

**Result**: AI insights widget appears on main dashboard with auto-refresh

---

### 2. Add AI Chat to Supplier Detail Page

**File**: `/src/app/suppliers/[id]/page.tsx`

```typescript
// Add imports
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import AIChatInterfaceV5 from '@/components/ai/ChatInterfaceV5'

// In your supplier detail page
export default function SupplierDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="container mx-auto p-6">
      {/* Existing supplier info */}

      <Tabs defaultValue="overview" className="mt-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          {/* ADD THIS */}
          <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
        </TabsList>

        {/* Existing tabs */}

        {/* ADD THIS: AI Assistant Tab */}
        <TabsContent value="ai-assistant">
          <AIChatInterfaceV5
            compactMode={false}
            enableVoice={true}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
```

**Result**: AI chat available as a tab on supplier detail pages

---

### 3. Add Mobile AI Interface

**File**: `/src/components/layout/MobileNav.tsx` or `/src/app/layout.tsx`

```typescript
// Add imports
import { useState } from 'react'
import { Brain } from 'lucide-react'
import { Button } from '@/components/ui/button'
import MobileAIInterfaceV5 from '@/components/ai/MobileAIInterfaceV5'

export default function MobileNav() {
  const [showAI, setShowAI] = useState(false)

  return (
    <>
      {/* Your existing mobile navigation */}

      {/* ADD THIS: AI FAB Button */}
      <Button
        onClick={() => setShowAI(true)}
        className="fixed bottom-4 right-4 z-40 md:hidden w-14 h-14 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 shadow-lg"
        aria-label="Open AI Assistant"
      >
        <Brain className="h-6 w-6 text-white" />
      </Button>

      {/* ADD THIS: Mobile AI Interface */}
      {showAI && (
        <MobileAIInterfaceV5
          onClose={() => setShowAI(false)}
          startMinimized={false}
        />
      )}
    </>
  )
}
```

**Result**: Floating AI button on mobile devices

---

### 4. Add AI Insights to Inventory Page

**File**: `/src/app/inventory/page.tsx`

```typescript
// Add import
import AIInsightCards from '@/components/ai/InsightCards'

export default function InventoryPage() {
  return (
    <div className="container mx-auto p-6">
      {/* Existing inventory management */}

      {/* ADD THIS: AI Inventory Insights */}
      <div className="mt-6">
        <h2 className="text-2xl font-bold mb-4">AI Inventory Insights</h2>
        <AIInsightCards
          filterBy={{
            category: ['inventory'],
            type: ['opportunity', 'risk']
          }}
          maxCards={3}
          compactMode={true}
        />
      </div>
    </div>
  )
}
```

**Result**: AI-powered inventory insights and recommendations

---

## 🎯 Navigation Setup

### Add AI Dashboard to Navigation

**File**: `/src/components/layout/MainNav.tsx` or similar

```typescript
// Add to navigation items
const navItems = [
  { href: '/', label: 'Dashboard', icon: Home },
  { href: '/suppliers', label: 'Suppliers', icon: Building2 },
  { href: '/inventory', label: 'Inventory', icon: Package },
  // ADD THIS
  { href: '/ai-insights', label: 'AI Insights', icon: Brain },
  // ... other items
]
```

**Result**: AI Insights accessible from main navigation

---

## ⚙️ Configuration

### Environment Variables

Create or update `.env.local`:

```bash
# AI Configuration
AI_SDK_ANTHROPIC_API_KEY=sk-ant-your-key-here
AI_SDK_DEFAULT_MODEL=claude-3-5-sonnet-20241022

# API Endpoints
NEXT_PUBLIC_AI_API_ENDPOINT=/api/ai/chat
NEXT_PUBLIC_AI_INSIGHTS_ENDPOINT=/api/ai/insights/generate
```

---

## 🎨 Styling Customization

### Change AI Widget Theme

```typescript
<AIInsightsWidget
  maxInsights={5}
  className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20"
/>
```

### Customize Chat Interface Colors

```typescript
<AIChatInterfaceV5
  compactMode={false}
  // The component uses Tailwind classes, customize via:
  // - Global CSS overrides
  // - Tailwind theme configuration
  // - Component className props
/>
```

---

## 🧪 Testing Integration

### Test AI Widget

```bash
# 1. Start dev server
npm run dev

# 2. Navigate to dashboard
http://localhost:3000

# 3. Verify AI widget appears and loads insights
# 4. Click "View All Insights" to test navigation
# 5. Click "Refresh" to test data loading
```

### Test Chat Interface

```bash
# 1. Navigate to /ai-insights
http://localhost:3000/ai-insights

# 2. Click "Chat" tab
# 3. Type a message and send
# 4. Verify streaming response appears
# 5. Test quick prompts
```

### Test Mobile Interface

```bash
# 1. Open Chrome DevTools
# 2. Toggle device toolbar (Cmd+Shift+M)
# 3. Select iPhone/Android device
# 4. Look for AI FAB button (bottom right)
# 5. Click to open mobile interface
# 6. Test drag-to-minimize gesture
```

---

## 🔧 Troubleshooting

### Widget Not Loading

**Issue**: AI widget shows "Loading..." forever

**Solution**:
```typescript
// Check API endpoint in browser console
// Verify /api/ai/insights/generate is accessible
// Check .env.local has correct API keys
```

### Chat Not Streaming

**Issue**: Messages don't appear in real-time

**Solution**:
```typescript
// Verify Vercel AI SDK is installed
npm list ai

// Should show: ai@5.0.0 or higher
// If not: npm install ai@^5.0.0
```

### Mobile Interface Not Showing

**Issue**: FAB button not visible on mobile

**Solution**:
```typescript
// Check z-index conflicts
// Verify component is rendered only on mobile:
className="md:hidden"

// Check if parent has overflow:hidden
```

---

## 📊 Performance Optimization

### Lazy Loading

```typescript
// Lazy load AI components for better performance
import dynamic from 'next/dynamic'

const AIInsightsWidget = dynamic(
  () => import('@/components/dashboard/AIInsightsWidget'),
  { loading: () => <div>Loading AI...</div> }
)

const AIChatInterfaceV5 = dynamic(
  () => import('@/components/ai/ChatInterfaceV5'),
  { ssr: false }
)
```

### Disable Auto-Refresh

```typescript
// For pages where real-time updates aren't needed
<AIInsightsWidget
  maxInsights={5}
  refreshInterval={0} // Disable auto-refresh
/>
```

---

## 🎓 Advanced Usage

### Custom Insights Filtering

```typescript
<AIInsightCards
  filterBy={{
    type: ['opportunity', 'risk'],
    priority: ['critical', 'high'],
    category: ['supplier']
  }}
  onInsightAction={(insightId, action) => {
    console.log('Custom action:', insightId, action)
    // Handle custom actions
  }}
/>
```

### Custom Chat Actions

```typescript
<AIChatInterfaceV5
  onActionTrigger={(action) => {
    if (action.action === 'open_supplier_report') {
      router.push(`/suppliers/${action.data.supplierId}`)
    }
  }}
/>
```

### Programmatic Chat Messages

```typescript
// Using the underlying useChat hook
import { useChat } from 'ai/react'

function CustomChat() {
  const { messages, append } = useChat({
    api: '/api/ai/chat'
  })

  const askQuestion = (question: string) => {
    append({
      role: 'user',
      content: question
    })
  }

  return (
    <Button onClick={() => askQuestion('Analyze suppliers')}>
      Quick Analysis
    </Button>
  )
}
```

---

## ✅ Integration Checklist

### Phase 1: Essential Integration
- [ ] Add AI widget to main dashboard
- [ ] Add AI Insights to navigation
- [ ] Configure environment variables
- [ ] Test basic functionality

### Phase 2: Enhanced Integration
- [ ] Add AI chat to supplier pages
- [ ] Add mobile AI interface
- [ ] Add AI insights to inventory
- [ ] Add AI insights to analytics pages

### Phase 3: Optimization
- [ ] Implement lazy loading
- [ ] Configure auto-refresh intervals
- [ ] Add custom action handlers
- [ ] Set up analytics tracking

---

## 🚀 Go Live

### Pre-Deployment Checklist

1. **Build Test**
   ```bash
   npm run build
   # Verify no errors
   ```

2. **Type Check**
   ```bash
   npm run type-check
   # Verify no type errors
   ```

3. **Environment Variables**
   ```bash
   # Verify all AI_* variables are set in production
   ```

4. **Test Production Build**
   ```bash
   npm run start
   # Test all AI features work
   ```

5. **Deploy**
   ```bash
   git add .
   git commit -m "feat: integrate Vercel AI SDK v5"
   git push origin main
   ```

---

## 📚 Additional Resources

- **Full Documentation**: `/AI_UI_INTEGRATION_REPORT.md`
- **Delivery Summary**: `/AI_DELIVERY_SUMMARY.md`
- **Component Docs**: Inline JSDoc comments
- **Vercel AI SDK**: https://sdk.vercel.ai/docs

---

## 🎉 You're Done!

Your MantisNXT application now has:
- ✅ AI chat interface
- ✅ AI insights dashboard
- ✅ Dashboard widget
- ✅ Mobile AI interface
- ✅ Supplier intelligence
- ✅ Inventory insights

**Estimated Setup Time**: 15 minutes
**Difficulty**: Easy
**Result**: Production-ready AI features

---

**Need Help?**
- Check `/AI_UI_INTEGRATION_REPORT.md` for detailed documentation
- Review component source code for inline documentation
- Refer to Vercel AI SDK documentation for advanced features

🧠 *Data flows eternal* - Data Oracle
