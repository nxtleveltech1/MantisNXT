# NEON DATABASE - QUICK FIX GUIDE
**Execute these steps in order. Total time: 30-60 minutes**

---

## STEP 1: Update Pool Settings (5 minutes)

### Edit `.env.local`
```bash
code .env.local
```

### Find lines 15-19 and replace with:
```env
# ✅ OPTIMIZED FOR NEON SERVERLESS
DB_POOL_MIN=1
DB_POOL_MAX=8
DB_POOL_IDLE_TIMEOUT=10000
DB_POOL_CONNECTION_TIMEOUT=5000
DB_POOL_ACQUIRE_TIMEOUT=10000

# Circuit Breaker (add these new lines)
CIRCUIT_BREAKER_THRESHOLD=10
CIRCUIT_BREAKER_RESET_MS=30000
```

### Save and verify:
```bash
node -e "
const dotenv = require('dotenv');
dotenv.config({ path: '.env.local' });
console.log('✓ Pool Max:', process.env.DB_POOL_MAX);
console.log('✓ Pool Min:', process.env.DB_POOL_MIN);
console.log('✓ Idle Timeout:', process.env.DB_POOL_IDLE_TIMEOUT);
"
```

Expected output:
```
✓ Pool Max: 8
✓ Pool Min: 1
✓ Idle Timeout: 10000
```

---

## STEP 2: Fix Security Vulnerability (10 minutes)

### Edit `src/app/api/health/database/route.ts`

#### Find line 129-132 (inside success response):
**Remove:**
```typescript
host: process.env.DB_HOST || '62.169.20.53',
port: process.env.DB_PORT || '6600',
database: process.env.DB_NAME || 'nxtprod-db_001'
```

**Replace with:**
```typescript
provider: 'neon',
region: 'azure-gwc',
status: 'connected'
```

#### Find line 158-161 (inside error response):
**Remove the same 3 lines, replace with:**
```typescript
provider: 'neon',
region: 'azure-gwc',
status: 'disconnected'
```

### Save the file

---

## STEP 3: Deploy Database Schema (15-30 minutes)

### Option A: If you have a combined schema file
```bash
# Find your schema file
ls database/migrations/*.sql

# Apply to Neon (replace filename with your actual file)
psql "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require" \
  -f database/migrations/YOUR_SCHEMA_FILE.sql
```

### Option B: If you have migration files in a migrations directory
```bash
# Apply all migrations in order
for file in database/migrations/*.sql; do
  echo "Applying $file..."
  psql "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require" -f "$file"
done
```

### Option C: If you have a backup from the old database
```bash
# Create a dump from old database (if still accessible)
pg_dump "postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001" \
  --schema-only > schema_backup.sql

# Apply to Neon
psql "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require" \
  -f schema_backup.sql
```

### Verify tables created:
```bash
psql "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require" \
  -c "SELECT COUNT(*) as table_count FROM information_schema.tables WHERE table_schema = 'public'"
```

**Expected**: table_count should be 50+ (not 0)

---

## STEP 4: Restart Application (2 minutes)

```bash
# Stop current server
npm run dev:stop

# Start fresh
npm run dev

# Wait for startup (about 10 seconds)
```

---

## STEP 5: Test API Endpoints (5 minutes)

### Test 1: Database Health
```bash
curl http://localhost:3000/api/health/database | jq
```

**Expected**:
```json
{
  "success": true,
  "database": {
    "status": "connected",
    "healthScore": 100,
    "connection": {
      "provider": "neon",  // ✅ No host/port exposed
      "status": "connected"
    }
  }
}
```

### Test 2: Suppliers API
```bash
curl http://localhost:3000/api/suppliers | jq
```

**Expected**: Array of suppliers (not 500 error)

### Test 3: Inventory API
```bash
curl http://localhost:3000/api/inventory | jq
```

**Expected**: Array of inventory items (not 500 error)

---

## STEP 6: Monitor Connection Pool (5 minutes)

### Check pool status in logs
```bash
# Watch the console output for these messages:
# ✅ "Client acquired for query ..."
# ✅ "Query completed in ...ms"
# ✅ "Circuit breaker state: closed"
```

### Manual pool check (optional)
```bash
node -e "
const { dbManager } = require('./lib/database/enterprise-connection-manager');
const status = dbManager.getStatus();
console.log('Pool Status:', {
  total: status.totalConnections,
  active: status.activeConnections,
  idle: status.idleConnections,
  utilization: ((status.activeConnections / 8) * 100).toFixed(1) + '%'
});
console.log('Circuit Breaker:', status.state);
"
```

**Expected**:
```
Pool Status: {
  total: 2,
  active: 1,
  idle: 1,
  utilization: '12.5%'
}
Circuit Breaker: closed
```

---

## TROUBLESHOOTING

### Problem: "Too many connections" error
**Solution**: Reduce DB_POOL_MAX to 5
```env
DB_POOL_MAX=5
```

### Problem: Tables still showing 0
**Cause**: Schema deployment failed
**Solution**: Check psql output for errors, fix syntax issues, retry

### Problem: API still returning 500 errors
**Checks**:
```bash
# 1. Verify tables exist
psql "..." -c "\dt"

# 2. Check for specific missing table
psql "..." -c "SELECT COUNT(*) FROM suppliers"

# 3. Review application logs
npm run dev  # Watch for errors
```

### Problem: Circuit breaker opened
**Solution**: Wait 30 seconds for auto-recovery, or restart app
```bash
npm run dev:restart
```

### Problem: Slow queries (>1000ms)
**Check**:
```bash
# Look for "SLOW QUERY" warnings in logs
# Check Neon dashboard for compute metrics
# Consider increasing Neon compute units
```

---

## VERIFICATION CHECKLIST

After completing all steps, verify:

- [ ] Pool max is 8 (not 20)
- [ ] Pool min is 1 (not 5)
- [ ] Tables exist in database (50+ tables)
- [ ] API health endpoint returns 200
- [ ] Suppliers API returns data
- [ ] Inventory API returns data
- [ ] No credentials in API responses
- [ ] Circuit breaker state is "closed"
- [ ] Pool utilization < 80%
- [ ] No "too many connections" errors in logs

---

## SUCCESS INDICATORS

You'll know everything is working when:

1. **Console shows**:
   ```
   ✅ Client acquired for query ... in 50ms
   ✅ Query completed in 150ms, rows: 25
   🔌 [Circuit Breaker] state: closed
   ```

2. **API responses are fast**:
   ```bash
   time curl http://localhost:3000/api/suppliers
   # Should complete in < 500ms
   ```

3. **No errors in logs**:
   - No "too many connections"
   - No "circuit breaker is open"
   - No "timeout" errors

---

## ROLLBACK PLAN

If something goes wrong, revert changes:

### Rollback Pool Settings
```env
# Temporary fallback (not optimal long-term)
DB_POOL_MIN=2
DB_POOL_MAX=10
DB_POOL_IDLE_TIMEOUT=30000
```

### Rollback API Changes
```bash
git checkout src/app/api/health/database/route.ts
```

### Contact for Help
- Check: `NEON_DATABASE_INFRASTRUCTURE_REVIEW.md` for detailed analysis
- Review: Neon dashboard logs
- Escalate: Post in #database-support channel

---

## NEXT STEPS (After Quick Fix)

1. **Monitor for 1 hour**
   - Watch logs for errors
   - Check Neon dashboard for metrics
   - Verify cost reduction

2. **Apply remaining optimizations** (from NEON_DATABASE_INFRASTRUCTURE_REVIEW.md)
   - Reduce retry attempts to 1
   - Add connection pool monitoring endpoint
   - Implement prepared statement caching

3. **Load testing**
   ```bash
   ab -n 1000 -c 50 http://localhost:3000/api/suppliers
   ```

4. **Set up monitoring**
   - Configure Neon dashboard alerts
   - Add circuit breaker state to monitoring
   - Track query performance metrics

---

**Total Time**: 30-60 minutes
**Risk Level**: LOW (configuration changes only)
**Rollback Time**: < 5 minutes if needed

**Good luck! 🚀**
