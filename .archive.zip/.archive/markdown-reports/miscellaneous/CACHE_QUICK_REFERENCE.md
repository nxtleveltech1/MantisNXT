# Cache Invalidation - Quick Reference Guide

## Quick Start

### 1. Import the Invalidator
```typescript
import { CacheInvalidator } from '@/lib/cache/invalidation'
```

### 2. Add After Successful Mutation
```typescript
// After successful database write
await pool.query('DELETE FROM suppliers WHERE id = $1', [id])

// Invalidate cache
CacheInvalidator.invalidateSupplier(id, supplierName)
```

## Common Patterns

### Pattern 1: DELETE Endpoint
```typescript
export async function DELETE(request: NextRequest, { params }) {
  try {
    const { id } = params

    // Get entity before deletion (for cache invalidation)
    const entity = await getById(id)

    // Perform deletion
    await deleteFromDB(id)

    // Invalidate cache AFTER successful deletion
    CacheInvalidator.invalidateSupplier(id, entity.name)

    return NextResponse.json({ success: true })
  } catch (error) {
    // Cache NOT invalidated if deletion fails
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### Pattern 2: POST Endpoint
```typescript
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Create new entity
    const result = await insertIntoDB(body)
    const newEntity = result.rows[0]

    // Invalidate cache AFTER successful creation
    CacheInvalidator.invalidateSupplier(newEntity.id, newEntity.name)

    return NextResponse.json({ success: true, data: newEntity })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### Pattern 3: PUT/PATCH Endpoint
```typescript
export async function PUT(request: NextRequest, { params }) {
  try {
    const { id } = params
    const body = await request.json()

    // Update entity
    const result = await updateInDB(id, body)
    const updatedEntity = result.rows[0]

    // Invalidate cache AFTER successful update
    CacheInvalidator.invalidateSupplier(id, updatedEntity.name)

    return NextResponse.json({ success: true, data: updatedEntity })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### Pattern 4: Batch Operations
```typescript
export async function DELETE(request: NextRequest) {
  try {
    const { ids } = await request.json()

    // Batch delete
    await batchDeleteFromDB(ids)

    // Invalidate cache for all (wildcard)
    CacheInvalidator.invalidateInventory() // No ID = invalidate all

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

## Method Reference

### Supplier Operations
```typescript
// Basic invalidation
CacheInvalidator.invalidateSupplier(id: string, name?: string)

// Example
CacheInvalidator.invalidateSupplier('SUP-123', 'Acme Corp')
```

**What it invalidates:**
- `/api/suppliers` (list)
- `/api/suppliers/[id]` (detail)
- `/api/suppliers/v3/*` (all v3 endpoints)
- `/api/suppliers/discovery` (search/AI)
- `/suppliers/*` (frontend pages)

---

### Product Operations
```typescript
// Basic invalidation
CacheInvalidator.invalidateProduct(id: string, supplierId?: string)

// Example
CacheInvalidator.invalidateProduct('PROD-456', 'SUP-123')
```

**What it invalidates:**
- Product cache + cascades to supplier if supplierId provided

---

### Inventory Operations
```typescript
// Single item invalidation
CacheInvalidator.invalidateInventory(itemId: string, supplierId?: string)

// Bulk/all invalidation
CacheInvalidator.invalidateInventory()

// Examples
CacheInvalidator.invalidateInventory('INV-789', 'SUP-123') // Single with cascade
CacheInvalidator.invalidateInventory() // All inventory
```

**What it invalidates:**
- All `/api/inventory/*` endpoints
- `/inventory/*` frontend pages
- Cascades to supplier if provided

---

### Purchase Order Operations
```typescript
// Invalidation with cascade
CacheInvalidator.invalidatePurchaseOrder(poId: string, supplierId?: string)

// Example
CacheInvalidator.invalidatePurchaseOrder('PO-001', 'SUP-123')
```

**What it invalidates:**
- All `/api/purchase-orders/*` endpoints
- Cascades to supplier if provided

---

### Stock Movement Operations
```typescript
// Invalidation (automatically cascades to inventory)
CacheInvalidator.invalidateStockMovements(inventoryItemId?: string)

// Example
CacheInvalidator.invalidateStockMovements('INV-789')
```

**What it invalidates:**
- Stock movements cache
- Related inventory item cache

---

### Warehouse Operations
```typescript
// Single warehouse invalidation
CacheInvalidator.invalidateWarehouse(warehouseId: string)

// All warehouses
CacheInvalidator.invalidateWarehouse()

// Example
CacheInvalidator.invalidateWarehouse('WH-001')
```

**What it invalidates:**
- All `/api/warehouses/*` endpoints
- Related inventory cache

---

### Analytics Operations
```typescript
// Invalidate all analytics and dashboard cache
CacheInvalidator.invalidateAnalytics()
```

**When to use:**
- After any major data change that affects dashboard
- Usually called automatically via cascade

---

### Nuclear Option
```typescript
// Invalidate EVERYTHING (use sparingly!)
CacheInvalidator.invalidateAll()
```

**When to use:**
- System-wide data migrations
- Major schema changes
- Emergency cache clear

---

## Smart Cascade
```typescript
// Automatic cascade based on relationships
CacheInvalidator.cascadeInvalidation({
  type: 'supplier' | 'product' | 'inventory' | 'po' | 'warehouse',
  id: string,
  includedRelations: {
    supplierId?: string,
    inventoryItemId?: string,
    warehouseId?: string
  },
  invalidateAnalytics: boolean  // default: true
})

// Example
CacheInvalidator.cascadeInvalidation({
  type: 'supplier',
  id: 'SUP-123',
  invalidateAnalytics: true
})
```

## Helper Function (Shorthand)
```typescript
import { invalidateCache } from '@/lib/cache/invalidation'

// Quick one-liner
invalidateCache('supplier', 'SUP-123')
invalidateCache('inventory', 'INV-789', { supplierId: 'SUP-123' })
invalidateCache('all') // Nuclear option
```

## Console Log Indicators

Watch your server console for these:
```
🔄 Cache invalidated for supplier: SUP-123
🔄 Cache invalidated for product: PROD-456
🔄 Cache invalidated for inventory INV-789
🔄 Cache invalidated for inventory (all)
🔄 Cache invalidated for PO: PO-001
🔄 Cache invalidated for stock movements
🔄 Cache invalidated for warehouse WH-001
🔄 Cache invalidated for analytics
🗑️ Deleted 3 cache entries for pattern: supplier_acme
💥 ALL cache invalidated
```

## Troubleshooting

### Problem: Cache not invalidating
**Check:**
1. Import statement is correct
2. Invalidation is called AFTER successful database write (inside try block)
3. Invalidation is NOT called if error occurs
4. Check server console for invalidation logs

### Problem: Partial invalidation
**Solution:**
- Use wildcard methods (no ID parameter) for bulk operations
- Ensure cascading is enabled (default behavior)

### Problem: Too many invalidations
**Solution:**
- Use targeted invalidation (specific IDs)
- Skip analytics invalidation for minor changes:
  ```typescript
  CacheInvalidator.cascadeInvalidation({
    type: 'inventory',
    id: 'INV-123',
    invalidateAnalytics: false  // Skip analytics
  })
  ```

## Best Practices

### ✅ DO
- Call invalidation AFTER successful database write
- Use specific entity IDs when available
- Include related entity IDs for cascading (supplierId, etc.)
- Check console logs during development

### ❌ DON'T
- Don't call invalidation BEFORE database write
- Don't call invalidation in catch blocks
- Don't use `invalidateAll()` for routine operations
- Don't forget to import the invalidator

## Testing

### Manual Test
```bash
# 1. Get data
curl http://localhost:3000/api/suppliers

# 2. Perform mutation (DELETE/POST/PUT)
curl -X DELETE http://localhost:3000/api/suppliers/[id]

# 3. Check console for: 🔄 Cache invalidated for supplier: [id]

# 4. Get data again (should be fresh, not cached)
curl http://localhost:3000/api/suppliers
```

### Automated Test
```bash
# Run the provided test script
bash test-cache-invalidation.sh
```

## Common Mistakes

### Mistake 1: Forgetting to invalidate
```typescript
// ❌ WRONG
export async function DELETE(request, { params }) {
  await deleteSupplier(params.id)
  return NextResponse.json({ success: true })
  // Missing cache invalidation!
}

// ✅ CORRECT
export async function DELETE(request, { params }) {
  await deleteSupplier(params.id)
  CacheInvalidator.invalidateSupplier(params.id) // Added
  return NextResponse.json({ success: true })
}
```

### Mistake 2: Invalidating before write
```typescript
// ❌ WRONG
CacheInvalidator.invalidateSupplier(id) // Too early!
await deleteSupplier(id) // What if this fails?

// ✅ CORRECT
await deleteSupplier(id) // Write first
CacheInvalidator.invalidateSupplier(id) // Then invalidate
```

### Mistake 3: Invalidating in catch block
```typescript
// ❌ WRONG
try {
  await deleteSupplier(id)
} catch (error) {
  CacheInvalidator.invalidateSupplier(id) // Don't invalidate on error!
  throw error
}

// ✅ CORRECT
try {
  await deleteSupplier(id)
  CacheInvalidator.invalidateSupplier(id) // Only on success
} catch (error) {
  throw error
}
```

## Quick Checklist

Before committing new mutation endpoints:
- [ ] Import `CacheInvalidator`
- [ ] Call appropriate invalidation method
- [ ] Call AFTER successful database write
- [ ] Include entity ID and related IDs (supplierId, etc.)
- [ ] Test manually and check console logs
- [ ] Verify fresh data appears immediately

## Support

For issues or questions:
1. Check `CACHE_INVALIDATION_REPORT.md` for detailed documentation
2. Review console logs for invalidation indicators
3. Run `test-cache-invalidation.sh` to verify system health