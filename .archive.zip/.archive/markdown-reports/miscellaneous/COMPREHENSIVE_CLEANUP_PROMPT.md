# COMPREHENSIVE REPOSITORY CLEANUP - PARALLEL AGENT COORDINATION

## CONTEXT & PROBLEM STATEMENT

**Repository:** MantisNXT (Next.js inventory management system with AI capabilities)
**Current State:** CRITICAL MESS - 362 items in root directory, 197+ markdown files cluttering workspace
**Impact:** Severely degraded developer experience, difficult navigation, unclear project structure
**Objective:** Archive all non-essential/non-critical files while preserving production-critical code and configuration

---

## COORDINATION PROTOCOL

**Execute with:** `/spawn` - launch all 6 agents in PARALLEL
**Coordination:** Each agent has specific domain; share findings via reports before execution
**Safety:** NO deletions - archive only; create rollback plan; validate before committing

---

## AGENT ASSIGNMENTS

### 🏗️ AGENT 1: @aster-fullstack-architect
**Role:** Architecture Analysis & Essential File Classification
**Tasks:**
1. **Analyze current architecture** (`package.json`, `next.config.js`, `tsconfig.json`)
2. **Identify CRITICAL directories & files** that MUST remain:
   - `/src/` - application source code
   - `/pages/` - Next.js pages/routes
   - `/public/` - static assets
   - `/lib/` - shared libraries
   - `/scripts/` - build/migration scripts
   - `/database/`, `/migrations/`, `/sql/` - database layer
   - `/tests/`, `/playwright-report/`, `/test-results/` - testing infrastructure
   - Root configs: `package.json`, `next.config.js`, `tsconfig.json`, `tailwind.config.js`
   - Git/CI: `.git/`, `.github/`, `.husky/`, `.gitignore`
   - Claude Code: `.claude/`

3. **Categorize 197 root markdown files**:
   - Identify which are active documentation (keep)
   - Which are historical reports (archive)
   - Naming patterns: `AI_*.md`, `ADR_*.md`, `AGENT_*.md`, `*_REPORT.md`, `*_SUMMARY.md`

4. **Create classification matrix**:
   ```
   KEEP (Production Critical):
   - [List specific files/directories]

   ARCHIVE (Historical/Redundant):
   - [List with rationale]

   REVIEW (Needs human judgment):
   - [List with questions]
   ```

**Deliverable:** `ARCHITECTURE_CLASSIFICATION_REPORT.md` with categorized inventory

---

### 🔍 AGENT 2: @code-reviewer
**Role:** Code Quality Audit & Redundancy Detection
**Tasks:**
1. **Scan for duplicate/redundant files**:
   - Multiple `.env.*` files (`.env.example`, `.env.local`, `.env.production`) - keep only example + local
   - Duplicate config files (`.eslintrc.json` vs `.eslintrc.enhanced.json`)
   - Legacy AI configs (`.windsurfrules`, `.cursor/`)

2. **Identify orphaned/unused code**:
   - Check imports/references for files in `/docs/`, `/claudedocs/`
   - Verify if Python `venv/` and `venv_data_validation/` are needed (this is a Node.js project)
   - Scan for unused dependencies in `package.json`

3. **Security audit**:
   - Flag `/secrets/` directory - SHOULD NOT be in git
   - Check for committed credentials in historical markdown files
   - Review `.env.*` files for sensitive data

4. **Generate cleanup recommendations**:
   ```
   SAFE TO ARCHIVE:
   - [Files/dirs with zero references]

   RISKY TO ARCHIVE (has references):
   - [Files with active imports/links]

   SECURITY CONCERNS:
   - [Sensitive files that need immediate action]
   ```

**Deliverable:** `CODE_AUDIT_CLEANUP_RECOMMENDATIONS.md`

---

### 🚀 AGENT 3: @deployment-engineer
**Role:** Deployment Safety & Environment Configuration
**Tasks:**
1. **Audit build/deployment configs**:
   - Verify what's needed for production builds (`npm run build`)
   - Check CI/CD pipeline requirements (`.github/`, `.gitlab-ci.yml`)
   - Identify which scripts in `/scripts/` are build-critical vs one-time migration scripts

2. **Environment file strategy**:
   - Determine which `.env.*` files are deployment-critical
   - Recommend `.env.example` (for repo) + `.env.local` (gitignored)
   - Archive: `.env.production` (should be in deployment system, not git)

3. **Create deployment validation checklist**:
   ```
   PRE-CLEANUP VALIDATION:
   - [ ] npm run build (succeeds)
   - [ ] npm run test (passes)
   - [ ] npm run type-check (clean)
   - [ ] Deployment pipeline config intact

   POST-CLEANUP VALIDATION:
   - [ ] All above still pass
   - [ ] No broken imports
   - [ ] Environment configs functional
   ```

4. **Archive safety protocol**:
   - Create `.archive/` directory structure
   - Define rollback procedure
   - Create `ARCHIVE_MANIFEST.md` with file→archive mapping

**Deliverable:** `DEPLOYMENT_SAFETY_PROTOCOL.md` + archive directory structure

---

### 📊 AGENT 4: @data-engineer (from supabase-toolkit)
**Role:** Database & Data File Management
**Tasks:**
1. **Audit database-related files**:
   - `/database/` - production schemas (KEEP)
   - `/migrations/` - migration history (KEEP)
   - `/sql/` - SQL scripts (REVIEW - which are one-time vs reusable?)
   - Identify database validation reports in root markdown files

2. **Data validation artifacts**:
   - Review `/validation-reports/` - likely archivable
   - Check for CSV/Excel files at root or in `/docs/`
   - Identify sample data generators vs production seeds

3. **Migration history preservation**:
   - Ensure no migration files are archived (breaking database versioning)
   - Verify migration order is intact
   - Document which validation scripts are still relevant

**Deliverable:** `DATABASE_FILES_AUDIT.md` + recommendations on `/sql/` and validation artifacts

---

### 📝 AGENT 5: @documentation-generator
**Role:** Documentation Consolidation & Organization
**Tasks:**
1. **Audit 197 root markdown files**:
   - **Pattern analysis**:
     - `AI_*.md` (24+ files) - AI integration reports → ARCHIVE
     - `ADR_*.md` - Architecture Decision Records → Consolidate or archive old versions
     - `AGENT_*_REPORT.md` - Historical agent execution logs → ARCHIVE
     - `*_CHECKLIST.md`, `*_SUMMARY.md`, `*_ROADMAP.md` → Review for currency

2. **Create consolidated documentation structure**:
   ```
   /docs/
     /archive/               ← Historical reports
       /ai-implementation/   ← AI_*.md files
       /agent-reports/       ← AGENT_*.md files
       /validation/          ← *_VALIDATION_*.md files
     /active/               ← Current, relevant docs
       README.md            ← Consolidated getting started
       ARCHITECTURE.md      ← Current architecture
       DEPLOYMENT.md        ← Deployment guide
       DEVELOPMENT.md       ← Dev workflow
   ```

3. **Determine which docs are essential**:
   - Active: Referenced in code, current architecture, deployment guides
   - Archive: Historical reports, completed initiatives, outdated roadmaps

4. **Create migration mapping**:
   ```markdown
   | Current File | New Location | Rationale |
   |--------------|--------------|-----------|
   | AI_README.md | /docs/archive/ai-implementation/ | Historical implementation detail |
   | ACTION_CHECKLIST_NEXT_STEPS.md | /docs/archive/ | Completed action items |
   ```

**Deliverable:** `DOCUMENTATION_CONSOLIDATION_PLAN.md` + new `/docs/` structure

---

### 🧹 AGENT 6: @frontend-developer
**Role:** Frontend Asset & Config Cleanup
**Tasks:**
1. **Audit frontend-specific directories**:
   - `/public/` - ensure all assets are referenced
   - `/pages/` - check for deprecated routes
   - `/src/components/` - identify unused components

2. **Review editor/tooling configs**:
   - `.cursor/` - Cursor editor config (archive if not actively used)
   - `.devcontainer/` - Dev container config (keep if team uses)
   - `.windsurfrules` - Legacy Windsurf AI config (likely archive)
   - `.prettierrc`, `.prettierignore`, `.eslintrc.json` - consolidate duplicates

3. **Build artifact cleanup**:
   - `.next/` - build cache (KEEP but ensure in .gitignore)
   - `/playwright-report/`, `/test-results/` - test outputs (archive old, keep recent)
   - `/validation-reports/` - likely archivable
   - `/monitoring/`, `/nginx/` - review if used in dev or just deployment artifacts

4. **Create frontend asset inventory**:
   ```
   KEEP:
   - Active components, pages, public assets

   ARCHIVE:
   - Unused editor configs
   - Historical test reports (>30 days old)
   - Legacy tooling configs
   ```

**Deliverable:** `FRONTEND_CLEANUP_INVENTORY.md`

---

## ARCHIVE STRUCTURE

Create this directory structure in `.archive/` at project root:

```
.archive/
├── README.md                          # Index of archived content with dates
├── ROLLBACK_INSTRUCTIONS.md           # How to restore if needed
├── markdown-reports/                  # 197 root markdown files
│   ├── ai-implementation/             # AI_*.md
│   ├── agent-reports/                 # AGENT_*.md
│   ├── architecture-decisions/        # ADR_*.md
│   ├── validation/                    # *_VALIDATION_*.md
│   └── miscellaneous/                 # Other *.md
├── configs/                           # Redundant/legacy configs
│   ├── editor/                        # .cursor/, .windsurfrules
│   ├── env/                           # .env.production, duplicates
│   └── eslint/                        # .eslintrc.enhanced.json
├── documentation/                     # docs/, claudedocs/
├── validation-reports/                # Old test/validation outputs
├── scripts-deprecated/                # One-time migration scripts
└── miscellaneous/                     # venv/, secrets/, etc.
```

---

## EXECUTION WORKFLOW

### Phase 1: ANALYSIS (Parallel - All Agents)
**Timeline:** Agents work simultaneously for 10-15 minutes

1. Each agent performs their domain analysis
2. Generates their deliverable report
3. Identifies KEEP vs ARCHIVE vs REVIEW items

**Output:** 6 reports ready for review

---

### Phase 2: CONSOLIDATION (Sequential - Lead: @aster-fullstack-architect)
**Timeline:** 5 minutes

1. @aster-fullstack-architect reviews all 6 reports
2. Creates unified `MASTER_CLEANUP_PLAN.md`:
   ```markdown
   ## CONSENSUS DECISIONS

   ### KEEP (All agents agree):
   - [List]

   ### ARCHIVE (All agents agree):
   - [List]

   ### NEEDS HUMAN REVIEW (Conflicts or uncertainty):
   - [List with agent opinions]

   ## ESTIMATED IMPACT
   - Files to archive: ~250
   - Directories to archive: ~8
   - Disk space freed: ~XX MB
   - Risk level: LOW/MEDIUM/HIGH
   ```

3. Present `MASTER_CLEANUP_PLAN.md` to USER for approval

**⚠️ STOP POINT:** Wait for explicit user approval before Phase 3

---

### Phase 3: EXECUTION (Parallel - All Agents)
**Timeline:** Only after user approval

1. Create `.archive/` structure (@deployment-engineer)
2. Each agent moves their identified files to appropriate archive subdirectories
3. Update `.gitignore` to exclude archived content from tracking
4. Create `ARCHIVE_MANIFEST.md` with full file→archive mapping
5. Run validation tests:
   ```bash
   npm run build
   npm run type-check
   npm run test
   ```

**Output:** Clean repository with archived content safely stored

---

### Phase 4: VALIDATION (Parallel - All Agents)
**Timeline:** 5 minutes

1. Each agent verifies their domain is functional:
   - @aster-fullstack-architect: Architecture intact
   - @code-reviewer: No broken imports
   - @deployment-engineer: Build succeeds
   - @data-engineer: Database migrations intact
   - @documentation-generator: Essential docs preserved
   - @frontend-developer: Frontend builds cleanly

2. Create `POST_CLEANUP_VALIDATION_REPORT.md`

---

## SAFETY MEASURES

### Rollback Plan
```bash
# If something breaks, restore from archive:
cp -r .archive/[specific-dir]/* ./
git checkout HEAD -- [specific-file]
```

### Pre-Cleanup Snapshot
```bash
# Create git branch before cleanup
git checkout -b pre-cleanup-snapshot-$(date +%Y%m%d)
git add -A
git commit -m "Snapshot before comprehensive cleanup"
git checkout main
```

### Validation Gates
- ✅ All builds pass
- ✅ All tests pass
- ✅ Type checking clean
- ✅ No broken imports
- ✅ Deployment configs intact
- ✅ Database migrations functional

---

## SUCCESS CRITERIA

1. **Root directory reduced** from 362 items to ~30-40 essential items
2. **197 markdown files** moved to organized `.archive/markdown-reports/`
3. **All builds/tests passing** post-cleanup
4. **Zero production impact** - deployment configs intact
5. **Clear documentation** in `ARCHIVE_MANIFEST.md` for recovery
6. **Developer experience improved** - can actually navigate the project

---

## SPAWN COMMAND

```bash
/spawn 6

# Agent 1: @aster-fullstack-architect
# Agent 2: @code-reviewer
# Agent 3: @deployment-engineer
# Agent 4: @data-engineer (supabase-toolkit)
# Agent 5: @documentation-generator
# Agent 6: @frontend-developer
```

---

## DELIVERABLES CHECKLIST

- [ ] `ARCHITECTURE_CLASSIFICATION_REPORT.md` (@aster-fullstack-architect)
- [ ] `CODE_AUDIT_CLEANUP_RECOMMENDATIONS.md` (@code-reviewer)
- [ ] `DEPLOYMENT_SAFETY_PROTOCOL.md` (@deployment-engineer)
- [ ] `DATABASE_FILES_AUDIT.md` (@data-engineer)
- [ ] `DOCUMENTATION_CONSOLIDATION_PLAN.md` (@documentation-generator)
- [ ] `FRONTEND_CLEANUP_INVENTORY.md` (@frontend-developer)
- [ ] `MASTER_CLEANUP_PLAN.md` (consolidated by @aster-fullstack-architect)
- [ ] `ARCHIVE_MANIFEST.md` (post-execution)
- [ ] `POST_CLEANUP_VALIDATION_REPORT.md` (post-execution)

---

## FINAL NOTE

This is a MAJOR refactoring operation. The parallel agent approach ensures:
- ✅ Comprehensive domain coverage
- ✅ Multiple perspectives on what's safe to archive
- ✅ Coordination prevents conflicts
- ✅ Safety checks at every phase
- ✅ Rollback capability if issues arise

**DO NOT PROCEED with Phase 3 (Execution) without explicit user review and approval of the MASTER_CLEANUP_PLAN.**
