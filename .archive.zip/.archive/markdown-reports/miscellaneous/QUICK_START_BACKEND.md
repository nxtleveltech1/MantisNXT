# Quick Start Guide - Backend Integration

## For Developers

### Running the Integration Test

```bash
# Terminal 1: Start development server
npm run dev

# Terminal 2: Run integration tests
node scripts/test-neon-integration.js
```

Expected result: All 6 tests should pass ✅

---

## Using the React Query Hooks

### Import the hooks:
```typescript
import {
  useActiveSelection,
  useSelections,
  useCreateSelection,
  useAddProductsToSelection,
  useActivateSelection,
  useDashboardMetrics,
  useNxtSoh,
  useProductsBySupplier,
  useUploadPricelist,
  useMergeUpload,
} from '@/hooks/useNeonSpp'
```

### Example: Upload a pricelist
```typescript
const uploadMutation = useUploadPricelist()

const handleUpload = async (file: File, supplierId: string) => {
  try {
    const uploadId = await uploadMutation.mutateAsync({
      file,
      supplier_id: supplierId,
      filename: file.name,
      currency: 'GBP',
    })

    toast({ title: 'Success', description: 'Upload complete' })
    return uploadId
  } catch (error) {
    toast({
      title: 'Error',
      description: error.message,
      variant: 'destructive'
    })
  }
}

// Access loading state
{uploadMutation.isPending && <Loader2 className="animate-spin" />}
```

### Example: Get active selection
```typescript
const { data: activeSelection, isLoading } = useActiveSelection()

if (isLoading) return <Skeleton />
if (!activeSelection) return <Alert>No active selection</Alert>

return <div>{activeSelection.selection_name}</div>
```

### Example: Create and activate selection
```typescript
const createMutation = useCreateSelection()
const activateMutation = useActivateSelection()

const handleCreate = async () => {
  // Step 1: Create
  const selection = await createMutation.mutateAsync({
    selectionName: 'Q2 2025 Inventory',
    description: 'Spring inventory selection',
    createdBy: 'user-id',
  })

  // Step 2: Add products (assume productIds is populated)
  await addProductsMutation.mutateAsync({
    selectionId: selection.selection_id,
    productIds: ['id1', 'id2'],
    action: 'select',
    selectedBy: 'user-id',
  })

  // Step 3: Activate
  await activateMutation.mutateAsync({
    selectionId: selection.selection_id,
    deactivateOthers: true,
  })
}
```

---

## Component Locations

### Pricelist Upload
```
src/components/supplier-portfolio/EnhancedPricelistUpload.tsx
```

Usage:
```typescript
<EnhancedPricelistUpload
  open={isOpen}
  onOpenChange={setIsOpen}
  onComplete={(result) => console.log('Merged!', result)}
  defaultSupplierId={supplierId}
  autoValidate={true}
/>
```

### Inventory Selection Interface (ISI)
```
src/components/supplier-portfolio/ISIWizard.tsx
```

Usage:
```typescript
<ISIWizard
  defaultSupplierId={supplierId}
  onComplete={(selection) => navigate('/reports')}
  onNavigateToReports={() => navigate('/reports')}
/>
```

### Stock on Hand Reports
```
src/components/supplier-portfolio/ISSohReports.tsx
```

Usage:
```typescript
<ISSohReports
  onExport={(data, format) => exportToFile(data, format)}
/>
```

---

## API Endpoints Reference

### SPP (Staging/Upload)
- `POST /api/spp/upload` - Upload pricelist
- `POST /api/spp/validate` - Validate upload
- `POST /api/spp/merge` - Merge to catalog
- `GET /api/spp/dashboard/metrics` - Get metrics

### CORE (Canonical Data)
- `GET /api/core/suppliers` - List suppliers
- `GET /api/core/selections` - List selections
- `GET /api/core/selections/active` - Get active selection
- `POST /api/core/selections` - Create selection
- `POST /api/core/selections/{id}/activate` - Activate selection
- `POST /api/core/selections/workflow` - Add/remove products

### SERVE (Reporting Views)
- `GET /api/serve/nxt-soh` - Stock on hand report
- `GET /api/serve/products-by-supplier` - Product listings

### Health
- `GET /api/health/database` - Database health check

---

## Troubleshooting

### Problem: "No active selection" warning
**Solution**: Create and activate a selection using ISIWizard

### Problem: Integration test fails
**Solution**: Check that dev server is running on port 3000

### Problem: TypeScript errors
**Solution**: Most are in docs/ folder, ignore them. Focus on src/ errors only.

### Problem: Upload fails
**Solution**:
1. Check file format (Excel or CSV)
2. Verify supplier exists
3. Check network console for error details

### Problem: React Query cache not updating
**Solution**: Mutations automatically invalidate related queries. If issues persist, check query keys in useNeonSpp.ts

---

## Best Practices

### Always use hooks from useNeonSpp.ts
❌ Don't:
```typescript
const response = await fetch('/api/spp/upload', { ... })
```

✅ Do:
```typescript
const uploadMutation = useUploadPricelist()
await uploadMutation.mutateAsync({ ... })
```

### Handle loading and error states
✅ Do:
```typescript
const { data, isLoading, error } = useQuery(...)

if (isLoading) return <Skeleton />
if (error) return <Alert variant="destructive">{error.message}</Alert>
if (!data) return <Alert>No data</Alert>

return <DataTable data={data} />
```

### Use toast for user feedback
✅ Do:
```typescript
const { toast } = useToast()

toast({
  title: 'Success',
  description: 'Operation completed',
  variant: 'default'
})
```

---

## Getting Help

1. Check `BACKEND_INTEGRATION_COMPLETE.md` for detailed documentation
2. Review `src/hooks/useNeonSpp.ts` for available hooks
3. Look at existing component implementations for examples
4. Run integration tests to verify backend health

---

**Updated**: 2025-10-07
**Version**: 1.0.0
**Status**: Production Ready ✅
