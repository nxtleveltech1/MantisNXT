# IMMEDIATE FIX RECOMMENDATIONS

**File**: `src/components/ai/InsightCards.tsx`
**Critical Lines**: 800, 816
**Status**: Ready for implementation

## 🔧 EXACT CODE CHANGES REQUIRED

### Fix 1: Line 800 - Secondary Action Button Icon
**Location**: Around line 800 in secondary action button
**Current (BROKEN)**:
```jsx
<insight.actions.secondary[0].icon className="h-3 w-3 mr-1" />
```

**Fixed Code**:
```jsx
{(() => {
  const SecondaryIcon = insight.actions.secondary[0].icon;
  return <SecondaryIcon className="h-3 w-3 mr-1" />;
})()}
```

### Fix 2: Line 816 - Dropdown Menu Item Icon
**Location**: Around line 816 in dropdown menu item
**Current (BROKEN)**:
```jsx
<action.icon className="h-4 w-4 mr-2" />
```

**Fixed Code**:
```jsx
{(() => {
  const ActionIcon = action.icon;
  return <ActionIcon className="h-4 w-4 mr-2" />;
})()}
```

## 📋 COMPLETE CONTEXT REPLACEMENTS

### Context 1: Secondary Button Section (Lines ~792-802)
**Replace this entire section**:
```jsx
{insight.actions.secondary.length > 0 && (
  <div className="flex gap-2">
    <Button
      variant="outline"
      size="sm"
      onClick={() => handleInsightAction(insight, insight.actions.secondary[0])}
      className="flex-1"
    >
      <insight.actions.secondary[0].icon className="h-3 w-3 mr-1" />
      {insight.actions.secondary[0].label}
    </Button>
```

**With this fixed version**:
```jsx
{insight.actions.secondary.length > 0 && (
  <div className="flex gap-2">
    <Button
      variant="outline"
      size="sm"
      onClick={() => handleInsightAction(insight, insight.actions.secondary[0])}
      className="flex-1"
    >
      {(() => {
        const SecondaryIcon = insight.actions.secondary[0].icon;
        return <SecondaryIcon className="h-3 w-3 mr-1" />;
      })()}
      {insight.actions.secondary[0].label}
    </Button>
```

### Context 2: Dropdown Menu Items (Lines ~811-819)
**Replace this section**:
```jsx
{insight.actions.secondary.slice(1).map((action) => (
  <DropdownMenuItem
    key={action.id}
    onClick={() => handleInsightAction(insight, action)}
  >
    <action.icon className="h-4 w-4 mr-2" />
    {action.label}
  </DropdownMenuItem>
))}
```

**With this fixed version**:
```jsx
{insight.actions.secondary.slice(1).map((action) => (
  <DropdownMenuItem
    key={action.id}
    onClick={() => handleInsightAction(insight, action)}
  >
    {(() => {
      const ActionIcon = action.icon;
      return <ActionIcon className="h-4 w-4 mr-2" />;
    })()}
    {action.label}
  </DropdownMenuItem>
))}
```

## ⚡ QUICK IMPLEMENTATION STEPS

1. **Open File**: `src/components/ai/InsightCards.tsx`
2. **Navigate to Line 800**: Look for `<insight.actions.secondary[0].icon`
3. **Replace**: Apply Context 1 fix above
4. **Navigate to Line 816**: Look for `<action.icon`
5. **Replace**: Apply Context 2 fix above
6. **Save File**
7. **Test Build**: Run `npm run build` to verify fixes

## 🧪 VERIFICATION COMMANDS

```bash
# 1. Check build compilation
npm run build

# 2. Start development server
npm run dev

# 3. Navigate to analytics page
# http://localhost:3000/analytics

# 4. Verify no console errors
# Check browser dev tools for errors
```

## 🎯 SUCCESS INDICATORS

**Build Success**:
- ✅ `npm run build` completes without syntax errors
- ✅ No "Expected '</', got '['" errors in output
- ✅ Build size reports normally

**Runtime Success**:
- ✅ Analytics page loads (no 500 error)
- ✅ InsightCards component renders
- ✅ Icons display in action buttons
- ✅ Dropdown menu icons appear correctly

**Development Success**:
- ✅ `npm run dev` starts without warnings
- ✅ Hot reload works properly
- ✅ TypeScript compilation clean

## 🚨 EMERGENCY ALTERNATIVE

If the IIFE (Immediately Invoked Function Expression) pattern seems complex, use this simpler approach:

**Alternative Fix Pattern**:
```jsx
// Instead of IIFE, extract to render function
const renderIcon = (IconComponent: React.ComponentType<{ className?: string }>, className: string) => {
  return <IconComponent className={className} />;
};

// Then use:
{renderIcon(insight.actions.secondary[0].icon, "h-3 w-3 mr-1")}
{renderIcon(action.icon, "h-4 w-4 mr-2")}
```

## ⏰ ESTIMATED FIX TIME

- **Implementation**: 5-10 minutes
- **Testing**: 5 minutes
- **Verification**: 5 minutes
- **Total**: 15-20 minutes

**Next Action**: Apply these exact code changes to restore system functionality immediately.

---
*Ready for immediate implementation*