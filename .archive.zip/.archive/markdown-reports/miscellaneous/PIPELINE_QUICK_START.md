# Data Pipeline - Quick Start Guide

**⚡ Fast reference for using the optimized data pipeline infrastructure**

---

## Installation

Already included in your project! No additional dependencies needed.

```typescript
// Import utilities
import {
  BatchProcessor,
  CursorPaginator,
  aggregateMetricsInParallel
} from '@/lib/pipeline/batch-processor';

import {
  SWRCache,
  CacheManager
} from '@/lib/pipeline/cache-manager';
```

---

## Common Patterns

### 1. Add Caching to an Endpoint

```typescript
// Create cache instance
const myCache = new SWRCache(
  {
    ttl: 2 * 60 * 1000,        // 2 minutes
    staleTime: 1 * 60 * 1000,  // 1 minute stale
    maxSize: 100,
    namespace: 'my-endpoint'
  },
  async (key: string) => {
    // Your data fetcher
    return fetchDataFromDatabase();
  }
);

// Use in endpoint
export async function GET(request: NextRequest) {
  const data = await myCache.get('cache-key');
  return NextResponse.json({ success: true, data });
}
```

### 2. Parallel Database Queries

```typescript
// Define queries
const queries = [
  {
    key: 'suppliers',
    query: 'SELECT COUNT(*) FROM suppliers'
  },
  {
    key: 'inventory',
    query: 'SELECT SUM(value) FROM inventory'
  },
  {
    key: 'alerts',
    query: 'SELECT COUNT(*) FROM alerts WHERE status = $1',
    params: ['active']
  }
];

// Execute in parallel
const metrics = await aggregateMetricsInParallel(pool, queries);

// Access results
console.log(metrics.suppliers); // { count: 22 }
console.log(metrics.inventory); // { sum: 125000 }
console.log(metrics.alerts);    // { count: 45 }
```

### 3. Batch Processing Large Arrays

```typescript
// Process 25K items in batches
const processor = new BatchProcessor(
  async (batch) => {
    // Your processing logic
    return batch.map(item => validateItem(item));
  },
  {
    batchSize: 250,
    maxConcurrency: 4,
    onProgress: (done, total) => {
      console.log(`${done}/${total} processed`);
    }
  }
);

const result = await processor.process(allItems);
// { data, processed, failed, errors, duration }
```

### 4. Cursor Pagination for Large Tables

```typescript
// Stream large datasets efficiently
const paginator = new CursorPaginator(
  pool,
  'inventory_items',
  {
    cursorColumn: 'id',
    orderDirection: 'ASC',
    limit: 500
  }
);

const allItems = [];
for await (const batch of paginator.paginate()) {
  console.log(`Fetched ${batch.length} items`);
  allItems.push(...batch);
}
```

---

## Real-World Examples

### Example 1: Optimize Slow Endpoint

**Before** (Slow - 500ms):
```typescript
export async function GET(request: NextRequest) {
  const data = await pool.query('SELECT * FROM large_table');
  return NextResponse.json({ success: true, data: data.rows });
}
```

**After** (Fast - <10ms cached):
```typescript
const cache = new SWRCache(
  { ttl: 2 * 60 * 1000 },
  async () => {
    const result = await pool.query('SELECT * FROM large_table');
    return result.rows;
  }
);

export async function GET(request: NextRequest) {
  const data = await cache.get('large-table-data');
  return NextResponse.json({ success: true, data });
}
```

### Example 2: Dashboard Metrics

**Before** (Sequential - 300ms):
```typescript
const suppliers = await pool.query('SELECT COUNT(*) FROM suppliers');
const inventory = await pool.query('SELECT COUNT(*) FROM inventory');
const alerts = await pool.query('SELECT COUNT(*) FROM alerts');
```

**After** (Parallel + Cached - 5ms):
```typescript
const dashboardCache = new SWRCache(
  { ttl: 2 * 60 * 1000 },
  async () => {
    return aggregateMetricsInParallel(pool, [
      { key: 'suppliers', query: 'SELECT COUNT(*) FROM suppliers' },
      { key: 'inventory', query: 'SELECT COUNT(*) FROM inventory' },
      { key: 'alerts', query: 'SELECT COUNT(*) FROM alerts' }
    ]);
  }
);

const metrics = await dashboardCache.get('dashboard-metrics');
```

### Example 3: Validate Large Dataset

**Before** (Memory crash):
```typescript
const items = await pool.query('SELECT * FROM inventory'); // 25K items
const validated = items.rows.map(item => validate(item)); // BOOM!
```

**After** (Streaming - 250ms):
```typescript
const paginator = new CursorPaginator(pool, 'inventory', {
  limit: 500,
  cursorColumn: 'id'
});

const validated = [];
for await (const batch of paginator.paginate()) {
  const batchValidated = batch.map(item => validate(item));
  validated.push(...batchValidated);
}
```

---

## Performance Tips

### ✅ DO

- **Use caching** for read-heavy endpoints
- **Batch process** large arrays (>1000 items)
- **Cursor paginate** database queries (>500 rows)
- **Parallel execute** independent queries
- **Monitor** cache hit rates

### ❌ DON'T

- Load entire datasets into memory
- Use OFFSET-based pagination for large tables
- Execute queries sequentially
- Skip error handling in batch processing
- Ignore cache invalidation

---

## Configuration

### Cache Settings

```typescript
// Fast-changing data (inventory, alerts)
{
  ttl: 30 * 1000,        // 30 seconds
  staleTime: 15 * 1000,  // 15 seconds
  maxSize: 500
}

// Slow-changing data (suppliers, settings)
{
  ttl: 5 * 60 * 1000,    // 5 minutes
  staleTime: 2 * 60 * 1000, // 2 minutes
  maxSize: 200
}
```

### Batch Processing

```typescript
// CPU-intensive operations
{
  batchSize: 100,
  maxConcurrency: 8
}

// Database operations
{
  batchSize: 500,
  maxConcurrency: 4
}

// I/O operations
{
  batchSize: 250,
  maxConcurrency: 6
}
```

### Cursor Pagination

```typescript
// Memory-constrained
{
  limit: 250,
  cursorColumn: 'id'
}

// Performance-optimized
{
  limit: 1000,
  cursorColumn: 'created_at'
}
```

---

## Monitoring

### Check Pipeline Health

```bash
curl http://localhost:3000/api/health/pipeline
```

### Response

```json
{
  "status": "healthy",
  "caches": {
    "aggregate": {
      "hits": 1250,
      "misses": 180,
      "hitRate": 0.87,
      "size": 145
    }
  },
  "database": {
    "activeConnections": 8,
    "idleConnections": 12,
    "poolSize": 20
  },
  "recommendations": [
    "✅ All pipeline metrics within healthy ranges"
  ]
}
```

### Reset Cache Stats

```bash
curl -X POST http://localhost:3000/api/health/pipeline?action=reset-stats
```

---

## Troubleshooting

### Issue: Low Cache Hit Rate

```typescript
// Check cache stats
const stats = myCache.getStats();
console.log('Hit rate:', stats.hitRate);

// Increase TTL if too short
const cache = new SWRCache({ ttl: 5 * 60 * 1000 }, fetcher);
```

### Issue: High Memory Usage

```typescript
// Use cursor pagination instead of full load
const paginator = new CursorPaginator(pool, 'table', {
  limit: 250  // Reduce batch size
});
```

### Issue: Slow Batch Processing

```typescript
// Increase concurrency
const processor = new BatchProcessor(handler, {
  maxConcurrency: 8,  // Up from 4
  batchSize: 500      // Larger batches
});
```

---

## Testing

### Test Cache Performance

```typescript
const cache = new SWRCache({ ttl: 60000 }, async () => {
  return { data: 'test' };
});

// First call (miss)
const start1 = Date.now();
await cache.get('test');
console.log('Cache miss:', Date.now() - start1, 'ms');

// Second call (hit)
const start2 = Date.now();
await cache.get('test');
console.log('Cache hit:', Date.now() - start2, 'ms');

// Get stats
console.log(cache.getStats());
```

### Test Batch Processing

```typescript
const items = Array.from({ length: 10000 }, (_, i) => ({ id: i }));

const processor = new BatchProcessor(
  async (batch) => batch.map(i => ({ ...i, processed: true })),
  { batchSize: 250, maxConcurrency: 4 }
);

const result = await processor.process(items);
console.log('Processed:', result.processed);
console.log('Duration:', result.duration, 'ms');
console.log('Throughput:', Math.round(result.processed / (result.duration / 1000)), 'items/sec');
```

---

## API Reference

### BatchProcessor

```typescript
new BatchProcessor<TInput, TOutput>(
  processor: (batch: TInput[]) => Promise<TOutput[]>,
  config?: {
    batchSize?: number;           // Default: 250
    maxConcurrency?: number;      // Default: 4
    retryAttempts?: number;       // Default: 3
    retryDelay?: number;          // Default: 1000ms
    onProgress?: (done, total) => void;
    onError?: (error, batch) => void;
  }
)
```

### CursorPaginator

```typescript
new CursorPaginator<T>(
  pool: Pool,
  table: string,
  options: {
    cursorColumn: string;          // e.g., 'id'
    orderDirection: 'ASC' | 'DESC'; // Default: 'ASC'
    limit: number;                 // Default: 500
    filters?: Record<string, any>; // WHERE conditions
  }
)
```

### SWRCache

```typescript
new SWRCache<T>(
  config: {
    ttl: number;         // Time to live (ms)
    staleTime?: number;  // Stale window (ms)
    maxSize?: number;    // Max entries
    namespace?: string;  // Cache prefix
  },
  fetcher: (key: string, ...args) => Promise<T>
)
```

---

## Support

- 📖 Full Guide: `docs/DATA_PIPELINE_OPTIMIZATION_GUIDE.md`
- 📊 Implementation Summary: `DATA_PIPELINE_IMPLEMENTATION_SUMMARY.md`
- 🏥 Health Check: `GET /api/health/pipeline`
- 💻 Source Code: `src/lib/pipeline/`

---

**Last Updated**: 2025-10-08
**Version**: 1.0.0
