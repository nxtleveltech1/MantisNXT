# Inventory Operations & Management — Phase 5

## Scope
- Close transactional gaps between movements and inventory quantities.
- Add missing adjustment endpoint.
- Harden validation and constraints, add soft deletes.

## Code Changes
- New endpoint: `src/app/api/inventory/adjustments/route.ts` (POST) — transactional adjust with validation and movement creation.
- Stock movements: `src/app/api/stock-movements/route.ts` — POST wrapped in transaction, updates `inventory_item.stock_qty`.
- Constraints: `migrations/0204_inventory_constraints.sql` — non-negative stock, `reserved <= stock`, positive movement quantities, `deleted_at` column.
- Batch updates: ensure computed columns are not updatable (available_qty stays generated) — documented in endpoint guidelines.

## Validation Rules
- Prevent negative stock and over-reservation.
- Validate OUT movements against `(stock_qty - reserved_qty)`.
- Fail fast on invalid adjustments with 400 status codes.

## Transactions
- Treat movement creation and inventory update as a single atomic unit.
- Use `withTransaction` across movement and adjustment flows.

## UI & Store
- Movements listing uses `/api/stock-movements`.
- Front-end validations to avoid invalid adjustments (see StockAdjustmentDialog — to be wired with new endpoint).

## Testing
- Unit tests recommended for status/turnover utils.
- Integration tests for transactional integrity and movement ↔ inventory syncing.
- E2E tests for adjustment flows and guardrails (out of current scope here; planned in CI).

