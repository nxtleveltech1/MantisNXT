# Hydration Fix Quick Guide

**Status:** ✅ Issues Resolved
**Date:** 2025-10-10

---

## What Was Fixed

### Issue: HTML Nesting Violation in MetricsDashboard.tsx

**Lines Affected:** 82, 150

**Before (Broken):**
```tsx
{description && (
  <p className="text-xs text-muted-foreground">{description}</p>
)}

// Usage with complex content (line 148-154)
description={
  <div className="space-y-1">
    <div className="text-xs text-muted-foreground">
      {selectionPercentage}% of catalog selected
    </div>
    <Progress value={selectionPercentage} className="h-1" />
  </div>
}
```

**Problem:** `<p>` cannot contain `<div>` elements (HTML5 spec violation)

**After (Fixed):**
```tsx
{description && (
  <div className="text-xs text-muted-foreground">{description}</div>
)}
```

---

## Quick Decision Tree

```
Is the prop content ALWAYS plain text?
├─ YES → Use <p> + type prop as `string`
│         Example: description?: string
│
└─ NO → Use <div> + type prop as `ReactNode`
          Example: description?: ReactNode
```

---

## Pattern Reference

### ✅ CORRECT Patterns

```tsx
// Pattern 1: Text-only prop
interface Props {
  description?: string; // Type enforces text
}

function Component({ description }: Props) {
  return (
    <div>
      {description && <p>{description}</p>}
    </div>
  );
}

// Pattern 2: Complex content prop
interface Props {
  description?: ReactNode; // Can be anything
}

function Component({ description }: Props) {
  return (
    <div>
      {description && <div>{description}</div>}
    </div>
  );
}

// Pattern 3: Discriminated union (best)
type Props =
  | { description: string; descriptionNode?: never }
  | { description?: never; descriptionNode: ReactNode };

function Component(props: Props) {
  return (
    <div>
      {props.description && <p>{props.description}</p>}
      {props.descriptionNode && <div>{props.descriptionNode}</div>}
    </div>
  );
}
```

### ❌ INCORRECT Patterns

```tsx
// DON'T: ReactNode in <p>
interface Props {
  description?: ReactNode;
}

function Component({ description }: Props) {
  return (
    <div>
      {description && <p>{description}</p>} // ❌ Breaks if description has <div>
    </div>
  );
}

// DON'T: Nested HTML structural elements
function Layout() {
  return (
    <html>
      <body>
        <html> // ❌ Never nest <html>
          ...
        </html>
      </body>
    </html>
  );
}
```

---

## Search & Replace Patterns

### Find Potential Issues
```bash
# Command line
grep -rn "<p[^>]*>.*{.*}" src/components/

# Or manually search in VS Code
<p[^>]*>.*\{
```

### Safe Automated Fix
```bash
# Only for simple {description} cases
find src/ -name "*.tsx" -type f -exec sed -i \
  's/<p className="\([^"]*\)">{description}<\/p>/<div className="\1">{description}<\/div>/g' {} +
```

**⚠️ Warning:** Review all changes manually. This may break intentional text-only props.

---

## Component Props Type Safety

### Define Clear Contracts

```tsx
// components/ui/metric-card.tsx
import type { ReactNode } from 'react';

export interface MetricCardProps {
  title: string;
  value: string | number;

  // Option A: Simple - accept anything, use div
  description?: ReactNode;

  // Option B: Type-safe - discriminate
  // description?: string;
  // descriptionNode?: ReactNode;

  icon: React.ElementType;
  iconColor: string;

  trend?: {
    value: number;
    direction: 'up' | 'down' | 'neutral';
  };

  badge?: {
    text: string;
    variant: 'default' | 'secondary' | 'destructive' | 'outline';
  };
}

export function MetricCard({
  title,
  value,
  description,
  icon: Icon,
  iconColor,
  trend,
  badge,
}: MetricCardProps) {
  return (
    <Card>
      <CardContent>
        {/* Use div for ReactNode content */}
        {description && (
          <div className="text-xs text-muted-foreground">
            {description}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
```

---

## Testing Hydration Issues

### Manual Test
1. Run production build: `npm run build`
2. Start production server: `npm start`
3. Open browser console
4. Look for warnings: `Warning: Text content did not match`

### Automated Test
```tsx
// tests/hydration/metrics-dashboard.test.tsx
import { render } from '@testing-library/react';
import { MetricsDashboard } from '@/components/spp/MetricsDashboard';

describe('MetricsDashboard Hydration', () => {
  it('handles complex description without hydration errors', () => {
    const consoleSpy = jest.spyOn(console, 'error');

    const metrics = {
      total_suppliers: 10,
      total_products: 1000,
      selected_products: 750,
      selected_inventory_value: 50000,
      new_products_count: 50,
      recent_price_changes_count: 25,
    };

    render(<MetricsDashboard metrics={metrics} />);

    // Should not have hydration warnings
    expect(consoleSpy).not.toHaveBeenCalledWith(
      expect.stringMatching(/did not match/i)
    );
  });
});
```

---

## Enabling Enhanced Linting

### Step 1: Install Dependencies
```bash
npm install -D eslint-plugin-jsx-a11y
```

### Step 2: Update ESLint Config
```bash
# Rename current config
mv .eslintrc.json .eslintrc.json.backup

# Use enhanced config
mv .eslintrc.enhanced.json .eslintrc.json
```

### Step 3: Run Linter
```bash
npm run lint
```

### Step 4: Fix Issues
```bash
# Auto-fix safe issues
npm run lint -- --fix
```

---

## Current Build Status

### ✅ Resolved
- Hydration errors in MetricsDashboard.tsx
- HTML nesting violations in error.tsx

### ⚠️ Outstanding (Unrelated)
**Build Error:**
```
Module not found: Can't resolve '@/components/suppliers/ProductSelectionWizard'
File: src/app/suppliers/pricelists/[id]/promote/page.tsx
```

**Fix Required:** Create the missing component or update the import.

---

## Next Steps

1. **Immediate:** Fix missing `ProductSelectionWizard` component
2. **Short-term:** Enable enhanced ESLint config
3. **Medium-term:** Add pre-commit hooks for HTML validation
4. **Long-term:** Establish component library with type-safe contracts

---

## Reference: Valid HTML Nesting

| Parent | Valid Children | Invalid Children |
|--------|---------------|------------------|
| `<p>` | Text, `<span>`, `<strong>`, `<em>`, `<a>` | `<div>`, `<section>`, `<article>`, `<p>` |
| `<div>` | Any | None (very permissive) |
| `<span>` | Phrasing content only | `<div>`, `<p>`, block elements |
| `<button>` | Phrasing content | Interactive elements (`<button>`, `<a>`) |
| `<a>` | Transparent (inherit parent rules) | Interactive elements (`<button>`, `<a>`) |

**Golden Rule:** When in doubt, use `<div>`. It's the most permissive block container.

---

## Questions?

See full architectural review: `ARCHITECTURAL_REVIEW_HTML_HYDRATION_PATTERNS.md`

**Document Version:** 1.0
**Last Updated:** 2025-10-10
