# Cache Invalidation - Developer Migration Guide

## For Developers Adding New Mutation Endpoints

This guide shows you how to add cache invalidation to new or existing mutation endpoints.

---

## Step 1: Identify Mutation Endpoints

Mutation endpoints are those that change data:
- **DELETE** - Removing entities
- **POST** - Creating entities
- **PUT** - Updating entire entities
- **PATCH** - Partially updating entities

If your endpoint only reads data (GET), you DON'T need cache invalidation.

---

## Step 2: Import the Cache Invalidator

At the top of your route file, add the import:

```typescript
import { CacheInvalidator } from '@/lib/cache/invalidation'
```

**Full Example:**
```typescript
import { NextRequest, NextResponse } from 'next/server'
import { pool } from '@/lib/database'
import { z } from 'zod'
import { CacheInvalidator } from '@/lib/cache/invalidation'  // ← Add this
```

---

## Step 3: Add Invalidation After Successful Mutation

### Pattern for DELETE Endpoints

```typescript
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // STEP 1: Get entity BEFORE deletion (if you need name/metadata)
    const entity = await pool.query('SELECT * FROM table WHERE id = $1', [id])
    const entityName = entity.rows[0]?.name

    // STEP 2: Perform deletion
    await pool.query('DELETE FROM table WHERE id = $1', [id])

    // STEP 3: ✅ Invalidate cache AFTER successful deletion
    CacheInvalidator.invalidateSupplier(id, entityName)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error:', error)
    // ❌ NO cache invalidation in catch block
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### Pattern for POST Endpoints

```typescript
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // STEP 1: Validate
    const validatedData = schema.parse(body)

    // STEP 2: Insert into database
    const result = await pool.query(
      'INSERT INTO table (...) VALUES (...) RETURNING *',
      [...]
    )
    const newEntity = result.rows[0]

    // STEP 3: ✅ Invalidate cache AFTER successful creation
    CacheInvalidator.invalidateSupplier(newEntity.id, newEntity.name)

    return NextResponse.json({ success: true, data: newEntity })
  } catch (error) {
    console.error('Error:', error)
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### Pattern for PUT/PATCH Endpoints

```typescript
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await request.json()

    // STEP 1: Validate
    const validatedData = schema.parse(body)

    // STEP 2: Update database
    const result = await pool.query(
      'UPDATE table SET ... WHERE id = $1 RETURNING *',
      [id]
    )
    const updatedEntity = result.rows[0]

    // STEP 3: ✅ Invalidate cache AFTER successful update
    CacheInvalidator.invalidateSupplier(id, updatedEntity.name)

    return NextResponse.json({ success: true, data: updatedEntity })
  } catch (error) {
    console.error('Error:', error)
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

---

## Step 4: Choose the Right Invalidation Method

### For Supplier Endpoints
```typescript
CacheInvalidator.invalidateSupplier(id, name?)
```

### For Product Endpoints
```typescript
CacheInvalidator.invalidateProduct(id, supplierId?)
```

### For Inventory Endpoints
```typescript
// Single item
CacheInvalidator.invalidateInventory(itemId, supplierId?)

// Bulk operations
CacheInvalidator.invalidateInventory() // No ID = invalidate all
```

### For Purchase Order Endpoints
```typescript
CacheInvalidator.invalidatePurchaseOrder(poId, supplierId?)
```

### For Stock Movement Endpoints
```typescript
CacheInvalidator.invalidateStockMovements(inventoryItemId?)
```

### For Warehouse Endpoints
```typescript
CacheInvalidator.invalidateWarehouse(warehouseId?)
```

### For Analytics/Dashboard Changes
```typescript
CacheInvalidator.invalidateAnalytics()
```

---

## Step 5: Handle Related Entities (Cascading)

If your mutation affects related entities, include their IDs:

```typescript
// Inventory change that affects a supplier
CacheInvalidator.invalidateInventory(
  inventoryId,
  supplierIdFromInventory  // ← This cascades to supplier cache
)

// Purchase order that affects a supplier
CacheInvalidator.invalidatePurchaseOrder(
  poId,
  supplierIdFromPO  // ← This cascades to supplier cache
)
```

---

## Step 6: Test Your Implementation

### Manual Testing

1. **Start your dev server**
   ```bash
   npm run dev
   ```

2. **Perform mutation**
   ```bash
   curl -X DELETE http://localhost:3000/api/your-endpoint/[id]
   ```

3. **Check console for log**
   ```
   🔄 Cache invalidated for [entity]: [id]
   ```

4. **Verify fresh data**
   ```bash
   curl http://localhost:3000/api/your-endpoint
   # Should show updated data, NOT cached old data
   ```

### Automated Testing

Run the test script:
```bash
bash test-cache-invalidation.sh
```

---

## Common Mistakes to Avoid

### ❌ Mistake 1: Forgetting to Import
```typescript
// ❌ WRONG - Missing import
export async function DELETE(request, { params }) {
  await deleteEntity(params.id)
  CacheInvalidator.invalidateSupplier(params.id) // ← Error: CacheInvalidator is not defined
}

// ✅ CORRECT
import { CacheInvalidator } from '@/lib/cache/invalidation'

export async function DELETE(request, { params }) {
  await deleteEntity(params.id)
  CacheInvalidator.invalidateSupplier(params.id)
}
```

### ❌ Mistake 2: Invalidating Before Database Write
```typescript
// ❌ WRONG - Invalidate too early
CacheInvalidator.invalidateSupplier(id) // What if deletion fails?
await deleteSupplier(id)

// ✅ CORRECT - Invalidate after successful write
await deleteSupplier(id)
CacheInvalidator.invalidateSupplier(id)
```

### ❌ Mistake 3: Invalidating in Error Handler
```typescript
// ❌ WRONG - Don't invalidate on failure
try {
  await deleteSupplier(id)
} catch (error) {
  CacheInvalidator.invalidateSupplier(id) // ← NO! Deletion failed!
  throw error
}

// ✅ CORRECT - Only invalidate on success
try {
  await deleteSupplier(id)
  CacheInvalidator.invalidateSupplier(id) // ← YES! Deletion succeeded
} catch (error) {
  throw error // No invalidation
}
```

### ❌ Mistake 4: Forgetting Related Entities
```typescript
// ❌ WRONG - Missing cascade to supplier
await updateInventory(inventoryId, { stock: 100 })
CacheInvalidator.invalidateInventory(inventoryId) // Only inventory

// ✅ CORRECT - Cascade to supplier
await updateInventory(inventoryId, { stock: 100, supplierId: 'SUP-123' })
CacheInvalidator.invalidateInventory(inventoryId, 'SUP-123') // Inventory + Supplier
```

### ❌ Mistake 5: Using Wrong Method
```typescript
// ❌ WRONG - Using supplier method for inventory
CacheInvalidator.invalidateSupplier(inventoryId)

// ✅ CORRECT - Use correct method
CacheInvalidator.invalidateInventory(inventoryId)
```

---

## Advanced: Transaction-Safe Invalidation

For operations using database transactions:

```typescript
export async function DELETE(request, { params }) {
  const client = await pool.connect()

  try {
    await client.query('BEGIN')

    // Get entity before deletion
    const result = await client.query('SELECT * FROM table WHERE id = $1', [params.id])
    const entity = result.rows[0]

    // Perform deletion
    await client.query('DELETE FROM table WHERE id = $1', [params.id])

    // Commit transaction
    await client.query('COMMIT')

    // ✅ Invalidate AFTER commit succeeds
    CacheInvalidator.invalidateSupplier(params.id, entity.name)

    return NextResponse.json({ success: true })
  } catch (error) {
    await client.query('ROLLBACK')
    // ❌ NO invalidation on rollback
    throw error
  } finally {
    client.release()
  }
}
```

---

## Decision Tree: Which Method to Use?

```
What entity are you mutating?
│
├─ Supplier?
│  └─> CacheInvalidator.invalidateSupplier(id, name?)
│
├─ Product?
│  └─> CacheInvalidator.invalidateProduct(id, supplierId?)
│
├─ Inventory?
│  ├─ Single item?
│  │  └─> CacheInvalidator.invalidateInventory(id, supplierId?)
│  └─ Batch operation?
│     └─> CacheInvalidator.invalidateInventory() // No ID
│
├─ Purchase Order?
│  └─> CacheInvalidator.invalidatePurchaseOrder(id, supplierId?)
│
├─ Stock Movement?
│  └─> CacheInvalidator.invalidateStockMovements(inventoryItemId?)
│
├─ Warehouse?
│  └─> CacheInvalidator.invalidateWarehouse(id?)
│
├─ Analytics/Dashboard data?
│  └─> CacheInvalidator.invalidateAnalytics()
│
└─ Everything (emergency)?
   └─> CacheInvalidator.invalidateAll()
```

---

## Checklist for New Endpoints

Before committing your new mutation endpoint:

- [ ] Import `CacheInvalidator` at the top of the file
- [ ] Identify the correct invalidation method for your entity type
- [ ] Place invalidation call AFTER successful database write
- [ ] Place invalidation BEFORE return statement
- [ ] Include related entity IDs (supplierId, etc.) if applicable
- [ ] NO invalidation in catch blocks or error handlers
- [ ] Test manually and verify console log appears
- [ ] Test that fresh data appears on next GET request
- [ ] Verify deleted entities don't appear in lists
- [ ] For batch operations, use wildcard invalidation (no ID)

---

## Quick Copy-Paste Templates

### DELETE Template
```typescript
export async function DELETE(request: NextRequest, { params }) {
  try {
    const { id } = params
    const entity = await getById(id) // Get before delete
    await deleteFromDB(id)
    CacheInvalidator.invalidate[EntityType](id, entity.name) // ← Change method
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### POST Template
```typescript
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const result = await insertIntoDB(body)
    const newEntity = result.rows[0]
    CacheInvalidator.invalidate[EntityType](newEntity.id, newEntity.name) // ← Change method
    return NextResponse.json({ success: true, data: newEntity })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

### PUT Template
```typescript
export async function PUT(request: NextRequest, { params }) {
  try {
    const { id } = params
    const body = await request.json()
    const result = await updateInDB(id, body)
    const updatedEntity = result.rows[0]
    CacheInvalidator.invalidate[EntityType](id, updatedEntity.name) // ← Change method
    return NextResponse.json({ success: true, data: updatedEntity })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
```

---

## Need Help?

1. **Check existing endpoints** - Look at `/api/suppliers/[id]/route.ts` for reference
2. **Read the Quick Reference** - See `CACHE_QUICK_REFERENCE.md`
3. **Check console logs** - Watch for cache invalidation indicators
4. **Run test script** - `bash test-cache-invalidation.sh`

---

## Summary

**Three Simple Rules:**
1. Import `CacheInvalidator` at the top
2. Call the right `invalidate` method AFTER successful database write
3. Include related entity IDs for cascading

That's it! Fresh data guaranteed.