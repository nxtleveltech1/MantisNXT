# Authentication/Authorization Fix Documentation

## Issue Summary

The MantisNXT platform was experiencing 401 Unauthorized errors on several API endpoints while others worked fine. This created an inconsistent user experience.

## Root Cause Analysis

### Affected Endpoints (401 Errors)
1. `/api/suppliers` - GET requests with filters
2. `/api/inventory` - GET requests with includeAlerts parameter
3. All variants of these endpoints with query parameters

### Working Endpoints (200 OK)
1. `/api/dashboard_metrics` - No authentication
2. `/api/alerts` - No authentication
3. `/api/activities/recent` - No authentication

### Key Issues Identified

1. **Inconsistent Middleware Application**
   - Some routes use `withAuth` from `@/middleware/api-auth`
   - Other routes have no authentication middleware at all
   - No clear pattern for which routes are protected

2. **Missing Authentication Headers**
   - Frontend hooks (`useSuppliers`, `useInventory`) make requests without authentication headers
   - No Bearer token or API key included in fetch requests
   - Frontend expects public access to these endpoints

3. **Environment Configuration Gap**
   - `ALLOW_PUBLIC_GET_ENDPOINTS` environment variable was not set
   - No transitional public GET access during development
   - Production-ready auth was enforced in development environment

## Solution Implemented

### 1. Environment Configuration (.env.local & .env.example)

Added the `ALLOW_PUBLIC_GET_ENDPOINTS` environment variable to allow public GET access during development:

```bash
# Authentication - Allow public GET access during development
# Comma-separated list of API endpoint prefixes that allow unauthenticated GET requests
# Leave empty for production (full auth enforcement)
ALLOW_PUBLIC_GET_ENDPOINTS=/api/suppliers,/api/inventory,/api/dashboard_metrics,/api/alerts,/api/activities,/api/warehouses,/api/purchase-orders,/api/products,/api/analytics
```

**Rationale:**
- Enables development without requiring authentication infrastructure
- Maintains security model in code for production deployment
- Allows gradual migration to full authentication
- Only affects GET requests (read operations)

### 2. Added Authentication Middleware to /api/inventory/enhanced

The `/api/inventory/enhanced` route had no authentication middleware. Added `withAuth` for consistency:

```typescript
import { withAuth } from '@/middleware/api-auth'

export const GET = withAuth(async (request: NextRequest) => {
  // ... route implementation
})
```

**Rationale:**
- Maintains consistent security posture across all inventory endpoints
- Allows public access through ALLOW_PUBLIC_GET_ENDPOINTS during development
- Enforces authentication in production when env var is empty

### 3. Authentication Middleware Behavior

The `withAuth` middleware in `@/middleware/api-auth.ts` now supports:

1. **Public Endpoints** - Always accessible (health checks, etc.)
   ```typescript
   const PUBLIC_ENDPOINTS = [
     '/api/health',
     '/api/health/database',
     '/api/health/database-enterprise',
   ]
   ```

2. **Transitional Public GET Endpoints** - Configurable via environment
   ```typescript
   const ALLOW_PUBLIC_GET_ENDPOINTS = (process.env.ALLOW_PUBLIC_GET_ENDPOINTS || '')
     .split(',')
     .map((s) => s.trim())
     .filter(Boolean)
   ```

3. **Protected Endpoints** - Require Bearer token authentication
   - Checks `Authorization: Bearer <token>` header
   - Validates JWT token (currently accepts any non-empty token for development)
   - Returns 401 if missing or invalid

## Testing the Fix

### 1. Restart the Development Server

```bash
# Kill existing server
pkill -f "next dev"

# Start fresh server (loads new .env.local)
npm run dev
```

### 2. Test Previously Failing Endpoints

```bash
# Test suppliers endpoint
curl http://localhost:3000/api/suppliers?status=active

# Test inventory endpoint
curl http://localhost:3000/api/inventory?includeAlerts=true&includeMetrics=true

# Should all return 200 OK with data
```

### 3. Verify Frontend Hooks

The `useSuppliers` hook should now work without errors:

```typescript
const { suppliers, loading, error } = useSuppliers()
// error should be null
// suppliers should contain data
```

## Production Deployment

### Important: Securing Production

For production deployment, **DO NOT** set `ALLOW_PUBLIC_GET_ENDPOINTS`. Instead:

1. **Remove or Leave Empty** in production .env:
   ```bash
   # ALLOW_PUBLIC_GET_ENDPOINTS=  # Leave empty or remove entirely
   ```

2. **Implement Frontend Authentication**:
   ```typescript
   // Update useSuppliers hook to include auth token
   const fetchSuppliers = async () => {
     const token = getAuthToken() // Get from auth context/storage

     const response = await fetch('/api/suppliers', {
       headers: {
         'Authorization': `Bearer ${token}`,
         'Content-Type': 'application/json'
       }
     })

     // ... handle response
   }
   ```

3. **Configure JWT Secret**:
   ```bash
   JWT_SECRET=<strong-random-32-char-minimum-secret>
   ```

4. **Update Token Validation**:
   The `validateToken()` function in `@/middleware/api-auth.ts` currently accepts any token. Update it to use proper JWT validation:

   ```typescript
   import { verify } from 'jsonwebtoken'

   function validateToken(token: string): boolean {
     const secret = process.env.JWT_SECRET
     if (!secret) {
       console.error('JWT_SECRET not configured')
       return false
     }

     try {
       verify(token, secret)
       return true
     } catch (error) {
       return false
     }
   }
   ```

## Migration Path

### Phase 1: Development (Current)
- ✅ `ALLOW_PUBLIC_GET_ENDPOINTS` enables public GET access
- ✅ No frontend authentication required
- ✅ Rapid development and testing

### Phase 2: Staging
- Add authentication context to frontend
- Update all API hooks to include Bearer tokens
- Test with real JWT tokens
- Keep `ALLOW_PUBLIC_GET_ENDPOINTS` for backwards compatibility

### Phase 3: Production
- Remove `ALLOW_PUBLIC_GET_ENDPOINTS` entirely
- Full authentication enforcement
- All requests require valid JWT tokens
- Security headers and CSRF protection active

## Files Modified

1. **K:\00Project\MantisNXT\.env.local**
   - Added `ALLOW_PUBLIC_GET_ENDPOINTS` configuration

2. **K:\00Project\MantisNXT\.env.example**
   - Added documentation for `ALLOW_PUBLIC_GET_ENDPOINTS`

3. **K:\00Project\MantisNXT\src\app\api\inventory\enhanced\route.ts**
   - Added `withAuth` middleware import
   - Wrapped GET handler with `withAuth`

## Verification Checklist

- [x] Environment variable added to .env.local
- [x] Environment variable documented in .env.example
- [x] All inventory endpoints use consistent auth middleware
- [x] Development server can be restarted successfully
- [x] Previously failing endpoints now return 200 OK
- [x] Frontend hooks no longer throw 401 errors
- [x] Production security path documented

## Additional Notes

### Why Not Remove Auth Entirely?

We kept the authentication middleware in place because:

1. **Production Ready** - Code is ready for production deployment
2. **Security by Default** - Fail secure when env var is missing
3. **Gradual Migration** - Allows adding auth without code changes
4. **Best Practices** - Maintains security model throughout

### Alternative Approaches Considered

1. **Remove withAuth from all routes** ❌
   - Would require re-adding for production
   - Security regression risk

2. **Add auth tokens to frontend immediately** ❌
   - Blocks development velocity
   - Requires full auth infrastructure

3. **Use API keys instead of JWT** ❌
   - Less flexible for multi-user scenarios
   - Harder to implement role-based access

4. **Current approach: Transitional public GET** ✅
   - Maintains security model
   - Enables rapid development
   - Clear migration path

## Support and Troubleshooting

### Still Getting 401 Errors?

1. **Check server restart**:
   ```bash
   # Ensure server loaded new env vars
   pkill -f "next dev"
   npm run dev
   ```

2. **Verify .env.local syntax**:
   ```bash
   # No spaces around = sign
   # No quotes around value
   ALLOW_PUBLIC_GET_ENDPOINTS=/api/suppliers,/api/inventory
   ```

3. **Check endpoint prefix**:
   The endpoint must START with one of the configured prefixes:
   - `/api/suppliers/123` ✅ matches `/api/suppliers`
   - `/api/supplier/123` ❌ does NOT match `/api/suppliers`

4. **Check HTTP method**:
   Only GET requests are allowed without auth:
   - `GET /api/suppliers` ✅ allowed
   - `POST /api/suppliers` ❌ requires auth
   - `PUT /api/suppliers/123` ❌ requires auth

### Need Help?

Contact the development team with:
- Exact endpoint URL causing issues
- HTTP method (GET, POST, etc.)
- Current .env.local configuration
- Server console logs
- Browser network tab screenshot

---

**Last Updated**: 2025-10-13
**Created By**: Claude Code
**Issue**: Authentication/Authorization 401 Errors
**Status**: ✅ Resolved
