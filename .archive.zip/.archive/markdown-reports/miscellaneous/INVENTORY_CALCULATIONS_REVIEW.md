# Inventory Calculations & Metrics — Phase 2

## Summary
- Replaced hardcoded turnover with computed metric derived from outbound movements and average inventory.
- Replaced mock movement data with queries to `stock_movements`.
- Standardized stock status derivation and turnover calculation across endpoints.
- Ensured `status = 'active'` filter in analytics.
- Consolidated utility logic to avoid duplication.

## Code Changes
- Added `src/lib/utils/inventory-metrics.ts` (turnover, fillRate, status helper, moving average utilities).
- Updated analytics endpoint:
  - `src/app/api/inventory/analytics/route.ts`
  - Provides: `forecastAccuracy`, `fillRate`, `criticalItems`, `excessStockValue`, `deadStockValue`, `turnover`.
- Added trends endpoint:
  - `src/app/api/inventory/trends/route.ts` — series from `stock_movements`, aligned formula.

## Schema References
- Reads `inventory_items` (compat view) with `status='active'`.
- Reads `stock_movements` for inbound/outbound events.

## Notes
- Turnover uses outbound quantity / average inventory snapshot as an approximation in-app.
- Fill rate currently proxies fulfilled vs requested; enhance once request baselines are present.

