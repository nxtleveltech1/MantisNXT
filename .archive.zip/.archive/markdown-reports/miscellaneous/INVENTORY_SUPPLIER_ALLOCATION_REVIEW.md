# Supplier Allocation & Association — Phase 3

## Summary
- Introduced `inventory_allocations` to support supplier-linked allocations and consignments.
- Implemented allocation operations in API:
  - `allocate_to_supplier`, `deallocate_from_supplier`, `transfer_allocation`, `consignment_in`, `consignment_out`.
- Added stock movement records for each adjustment.
- Added UI hooks and actions to Supplier view; extended store with allocation helpers.

## Code Changes
- Migration: `migrations/0202_inventory_allocations.sql` — table with validations and indexes.
- API: `src/app/api/suppliers/[id]/inventory/route.ts` — transactional operations with validation.
- Store: `src/lib/stores/inventory-store.ts` — `allocateToSupplier`, `deallocateFromSupplier`, `consignmentIn`, `consignmentOut` helpers.
- UI: `src/components/inventory/SupplierInventoryView.tsx` — allocation action handlers and notifications.

## Validation & Audit
- Prevent negative stock and ensure `reserved_qty <= stock_qty`.
- Allocation inserts recorded in `stock_movements` with appropriate reasons.
- Optional `expires_at` for time-bound allocations.

