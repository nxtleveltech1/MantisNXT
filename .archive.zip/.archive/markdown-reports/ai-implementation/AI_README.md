# AI Features - MantisNXT

## 🤖 AI-Powered Procurement Intelligence

MantisNXT is equipped with enterprise-grade AI capabilities powered by **Vercel AI SDK v5**.

---

## ⚡ Quick Setup

### 1. Install Dependencies (Already Done ✅)

```bash
npm install
```

Dependencies:
- `ai` v5.0.0 - Vercel AI SDK
- `@ai-sdk/anthropic` - Claude provider
- `@ai-sdk/openai` - OpenAI provider
- `@ai-sdk/gateway` - Vercel AI Gateway
- `@ai-sdk/vercel` - Vercel integration

### 2. Add API Key

Edit `.env.local`:

```bash
# Anthropic (Recommended)
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here

# OR OpenAI (Alternative)
OPENAI_API_KEY=sk-your-key-here
```

Get keys:
- Anthropic: https://console.anthropic.com/
- OpenAI: https://platform.openai.com/api-keys

### 3. Verify & Test

```bash
npm run ai:verify    # Verify configuration
npm run ai:test      # Test AI generation
```

---

## 🎯 AI Features Available

### ✅ Currently Implemented

- **Text Generation** - Generate text from prompts
- **Streaming Responses** - Real-time text streaming
- **Chat Completion** - Multi-turn conversations
- **Embeddings** - Semantic search (OpenAI only)
- **Automatic Failover** - Provider redundancy
- **Health Monitoring** - Provider status tracking
- **Usage Analytics** - Token & cost tracking

### 🚀 Ready to Implement

**Supplier Intelligence:**
- Supplier discovery & analysis
- Contract summarization
- Risk assessment
- Performance predictions

**Inventory Optimization:**
- Demand forecasting
- Reorder point recommendations
- Stock level optimization
- Trend analysis

**Document Processing:**
- Invoice parsing
- PO generation
- Contract extraction
- Compliance checking

**Analytics & Insights:**
- Spending pattern analysis
- Anomaly detection
- Cost optimization suggestions
- Market intelligence

---

## 🔧 Provider Configuration

### Configured Providers

| Provider | Status | Capabilities |
|----------|--------|--------------|
| **Anthropic Claude** | ✅ Ready | Text, Streaming, Chat |
| **OpenAI GPT-4** | ✅ Ready | Text, Streaming, Chat, Embeddings |
| **Vercel AI Gateway** | ⚙️ Optional | Routing, Load Balancing |
| **Custom (Groq, etc.)** | ⚙️ Optional | Depends on provider |

### Fallback Chain

```
Primary: Anthropic Claude 3.5 Sonnet
    ↓ (if unavailable)
Secondary: OpenAI GPT-4
    ↓ (if unavailable)
Tertiary: Vercel AI Gateway
    ↓ (if unavailable)
Final: Custom Provider
```

---

## 💻 Code Examples

### Basic AI Generation

```typescript
import { getProviderClient } from '@/lib/ai/providers';

// Get client
const ai = getProviderClient('anthropic');

// Generate text
const result = await ai.generateText(
  "Analyze supplier performance for Q4",
  {
    temperature: 0.3,
    maxTokens: 500
  }
);

console.log(result.text);
```

### Streaming Response

```typescript
const stream = await ai.streamText(
  "Generate procurement insights"
);

for await (const chunk of stream) {
  process.stdout.write(chunk.token);
  if (chunk.done) break;
}
```

### Chat Conversation

```typescript
const result = await ai.chat([
  {
    role: 'system',
    content: 'You are a procurement analyst.'
  },
  {
    role: 'user',
    content: 'What are our top spending categories?'
  }
], {
  temperature: 0.3
});

console.log(result.text);
```

### API Route

```typescript
// /src/app/api/ai/analyze/route.ts
import { getProviderClient } from '@/lib/ai/providers';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const { prompt, provider = 'anthropic' } = await request.json();

  const ai = getProviderClient(provider);
  const result = await ai.generateText(prompt, {
    temperature: 0.3,
    maxTokens: 1000
  });

  return NextResponse.json({
    text: result.text,
    model: result.model,
    tokens: result.usage?.totalTokens
  });
}
```

### React Component

```typescript
'use client';

import { useState } from 'react';
import { getProviderClient } from '@/lib/ai/providers';

export function AIAnalyzer() {
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    setLoading(true);

    const ai = getProviderClient('anthropic');
    const response = await ai.generateText(
      "Analyze procurement trends"
    );

    setResult(response.text);
    setLoading(false);
  };

  return (
    <div>
      <button onClick={analyze} disabled={loading}>
        {loading ? 'Analyzing...' : 'Analyze'}
      </button>
      <p>{result}</p>
    </div>
  );
}
```

---

## 🎨 Use Cases

### Supplier Management

**Supplier Discovery:**
```typescript
const ai = getProviderClient('anthropic');
const result = await ai.generateText(
  `Find suppliers for: ${productCategory}
   Location: ${location}
   Requirements: ${requirements}`
);
```

**Risk Assessment:**
```typescript
const analysis = await ai.chat([
  { role: 'system', content: 'You are a supply chain risk analyst.' },
  { role: 'user', content: `Assess risk for supplier: ${supplierData}` }
]);
```

### Inventory Intelligence

**Demand Forecasting:**
```typescript
const forecast = await ai.generateText(
  `Forecast demand for next quarter based on:
   Historical data: ${historicalData}
   Market trends: ${trends}`
);
```

**Reorder Recommendations:**
```typescript
const recommendation = await ai.generateText(
  `Recommend reorder points for:
   Product: ${product}
   Current stock: ${currentStock}
   Lead time: ${leadTime}`
);
```

### Document Processing

**Invoice Parsing:**
```typescript
const parsed = await ai.generateText(
  `Extract structured data from invoice:
   ${invoiceText}`,
  { responseFormat: 'json' }
);
```

**Contract Summarization:**
```typescript
const summary = await ai.generateText(
  `Summarize key terms from contract:
   ${contractText}`
);
```

---

## 📊 Monitoring & Analytics

### Usage Tracking

```typescript
import { onAIUsage } from '@/lib/ai/providers';

// Subscribe to usage events
onAIUsage((event) => {
  console.log({
    provider: event.provider,
    model: event.model,
    tokens: event.totalTokens,
    duration: event.durationMs,
    cost: event.costInCents
  });
});
```

### Health Monitoring

```typescript
import { getAllProviderHealthStatus } from '@/lib/ai/providers';

const health = await getAllProviderHealthStatus();

health.forEach(status => {
  console.log(`${status.id}: ${status.status}`);
  // → 'anthropic: healthy'
});
```

---

## ⚙️ Configuration

### Environment Variables

```env
# Provider Selection
DEFAULT_AI_PROVIDER=anthropic
AI_FALLBACK_ORDER=anthropic,openai,vercel

# Features
ENABLE_AI_FEATURES=true
ENABLE_AI_STREAMING=true
ENABLE_AI_FALLBACK=true

# Model Settings
AI_MAX_TOKENS=8192
AI_TEMPERATURE=0.2
AI_REQUEST_TIMEOUT=30000

# Monitoring
AI_ANALYTICS_ENABLED=true
AI_MONITORING_ENABLED=true
AI_HEALTHCHECK_INTERVAL_MS=60000
```

### Runtime Configuration

```typescript
import { updateAIConfig } from '@/lib/ai/config';

// Update configuration dynamically
updateAIConfig({
  defaultProvider: 'openai',
  temperature: 0.5,
  maxTokens: 4000
});
```

---

## 🔒 Security

### API Key Management

✅ **Environment Variables** (Development):
```env
ANTHROPIC_API_KEY=sk-ant-...
```

✅ **File-based Secrets** (Production):
```env
ANTHROPIC_API_KEY_FILE=/run/secrets/anthropic_key
```

✅ **Secret Directory** (Docker/K8s):
```env
AI_SECRETS_DIR=/run/secrets
```

### Rate Limiting

Automatic rate limiting per provider:
- OpenAI: 500 req/min, 8 concurrent
- Anthropic: 200 req/min, 4 concurrent

---

## 📈 Performance

### Model Selection

**For Speed:**
- `claude-3-5-haiku-latest` (fastest)
- `gpt-4o-mini` (fast)

**For Quality:**
- `claude-3-5-sonnet-latest` (best)
- `gpt-4-turbo` (excellent)

**For Cost:**
- `claude-3-5-haiku-latest` (economical)
- `gpt-4o-mini` (affordable)

### Optimization Tips

1. **Use Streaming** - Better UX for long responses
2. **Set Token Limits** - Control costs
3. **Cache Responses** - Reduce duplicate requests
4. **Choose Right Model** - Balance speed/quality/cost

---

## 🛠 NPM Scripts

```bash
# Verification & Testing
npm run ai:verify      # Verify provider configuration
npm run ai:test        # Test default provider
npm run ai:test:all    # Test all providers

# Development
npm run dev           # Start dev server (AI enabled)
npm run build         # Build for production
npm run start         # Start production server
```

---

## 📚 Documentation

### Complete Guides
- **[Configuration Report](./AI_PROVIDER_CONFIGURATION_REPORT.md)** - Full technical reference
- **[Quick Start Guide](./AI_QUICK_START.md)** - 5-minute setup guide
- **[Configuration Summary](./AI_CONFIGURATION_SUMMARY.md)** - Overview & examples

### Key Files
- `/src/lib/ai/providers.ts` - Provider implementation
- `/src/lib/ai/config.ts` - Configuration management
- `/src/types/ai.ts` - TypeScript types
- `/scripts/verify-ai-providers.js` - Verification script
- `/scripts/test-ai-generation.js` - Test suite

---

## 🐛 Troubleshooting

### Common Issues

**Provider Not Available:**
```bash
# Error: Provider not enabled
# Fix: Add API key to .env.local
ANTHROPIC_API_KEY=sk-ant-...
```

**Rate Limit Exceeded:**
```env
# Reduce concurrency or enable fallback
ENABLE_AI_FALLBACK=true
```

**Timeout Errors:**
```env
# Increase timeout
AI_REQUEST_TIMEOUT=60000
```

**No Embeddings:**
```bash
# Use OpenAI for embeddings
OPENAI_API_KEY=sk-...
const ai = getProviderClient('openai');
```

---

## 🎯 Roadmap

### Phase 1: Foundation ✅
- [x] Provider configuration
- [x] Automatic failover
- [x] Health monitoring
- [x] Usage analytics

### Phase 2: Features (In Progress)
- [ ] Supplier intelligence
- [ ] Document processing
- [ ] Inventory optimization
- [ ] Market insights

### Phase 3: Advanced
- [ ] Custom fine-tuning
- [ ] Multi-modal analysis
- [ ] Voice integration
- [ ] Predictive analytics

---

## 🔗 External Resources

### API Documentation
- [Vercel AI SDK](https://sdk.vercel.ai/docs)
- [Anthropic Claude](https://docs.anthropic.com/claude/reference)
- [OpenAI API](https://platform.openai.com/docs)

### Provider Dashboards
- [Anthropic Console](https://console.anthropic.com/)
- [OpenAI Platform](https://platform.openai.com/)
- [Vercel Dashboard](https://vercel.com/dashboard)

---

## 📞 Support

### Get Help
- Check [Troubleshooting](#-troubleshooting) section
- Review [Documentation](#-documentation)
- Run `npm run ai:verify` for diagnostics

### Contribute
- Report issues
- Suggest features
- Submit PRs

---

**Status**: ✅ Production Ready
**SDK Version**: Vercel AI SDK v5
**Last Updated**: 2025-10-01
