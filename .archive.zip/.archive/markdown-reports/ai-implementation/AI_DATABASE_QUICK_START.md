# AI Database Integration - Quick Start Guide

**5-Minute Setup for MantisNXT AI Database Features**

---

## Prerequisites

✅ MantisNXT running on http://localhost:3000
✅ PostgreSQL database accessible
✅ Anthropic API key configured in `.env.local`
✅ OpenAI API key configured (optional, for fallback)

---

## Step 1: Run Database Migration

```bash
# Connect to database and run migration
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001 \
  -f database/migrations/003_ai_database_integration.sql
```

**Expected output:**
```
CREATE TABLE
CREATE TABLE
CREATE TABLE
CREATE VIEW
CREATE VIEW
CREATE FUNCTION
COMMIT
```

---

## Step 2: Verify Installation

```bash
# Start development server
npm run dev

# Run test suite (in new terminal)
node scripts/test-ai-database.js
```

**Expected result:**
```
✓ All tests passing
Pass Rate: 100%
```

---

## Step 3: Try Your First AI Query

### Option A: Using cURL

```bash
curl -X POST http://localhost:3000/api/ai/data/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Show me the top 5 suppliers by inventory value"
  }' | jq
```

### Option B: Using Postman/Thunder Client

**URL:** `POST http://localhost:3000/api/ai/data/query`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "query": "Show me the top 5 suppliers by inventory value"
}
```

### Option C: Using JavaScript (Frontend)

```javascript
const response = await fetch('/api/ai/data/query', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    query: 'Show me the top 5 suppliers by inventory value'
  })
});

const data = await response.json();
console.log(data);
```

---

## Common Queries to Try

```javascript
// Natural Language Queries
const queries = [
  "Show me suppliers with more than 100 products",
  "Which products have low stock levels?",
  "Find the top 10 best-selling products",
  "Show recent purchase orders from last month",
  "Which suppliers have the highest order values?"
];

// Data Analysis
const analysis = {
  table: "inventory_items",
  focus: "trends" // or 'risks', 'opportunities', 'patterns', 'all'
};

// Anomaly Detection
const anomalyCheck = {
  table: "suppliers",
  checks: ["data_quality", "statistical", "business_rule"]
};

// Predictions
const prediction = {
  type: "inventory_demand", // or 'supplier_performance', 'stock_levels'
  forecast_days: 30
};
```

---

## API Endpoint Reference

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/ai/data/query` | POST | Natural language to SQL |
| `/api/ai/data/analyze` | POST | Data analysis with insights |
| `/api/ai/data/anomalies` | POST | Anomaly detection |
| `/api/ai/data/predictions` | POST | Predictive analytics |

**Get endpoint info:**
```bash
curl http://localhost:3000/api/ai/data/query
# Returns usage examples and schema
```

---

## Monitoring

### Check AI Health

```sql
-- Connect to database
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001

-- Check health score
SELECT * FROM get_ai_health_score();

-- View recent queries
SELECT * FROM ai_query_history
ORDER BY created_at DESC
LIMIT 10;

-- Check anomalies
SELECT * FROM v_ai_anomaly_summary;

-- View prediction stats
SELECT * FROM v_ai_prediction_stats;
```

### Performance Dashboard

```sql
-- Query performance trends
SELECT * FROM v_ai_query_performance
WHERE hour > NOW() - INTERVAL '24 hours'
ORDER BY hour DESC;

-- Success rate
SELECT
  DATE(created_at) as date,
  COUNT(*) as total_queries,
  AVG(CASE WHEN success THEN 1.0 ELSE 0.0 END) * 100 as success_rate,
  AVG(execution_time_ms) as avg_time_ms
FROM ai_query_history
WHERE created_at > NOW() - INTERVAL '7 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;
```

---

## Troubleshooting

### Issue: "Server not responding"
```bash
# Check if server is running
lsof -i :3000

# Start server
npm run dev
```

### Issue: "Database connection failed"
```bash
# Test database connection
node scripts/test-db-connection.js

# Check environment variables
grep DATABASE .env.local
```

### Issue: "AI API key not configured"
```bash
# Verify API keys
grep ANTHROPIC_API_KEY .env.local
grep OPENAI_API_KEY .env.local

# Add keys if missing
echo "ANTHROPIC_API_KEY=sk-ant-..." >> .env.local
echo "OPENAI_API_KEY=sk-..." >> .env.local
```

### Issue: "Query rejected for safety"
**Cause:** AI detected potentially unsafe query

**Solutions:**
1. Rephrase query to be more specific
2. Ensure read-only intent
3. Check logs for safety score

### Issue: "Analysis failed - no data"
```sql
-- Check if tables have data
SELECT
  'suppliers' as table_name, COUNT(*) as row_count FROM suppliers
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'inventory_items', COUNT(*) FROM inventory_items;
```

---

## Next Steps

1. **Integrate into UI:**
   - Add AI query interface to dashboard
   - Display anomaly alerts
   - Show prediction charts

2. **Customize Prompts:**
   - Edit schemas in `/src/lib/ai/database-integration.ts`
   - Adjust safety thresholds
   - Add business-specific rules

3. **Set Up Monitoring:**
   - Create dashboard for AI metrics
   - Set up alerts for anomalies
   - Track token usage

4. **Optimize Performance:**
   - Add caching layers
   - Implement rate limiting
   - Set up prediction pre-computation

---

## Example Use Cases

### 1. Daily Inventory Report
```javascript
// scripts/daily-inventory-report.js
import { aiDatabase } from '@/lib/ai/database-integration';

const report = await aiDatabase.analyzeData({
  table: 'inventory_items',
  focus: 'all'
});

const anomalies = await aiDatabase.detectAnomalies({
  table: 'inventory_items',
  checks: ['data_quality', 'business_rule']
});

const predictions = await aiDatabase.generatePredictions({
  type: 'stock_levels',
  forecast_days: 30
});

console.log(`
Daily Inventory Report
======================
Data Quality Score: ${report.metrics.data_quality_score}
Insights Found: ${report.insights.length}
Anomalies Detected: ${anomalies.anomalies.length}
30-Day Forecast: ${predictions.predictions.length} predictions
`);
```

### 2. Supplier Performance Dashboard
```javascript
const supplierAnalysis = await aiDatabase.executeNaturalLanguageQuery(
  "Compare supplier performance by delivery time and order value"
);

const supplierPredictions = await aiDatabase.generatePredictions({
  type: 'supplier_performance',
  forecast_days: 60
});
```

### 3. Automated Alerts
```javascript
const criticalAnomalies = await aiDatabase.detectAnomalies({
  table: 'products',
  checks: ['data_quality', 'security']
});

const critical = criticalAnomalies.anomalies.filter(
  a => a.severity === 'critical'
);

if (critical.length > 0) {
  sendAlert({
    to: 'admin@company.com',
    subject: `${critical.length} Critical Anomalies Detected`,
    body: critical.map(a => a.description).join('\n')
  });
}
```

---

## Performance Tips

1. **Use Caching:**
   - Predictions are cached for 24 hours
   - Repeated queries use cached SQL
   - Enable Redis for better caching

2. **Limit Result Sizes:**
   ```javascript
   await aiDatabase.executeNaturalLanguageQuery(query, {
     limit: 100 // Don't fetch thousands of rows
   });
   ```

3. **Pre-compute Predictions:**
   ```javascript
   // Run nightly via cron
   cron.schedule('0 0 * * *', async () => {
     await aiDatabase.generatePredictions({
       type: 'inventory_demand',
       forecast_days: 30
     });
   });
   ```

4. **Monitor Token Usage:**
   - Track costs in Anthropic/OpenAI dashboard
   - Set budget alerts
   - Optimize prompts to reduce tokens

---

## Security Checklist

- [ ] API keys stored in environment variables (not code)
- [ ] Database user has read-only permissions
- [ ] Rate limiting implemented on API routes
- [ ] User authentication required for AI endpoints
- [ ] Query logs reviewed regularly for suspicious activity
- [ ] Safety score threshold set appropriately (0.8+)
- [ ] Input validation on all endpoints

---

## Support

**Documentation:** `/AI_DATABASE_INTEGRATION_COMPLETE.md`
**Test Suite:** `node scripts/test-ai-database.js`
**API Info:** `GET /api/ai/data/{endpoint}`
**Database Schema:** `database/migrations/003_ai_database_integration.sql`

**Health Check:**
```bash
# Quick health check
curl http://localhost:3000/api/health/database
```

---

**Ready to Go!** 🚀

Your AI Database Integration is now configured and ready to transform raw data into actionable intelligence.

Try your first query:
```bash
curl -X POST http://localhost:3000/api/ai/data/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Show me everything"}' | jq
```
