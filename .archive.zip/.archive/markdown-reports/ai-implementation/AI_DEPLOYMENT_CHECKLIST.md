# AI Provider Deployment Checklist

## 📋 Pre-Deployment Verification

### ✅ 1. Dependencies Check

- [x] `ai` v5.0.0 installed
- [x] `@ai-sdk/anthropic` installed
- [x] `@ai-sdk/openai` installed
- [x] `@ai-sdk/gateway` installed
- [x] All TypeScript types configured

**Verify:**
```bash
npm list ai @ai-sdk/anthropic @ai-sdk/openai @ai-sdk/gateway
```

---

### ✅ 2. Provider Configuration

#### Anthropic (Primary Provider)
- [ ] API key obtained from https://console.anthropic.com/
- [ ] `ANTHROPIC_API_KEY` added to `.env.local` (dev) or `.env.production` (prod)
- [ ] Base URL configured (optional)
- [ ] Timeout settings configured

**Environment Variables:**
```env
ANTHROPIC_API_KEY=sk-ant-api03-...
ANTHROPIC_BASE_URL=https://api.anthropic.com/v1  # Optional
AI_ANTHROPIC_TIMEOUT_MS=30000
AI_ANTHROPIC_MAX_RETRIES=2
```

#### OpenAI (Secondary Provider)
- [ ] API key obtained from https://platform.openai.com/api-keys
- [ ] `OPENAI_API_KEY` added to environment
- [ ] Organization/Project IDs configured (optional)

**Environment Variables:**
```env
OPENAI_API_KEY=sk-...
OPENAI_ORGANIZATION=org-...  # Optional
OPENAI_PROJECT=proj-...      # Optional
AI_OPENAI_TIMEOUT_MS=30000
AI_OPENAI_MAX_RETRIES=2
```

#### Vercel AI Gateway (Optional)
- [ ] Gateway token obtained from https://vercel.com/dashboard
- [ ] Gateway URL configured
- [ ] Routing rules set up

**Environment Variables:**
```env
VERCEL_AI_GATEWAY_TOKEN=...
VERCEL_AI_GATEWAY_URL=https://gateway.vercel.com/v1
```

---

### ✅ 3. Global Configuration

- [ ] Default provider selected
- [ ] Fallback order configured
- [ ] Feature flags enabled
- [ ] Token limits set
- [ ] Temperature configured
- [ ] Timeout settings appropriate

**Environment Variables:**
```env
DEFAULT_AI_PROVIDER=anthropic
AI_FALLBACK_ORDER=anthropic,openai,vercel
ENABLE_AI_FEATURES=true
ENABLE_AI_STREAMING=true
ENABLE_AI_FALLBACK=true
AI_MAX_TOKENS=8192
AI_TEMPERATURE=0.2
AI_REQUEST_TIMEOUT=30000
```

---

### ✅ 4. Security Configuration

#### Development
- [ ] `.env.local` created and git-ignored
- [ ] API keys not committed to git
- [ ] `.env.example` updated with placeholders

#### Production
- [ ] Secrets stored securely (not in code)
- [ ] File-based secrets configured (Docker/K8s)
- [ ] Secret directory permissions set correctly
- [ ] API keys rotated regularly

**Security Options:**
```env
# Option 1: Direct environment variables
ANTHROPIC_API_KEY=sk-ant-...

# Option 2: File-based secrets (Recommended for prod)
ANTHROPIC_API_KEY_FILE=/run/secrets/anthropic_key

# Option 3: Secret directory
AI_SECRETS_DIR=/run/secrets
```

---

### ✅ 5. Monitoring & Analytics

- [ ] Analytics enabled
- [ ] Sample rate configured
- [ ] Event name set
- [ ] Health monitoring enabled
- [ ] Health check interval appropriate
- [ ] Latency tracking enabled

**Environment Variables:**
```env
AI_ANALYTICS_ENABLED=true
AI_ANALYTICS_SAMPLE_RATE=1.0
AI_ANALYTICS_EVENT_NAME=ai.usage
AI_MONITORING_ENABLED=true
AI_HEALTHCHECK_INTERVAL_MS=60000
AI_UNHEALTHY_THRESHOLD=3
AI_RECOVERY_WINDOW_MS=300000
AI_MONITOR_LATENCY=true
```

---

## 🧪 Testing & Validation

### ✅ 1. Configuration Verification

- [ ] Run verification script
- [ ] All providers detected correctly
- [ ] Default provider configured
- [ ] Fallback chain working

**Commands:**
```bash
npm run ai:verify
```

**Expected Output:**
```
✅ Dependencies installed
✅ Anthropic configured
✅ Default provider: anthropic
✅ Fallback chain: anthropic → openai
✅ Analytics enabled
✅ Monitoring enabled
```

---

### ✅ 2. Provider Testing

- [ ] Test default provider
- [ ] Test text generation
- [ ] Test streaming
- [ ] Test chat completion
- [ ] Test embeddings (if OpenAI)
- [ ] Test all providers

**Commands:**
```bash
npm run ai:test          # Test default provider
npm run ai:test:all      # Test all providers
```

**Expected Results:**
- ✅ Text generation working
- ✅ Streaming responses working
- ✅ Chat completion working
- ✅ Embeddings working (OpenAI only)
- ✅ Error handling functional

---

### ✅ 3. Failover Testing

- [ ] Primary provider fails gracefully
- [ ] Fallback to secondary provider works
- [ ] Health status updates correctly
- [ ] Circuit breaker activates
- [ ] Recovery mechanism works

**Manual Test:**
```typescript
// Temporarily disable primary
process.env.ANTHROPIC_API_KEY = 'invalid';

// Should fallback to OpenAI
const client = getProviderClient('anthropic');
const result = await client.generateText("test");
// Should use OpenAI instead
```

---

### ✅ 4. Performance Testing

- [ ] Response time acceptable
- [ ] Streaming latency low
- [ ] Token usage as expected
- [ ] Concurrent requests handled
- [ ] Memory usage stable

**Performance Benchmarks:**
- Text generation: < 3s
- Streaming first token: < 500ms
- Chat completion: < 2s
- Embeddings: < 1s
- Health check: < 500ms

---

## 🚀 Deployment Steps

### ✅ 1. Environment Setup

#### Development
- [ ] Copy `.env.production.example` to `.env.local`
- [ ] Add development API keys
- [ ] Set `NODE_ENV=development`
- [ ] Enable debug logging

#### Staging
- [ ] Configure staging environment variables
- [ ] Use separate API keys from production
- [ ] Enable full monitoring
- [ ] Test with production-like data

#### Production
- [ ] Configure production environment variables
- [ ] Use production API keys
- [ ] Enable monitoring & analytics
- [ ] Configure alerts
- [ ] Set appropriate rate limits

---

### ✅ 2. Build & Deploy

- [ ] Run TypeScript type check
- [ ] Build application
- [ ] Verify build includes AI modules
- [ ] Deploy to target environment
- [ ] Verify environment variables loaded

**Commands:**
```bash
npm run type-check     # TypeScript validation
npm run build          # Build for production
npm run start          # Start production server
```

---

### ✅ 3. Post-Deployment Verification

- [ ] Health endpoint responding
- [ ] AI features accessible
- [ ] Provider status healthy
- [ ] Fallback chain working
- [ ] Analytics collecting data
- [ ] Logs clean (no errors)

**Health Check:**
```bash
curl http://localhost:3000/api/health
curl http://localhost:3000/api/ai/health  # If implemented
```

---

## 📊 Monitoring Setup

### ✅ 1. Usage Analytics

- [ ] Analytics platform integrated
- [ ] Usage events tracked
- [ ] Token consumption monitored
- [ ] Cost tracking enabled
- [ ] Dashboards created

**Integration Example:**
```typescript
import { onAIUsage } from '@/lib/ai/providers';

onAIUsage((event) => {
  analytics.track('ai_usage', {
    provider: event.provider,
    tokens: event.totalTokens,
    cost: event.costInCents,
    duration: event.durationMs
  });
});
```

---

### ✅ 2. Health Monitoring

- [ ] Health checks scheduled
- [ ] Provider status dashboard
- [ ] Alert rules configured
- [ ] Incident response plan
- [ ] Escalation procedures

**Health Metrics:**
- Provider status (healthy/degraded/unhealthy)
- Response latency (ms)
- Error rate (%)
- Token usage (tokens/min)
- Cost ($/hour)

---

### ✅ 3. Alerting

- [ ] Low quota alerts
- [ ] Rate limit alerts
- [ ] Provider down alerts
- [ ] High latency alerts
- [ ] Cost threshold alerts

**Alert Conditions:**
```yaml
alerts:
  - name: "Provider Unhealthy"
    condition: "status == 'unhealthy'"
    severity: "critical"

  - name: "High Latency"
    condition: "latencyMs > 5000"
    severity: "warning"

  - name: "Rate Limit Approaching"
    condition: "usage > 0.9 * limit"
    severity: "warning"

  - name: "Cost Threshold"
    condition: "dailyCost > $100"
    severity: "info"
```

---

## 🔒 Security Checklist

### ✅ 1. API Key Security

- [ ] Keys stored in secure vault
- [ ] No keys in source code
- [ ] No keys in logs
- [ ] No keys in error messages
- [ ] Keys rotated regularly
- [ ] Access audited

---

### ✅ 2. Access Control

- [ ] Role-based access control
- [ ] API usage limits per user
- [ ] Request authentication
- [ ] Rate limiting per user
- [ ] Audit logging enabled

---

### ✅ 3. Data Privacy

- [ ] PII not sent to AI
- [ ] Data retention policies
- [ ] GDPR compliance
- [ ] Data anonymization
- [ ] User consent obtained

---

## 📈 Optimization

### ✅ 1. Cost Optimization

- [ ] Appropriate models selected
- [ ] Token limits configured
- [ ] Response caching enabled
- [ ] Batch requests used
- [ ] Sample rate optimized

**Cost Reduction Strategies:**
```typescript
// Use cheaper models for simple tasks
const result = await ai.generateText(prompt, {
  model: 'claude-3-5-haiku-latest',  // Cheaper
  maxTokens: 500,                     // Limit length
  temperature: 0.3                    // More focused
});

// Cache responses
const cache = new Map();
const cacheKey = hash(prompt);
if (cache.has(cacheKey)) {
  return cache.get(cacheKey);
}
```

---

### ✅ 2. Performance Optimization

- [ ] Streaming enabled for UX
- [ ] Concurrent requests optimized
- [ ] Timeout values tuned
- [ ] Connection pooling configured
- [ ] CDN caching enabled

---

### ✅ 3. Reliability

- [ ] Multiple providers configured
- [ ] Fallback chain tested
- [ ] Circuit breaker working
- [ ] Retry logic implemented
- [ ] Graceful degradation

---

## 🎯 Go-Live Checklist

### Final Verification

- [ ] All tests passing
- [ ] Documentation complete
- [ ] Team trained
- [ ] Support procedures documented
- [ ] Rollback plan prepared
- [ ] Monitoring active
- [ ] Alerts configured
- [ ] Budget approved

### Go-Live Steps

1. **Pre-deployment**
   - [ ] Final code review
   - [ ] Security audit
   - [ ] Load testing
   - [ ] Staging validation

2. **Deployment**
   - [ ] Deploy to production
   - [ ] Verify health checks
   - [ ] Monitor for errors
   - [ ] Validate functionality

3. **Post-deployment**
   - [ ] Monitor usage
   - [ ] Check performance
   - [ ] Review costs
   - [ ] Gather feedback

---

## 📞 Support & Resources

### Documentation
- [Configuration Report](./AI_PROVIDER_CONFIGURATION_REPORT.md)
- [Quick Start Guide](./AI_QUICK_START.md)
- [Configuration Summary](./AI_CONFIGURATION_SUMMARY.md)
- [AI Features README](./AI_README.md)

### Scripts
```bash
npm run ai:verify      # Verify configuration
npm run ai:test        # Test providers
npm run ai:test:all    # Test all providers
```

### External Resources
- [Vercel AI SDK Docs](https://sdk.vercel.ai/docs)
- [Anthropic API Docs](https://docs.anthropic.com/claude/reference)
- [OpenAI API Docs](https://platform.openai.com/docs)

---

## ✅ Sign-Off

### Development Environment
- [ ] Configuration verified
- [ ] All tests passing
- [ ] Documentation reviewed
- [ ] Team approval

**Approved by:** _______________
**Date:** _______________

### Production Environment
- [ ] Security audit complete
- [ ] Performance validated
- [ ] Monitoring active
- [ ] Stakeholder approval

**Approved by:** _______________
**Date:** _______________

---

**Checklist Version**: 1.0
**Last Updated**: 2025-10-01
**Project**: MantisNXT AI Integration
