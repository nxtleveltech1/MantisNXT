# AI API Quick Start Guide
## MantisNXT - Vercel AI SDK v5

**Last Updated**: 2025-10-01

---

## 🚀 Quick Start (2 Minutes)

### Step 1: Add API Key

Edit `/mnt/k/00Project/MantisNXT/.env.local` and add your Anthropic API key:

```bash
# Add this line
ANTHROPIC_API_KEY=sk-ant-api03-YOUR_KEY_HERE

# Optional: Add OpenAI as fallback
OPENAI_API_KEY=sk-YOUR_KEY_HERE
```

### Step 2: Start Development Server

```bash
cd /mnt/k/00Project/MantisNXT
npm run dev
```

### Step 3: Test Basic Functionality

```bash
# Test chat endpoint
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello AI!"}]}'
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "conversationId": "conv_abc123",
    "response": {
      "success": true,
      "data": {
        "text": "Hello! How can I help you today?"
      }
    }
  }
}
```

✅ **If you see this response, AI is working!**

---

## 📋 Available Endpoints

### 1. **Chat API** - `/api/ai/chat`
Interactive AI conversation with history

```bash
# Basic chat
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Explain supply chain management"}
    ]
  }'

# Streaming response
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role": "user", "content": "Write a procurement policy"}],
    "stream": true
  }'
```

### 2. **Analysis API** - `/api/ai/analyze`
Business intelligence and data analysis

```bash
curl -X POST http://localhost:3000/api/ai/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "analysisType": "business",
    "objectives": ["Identify cost reduction opportunities"],
    "questions": ["What are the top 3 areas for improvement?"],
    "dataSources": [{
      "type": "inventory",
      "metrics": ["stock_level", "turnover_rate"]
    }]
  }'
```

### 3. **Text Generation API** - `/api/ai/generate`
Content, summaries, translations, and formatting

```bash
# Content generation
curl -X POST http://localhost:3000/api/ai/generate \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "content",
    "content": {
      "topic": "Sustainable procurement",
      "type": "article",
      "length": "brief"
    }
  }'

# Text summarization
curl -X POST http://localhost:3000/api/ai/generate \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "summarization",
    "summarization": {
      "text": "Your long text here...",
      "summaryType": "bullet",
      "targetLength": "short"
    }
  }'
```

### 4. **Supplier Discovery API** - `/api/ai/suppliers/discover`
AI-powered supplier search and matching

```bash
curl -X POST http://localhost:3000/api/ai/suppliers/discover \
  -H "Content-Type: application/json" \
  -d '{
    "query": "ISO certified steel manufacturers in Europe",
    "requirements": {
      "category": ["steel", "manufacturing"],
      "location": "Europe",
      "certifications": ["ISO9001"]
    }
  }'
```

### 5. **Predictive Analytics API** - `/api/ai/analytics/predictive`
Forecast future trends and metrics

```bash
curl -X POST http://localhost:3000/api/ai/analytics/predictive \
  -H "Content-Type: application/json" \
  -d '{
    "timeHorizon": "6months",
    "metrics": ["cost", "performance", "risk"]
  }'
```

### 6. **Anomaly Detection API** - `/api/ai/analytics/anomalies`
Detect unusual patterns in data

```bash
curl -X POST http://localhost:3000/api/ai/analytics/anomalies \
  -H "Content-Type: application/json" \
  -d '{
    "entityType": "supplier",
    "timeRange": {
      "start": "2025-01-01",
      "end": "2025-10-01"
    },
    "sensitivity": "medium",
    "metrics": ["cost", "delivery_time"]
  }'
```

### 7. **Insights Generation API** - `/api/ai/insights/generate`
Generate actionable business insights

```bash
curl -X POST http://localhost:3000/api/ai/insights/generate \
  -H "Content-Type: application/json" \
  -d '{
    "context": {"type": "portfolio"},
    "focusAreas": ["cost", "risk", "sustainability"],
    "timeFrame": {
      "start": "2025-01-01",
      "end": "2025-12-31"
    },
    "includeActions": true
  }'
```

---

## 🧪 Run Automated Tests

```bash
# Make script executable
chmod +x scripts/test-ai-endpoints.sh

# Run all tests
./scripts/test-ai-endpoints.sh

# Run with verbose output
VERBOSE=true ./scripts/test-ai-endpoints.sh
```

---

## 📊 Example Use Cases

### Use Case 1: Supplier Risk Analysis
```bash
curl -X POST http://localhost:3000/api/ai/insights/generate \
  -H "Content-Type: application/json" \
  -d '{
    "context": {"type": "supplier", "id": "supplier_123"},
    "focusAreas": ["risk", "performance"],
    "timeFrame": {
      "start": "2025-01-01",
      "end": "2025-12-31"
    },
    "includeActions": true
  }'
```

### Use Case 2: Cost Optimization Analysis
```bash
curl -X POST http://localhost:3000/api/ai/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "analysisType": "financial",
    "objectives": ["Reduce procurement costs by 15%"],
    "questions": [
      "Which categories have the highest cost reduction potential?",
      "What are the quick wins?",
      "What requires long-term strategy?"
    ],
    "dataSources": [{
      "type": "financial",
      "metrics": ["spend_by_category", "payment_terms", "discount_utilization"]
    }]
  }'
```

### Use Case 3: Document Summarization
```bash
curl -X POST http://localhost:3000/api/ai/generate \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "summarization",
    "summarization": {
      "text": "Your long procurement report or contract text...",
      "summaryType": "key_points",
      "targetLength": "medium",
      "includeQuotes": true
    }
  }'
```

### Use Case 4: Market Intelligence
```bash
curl http://localhost:3000/api/ai/insights/generate?category=electronics
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Required
ANTHROPIC_API_KEY=sk-ant-api03-...

# Optional - Fallback Providers
OPENAI_API_KEY=sk-...
VERCEL_AI_GATEWAY_TOKEN=your-token
VERCEL_AI_GATEWAY_URL=https://gateway.vercel.ai

# AI Configuration
DEFAULT_AI_PROVIDER=anthropic          # or 'openai', 'vercel'
AI_FALLBACK_ORDER=anthropic,openai     # Fallback chain
ENABLE_AI_FALLBACK=true                # Enable automatic fallback
AI_MAX_TOKENS=8192                     # Max response tokens
AI_TEMPERATURE=0.2                     # Response randomness (0-2)
AI_REQUEST_TIMEOUT=30000               # Request timeout (ms)
```

### Provider Selection

The system automatically selects providers based on:
1. **Primary**: Anthropic Claude (configured as default)
2. **Fallback**: OpenAI GPT (if Anthropic fails)
3. **Last Resort**: Vercel AI Gateway

You can override per-request:
```bash
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role": "user", "content": "Hello"}],
    "runtime": {
      "provider": "openai",
      "model": "gpt-4o",
      "temperature": 0.5
    }
  }'
```

---

## 📈 Monitoring

### Check AI Provider Health

```bash
# Via AI service
curl http://localhost:3000/api/health/ai-providers

# Via system health
curl http://localhost:3000/api/health
```

### Usage Tracking

All AI operations emit usage events that you can monitor:

```typescript
import { onAIUsage } from '@/lib/ai';

const unsubscribe = onAIUsage((event) => {
  console.log('AI Usage:', {
    provider: event.provider,
    model: event.model,
    tokens: event.tokens,
    cost: event.costInCents / 100,
    operation: event.operation,
  });
});
```

---

## 🐛 Troubleshooting

### Issue: "API key not configured"

**Solution**: Add API key to `.env.local`:
```bash
echo 'ANTHROPIC_API_KEY=sk-ant-api03-YOUR_KEY' >> .env.local
# Restart server
npm run dev
```

### Issue: "Provider not available"

**Solution**: Check provider health:
```bash
curl http://localhost:3000/api/health
```

Enable fallback:
```bash
echo 'ENABLE_AI_FALLBACK=true' >> .env.local
```

### Issue: Slow responses

**Solution**:
1. Reduce `maxTokens` in request
2. Enable caching:
   ```json
   {
     "messages": [...],
     "cache": {"enabled": true, "ttlMs": 300000}
   }
   ```
3. Use streaming for long responses

### Issue: Rate limits

**Solution**:
1. Add delay between requests
2. Use batch endpoints where available
3. Configure multiple providers for load balancing

---

## 🔒 Security Best Practices

### ✅ DO:
- Store API keys in environment variables
- Use `.env.local` (not committed to git)
- Implement rate limiting on AI endpoints
- Validate all input with Zod schemas
- Log AI usage for cost tracking

### ❌ DON'T:
- Hardcode API keys in source code
- Commit `.env.local` to version control
- Expose raw AI responses without sanitization
- Allow unlimited AI requests from clients
- Ignore usage monitoring

---

## 💰 Cost Optimization

### Tips to Reduce AI Costs:

1. **Use Caching**:
   ```typescript
   const result = await service.generateText(prompt, {
     cache: true,
     cacheTtlMs: 5 * 60 * 1000, // 5 minutes
   });
   ```

2. **Limit Token Usage**:
   ```typescript
   const result = await service.generateText(prompt, {
     maxTokens: 1000, // Limit response length
   });
   ```

3. **Choose Appropriate Models**:
   - Simple tasks: `claude-3-haiku` (fast, cheap)
   - Standard tasks: `claude-3-5-sonnet` (balanced)
   - Complex reasoning: `claude-3-opus` (powerful, expensive)

4. **Batch Operations**:
   ```typescript
   // More efficient than individual requests
   const results = await service.generateBatch(prompts);
   ```

5. **Use Lower Temperature**:
   ```typescript
   // More deterministic = fewer retries
   const result = await service.generateText(prompt, {
     temperature: 0.3,
   });
   ```

---

## 📚 Additional Resources

- **Full Implementation Report**: [`AI_API_IMPLEMENTATION_REPORT.md`](/mnt/k/00Project/MantisNXT/AI_API_IMPLEMENTATION_REPORT.md)
- **Example Upgrade**: [`route.v5.example.ts`](/mnt/k/00Project/MantisNXT/src/app/api/ai/suppliers/discover/route.v5.example.ts)
- **Test Script**: [`test-ai-endpoints.sh`](/mnt/k/00Project/MantisNXT/scripts/test-ai-endpoints.sh)

- **Vercel AI SDK Docs**: https://sdk.vercel.ai/docs
- **Anthropic API Docs**: https://docs.anthropic.com/
- **OpenAI API Docs**: https://platform.openai.com/docs

---

## 🎯 Next Steps

1. ✅ **Add API key** to `.env.local`
2. ✅ **Start server**: `npm run dev`
3. ✅ **Test endpoints**: Run test script
4. 📖 **Read full report**: `AI_API_IMPLEMENTATION_REPORT.md`
5. 🚀 **Integrate with frontend**: Use AI endpoints in your UI
6. 📊 **Set up monitoring**: Track usage and costs
7. 🔧 **Customize**: Adjust prompts and parameters for your use cases

---

## 💬 Support

For issues or questions:
1. Check the [Implementation Report](/mnt/k/00Project/MantisNXT/AI_API_IMPLEMENTATION_REPORT.md)
2. Review the [test scripts](/mnt/k/00Project/MantisNXT/scripts/test-ai-endpoints.sh)
3. Consult Vercel AI SDK documentation

---

**Happy AI Integration! 🤖**
