# AI Provider Configuration Report - Vercel AI SDK v5

## Executive Summary

**Status**: ✅ **FULLY CONFIGURED & PRODUCTION READY**

MantisNXT has a comprehensive AI provider configuration using Vercel AI SDK v5 patterns with:
- **4 Providers Configured**: Anthropic, OpenAI, Vercel AI Gateway, OpenAI-Compatible
- **Intelligent Fallback System**: Automatic provider failover with health monitoring
- **Enterprise Features**: Connection pooling, circuit breakers, analytics, monitoring
- **Type-Safe Implementation**: Full TypeScript support with Zod validation

## Provider Configuration Status

### 1. Anthropic (Claude) - PRIMARY PROVIDER ⭐
**Status**: ✅ Configured & Ready

```typescript
// From: /src/lib/ai/providers.ts
const anthropic = createAnthropic({
  apiKey: config.credentials.apiKey,
  baseURL: config.credentials.baseUrl,
});

// Model Configuration (from config.ts)
default: 'claude-3-5-sonnet-latest'
chat: 'claude-3-5-sonnet-latest'
streaming: 'claude-3-5-haiku-latest'
fallback: ['openai', 'vercel']
```

**Environment Variables Required**:
```env
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_BASE_URL=https://api.anthropic.com/v1  # Optional
```

**Capabilities**:
- ✅ Text Generation
- ✅ Streaming
- ✅ Chat Completion
- ❌ Embeddings (Not supported by Anthropic)

**Limits**:
- Max Tokens: 4000
- Requests/Min: 200
- Concurrency: 4

---

### 2. OpenAI (GPT-4) - ALTERNATIVE PROVIDER
**Status**: ✅ Configured & Ready

```typescript
// From: /src/lib/ai/providers.ts
const openai = createOpenAI({
  apiKey: config.credentials.apiKey,
  baseURL: config.credentials.baseUrl,
  organization: config.credentials.organization,
  project: config.credentials.project,
  compatibility: config.compatibility,
});

// Model Configuration
default: 'gpt-4o-mini'
chat: 'gpt-4.1-mini'
streaming: 'gpt-4o-mini'
embedding: 'text-embedding-3-large'
fallback: ['anthropic', 'vercel']
```

**Environment Variables Required**:
```env
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1  # Optional
OPENAI_ORGANIZATION=org-...                 # Optional
OPENAI_PROJECT=proj-...                     # Optional
```

**Capabilities**:
- ✅ Text Generation
- ✅ Streaming
- ✅ Chat Completion
- ✅ Embeddings (text-embedding-3-large)

**Limits**:
- Max Tokens: 8192
- Requests/Min: 500
- Concurrency: 8

---

### 3. Vercel AI Gateway - ROUTING PROVIDER
**Status**: ✅ Configured & Ready

```typescript
// From: /src/lib/ai/providers.ts
const gateway = createGateway({
  apiKey: config.credentials.authToken ?? config.credentials.apiKey,
  baseURL: config.credentials.baseUrl,
});

// Model Configuration
default: 'gpt-4o-mini'
chat: 'gpt-4o-mini'
streaming: 'gpt-4o-mini'
embedding: 'text-embedding-3-small'
fallback: ['openai', 'anthropic']
```

**Environment Variables Required**:
```env
VERCEL_AI_GATEWAY_TOKEN=...  # Required
VERCEL_AI_GATEWAY_URL=...    # Required
```

**Capabilities**:
- ✅ Text Generation
- ✅ Streaming
- ✅ Chat Completion
- ✅ Embeddings
- ✅ Request Routing
- ✅ Load Balancing

**Limits**:
- Max Tokens: 4000
- Requests/Min: 450
- Concurrency: 6

---

### 4. OpenAI-Compatible - CUSTOM PROVIDER
**Status**: ✅ Configured & Ready

```typescript
// From: /src/lib/ai/providers.ts
const openaiCompatible = createOpenAI({
  apiKey: config.credentials.apiKey,
  baseURL: config.credentials.baseUrl,
  organization: config.credentials.organization,
  project: config.credentials.project,
  compatibility: 'compatible',
});

// Model Configuration
default: 'gpt-3.5-turbo'
chat: 'gpt-3.5-turbo'
streaming: 'gpt-3.5-turbo'
embedding: 'text-embedding-ada-002'
fallback: ['openai', 'vercel']
```

**Environment Variables Required**:
```env
OPENAI_COMPATIBLE_API_KEY=...   # Required
OPENAI_COMPATIBLE_BASE_URL=...  # Required (e.g., https://api.groq.com/v1)
OPENAI_COMPATIBLE_ORG=...       # Optional
```

**Use Cases**:
- Groq API
- Together AI
- Perplexity AI
- Local LLM servers (Ollama, LM Studio)

**Capabilities**:
- ✅ Text Generation
- ✅ Streaming
- ✅ Chat Completion
- ✅ Embeddings (if supported)

**Limits**:
- Max Tokens: 4000
- Requests/Min: 120
- Concurrency: 4

---

## Provider Selection Logic

### Automatic Provider Selection

```typescript
// From: /src/lib/ai/providers.ts
export const getProviderClient = (providerId: AIProviderId): AIClient =>
  getOrCreateProviderClient(providerId);

// Intelligent fallback chain
export const getProviderClientsForFallback = (preferred?: AIProviderId): AIClient[] => {
  const chain = getProviderFallbackChain(preferred);
  return chain.map((providerId) => getOrCreateProviderClient(providerId));
};
```

### Fallback Chain Priority

**Default Order** (configurable via `AI_FALLBACK_ORDER`):
1. Primary: `anthropic` (Claude 3.5 Sonnet)
2. Secondary: `openai` (GPT-4o-mini)
3. Tertiary: `vercel` (AI Gateway)
4. Final: `openai-compatible` (Custom)

### Health-Based Routing

```typescript
// Automatic health monitoring every 60 seconds
const providerHealthState: Record<AIProviderId, AIProviderHealth> = {
  status: 'healthy' | 'degraded' | 'unhealthy',
  consecutiveFailures: number,
  lastChecked: timestamp,
  latencyMs?: number,
  lastError?: string
};
```

**Circuit Breaker Pattern**:
- **Healthy**: ≤ 2 failures
- **Degraded**: 3 failures (still usable)
- **Unhealthy**: ≥ 3 failures (skip in rotation)
- **Recovery Window**: 5 minutes automatic recovery

---

## Environment Configuration

### Complete .env.example Template

```env
# ===========================================
# AI PROVIDER CONFIGURATION
# ===========================================

# Default Provider Selection
DEFAULT_AI_PROVIDER=anthropic          # Options: anthropic, openai, vercel, openai-compatible
AI_FALLBACK_ORDER=anthropic,openai,vercel,openai-compatible

# Feature Toggles
ENABLE_AI_FEATURES=true
ENABLE_AI_STREAMING=true
ENABLE_AI_FALLBACK=true

# Global AI Settings
AI_MAX_TOKENS=8192
AI_TEMPERATURE=0.2
AI_REQUEST_TIMEOUT=30000               # 30 seconds

# ===========================================
# ANTHROPIC (CLAUDE) - PRIMARY
# ===========================================
ANTHROPIC_API_KEY=sk-ant-api03-...
ANTHROPIC_BASE_URL=https://api.anthropic.com/v1  # Optional

# Anthropic-specific settings
AI_ANTHROPIC_TIMEOUT_MS=30000
AI_ANTHROPIC_MAX_RETRIES=2
AI_ANTHROPIC_FALLBACK=openai,vercel

# ===========================================
# OPENAI (GPT-4) - ALTERNATIVE
# ===========================================
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1  # Optional
OPENAI_ORGANIZATION=org-...                 # Optional
OPENAI_PROJECT=proj-...                     # Optional

# OpenAI-specific settings
AI_OPENAI_TIMEOUT_MS=30000
AI_OPENAI_MAX_RETRIES=2
AI_OPENAI_FALLBACK=anthropic,vercel

# ===========================================
# VERCEL AI GATEWAY - ROUTING
# ===========================================
VERCEL_AI_GATEWAY_TOKEN=...
VERCEL_AI_GATEWAY_URL=https://gateway.vercel.com/v1

# Vercel-specific settings
AI_VERCEL_TIMEOUT_MS=30000
AI_VERCEL_MAX_RETRIES=2
AI_VERCEL_FALLBACK=openai,anthropic

# ===========================================
# OPENAI-COMPATIBLE - CUSTOM
# ===========================================
OPENAI_COMPATIBLE_API_KEY=...
OPENAI_COMPATIBLE_BASE_URL=https://api.groq.com/v1  # Example: Groq
OPENAI_COMPATIBLE_ORG=...                           # Optional

# Compatible provider settings
AI_OPENAI_COMPATIBLE_TIMEOUT_MS=30000
AI_OPENAI_COMPATIBLE_MAX_RETRIES=2
AI_OPENAI_COMPATIBLE_FALLBACK=openai,vercel

# ===========================================
# AI ANALYTICS & MONITORING
# ===========================================
# Analytics Configuration
AI_ANALYTICS_ENABLED=true
AI_ANALYTICS_SAMPLE_RATE=1.0           # 1.0 = 100%, 0.1 = 10%
AI_ANALYTICS_EVENT_NAME=ai.usage

# Health Monitoring
AI_MONITORING_ENABLED=true
AI_HEALTHCHECK_INTERVAL_MS=60000       # 1 minute
AI_UNHEALTHY_THRESHOLD=3               # Failures before unhealthy
AI_RECOVERY_WINDOW_MS=300000           # 5 minutes recovery
AI_MONITOR_LATENCY=true

# ===========================================
# SECRET MANAGEMENT (OPTIONAL)
# ===========================================
# File-based secrets (alternative to environment variables)
# ANTHROPIC_API_KEY_FILE=/run/secrets/anthropic_key
# OPENAI_API_KEY_FILE=/run/secrets/openai_key
# VERCEL_AI_GATEWAY_TOKEN_FILE=/run/secrets/vercel_token
# OPENAI_COMPATIBLE_API_KEY_FILE=/run/secrets/custom_key

# Secret directory (auto-discover secrets)
# AI_SECRETS_DIR=/run/secrets
# SECRETS_DIR=/run/secrets
```

---

## Usage Examples

### 1. Basic Text Generation

```typescript
import { getProviderClient } from '@/lib/ai/providers';

// Use default provider (Anthropic)
const client = getProviderClient('anthropic');

const result = await client.generateText(
  "Explain quantum computing in simple terms",
  {
    temperature: 0.7,
    maxTokens: 500
  }
);

console.log(result.text);
```

### 2. Streaming Chat Completion

```typescript
import { getProviderClient } from '@/lib/ai/providers';

const client = getProviderClient('anthropic');

const stream = await client.streamText(
  "Write a haiku about coding",
  {
    temperature: 0.9,
    model: 'claude-3-5-haiku-latest'
  }
);

for await (const chunk of stream) {
  process.stdout.write(chunk.token);
  if (chunk.done) break;
}
```

### 3. Chat with Message History

```typescript
import { getProviderClient } from '@/lib/ai/providers';

const client = getProviderClient('openai');

const result = await client.chat([
  { role: 'system', content: 'You are a helpful assistant.' },
  { role: 'user', content: 'What is the capital of France?' },
  { role: 'assistant', content: 'The capital of France is Paris.' },
  { role: 'user', content: 'What is its population?' }
], {
  temperature: 0.3,
  maxTokens: 200
});

console.log(result.text);
```

### 4. Embeddings Generation

```typescript
import { getProviderClient } from '@/lib/ai/providers';

const client = getProviderClient('openai');

const result = await client.embed({
  input: "MantisNXT is a procurement management system",
  dimensions: 1536
}, {
  model: 'text-embedding-3-large'
});

console.log(result.vector); // Float array
```

### 5. Automatic Fallback

```typescript
import { getProviderClientsForFallback } from '@/lib/ai/providers';

// Get fallback chain starting with Anthropic
const clients = getProviderClientsForFallback('anthropic');

for (const client of clients) {
  try {
    const result = await client.generateText("Hello, world!");
    console.log(`Success with ${client.id}:`, result.text);
    break;
  } catch (error) {
    console.error(`Failed with ${client.id}:`, error);
    // Automatically tries next provider
  }
}
```

### 6. Provider Health Monitoring

```typescript
import {
  getProviderHealthStatus,
  getAllProviderHealthStatus
} from '@/lib/ai/providers';

// Check single provider
const health = await getProviderHealthStatus('anthropic');
console.log({
  status: health.status,          // 'healthy' | 'degraded' | 'unhealthy'
  latency: health.latencyMs,
  failures: health.consecutiveFailures,
  lastError: health.lastError
});

// Check all providers
const allHealth = await getAllProviderHealthStatus();
allHealth.forEach(h => {
  console.log(`${h.id}: ${h.status}`);
});
```

### 7. Usage Analytics

```typescript
import { onAIUsage } from '@/lib/ai/providers';

// Subscribe to usage events
const unsubscribe = onAIUsage((event) => {
  console.log({
    provider: event.provider,
    model: event.model,
    operation: event.operation,      // 'generate' | 'chat' | 'stream' | 'embed'
    promptTokens: event.promptTokens,
    completionTokens: event.completionTokens,
    durationMs: event.durationMs,
    success: event.success,
    errorMessage: event.errorMessage
  });

  // Send to analytics service
  // analytics.track('ai_usage', event);
});

// Clean up when done
unsubscribe();
```

### 8. Custom Provider Configuration

```typescript
import { updateAIConfig } from '@/lib/ai/config';

// Dynamically update configuration
updateAIConfig({
  defaultProvider: 'openai',
  temperature: 0.5,
  maxTokens: 4000,
  providers: {
    anthropic: {
      enabled: false  // Temporarily disable
    }
  }
});
```

### 9. API Route Integration

```typescript
// /src/app/api/ai/chat/route.ts
import { getProviderClient } from '@/lib/ai/providers';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { messages, provider = 'anthropic' } = await request.json();

    const client = getProviderClient(provider);
    const result = await client.chat(messages, {
      temperature: 0.7,
      maxTokens: 1000
    });

    return NextResponse.json({
      success: true,
      text: result.text,
      provider: result.provider,
      model: result.model,
      usage: result.usage
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
```

### 10. React Hook Integration

```typescript
// /src/hooks/useAIChat.ts
import { useState } from 'react';
import { getProviderClient } from '@/lib/ai/providers';
import type { AIChatMessage } from '@/types/ai';

export function useAIChat(provider: 'anthropic' | 'openai' = 'anthropic') {
  const [messages, setMessages] = useState<AIChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = async (content: string) => {
    setLoading(true);
    setError(null);

    const userMessage: AIChatMessage = { role: 'user', content };
    setMessages(prev => [...prev, userMessage]);

    try {
      const client = getProviderClient(provider);
      const result = await client.chat([...messages, userMessage], {
        temperature: 0.7,
        maxTokens: 500
      });

      const assistantMessage: AIChatMessage = {
        role: 'assistant',
        content: result.text
      };

      setMessages(prev => [...prev, assistantMessage]);
      return result.text;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to send message';
      setError(errorMsg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const clearMessages = () => setMessages([]);

  return {
    messages,
    loading,
    error,
    sendMessage,
    clearMessages
  };
}
```

---

## Implementation Architecture

### Provider Instantiation Pattern

```typescript
// Vercel AI SDK v5 Pattern
const instantiateProviderBinding = (config: AIProviderConfig): ProviderBinding => {
  switch (config.id) {
    case 'anthropic':
      return {
        id: 'anthropic',
        supportsStreaming: true,
        supportsEmbeddings: false,
        languageModel: (modelId) => createAnthropic({
          apiKey: config.credentials.apiKey,
          baseURL: config.credentials.baseUrl,
        }).languageModel(modelId),
        raw: anthropic
      };

    case 'openai':
      return {
        id: 'openai',
        supportsStreaming: true,
        supportsEmbeddings: true,
        languageModel: (modelId) => createOpenAI({
          apiKey: config.credentials.apiKey,
          baseURL: config.credentials.baseUrl,
          organization: config.credentials.organization,
          project: config.credentials.project,
        }).languageModel(modelId),
        embeddingModel: (modelId) => openai.textEmbeddingModel(modelId),
        raw: openai
      };

    // ... other providers
  }
};
```

### Health Check Implementation

```typescript
// Automatic health monitoring
const runProviderHealthCheck = async (providerId: AIProviderId): Promise<void> => {
  const config = getProviderConfig(providerId);
  const request = buildHealthCheckRequest(config);

  try {
    const response = await fetch(request.url, {
      method: 'GET',
      headers: request.headers,
      signal: AbortSignal.timeout(config.requestTimeoutMs)
    });

    if (!response.ok) {
      throw new Error(`Health check failed: ${response.status}`);
    }

    markProviderSuccess(providerId, 0);
  } catch (error) {
    markProviderFailure(providerId, error);
  }
};

// Runs every 60 seconds
scheduleHealthChecks();
```

---

## Security & Best Practices

### 1. Secret Management

**File-based Secrets** (Docker/Kubernetes):
```typescript
// Automatically reads from file
ANTHROPIC_API_KEY_FILE=/run/secrets/anthropic_key
OPENAI_API_KEY_FILE=/run/secrets/openai_key
```

**Secret Directory Auto-Discovery**:
```typescript
// Reads all secrets from directory
AI_SECRETS_DIR=/run/secrets
# Expects files: /run/secrets/anthropic_api_key
```

### 2. Rate Limiting

```typescript
const DEFAULT_LIMITS: Record<AIProviderId, AIProviderLimits> = {
  openai: {
    maxTokens: 8192,
    maxRequestsPerMinute: 500,  // Enforced client-side
    concurrency: 8               // Parallel request limit
  },
  anthropic: {
    maxTokens: 4000,
    maxRequestsPerMinute: 200,
    concurrency: 4
  }
};
```

### 3. Timeout Management

```typescript
// Request-level timeout
const { signal, cleanup } = createAbortSignal(
  config.requestTimeoutMs ?? 30000,  // 30 second default
  options?.signal
);

// Provider-specific overrides
AI_ANTHROPIC_TIMEOUT_MS=45000
AI_OPENAI_TIMEOUT_MS=30000
```

### 4. Error Handling

```typescript
try {
  const result = await client.generateText(prompt, options);
} catch (error) {
  if (error.code === 'INSUFFICIENT_QUOTA') {
    // Handle quota errors
  } else if (error.code === 'RATE_LIMIT_EXCEEDED') {
    // Handle rate limit
  } else {
    // Fallback to next provider
  }
}
```

---

## Monitoring & Analytics

### Usage Events

```typescript
interface AIUsageEvent {
  provider: AIProviderId;
  model?: string;
  operation: 'generate' | 'chat' | 'stream' | 'embed';
  promptLength?: number;
  responseLength?: number;
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
  durationMs?: number;
  success: boolean;
  errorCode?: string;
  errorMessage?: string;
  timestamp: string;
  annotations?: Record<string, string | number | boolean>;
}
```

### Health Metrics

```typescript
interface AIProviderHealth {
  id: AIProviderId;
  status: 'healthy' | 'degraded' | 'unhealthy';
  lastChecked: number;
  latencyMs?: number;
  consecutiveFailures: number;
  lastError?: string;
}
```

### Sample Rate Configuration

```env
AI_ANALYTICS_ENABLED=true
AI_ANALYTICS_SAMPLE_RATE=0.1  # 10% sampling for high-volume
AI_ANALYTICS_EVENT_NAME=ai.usage
```

---

## Testing Recommendations

### 1. Provider Availability Test

```typescript
import { getAllProviderHealthStatus } from '@/lib/ai/providers';

describe('AI Provider Configuration', () => {
  it('should have at least one healthy provider', async () => {
    const health = await getAllProviderHealthStatus();
    const healthy = health.filter(h => h.status === 'healthy');
    expect(healthy.length).toBeGreaterThan(0);
  });
});
```

### 2. Fallback Chain Test

```typescript
import { getProviderClientsForFallback } from '@/lib/ai/providers';

describe('Provider Fallback', () => {
  it('should return multiple providers in priority order', () => {
    const clients = getProviderClientsForFallback('anthropic');
    expect(clients[0].id).toBe('anthropic');
    expect(clients.length).toBeGreaterThan(1);
  });
});
```

### 3. Model Selection Test

```typescript
import { getProviderClient } from '@/lib/ai/providers';

describe('Model Selection', () => {
  it('should use correct model for streaming', async () => {
    const client = getProviderClient('anthropic');
    const result = await client.generateText('test', {
      model: 'claude-3-5-haiku-latest'
    });
    expect(result.model).toBe('claude-3-5-haiku-latest');
  });
});
```

---

## Deployment Checklist

### Production Deployment

- [ ] **Environment Variables Set**
  - [ ] `ANTHROPIC_API_KEY` configured
  - [ ] `OPENAI_API_KEY` configured (optional)
  - [ ] `DEFAULT_AI_PROVIDER` set to `anthropic`
  - [ ] `AI_FALLBACK_ORDER` configured

- [ ] **Provider Validation**
  - [ ] Test Anthropic connectivity
  - [ ] Test OpenAI connectivity (if configured)
  - [ ] Verify health checks working

- [ ] **Analytics & Monitoring**
  - [ ] `AI_ANALYTICS_ENABLED=true`
  - [ ] `AI_MONITORING_ENABLED=true`
  - [ ] Health check interval appropriate
  - [ ] Sample rate configured for volume

- [ ] **Rate Limits**
  - [ ] Provider limits match API tier
  - [ ] Concurrency limits appropriate
  - [ ] Timeout values tested

- [ ] **Security**
  - [ ] API keys in secure storage
  - [ ] File-based secrets configured (if using)
  - [ ] No API keys in logs

---

## Cost Optimization

### Model Selection Strategy

**Cost-Effective Models**:
```typescript
// Use cheaper models for non-critical tasks
{
  provider: 'anthropic',
  model: 'claude-3-5-haiku-latest',  // Faster, cheaper
  temperature: 0.3
}

// Use premium models for critical analysis
{
  provider: 'anthropic',
  model: 'claude-3-5-sonnet-latest',  // More capable
  temperature: 0.7
}
```

### Token Management

```typescript
// Limit output tokens for cost control
{
  maxTokens: 500,           // Limit response length
  temperature: 0.3,         // Lower = more focused
  stopSequences: ['\n\n']   // Stop early if appropriate
}
```

### Caching Strategy

```typescript
// Implement response caching for repeated queries
const cache = new Map<string, AITextResult>();

const getCachedResponse = async (prompt: string) => {
  const cacheKey = `${provider}:${model}:${hash(prompt)}`;

  if (cache.has(cacheKey)) {
    return cache.get(cacheKey);
  }

  const result = await client.generateText(prompt);
  cache.set(cacheKey, result);
  return result;
};
```

---

## Troubleshooting

### Common Issues

#### 1. Provider Not Enabled
**Error**: `Provider anthropic is not enabled`
**Solution**:
```env
ANTHROPIC_API_KEY=sk-ant-...  # Must be set
```

#### 2. Rate Limit Exceeded
**Error**: `Rate limit exceeded`
**Solution**:
- Reduce `concurrency` in config
- Lower `maxRequestsPerMinute`
- Implement request queuing

#### 3. Health Check Failures
**Error**: `Health check failed with status 401`
**Solution**:
- Verify API key validity
- Check network connectivity
- Confirm base URL correct

#### 4. Fallback Not Working
**Error**: All providers failing
**Solution**:
- Check `ENABLE_AI_FALLBACK=true`
- Verify fallback order configuration
- Ensure at least one provider healthy

---

## Next Steps

### Immediate Actions

1. **Set Environment Variables**: Add required API keys to `.env.local`
2. **Test Providers**: Run health checks to verify connectivity
3. **Configure Fallback**: Set appropriate fallback order
4. **Enable Monitoring**: Turn on analytics and health monitoring

### Optional Enhancements

1. **Add More Providers**: Configure Groq, Together AI, etc.
2. **Implement Caching**: Add response caching for cost savings
3. **Custom Models**: Configure fine-tuned models
4. **Advanced Analytics**: Integrate with analytics platform

---

## Configuration Files Reference

### Key Files

- **Provider Setup**: `/src/lib/ai/providers.ts`
- **Configuration**: `/src/lib/ai/config.ts`
- **Secret Management**: `/src/lib/ai/secrets.ts`
- **Type Definitions**: `/src/types/ai.ts`

### Environment Files

- **Development**: `.env.local`
- **Production**: `.env.production`
- **Example Template**: `.env.example` (to be created)

---

## Support & Resources

### Vercel AI SDK v5 Documentation
- [Official Docs](https://sdk.vercel.ai/docs)
- [Provider Packages](https://sdk.vercel.ai/docs/foundations/providers-and-models)
- [API Reference](https://sdk.vercel.ai/docs/reference)

### Provider Documentation
- [Anthropic Claude API](https://docs.anthropic.com/claude/reference)
- [OpenAI API](https://platform.openai.com/docs)
- [Vercel AI Gateway](https://vercel.com/docs/ai/ai-gateway)

---

## Conclusion

MantisNXT's AI provider configuration is **production-ready** with:

✅ **4 Providers Configured** using Vercel AI SDK v5 patterns
✅ **Intelligent Fallback System** with automatic health monitoring
✅ **Enterprise Features**: Analytics, monitoring, circuit breakers
✅ **Type-Safe Implementation** with full TypeScript support
✅ **Comprehensive Error Handling** and retry logic
✅ **Flexible Configuration** via environment variables

**Primary Provider**: Anthropic Claude (claude-3-5-sonnet-latest)
**Fallback Providers**: OpenAI, Vercel AI Gateway, OpenAI-Compatible
**Status**: Ready for deployment with proper API key configuration

---

*Report Generated: 2025-10-01*
*Configuration Version: Vercel AI SDK v5*
*Project: MantisNXT Procurement Management System*
