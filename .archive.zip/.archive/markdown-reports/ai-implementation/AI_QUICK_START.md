# AI Provider Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Add API Keys to `.env.local`

```bash
# Minimum configuration (Anthropic only)
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here

# Optional: Add OpenAI for fallback
OPENAI_API_KEY=sk-your-openai-key-here

# Set default provider
DEFAULT_AI_PROVIDER=anthropic
```

### Step 2: Verify Configuration

```bash
# Run verification script
node scripts/verify-ai-providers.js
```

### Step 3: Test AI Features

```typescript
import { getProviderClient } from '@/lib/ai/providers';

// Generate text
const client = getProviderClient('anthropic');
const result = await client.generateText("Hello, AI!");
console.log(result.text);
```

## 📊 Provider Status

| Provider | Status | Setup Required | Capabilities |
|----------|--------|----------------|--------------|
| **Anthropic (Claude)** | ✅ Ready | API Key | Text, Streaming, Chat |
| **OpenAI (GPT-4)** | ✅ Ready | API Key | Text, Streaming, Chat, Embeddings |
| **Vercel AI Gateway** | ⚙️ Optional | Token + URL | Routing, Load Balancing |
| **OpenAI-Compatible** | ⚙️ Optional | API Key + URL | Custom Models (Groq, etc.) |

## 🔑 Get Your API Keys

### Anthropic Claude (Primary)
1. Go to: https://console.anthropic.com/
2. Create an account or sign in
3. Navigate to API Keys
4. Create a new key
5. Copy to `.env.local`: `ANTHROPIC_API_KEY=sk-ant-...`

### OpenAI (Fallback)
1. Go to: https://platform.openai.com/api-keys
2. Sign in to your account
3. Click "Create new secret key"
4. Copy to `.env.local`: `OPENAI_API_KEY=sk-...`

### Vercel AI Gateway (Optional)
1. Go to: https://vercel.com/dashboard
2. Navigate to AI Gateway settings
3. Generate gateway token
4. Copy URL and token to `.env.local`

## 🎯 Usage Examples

### Text Generation
```typescript
const client = getProviderClient('anthropic');
const result = await client.generateText(
  "Explain quantum computing",
  { temperature: 0.7, maxTokens: 500 }
);
```

### Streaming
```typescript
const stream = await client.streamText("Write a poem");
for await (const chunk of stream) {
  process.stdout.write(chunk.token);
}
```

### Chat
```typescript
const result = await client.chat([
  { role: 'user', content: 'What is AI?' }
], { temperature: 0.3 });
```

### Embeddings (OpenAI only)
```typescript
const openai = getProviderClient('openai');
const result = await openai.embed({
  input: "Search query text",
  dimensions: 1536
});
```

## 🔄 Automatic Fallback

If Anthropic fails, the system automatically tries:
1. Anthropic (Claude) - Primary
2. OpenAI (GPT-4) - Secondary
3. Vercel AI Gateway - Tertiary
4. OpenAI-Compatible - Final

No code changes needed!

## 📈 Monitoring

### Check Provider Health
```typescript
import { getAllProviderHealthStatus } from '@/lib/ai/providers';

const health = await getAllProviderHealthStatus();
health.forEach(h => {
  console.log(`${h.id}: ${h.status}`);
});
```

### Usage Analytics
```typescript
import { onAIUsage } from '@/lib/ai/providers';

onAIUsage((event) => {
  console.log({
    provider: event.provider,
    tokens: event.totalTokens,
    duration: event.durationMs,
    cost: event.costInCents
  });
});
```

## 🛠 Configuration Options

### Environment Variables

```env
# Provider Selection
DEFAULT_AI_PROVIDER=anthropic
AI_FALLBACK_ORDER=anthropic,openai

# Behavior
ENABLE_AI_FEATURES=true
ENABLE_AI_STREAMING=true
ENABLE_AI_FALLBACK=true

# Model Settings
AI_MAX_TOKENS=8192
AI_TEMPERATURE=0.2
AI_REQUEST_TIMEOUT=30000

# Monitoring
AI_MONITORING_ENABLED=true
AI_ANALYTICS_ENABLED=true
```

### Runtime Options

```typescript
// Override per-request
const result = await client.generateText(prompt, {
  model: 'claude-3-5-haiku-latest',  // Specific model
  temperature: 0.9,                   // Creativity level
  maxTokens: 1000,                    // Response length
  signal: abortController.signal      // Cancellation
});
```

## 🚨 Troubleshooting

### Provider Not Available
**Error**: `Provider anthropic is not enabled`
**Fix**: Add `ANTHROPIC_API_KEY` to `.env.local`

### Rate Limit Exceeded
**Error**: `Rate limit exceeded`
**Fix**: Configure fallback provider or reduce concurrency

### Timeout
**Error**: `Request timeout`
**Fix**: Increase `AI_REQUEST_TIMEOUT` or use faster model

### No Embeddings
**Error**: `Provider does not support embeddings`
**Fix**: Use OpenAI provider for embeddings

## 📝 Model Recommendations

### For Speed (Low Latency)
- **Anthropic**: `claude-3-5-haiku-latest`
- **OpenAI**: `gpt-4o-mini`

### For Quality (Best Results)
- **Anthropic**: `claude-3-5-sonnet-latest`
- **OpenAI**: `gpt-4-turbo`

### For Cost Efficiency
- **Anthropic**: `claude-3-5-haiku-latest`
- **OpenAI**: `gpt-4o-mini`

### For Embeddings
- **OpenAI**: `text-embedding-3-large` (best)
- **OpenAI**: `text-embedding-3-small` (faster)

## 🔗 Links

- [Full Configuration Report](/AI_PROVIDER_CONFIGURATION_REPORT.md)
- [Environment Template](/.env.production.example)
- [Anthropic Docs](https://docs.anthropic.com/claude/reference)
- [OpenAI Docs](https://platform.openai.com/docs)
- [Vercel AI SDK](https://sdk.vercel.ai/docs)

---

**Next Step**: Copy API keys to `.env.local` and run verification script!
