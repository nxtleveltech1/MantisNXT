# Vercel AI SDK v5 - Quick Start Guide

## Installation Status: ✅ COMPLETE

All components have been verified and are ready for use.

## Quick Verification

```bash
# Run full verification
node scripts/verify-ai-sdk.js

# Expected output: "Overall Status: ✅ READY"
```

## Available Test Scripts

### 1. Package Verification (1 minute)
```bash
node scripts/verify-ai-sdk.js
```
Checks:
- Package installation
- Environment configuration
- Core files presence
- API routes availability
- UI components existence

### 2. Comprehensive Test Suite (5-10 minutes)
```bash
bash scripts/test-ai-complete.sh
```
Executes:
- Package verification
- Environment validation
- TypeScript compilation
- File structure check
- Import validation
- Configuration loading

### 3. Smoke Tests (1 minute)
```bash
# Start dev server first
npm run dev

# In another terminal
bash scripts/smoke-test-ai.sh
```
Tests:
- Server connectivity
- Chat API endpoint
- Generate API endpoint
- Analyze API endpoint
- Health check endpoint

### 4. Performance Tests (2-3 minutes)
```bash
# Ensure server is running
node scripts/test-ai-performance.js
```
Measures:
- Response times (average, median, P95, P99)
- Throughput (requests/second)
- Concurrent request handling
- Error rates
- Success rates

### 5. Unit Tests
```bash
npm test tests/ai/vercel-sdk-v5.test.ts
```
Tests:
- Package imports
- Configuration loading
- Provider clients
- Text generation
- Streaming support
- Chat interface
- Health monitoring
- Fallback chains
- Error handling

### 6. Integration Tests
```bash
# Start dev server
npm run dev

# Run integration tests
npm test tests/integration/ai-api.test.ts
```
Tests:
- All 7 API endpoints
- Request/response formats
- Error handling
- Performance benchmarks

## API Endpoints Reference

### 1. Chat Interface
```bash
POST /api/ai/chat
Content-Type: application/json

{
  "messages": [
    {"role": "user", "content": "Hello!"},
    {"role": "assistant", "content": "Hi there!"},
    {"role": "user", "content": "How are you?"}
  ]
}
```

### 2. Text Generation
```bash
POST /api/ai/generate
Content-Type: application/json

{
  "prompt": "Write a summary of...",
  "mode": "concise"
}
```
Modes: `concise`, `detailed`, `creative`

### 3. Data Analysis
```bash
POST /api/ai/analyze
Content-Type: application/json

{
  "data": {
    "sales": [100, 150, 200],
    "trend": "increasing"
  },
  "context": "quarterly analysis"
}
```

### 4. Insight Generation
```bash
POST /api/ai/insights/generate
Content-Type: application/json

{
  "inventoryData": [
    {"sku": "A001", "quantity": 50, "reorderPoint": 20}
  ],
  "context": {"period": "monthly"}
}
```

### 5. Supplier Discovery
```bash
POST /api/ai/suppliers/discover
Content-Type: application/json

{
  "requirements": {
    "products": ["electronics"],
    "location": "North America"
  }
}
```

### 6. Predictive Analytics
```bash
POST /api/ai/analytics/predictive
Content-Type: application/json

{
  "historicalData": [
    {"date": "2024-01", "value": 100},
    {"date": "2024-02", "value": 120}
  ],
  "predictionWindow": 3
}
```

### 7. Anomaly Detection
```bash
POST /api/ai/analytics/anomalies
Content-Type: application/json

{
  "data": [
    {"timestamp": "2024-01-01", "value": 100},
    {"timestamp": "2024-01-02", "value": 500}
  ]
}
```

## Configuration

### Environment Variables (.env.local)

```env
# AI Provider Configuration
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
DEFAULT_AI_PROVIDER=openai

# Feature Flags
ENABLE_AI_FEATURES=true
ENABLE_AI_STREAMING=true
ENABLE_AI_FALLBACK=true

# AI Settings
AI_MAX_TOKENS=8192
AI_TEMPERATURE=0.2
AI_REQUEST_TIMEOUT=30000

# Fallback Configuration
AI_FALLBACK_ORDER=openai,anthropic,vercel

# Analytics
AI_ANALYTICS_ENABLED=true
AI_MONITORING_ENABLED=true
```

### Provider Configuration in Code

```typescript
import { getAIConfig, getProviderClient } from '@/lib/ai';

// Get configuration
const config = getAIConfig();
console.log('Default provider:', config.defaultProvider);

// Get provider client
const client = getProviderClient('openai');

// Generate text
const result = await client.generateText('Hello world');
console.log(result.text);

// Stream text
const stream = await client.streamText('Tell me a story');
for await (const chunk of stream) {
  console.log(chunk.token);
}

// Chat
const chatResult = await client.chat([
  { role: 'user', content: 'What is AI?' }
]);
console.log(chatResult.text);
```

## UI Components Usage

### ChatInterfaceV5

```tsx
import ChatInterfaceV5 from '@/components/ai/ChatInterfaceV5';

export default function Page() {
  return (
    <div>
      <ChatInterfaceV5
        initialMessages={[]}
        onMessageSent={(message) => console.log(message)}
      />
    </div>
  );
}
```

### MobileAIInterfaceV5

```tsx
import MobileAIInterfaceV5 from '@/components/ai/MobileAIInterfaceV5';

export default function MobilePage() {
  return <MobileAIInterfaceV5 />;
}
```

### InsightCards

```tsx
import InsightCards from '@/components/ai/InsightCards';

export default function DashboardPage() {
  const insights = [
    { title: 'Inventory Alert', content: 'Low stock detected' }
  ];

  return <InsightCards insights={insights} />;
}
```

## Troubleshooting

### API Key Issues

```bash
# Verify API keys are set
grep "API_KEY" .env.local

# Should not show placeholder text like "your-key-here"
# If it does, replace with actual API keys
```

### Connection Errors

```bash
# Check server is running
curl http://localhost:3000/api/health

# Should return: {"status":"healthy"} or similar
```

### Provider Fallback

If one provider fails, the system automatically falls back to the next configured provider:

```typescript
import { getProviderHealthStatus } from '@/lib/ai';

// Check provider health
const health = getProviderHealthStatus('openai');
console.log('OpenAI status:', health.status);
// Status: 'healthy' | 'degraded' | 'unhealthy'
```

### Enable Debug Logging

```env
# Add to .env.local
DEBUG_MODE=true
LOG_LEVEL=debug
```

## Performance Tuning

### Adjust Token Limits

```env
# Reduce for faster responses
AI_MAX_TOKENS=2000

# Increase for more detailed responses
AI_MAX_TOKENS=16000
```

### Adjust Temperature

```env
# More deterministic (0.0 - 0.3)
AI_TEMPERATURE=0.1

# More creative (0.7 - 1.0)
AI_TEMPERATURE=0.9
```

### Timeout Configuration

```env
# Shorter timeout for quick responses
AI_REQUEST_TIMEOUT=15000

# Longer timeout for complex requests
AI_REQUEST_TIMEOUT=60000
```

## Next Steps

1. **Run Tests**: Execute all test scripts to validate installation
2. **Test API**: Use the curl commands to test each endpoint
3. **Integrate UI**: Add AI components to your pages
4. **Monitor**: Use health monitoring to track provider status
5. **Optimize**: Adjust configuration based on usage patterns

## Additional Resources

- **Full Validation Report**: `AI_FINAL_VALIDATION_REPORT.md`
- **Test Results**: `test-results/ai-performance-results.json`
- **API Documentation**: See individual route files in `src/app/api/ai/`
- **Type Definitions**: `src/types/ai.ts`

## Support

For issues or questions:
1. Check the validation report
2. Review test output
3. Check provider health status
4. Verify environment configuration
5. Review API logs in development mode

---

**Status:** ✅ All systems operational
**Last Updated:** October 1, 2025
**Version:** AI SDK v5.0.49
