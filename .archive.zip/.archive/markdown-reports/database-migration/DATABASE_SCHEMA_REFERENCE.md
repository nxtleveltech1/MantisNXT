# MantisNXT Database Schema Reference

## Critical Schema Information for API Development

### Database Connection
- **Host:** 62.169.20.53:6600
- **Database:** nxtprod-db_001
- **User:** nxtdb_admin
- **Active Tables:** suppliers (22 records), inventory_items (16 records)

---

## ✅ ACTIVE TABLES (Use These)

### `suppliers` table (22 records - ACTIVE)
```sql
Key Columns:
- id (uuid, primary key)
- name (varchar 255, not null)
- supplier_code (varchar 50, not null, unique)
- company_name (varchar 255)
- email (varchar 255)
- phone (varchar 50)
- contact_person (varchar 255)
- contact_email (varchar 255)
- status (varchar 50, default 'active')
- performance_tier (varchar 20, default 'unrated')
- primary_category (varchar 100)
- preferred_supplier (boolean, default false)
- payment_terms (varchar 100)
- website (varchar 255)
- tax_id (varchar 50)
- notes (text)
- created_at, updated_at (timestamptz)
```

### `inventory_items` table (16 records - ACTIVE)
```sql
Key Columns:
- id (uuid, primary key)
- sku (varchar 100, not null, unique)
- name (varchar 255, not null)
- description (text)
- category (varchar 100)
- brand (varchar 100)
- supplier_id (uuid, references suppliers.id)
- cost_price (numeric 15,2, not null)
- sale_price (numeric 15,2)
- stock_qty (integer, default 0)
- reserved_qty (integer, default 0)
- available_qty (computed: stock_qty - reserved_qty)
- reorder_point (integer, default 0)
- max_stock (integer)
- status (varchar 50, default 'active')
- location (varchar 100)
- unit (varchar 50)
- currency (varchar 3, default 'ZAR')
- created_at, updated_at (timestamptz)
```

### `"Product"` table (0 records - Prisma/Schema Only)
```sql
Key Columns (Prisma naming convention):
- id (text, primary key)
- sku (text, unique)
- name (text, not null)
- description (text)
- "basePrice" (numeric 12,2, not null)
- currency (text, default 'USD')
- "supplierId" (text, references "Supplier".id)
- "categoryId" (text, references "Category".id)
- active (boolean, default true)
- "createdAt", "updatedAt" (timestamp)
```

---

## ❌ EMPTY/UNUSED TABLES (Don't Use)

### `supplier` table (0 records - Different Schema)
- Uses different column names (org_id, risk_score, etc.)
- Foreign keys reference `organization` table
- `supplier_contacts` and `supplier_addresses` reference this table

### `inventory_item` table (0 records - Singular)
- Different schema from `inventory_items`
- References `supplier` table instead of `suppliers`

---

## 🔧 CORRECTED API PATTERNS

### Supplier Queries - Use These Columns:
```sql
-- ✅ CORRECT
SELECT name, supplier_code, company_name, status, performance_tier, primary_category
FROM suppliers
WHERE status = 'active'

-- ❌ WRONG
SELECT name, code, legal_name, tier, category FROM suppliers
```

### Inventory Queries - Use These Columns:
```sql
-- ✅ CORRECT
SELECT stock_qty, cost_price, reorder_point, available_qty
FROM inventory_items
WHERE status = 'active'

-- ❌ WRONG
SELECT current_stock, unit_cost_zar, total_value_zar FROM inventory_items
```

### Product Queries - Use Quoted Names:
```sql
-- ✅ CORRECT
SELECT id, sku, name, "basePrice", "supplierId", "categoryId"
FROM "Product"
WHERE active = true

-- ❌ WRONG
SELECT id FROM products WHERE status = 'active'
```

---

## 🚨 CRITICAL FOREIGN KEY ISSUES

### Supplier References:
- `inventory_items.supplier_id` → `suppliers.id` ✅ (Works - 22 records)
- `supplier_contacts.supplier_id` → `supplier.id` ❌ (0 records, don't use)

### Product References:
- `"Product"."supplierId"` → `"Supplier".id` (Prisma schema, 0 records)
- Consider using `inventory_items` for product data instead

---

## 📋 DEVELOPMENT RECOMMENDATIONS

1. **Primary Tables:** Use `suppliers` and `inventory_items` for all operations
2. **Avoid Empty Tables:** Don't query `supplier`, `inventory_item`, or `"Product"`
3. **Data Population:** Focus on populating existing active tables
4. **Column Names:** Always check actual column names before writing queries
5. **Foreign Keys:** Verify relationships match actual table structure

---

## 🧪 VALIDATION QUERIES

Test these queries to verify your API fixes:

```sql
-- Verify supplier data structure
SELECT id, name, supplier_code, status, performance_tier
FROM suppliers LIMIT 5;

-- Verify inventory data structure
SELECT id, sku, name, stock_qty, cost_price, supplier_id
FROM inventory_items LIMIT 5;

-- Check foreign key relationships
SELECT i.name, s.name as supplier_name
FROM inventory_items i
LEFT JOIN suppliers s ON i.supplier_id = s.id
LIMIT 5;
```

**Last Updated:** 2025-09-23
**Schema Status:** Production Database Audit Complete