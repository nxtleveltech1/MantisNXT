# Database Import Migration Guide

## Summary

Fixed critical module resolution error: `Module not found: Can't resolve '@/lib/database/neon-connection'`

The database layer has been refactored to use a centralized export structure through `src/lib/database/index.ts`.

## What Changed

### Old Import Paths (DEPRECATED)
```typescript
// ❌ OLD - No longer exists
import { neonDb } from "@/lib/database/neon-connection";
import { pool } from "@/lib/database/neon-connection";

// ⚠️ LEGACY - Still works but should migrate
import { pool } from "@/lib/database/unified-connection";
import { query } from "@/lib/database/unified-connection";
```

### New Import Path (CURRENT)
```typescript
// ✅ NEW - Use this for all new code
import { pool, query, db, withTransaction } from "@/lib/database";
```

## New Database Export Structure

The `src/lib/database/index.ts` module provides:

### 1. `query()` - Type-safe query helper
```typescript
import { query } from "@/lib/database";

// Simple query
const result = await query<User>("SELECT * FROM users WHERE id = $1", [userId]);
const users: User[] = result.rows;
const count: number = result.rowCount;
```

### 2. `pool` - pg-compatible pool interface
```typescript
import { pool } from "@/lib/database";

// Pool-style query (backward compatible)
const result = await pool.query("SELECT * FROM users");
const users = result.rows;
```

### 3. `withTransaction()` - Transaction helper
```typescript
import { withTransaction } from "@/lib/database";

const result = await withTransaction(async (client) => {
  await client.query("INSERT INTO users (name) VALUES ($1)", ["John"]);
  await client.query("INSERT INTO logs (action) VALUES ($1)", ["user_created"]);
  return { success: true };
});
```

### 4. `db` - DatabaseManager instance
```typescript
import { db } from "@/lib/database";

// Object-oriented API
await db.query("SELECT * FROM users");
await db.transaction(async (client) => { /* ... */ });
const status = db.getStatus();
```

### 5. Utility functions
```typescript
import { testConnection, getPoolStatus, closePool } from "@/lib/database";

// Test connection
const { success, error } = await testConnection();

// Get pool metrics
const status = getPoolStatus();
console.log(`Active: ${status.total}, Idle: ${status.idle}`);

// Graceful shutdown
await closePool();
```

## Files Modified

### Fixed Import Errors (3 files)

1. **src/app/api/spp/dashboard/metrics/route.ts**
   - Changed: `import { neonDb } from "@/lib/database/neon-connection"`
   - To: `import { query } from "@/lib/database"`
   - Converted Neon tagged template syntax to standard parameterized queries
   - Updated response handling from `result[0]` to `result.rows[0]`

2. **src/app/api/core/suppliers/route.ts**
   - Changed: `import { pool } from "@/lib/database/neon-connection"`
   - To: `import { pool } from "@/lib/database"`
   - No other changes needed (already using standard pool.query())

3. **src/app/api/supplier-products/route.ts**
   - Changed: `import { neonDb } from "@/lib/database/neon-connection"`
   - To: `import { query as dbQuery } from "@/lib/database"`
   - Renamed import to avoid conflict with local `query` variable
   - Updated `neonDb.query()` calls to `dbQuery()`

## Breaking Changes

### Neon Tagged Template Syntax No Longer Supported

**Old (Neon-specific):**
```typescript
const result = await neonDb`SELECT * FROM users WHERE id = ${userId}`;
const user = result[0];
```

**New (Standard PostgreSQL):**
```typescript
const result = await query<User>("SELECT * FROM users WHERE id = $1", [userId]);
const user = result.rows[0];
```

### Response Shape Changed

**Old:**
```typescript
const result = await neonDb`SELECT * FROM users`;
// result is an array: User[]
const firstUser = result[0];
```

**New:**
```typescript
const result = await query<User>("SELECT * FROM users");
// result is an object: { rows: User[], rowCount: number }
const firstUser = result.rows[0];
const count = result.rowCount;
```

## Files Still Using Legacy Imports

The following files import from `@/lib/database/unified-connection` and should be migrated to `@/lib/database` in future PRs (non-critical):

- src/app/api/alerts/*.ts (4 files)
- src/app/api/analytics/dashboard/route.ts
- src/app/api/dashboard/real-stats/route.ts
- src/app/api/dashboard_metrics/route.ts
- src/app/api/health/database-connections/route.ts
- src/app/api/health/pipeline/route.ts
- And others...

**Note:** These still work correctly as `unified-connection.ts` re-exports from the enterprise connection manager, but should eventually migrate to the centralized exports for consistency.

## Migration Checklist

When migrating files to the new import pattern:

- [ ] Replace old import path with `@/lib/database`
- [ ] Convert any Neon tagged template syntax to parameterized queries
- [ ] Update response handling from direct array access to `.rows` property
- [ ] Add TypeScript types to `query<Type>()` calls for type safety
- [ ] Test the endpoint to ensure it works correctly
- [ ] Update any variable naming conflicts (e.g., rename import if local `query` variable exists)

## Affected Routes Now Fixed

The following routes were returning 500 errors and are now operational:

- ✅ `/api/spp/dashboard/metrics` - Dashboard metrics endpoint
- ✅ `/api/core/selections/active` - Active selection endpoint (depends on metrics)
- ✅ `/api/spp/upload?limit=10` - SPP upload endpoint
- ✅ `/nxt-spp` - SPP dashboard page

## Database Architecture

```
┌─────────────────────────────────────────────┐
│     Application Layer (API Routes)         │
│  import { query, pool, db } from '@/lib/database' │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│   src/lib/database/index.ts                │
│   - Centralized exports                     │
│   - Type-safe wrappers                      │
│   - Backward-compatible pool interface     │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│   lib/database/enterprise-connection-manager.ts │
│   - Connection pooling                      │
│   - Circuit breaker                         │
│   - Query logging & metrics                 │
│   - Retry logic                             │
│   - Transaction management                  │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│          PostgreSQL Database                │
│  (Neon, AWS RDS, Supabase, etc.)           │
└─────────────────────────────────────────────┘
```

## Benefits of New Structure

1. **Centralized imports** - Single source of truth for database access
2. **Type safety** - Full TypeScript support with generic types
3. **Consistency** - Standard pg API across the entire codebase
4. **Enterprise features** - Circuit breaker, retry logic, query logging
5. **Backward compatibility** - Legacy `pool` interface still works
6. **Better error handling** - Comprehensive error messages and logging
7. **Production ready** - Battle-tested connection management

## Testing

To verify the migration:

```bash
# Build the application
npm run build

# Start dev server
npm run dev

# Test affected endpoints
curl http://localhost:3000/api/spp/dashboard/metrics
curl http://localhost:3000/api/core/suppliers
curl http://localhost:3000/api/supplier-products
```

## Rollback Plan

If issues arise, the `lib/database/unified-connection.ts` file still exists and can be used as a temporary bridge. However, the old `@/lib/database/neon-connection` path no longer exists and cannot be restored without reverting the entire database refactor.

## Next Steps

1. ✅ Fix critical module resolution errors (COMPLETED)
2. ✅ Update three failing API routes (COMPLETED)
3. ⏳ Gradually migrate remaining files from `unified-connection` to centralized exports
4. ⏳ Add integration tests for database layer
5. ⏳ Update developer documentation

---

**Date:** 2025-10-13
**Author:** Claude Code (Opus 4.1)
**Status:** Migration Complete - Critical Issues Resolved
