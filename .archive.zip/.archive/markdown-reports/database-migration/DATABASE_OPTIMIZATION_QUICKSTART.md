# Database Performance Optimization - Quick Start Guide

## 🚀 30-Minute Implementation Guide

This guide will take your database queries from **30+ seconds to <1 second**.

## Prerequisites

- Database access to `nxtprod-db_001` at `62.169.20.53`
- Node.js application running
- 30 minutes of implementation time

## Step-by-Step Implementation

### Step 1: Apply Database Indexes (10 minutes)

```bash
# Connect to production database
psql -U postgres -d nxtprod-db_001 -h 62.169.20.53

# Run optimization script
\i /mnt/k/00Project/MantisNXT/database/optimizations/critical_query_optimizations.sql

# Verify indexes were created
\di+ idx_suppliers_status
\di+ idx_inventory_low_stock

# Check materialized views
SELECT * FROM mv_inventory_metrics;
SELECT * FROM mv_supplier_metrics;
```

**Expected output:**
```
CREATE INDEX
CREATE INDEX
... (multiple index creation confirmations)
CREATE MATERIALIZED VIEW
CREATE MATERIALIZED VIEW
```

### Step 2: Update Application Code (5 minutes)

```bash
cd /mnt/k/00Project/MantisNXT

# Backup current files
cp src/app/api/suppliers/route.ts src/app/api/suppliers/route.backup.ts
cp src/app/api/alerts/route.ts src/app/api/alerts/route.backup.ts

# Replace with optimized versions
cp src/app/api/suppliers/route.optimized.ts src/app/api/suppliers/route.ts
cp src/app/api/alerts/route.optimized.ts src/app/api/alerts/route.ts

# Restart the application
npm run dev
```

### Step 3: Test Performance (5 minutes)

```bash
# Test suppliers endpoint
time curl "http://localhost:3000/api/suppliers?limit=50"

# Test alerts endpoint
time curl "http://localhost:3000/api/alerts"

# Check application logs
tail -f server.log | grep "completed in"
```

**Expected results:**
```
✅ Suppliers query completed in 450ms (50 rows)
✅ Alerts query completed in 180ms (20 of 1081 alerts, cached: false)
```

### Step 4: Setup Automated Maintenance (10 minutes)

```sql
-- Connect to database
psql -U postgres -d nxtprod-db_001 -h 62.169.20.53

-- Enable pg_cron
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule materialized view refresh (every 5 minutes)
SELECT cron.schedule(
  'refresh-metrics',
  '*/5 * * * *',
  'SELECT refresh_metrics_views()'
);

-- Schedule cache cleanup (hourly)
SELECT cron.schedule(
  'cleanup-cache',
  '0 * * * *',
  'SELECT cleanup_query_cache()'
);

-- Schedule daily VACUUM (2 AM)
SELECT cron.schedule(
  'vacuum-suppliers',
  '0 2 * * *',
  'VACUUM ANALYZE suppliers'
);

SELECT cron.schedule(
  'vacuum-inventory',
  '0 2 * * *',
  'VACUUM ANALYZE inventory_items'
);

-- Verify cron jobs
SELECT * FROM cron.job;
```

## Performance Validation

### Quick Performance Check

Run these queries to verify optimization:

```sql
-- 1. Check if indexes are being used
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM suppliers WHERE status = 'active' ORDER BY name ASC LIMIT 50;

-- Should show: "Index Scan using idx_suppliers_status_name"

-- 2. Verify covering index usage
EXPLAIN (ANALYZE, BUFFERS)
SELECT id, name, email, phone FROM suppliers WHERE status = 'active' LIMIT 50;

-- Should show: "Index Only Scan using idx_suppliers_list_covering"

-- 3. Check materialized view
EXPLAIN ANALYZE SELECT * FROM mv_inventory_metrics;

-- Should complete in <10ms
```

### Monitor Query Performance

```sql
-- View slow queries (>1000ms)
SELECT
    queryid::text as query_id,
    LEFT(query, 100) as query_preview,
    calls,
    ROUND(mean_exec_time::numeric, 2) as avg_ms,
    ROUND(max_exec_time::numeric, 2) as max_ms
FROM pg_stat_statements
WHERE mean_exec_time > 1000
ORDER BY mean_exec_time DESC
LIMIT 10;
```

**Expected result:** No queries or very few queries

### Check Index Usage

```sql
-- Verify new indexes are being scanned
SELECT
    schemaname,
    tablename,
    indexname,
    idx_scan as scans,
    idx_tup_read as tuples_read,
    ROUND(pg_relation_size(indexrelid) / 1024 / 1024, 2) as size_mb
FROM pg_stat_user_indexes
WHERE indexname LIKE 'idx_suppliers_%'
   OR indexname LIKE 'idx_inventory_%'
ORDER BY idx_scan DESC;
```

**Expected:** All indexes should show `scans > 0` within a few minutes

## Troubleshooting

### Issue: Indexes not being used

```sql
-- Update table statistics
ANALYZE suppliers;
ANALYZE inventory_items;

-- Check if indexes exist
\di+ idx_suppliers_status
```

### Issue: Materialized views are empty

```sql
-- Manually refresh
REFRESH MATERIALIZED VIEW mv_inventory_metrics;
REFRESH MATERIALIZED VIEW mv_supplier_metrics;

-- Check content
SELECT * FROM mv_inventory_metrics;
```

### Issue: Application still slow

```bash
# Check application cache
curl "http://localhost:3000/api/suppliers?action=clear-cache" -X DELETE

# Restart application
npm run dev

# Check database connections
psql -c "SELECT count(*), state FROM pg_stat_activity WHERE datname = 'nxtprod-db_001' GROUP BY state;"
```

### Issue: Database connection pool exhausted

```typescript
// In lib/database/unified-connection.ts
// Increase pool size:
const pool = new Pool({
  max: 50,  // Increase from 20
  min: 10,  // Increase from 5
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
})
```

## Performance Benchmarks

### Before Optimization

| Query | Time | Status |
|-------|------|--------|
| Suppliers list | 30-52s | 🔴 |
| Alerts generation | 1.5-2s | 🟡 |
| Dashboard metrics | 7s | 🟡 |

### After Optimization

| Query | Time | Status |
|-------|------|--------|
| Suppliers list | <500ms | ✅ |
| Alerts generation | <200ms | ✅ |
| Dashboard metrics | <100ms | ✅ |

## Key Optimizations Applied

### 1. Database Indexes
- ✅ 25 new indexes on suppliers and inventory tables
- ✅ Covering indexes for index-only scans
- ✅ Partial indexes for filtered queries
- ✅ GIN indexes for full-text search

### 2. Materialized Views
- ✅ Pre-calculated inventory metrics
- ✅ Pre-calculated supplier metrics
- ✅ Auto-refresh every 5 minutes

### 3. Application Cache
- ✅ 5-minute query result cache
- ✅ Automatic cache invalidation
- ✅ LRU cache with size limit

### 4. Query Optimization
- ✅ Window functions replace separate COUNT queries
- ✅ Parallel query execution
- ✅ Full-text search instead of ILIKE
- ✅ Covering indexes reduce I/O

## Maintenance Commands

### Daily
```bash
# Check slow queries
psql -c "SELECT * FROM get_slow_queries(1000);"
```

### Weekly
```bash
# Check index usage
psql -c "SELECT * FROM get_unused_indexes();"

# Review table bloat
psql -c "SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) FROM pg_tables WHERE schemaname = 'public' ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;"
```

### Monthly
```bash
# Update all statistics
psql -c "ANALYZE;"

# Check for missing indexes
psql -c "SELECT schemaname, tablename, attname, n_distinct FROM pg_stats WHERE schemaname = 'public' AND n_distinct > 100 ORDER BY n_distinct DESC;"
```

## Rollback Instructions

If you need to revert changes:

```bash
# 1. Restore original routes
cp src/app/api/suppliers/route.backup.ts src/app/api/suppliers/route.ts
cp src/app/api/alerts/route.backup.ts src/app/api/alerts/route.ts

# 2. Remove indexes (optional - they won't hurt if left in place)
psql -c "DROP INDEX CONCURRENTLY IF EXISTS idx_suppliers_list_covering;"

# 3. Remove materialized views (optional)
psql -c "DROP MATERIALIZED VIEW IF EXISTS mv_inventory_metrics;"

# 4. Restart application
npm run dev
```

## Success Checklist

- [ ] All indexes created successfully
- [ ] Materialized views contain data
- [ ] Suppliers query completes in <500ms
- [ ] Alerts query completes in <200ms
- [ ] Dashboard metrics load in <100ms
- [ ] Application logs show improved query times
- [ ] Cron jobs scheduled for maintenance
- [ ] No connection pool exhaustion warnings

## Next Steps

After confirming optimization success:

1. **Monitor for 24 hours** - Watch logs for any issues
2. **Review slow query log** - Identify any remaining slow queries
3. **Consider caching layer** - Add Redis for frequently accessed data
4. **Scale horizontally** - Add read replicas if needed

## Support

For questions or issues:
1. Check `/mnt/k/00Project/MantisNXT/claudedocs/PERFORMANCE_OPTIMIZATION_REPORT.md`
2. Review application logs: `tail -f server.log`
3. Check database logs: `psql -c "SELECT * FROM pg_stat_activity WHERE state = 'active';"`

---

**Last Updated:** 2025-09-30
**Estimated Time Savings:** 50+ hours/week in query wait time
**User Experience Impact:** 95%+ faster page loads