-- Minimal analytics tables
CREATE TABLE IF NOT EXISTS supplier_performance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_id UUID NOT NULL,
    evaluation_date TIMESTAMP NOT NULL DEFAULT NOW(),
    on_time_delivery_rate DECIMAL DEFAULT 85,
    quality_acceptance_rate DECIMAL DEFAULT 95,
    overall_rating DECIMAL DEFAULT 4.0,
    response_time_hours INTEGER DEFAULT 24
);

CREATE TABLE IF NOT EXISTS analytics_anomalies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id INTEGER DEFAULT 1,
    detected_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS analytics_predictions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id INTEGER DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    accuracy DECIMAL DEFAULT 0.85
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID,
    type VARCHAR(50) DEFAULT 'inbound',
    quantity INTEGER DEFAULT 0,
    timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);
