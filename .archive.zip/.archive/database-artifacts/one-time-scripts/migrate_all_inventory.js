const { Pool } = require('pg');
const fs = require('fs');

const oldDbPool = new Pool({
  host: '62.169.20.53',
  port: 6600,
  user: 'nxtdb_admin',
  password: 'P@33w0rd-1',
  database: 'nxtprod-db_001'
});

const neonPool = new Pool({
  connectionString: "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require",
  ssl: { rejectUnauthorized: false }
});

const supplier_map = {
  '06de9fb9-252b-4273-97eb-00140f03af55': 2, '11111111-1111-1111-1111-111111111111': 3,
  '1994eee7-5b44-43e6-95ce-70ea930a6cd2': 4, '22222222-2222-2222-2222-222222222222': 5,
  '33333333-3333-3333-3333-333333333333': 6, '48328342-709d-42f0-82aa-85395022e8f7': 7,
  '66666666-6666-6666-6666-666666666666': 8, '77777777-7777-7777-7777-777777777777': 9,
  '7d851f8b-99a7-4f55-a9b6-60ab0ff489bc': 10, '88888888-8888-8888-8888-888888888888': 11,
  '8f968e95-acc9-42f7-bad1-0507525dfa25': 12, '99999999-9999-9999-9999-999999999999': 13,
  'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1': 14, 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa': 15,
  'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2': 16, 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb': 17,
  'cccccccc-cccc-cccc-cccc-cccccccccccc': 18, 'cd8fa19a-2749-47ed-b932-d6b28fe9e149': 1,
  'dddddddd-dddd-dddd-dddd-dddddddddddd': 19, 'ecc30b28-10eb-4719-9bce-8d7267c7d37d': 20,
  'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee': 21, 'fc6cb400-493c-400d-a534-4f10dcf66f07': 22,
  'ffffffff-ffff-ffff-ffff-ffffffffffff': 23
};

// Group items by supplier for efficient batch processing
async function migrateAllInventory() {
  console.log('Starting complete inventory migration...\n');

  // Get all inventory grouped by supplier
  const inventoryQuery = `
    SELECT supplier_id, COUNT(*) as count
    FROM inventory_items
    WHERE supplier_id IS NOT NULL
    GROUP BY supplier_id
    ORDER BY COUNT(*) DESC
  `;

  const supplierCounts = await oldDbPool.query(inventoryQuery);
  console.log('Inventory by supplier:');
  supplierCounts.rows.forEach(row => {
    const supplierId = supplier_map[row.supplier_id];
    console.log(`  Supplier ${row.supplier_id} (ID ${supplierId}): ${row.count} items`);
  });

  console.log('\n');

  let totalProcessed = 0;
  const BATCH_SIZE = 1000;

  // Process each supplier's inventory
  for (const supplierRow of supplierCounts.rows) {
    const oldSupplierId = supplierRow.supplier_id;
    const newSupplierId = supplier_map[oldSupplierId];
    const count = parseInt(supplierRow.count);

    if (!newSupplierId) {
      console.log(`SKIP: No mapping for supplier ${oldSupplierId}`);
      continue;
    }

    console.log(`\n=== Processing Supplier ID ${newSupplierId} (${count} items) ===`);

    // Get supplier name
    const supplierNameQuery = await oldDbPool.query(
      'SELECT name FROM "Supplier" WHERE id = $1',
      [oldSupplierId]
    );
    const supplierName = supplierNameQuery.rows[0]?.name || 'Unknown';

    // Skip if already processed (supplier_id 8 = Stage Audio Works = batch 1)
    if (newSupplierId === 8) {
      console.log(`SKIP: Supplier "${supplierName}" already processed in batch 1`);
      totalProcessed += count;
      continue;
    }

    // Fetch items in batches
    let offset = 0;
    let supplierProcessed = 0;

    while (offset < count) {
      const itemsQuery = `
        SELECT id, sku, name, unit_price as price, unit_of_measure as uom, supplier_id
        FROM inventory_items
        WHERE supplier_id = $1
        LIMIT $2 OFFSET $3
      `;

      const items = await oldDbPool.query(itemsQuery, [oldSupplierId, BATCH_SIZE, offset]);

      if (items.rows.length === 0) break;

      // Create pricelist_upload record
      const neonClient = await neonPool.connect();
      try {
        await neonClient.query('BEGIN');

        const uploadRes = await neonClient.query(`
          INSERT INTO spp.pricelist_upload
          (supplier_id, received_at, filename, file_size_bytes, currency, valid_from, valid_to, row_count, status, processed_by)
          VALUES ($1, NOW(), $2, 0, 'USD', '2025-10-07', '2026-10-07', $3, 'received', 'migration_script')
          RETURNING upload_id
        `, [newSupplierId, `migration_${supplierName}_batch${Math.floor(offset/BATCH_SIZE)+1}.csv`, items.rows.length]);

        const uploadId = uploadRes.rows[0].upload_id;

        // Insert pricelist_row items
        let rowNum = 1;
        for (const item of items.rows) {
          await neonClient.query(`
            INSERT INTO spp.pricelist_row
            (upload_id, row_num, supplier_sku, name, uom, price, currency, validation_status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending')
          `, [uploadId, rowNum++, item.sku, item.name, item.uom || 'each', parseFloat(item.price) || 0, 'USD']);
        }

        // Merge pricelist
        const mergeRes = await neonClient.query('SELECT spp.merge_pricelist($1)', [uploadId]);
        console.log(`  Batch ${Math.floor(offset/BATCH_SIZE)+1}: Uploaded ${items.rows.length} items, Merged: ${mergeRes.rows[0].merge_pricelist}`);

        await neonClient.query('COMMIT');

        supplierProcessed += items.rows.length;
        totalProcessed += items.rows.length;
        offset += BATCH_SIZE;

      } catch (error) {
        await neonClient.query('ROLLBACK');
        console.error(`  ERROR in batch ${Math.floor(offset/BATCH_SIZE)+1}:`, error.message);
        throw error;
      } finally {
        neonClient.release();
      }
    }

    console.log(`  Supplier "${supplierName}" complete: ${supplierProcessed} items processed`);
  }

  console.log(`\n\n=== MIGRATION COMPLETE ===`);
  console.log(`Total items processed: ${totalProcessed}`);

  // Final verification
  const finalCount = await neonPool.query('SELECT COUNT(*) as count FROM core.supplier_product');
  console.log(`Final supplier_product count: ${finalCount.rows[0].count}`);

  await oldDbPool.end();
  await neonPool.end();
}

migrateAllInventory().catch(console.error);
