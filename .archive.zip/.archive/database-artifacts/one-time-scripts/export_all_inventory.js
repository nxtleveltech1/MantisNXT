const { Pool } = require('pg');
const fs = require('fs');

const oldDbPool = new Pool({
  host: '62.169.20.53',
  port: 6600,
  user: 'nxtdb_admin',
  password: 'P@33w0rd-1',
  database: 'nxtprod-db_001'
});

async function exportAllInventory() {
  console.log('Connecting to old database...');

  // Find the table with inventory data
  const tableCheckQuery = `
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'public'
    AND table_type = 'BASE TABLE'
    ORDER BY table_name
  `;

  const tables = await oldDbPool.query(tableCheckQuery);
  console.log(`Found ${tables.rows.length} tables`);

  // Try common inventory-related table names
  const possibleTables = [
    'inventory', 'inventory_items', 'stock', 'products', 'Product',
    'supplier_products', 'SupplierProduct', 'PricelistItem', 'pricelist_items'
  ];

  for (const tableName of possibleTables) {
    try {
      const countQuery = `SELECT COUNT(*) as count FROM "${tableName}"`;
      const countResult = await oldDbPool.query(countQuery);
      const count = parseInt(countResult.rows[0].count);

      if (count > 0) {
        console.log(`\nTable "${tableName}" has ${count} rows!`);

        // Get table structure
        const columnsQuery = `
          SELECT column_name, data_type
          FROM information_schema.columns
          WHERE table_name = '${tableName}'
          ORDER BY ordinal_position
        `;
        const columns = await oldDbPool.query(columnsQuery);
        console.log(`Columns:`, columns.rows.map(r => r.column_name).join(', '));

        // Sample data
        const sampleQuery = `SELECT * FROM "${tableName}" LIMIT 3`;
        const sample = await oldDbPool.query(sampleQuery);
        console.log(`Sample data:`, JSON.stringify(sample.rows, null, 2));
      }
    } catch (err) {
      // Table doesn't exist, skip
    }
  }

  await oldDbPool.end();
}

exportAllInventory().catch(console.error);
