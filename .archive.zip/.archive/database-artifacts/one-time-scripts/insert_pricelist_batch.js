const fs = require('fs');
const { Pool } = require('pg');

const NEON_CONN = "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require";

const pool = new Pool({
  connectionString: NEON_CONN,
  ssl: { rejectUnauthorized: false }
});

const supplier_map = {
  '06de9fb9-252b-4273-97eb-00140f03af55': 2, // BC Electronics
  '11111111-1111-1111-1111-111111111111': 3, // Viva Afrika
  '1994eee7-5b44-43e6-95ce-70ea930a6cd2': 4, // Active Music
  '22222222-2222-2222-2222-222222222222': 5, // Audiolite
  '33333333-3333-3333-3333-333333333333': 6, // Tuerk Multimedia
  '48328342-709d-42f0-82aa-85395022e8f7': 7, // Legacy Brands
  '66666666-6666-6666-6666-666666666666': 8, // Stage Audio Works
  '77777777-7777-7777-7777-777777777777': 9, // Stage One
  '7d851f8b-99a7-4f55-a9b6-60ab0ff489bc': 10, // Pro Audio platinum
  '88888888-8888-8888-8888-888888888888': 11, // Yamaha
  '8f968e95-acc9-42f7-bad1-0507525dfa25': 12, // SonicInformed
  '99999999-9999-9999-9999-999999999999': 13, // AV Distribution
  'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1': 14, // Audiosure
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa': 15, // Sennheiser
  'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2': 16, // ApexPro
  'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb': 17, // Planetworld
  'cccccccc-cccc-cccc-cccc-cccccccccccc': 18, // MD Distribution
  'cd8fa19a-2749-47ed-b932-d6b28fe9e149': 1, // BK Percussion
  'dddddddd-dddd-dddd-dddd-dddddddddddd': 19, // Rockit
  'ecc30b28-10eb-4719-9bce-8d7267c7d37d': 20, // Music Power
  'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee': 21, // Rolling Thunder
  'fc6cb400-493c-400d-a534-4f10dcf66f07': 22, // Alpha Technologies
  'ffffffff-ffff-ffff-ffff-ffffffffffff': 23  // Global Music
};

async function processInventory() {
  const inventoryFile = process.argv[2] || 'K:/00Project/MantisNXT/tmp_inventory_batch1.txt';
  const uploadId = parseInt(process.argv[3]) || 4;

  const data = fs.readFileSync(inventoryFile, 'utf-8');
  const lines = data.split('\n').filter(l => l.trim());

  console.log(`Processing ${lines.length} lines from ${inventoryFile} for upload_id ${uploadId}...`);

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    let inserted = 0;
    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split('|');
      if (parts.length >= 8) {
        const [itemId, sku, name, supplierUuid, supplierName, qty, price, currency, uom] = parts;
        const supplierId = supplier_map[supplierUuid];

        if (supplierId) {
          const rowNum = i + 1;
          const insertSql = `
            INSERT INTO spp.pricelist_row
            (upload_id, row_num, supplier_sku, name, uom, price, currency, validation_status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending')
          `;

          await client.query(insertSql, [
            uploadId,
            rowNum,
            sku,
            name.replace(/'/g, "''"),
            uom || 'each',
            parseFloat(price),
            currency
          ]);

          inserted++;
          if (inserted % 100 === 0) {
            console.log(`Inserted ${inserted} rows...`);
          }
        }
      }
    }

    // Update upload row_count
    await client.query(
      'UPDATE spp.pricelist_upload SET row_count = $1, status = $2 WHERE upload_id = $3',
      [inserted, 'received', uploadId]
    );

    await client.query('COMMIT');
    console.log(`Successfully inserted ${inserted} rows into pricelist_row for upload_id ${uploadId}`);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

processInventory().catch(console.error);
