#!/bin/bash
set -e

echo "Starting complete stock_on_hand migration for 25,602 items..."

# Neon connection string
NEON_CONN="postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require"

# Old database connection
export PGPASSWORD="P@33w0rd-1"

# Export all inventory with quantities
echo "Exporting all 25,602 items from old database..."
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001 -t -A -F '|' -c "SELECT sku, quantity_on_hand FROM inventory_items WHERE supplier_id IS NOT NULL ORDER BY sku" > /tmp/all_inventory_stock.txt

# Count exported items
TOTAL_ITEMS=$(wc -l < /tmp/all_inventory_stock.txt | tr -d ' ')
echo "Exported $TOTAL_ITEMS items"

# Create bulk INSERT SQL with VALUES
echo "Creating bulk INSERT statement..."
cat > /tmp/complete_stock_insert.sql << 'ENDSQL'
WITH stock_data (sku, qty) AS (
  VALUES
ENDSQL

# Convert to SQL VALUES format
cat /tmp/all_inventory_stock.txt | awk -F'|' '{
  gsub(/'\''/, "'\'''\''", $1);
  printf("('\''%s'\'',%s),\n", $1, $2);
}' | sed '$ s/,$//' >> /tmp/complete_stock_insert.sql

cat >> /tmp/complete_stock_insert.sql << 'ENDSQL'
)
INSERT INTO core.stock_on_hand (supplier_product_id, location_id, qty, as_of_ts)
SELECT sp.supplier_product_id, 1, sd.qty, NOW()
FROM stock_data sd
JOIN core.supplier_product sp ON sp.supplier_sku = sd.sku;
ENDSQL

echo "SQL file created: $(wc -l /tmp/complete_stock_insert.sql | awk '{print $1}') lines"

# Execute on Neon
echo "Executing bulk INSERT on Neon..."
psql "$NEON_CONN" -f /tmp/complete_stock_insert.sql

# Verify count
echo "Verifying insertion..."
COUNT=$(psql "$NEON_CONN" -t -c "SELECT COUNT(*) FROM core.stock_on_hand" | tr -d ' ')
echo "Total stock_on_hand records: $COUNT"

if [ "$COUNT" -ge 25602 ]; then
  echo "✅ SUCCESS! All $COUNT items migrated successfully!"
else
  echo "⚠️  WARNING: Only $COUNT items migrated. Expected 25,602+"
fi

echo "Migration complete!"
