const { Pool } = require('pg');

const oldDbPool = new Pool({
  host: '62.169.20.53',
  port: 6600,
  user: 'nxtdb_admin',
  password: 'P@33w0rd-1',
  database: 'nxtprod-db_001'
});

const neonPool = new Pool({
  connectionString: "postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require",
  ssl: { rejectUnauthorized: false }
});

const supplier_map = {
  '06de9fb9-252b-4273-97eb-00140f03af55': 2, '11111111-1111-1111-1111-111111111111': 3,
  '1994eee7-5b44-43e6-95ce-70ea930a6cd2': 4, '22222222-2222-2222-2222-222222222222': 5,
  '33333333-3333-3333-3333-333333333333': 6, '48328342-709d-42f0-82aa-85395022e8f7': 7,
  '66666666-6666-6666-6666-666666666666': 8, '77777777-7777-7777-7777-777777777777': 9,
  '7d851f8b-99a7-4f55-a9b6-60ab0ff489bc': 10, '88888888-8888-8888-8888-888888888888': 11,
  '8f968e95-acc9-42f7-bad1-0507525dfa25': 12, '99999999-9999-9999-9999-999999999999': 13,
  'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1': 14, 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa': 15,
  'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2': 16, 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb': 17,
  'cccccccc-cccc-cccc-cccc-cccccccccccc': 18, 'cd8fa19a-2749-47ed-b932-d6b28fe9e149': 1,
  'dddddddd-dddd-dddd-dddd-dddddddddddd': 19, 'ecc30b28-10eb-4719-9bce-8d7267c7d37d': 20,
  'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee': 21, 'fc6cb400-493c-400d-a534-4f10dcf66f07': 22,
  'ffffffff-ffff-ffff-ffff-ffffffffffff': 23
};

async function migrateRemaining() {
  console.log('Resuming inventory migration...\n');

  // Get current status in Neon
  const neonStatus = await neonPool.query(`
    SELECT s.supplier_id, s.name, COUNT(sp.supplier_product_id) as migrated_count
    FROM core.supplier s
    LEFT JOIN core.supplier_product sp ON s.supplier_id = sp.supplier_id
    GROUP BY s.supplier_id, s.name
    ORDER BY s.supplier_id
  `);

  const migratedBySupplier = {};
  neonStatus.rows.forEach(row => {
    migratedBySupplier[row.supplier_id] = parseInt(row.migrated_count);
  });

  // Get inventory counts from old DB
  const inventoryQuery = `
    SELECT supplier_id, COUNT(*) as count
    FROM inventory_items
    WHERE supplier_id IS NOT NULL
    GROUP BY supplier_id
    ORDER BY COUNT(*) DESC
  `;

  const supplierCounts = await oldDbPool.query(inventoryQuery);

  console.log('Migration Status:');
  let totalNeeded = 0;
  let totalMigrated = 0;

  for (const row of supplierCounts.rows) {
    const oldSupplierId = row.supplier_id;
    const newSupplierId = supplier_map[oldSupplierId];
    const totalCount = parseInt(row.count);
    const migratedCount = migratedBySupplier[newSupplierId] || 0;
    const remaining = totalCount - migratedCount;

    totalNeeded += totalCount;
    totalMigrated += migratedCount;

    const supplierRes = await oldDbPool.query('SELECT name FROM "Supplier" WHERE id = $1', [oldSupplierId]);
    const supplierName = supplierRes.rows[0]?.name || 'Unknown';

    console.log(`  Supplier ${newSupplierId} (${supplierName}): ${migratedCount}/${totalCount} (${remaining} remaining)`);
  }

  console.log(`\nOverall: ${totalMigrated}/${totalNeeded} items migrated\n`);

  // Process only suppliers that need more items
  const BATCH_SIZE = 500; // Smaller batches for reliability
  let overallProcessed = 0;

  for (const row of supplierCounts.rows) {
    const oldSupplierId = row.supplier_id;
    const newSupplierId = supplier_map[oldSupplierId];
    const totalCount = parseInt(row.count);
    const alreadyMigrated = migratedBySupplier[newSupplierId] || 0;

    if (!newSupplierId || alreadyMigrated >= totalCount) {
      continue; // Skip completed suppliers
    }

    const supplierRes = await oldDbPool.query('SELECT name FROM "Supplier" WHERE id = $1', [oldSupplierId]);
    const supplierName = supplierRes.rows[0]?.name || 'Unknown';

    const remaining = totalCount - alreadyMigrated;
    console.log(`\n=== Processing ${supplierName} (${remaining} remaining items) ===`);

    // Get SKUs already migrated to skip them
    const migratedSkusRes = await neonPool.query(
      'SELECT DISTINCT supplier_sku FROM core.supplier_product WHERE supplier_id = $1',
      [newSupplierId]
    );
    const migratedSkus = new Set(migratedSkusRes.rows.map(r => r.supplier_sku));

    // Fetch items not yet migrated
    const itemsQuery = `
      SELECT id, sku, name, unit_price as price, unit_of_measure as uom
      FROM inventory_items
      WHERE supplier_id = $1
      ORDER BY sku
    `;

    const allItems = await oldDbPool.query(itemsQuery, [oldSupplierId]);
    const newItems = allItems.rows.filter(item => !migratedSkus.has(item.sku));

    console.log(`  Found ${newItems.length} new items to migrate`);

    // Process in batches
    for (let i = 0; i < newItems.length; i += BATCH_SIZE) {
      const batch = newItems.slice(i, Math.min(i + BATCH_SIZE, newItems.length));
      const batchNum = Math.floor(i / BATCH_SIZE) + 1;

      const neonClient = await neonPool.connect();
      try {
        await neonClient.query('BEGIN');

        // Create upload record
        const uploadRes = await neonClient.query(`
          INSERT INTO spp.pricelist_upload
          (supplier_id, received_at, filename, file_size_bytes, currency, valid_from, valid_to, row_count, status, processed_by)
          VALUES ($1, NOW(), $2, 0, 'USD', '2025-10-07', '2026-10-07', $3, 'received', 'migration_resume')
          RETURNING upload_id
        `, [newSupplierId, `${supplierName}_resume_batch${batchNum}.csv`, batch.length]);

        const uploadId = uploadRes.rows[0].upload_id;

        // Insert rows
        for (let j = 0; j < batch.length; j++) {
          const item = batch[j];
          await neonClient.query(`
            INSERT INTO spp.pricelist_row
            (upload_id, row_num, supplier_sku, name, uom, price, currency, validation_status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending')
          `, [uploadId, j + 1, item.sku, item.name, item.uom || 'each', parseFloat(item.price) || 0, 'USD']);
        }

        // Merge
        const mergeRes = await neonClient.query('SELECT spp.merge_pricelist($1)', [uploadId]);
        await neonClient.query('COMMIT');

        console.log(`  Batch ${batchNum}: ${batch.length} items merged successfully`);
        overallProcessed += batch.length;

      } catch (error) {
        await neonClient.query('ROLLBACK');
        console.error(`  ERROR in batch ${batchNum}:`, error.message);
        // Continue with next batch instead of failing completely
      } finally {
        neonClient.release();
      }
    }

    console.log(`  ${supplierName} complete: ${newItems.length} new items migrated`);
  }

  console.log(`\n\n=== MIGRATION COMPLETE ===`);
  console.log(`Items processed in this run: ${overallProcessed}`);

  const finalCount = await neonPool.query('SELECT COUNT(*) as count FROM core.supplier_product');
  console.log(`Final supplier_product count: ${finalCount.rows[0].count}`);

  await oldDbPool.end();
  await neonPool.end();
}

migrateRemaining().catch(console.error);
