#!/bin/bash
set -e

echo "Starting complete stock_on_hand migration for 25,602 items..."

# Neon connection details
NEON_HOST="ep-aged-feather-a5d9glp6.us-east-2.aws.neon.tech"
NEON_DB="neondb"
NEON_USER="neondb_owner"
NEON_PASSWORD="npg_FxcZn6gTQPzF"

# Old database connection
OLD_HOST="62.169.20.53"
OLD_PORT="6600"
OLD_DB="nxtprod-db_001"
OLD_USER="nxtdb_admin"
OLD_PASS="P@33w0rd-1"

# Export all inventory with quantities
echo "Exporting all 25,602 items from old database..."
PGPASSWORD="$OLD_PASS" psql -h "$OLD_HOST" -p "$OLD_PORT" -U "$OLD_USER" -d "$OLD_DB" -t -A -F '|' -c "SELECT sku, quantity_on_hand FROM inventory_items WHERE supplier_id IS NOT NULL ORDER BY sku" > /tmp/all_inventory_stock.txt

# Count exported items
TOTAL_ITEMS=$(wc -l < /tmp/all_inventory_stock.txt)
echo "Exported $TOTAL_ITEMS items"

# Create bulk INSERT SQL
echo "Creating bulk INSERT statement..."
cat > /tmp/complete_stock_insert.sql << 'ENDSQL'
WITH stock_data (sku, qty) AS (
  VALUES
ENDSQL

# Convert to SQL VALUES format
cat /tmp/all_inventory_stock.txt | awk -F'|' '{
  gsub(/'\''/, "'\'''\''", $1);  # Escape single quotes
  printf("('\''%s'\'',%s),\n", $1, $2);
}' | sed '$ s/,$//' >> /tmp/complete_stock_insert.sql

cat >> /tmp/complete_stock_insert.sql << 'ENDSQL'
)
INSERT INTO core.stock_on_hand (supplier_product_id, location_id, qty, as_of_ts)
SELECT sp.supplier_product_id, 1, sd.qty, NOW()
FROM stock_data sd
JOIN core.supplier_product sp ON sp.supplier_sku = sd.sku;
ENDSQL

# Execute on Neon
echo "Executing bulk INSERT on Neon..."
PGPASSWORD="$NEON_PASSWORD" psql -h "$NEON_HOST" -U "$NEON_USER" -d "$NEON_DB" -f /tmp/complete_stock_insert.sql

# Verify count
echo "Verifying insertion..."
COUNT=$(PGPASSWORD="$NEON_PASSWORD" psql -h "$NEON_HOST" -U "$NEON_USER" -d "$NEON_DB" -t -c "SELECT COUNT(*) FROM core.stock_on_hand")
echo "Total stock_on_hand records: $COUNT"

if [ "$COUNT" -ge 25602 ]; then
  echo "✅ SUCCESS! All 25,602+ items migrated successfully!"
else
  echo "⚠️  WARNING: Only $COUNT items migrated. Expected 25,602+"
fi

echo "Migration complete!"
