#!/usr/bin/env python3
"""
Rockit Column Mapping Fix
==========================
Corrects column mapping error in Rockit supplier data.

Issue: SKU column contains BRAND, and PRODUCT DESCRIPTION contains actual SKU
Fix: Swap the values to correct positions

Author: Python Agent Beta-2
"""

import pandas as pd


def fix_rockit_columns():
    """Fix Rockit column mapping error."""

    print("\n" + "="*80)
    print("ROCKIT COLUMN MAPPING FIX")
    print("="*80)

    file_path = "/mnt/k/00Project/MantisNXT/database/Uploads/Consolidated_Supplier_Data_Batch2.xlsx"
    output_path = "/mnt/k/00Project/MantisNXT/database/Uploads/Consolidated_Supplier_Data_Batch2_ROCKIT_FIXED.xlsx"

    # Load all sheets
    excel_file = pd.ExcelFile(file_path)
    writer = pd.ExcelWriter(output_path, engine='openpyxl')

    for sheet_name in excel_file.sheet_names:
        df = pd.read_excel(excel_file, sheet_name=sheet_name)

        if sheet_name == 'Rockit':
            print(f"\n✅ Fixing {sheet_name}...")

            # Show before
            print("\nBEFORE:")
            print("  SKU column sample:", df['SKU / MODEL '].head(3).tolist())
            print("  PRODUCT DESCRIPTION sample:", df['PRODUCT DESCRIPTION'].head(3).tolist())
            print("  BRAND sample:", df['BRAND'].head(3).tolist())

            # The actual structure is:
            # - SKU / MODEL contains BRAND
            # - PRODUCT DESCRIPTION contains SKU
            # - BRAND is empty

            # Fix the mapping:
            # 1. Move SKU / MODEL (which has BRAND) to BRAND column
            # 2. Move PRODUCT DESCRIPTION (which has SKU) to SKU / MODEL
            # 3. Create a proper description from the brand + sku

            temp_brand = df['SKU / MODEL '].copy()  # This is actually the brand
            temp_sku = df['PRODUCT DESCRIPTION'].copy()  # This is actually the SKU

            # Update columns
            df['BRAND'] = temp_brand
            df['SKU / MODEL '] = temp_sku
            df['PRODUCT DESCRIPTION'] = temp_brand + ' - ' + temp_sku  # Brand + SKU as description

            # Show after
            print("\nAFTER:")
            print("  SKU column sample:", df['SKU / MODEL '].head(3).tolist())
            print("  PRODUCT DESCRIPTION sample:", df['PRODUCT DESCRIPTION'].head(3).tolist())
            print("  BRAND sample:", df['BRAND'].head(3).tolist())

            # Verify duplicates are gone
            duplicates_before = 2027  # Known from analysis
            duplicates_after = df['SKU / MODEL '].duplicated().sum()

            print(f"\n📊 DUPLICATE REDUCTION:")
            print(f"  Before: {duplicates_before} duplicate SKUs")
            print(f"  After: {duplicates_after} duplicate SKUs")
            print(f"  Reduction: {duplicates_before - duplicates_after} duplicates removed")

        # Write sheet
        df.to_excel(writer, sheet_name=sheet_name, index=False)

    writer.close()

    print(f"\n✅ Fixed file saved to:")
    print(f"   {output_path}")
    print("="*80 + "\n")


if __name__ == "__main__":
    fix_rockit_columns()
