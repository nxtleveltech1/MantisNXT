#!/usr/bin/env python3
"""
Rockit Duplicate SKU Analysis
==============================
Investigates 2,027 duplicate SKUs in Rockit supplier data.

Author: Python Agent Beta-2
Purpose: Phase 3 investigation - Understand duplicate nature
"""

import pandas as pd
import numpy as np


def analyze_rockit_duplicates():
    """Analyze Rockit duplicate SKUs in detail."""

    print("\n" + "="*80)
    print("ROCKIT DUPLICATE SKU ANALYSIS")
    print("="*80)

    file_path = "/mnt/k/00Project/MantisNXT/database/Uploads/Consolidated_Supplier_Data_Batch2.xlsx"
    df = pd.read_excel(file_path, sheet_name='Rockit')

    print(f"\nTotal Rows: {len(df)}")

    # Analyze SKU duplicates
    if 'SKU / MODEL ' in df.columns:
        sku_col = 'SKU / MODEL '
    elif 'SKU / MODEL' in df.columns:
        sku_col = 'SKU / MODEL'
    else:
        print("ERROR: SKU column not found!")
        return

    # Group by SKU
    sku_counts = df[sku_col].value_counts()
    duplicated_skus = sku_counts[sku_counts > 1]

    print(f"\nUnique SKUs: {df[sku_col].nunique()}")
    print(f"Total Duplicated SKUs: {len(duplicated_skus)}")
    print(f"Duplicate Rows: {duplicated_skus.sum() - len(duplicated_skus)}")

    # Analyze duplicate patterns
    print("\n" + "="*80)
    print("TOP 20 MOST DUPLICATED SKUs")
    print("="*80)

    for sku, count in duplicated_skus.head(20).items():
        print(f"\nSKU: {sku} (appears {count} times)")

        # Get all rows for this SKU
        sku_rows = df[df[sku_col] == sku]

        # Show key columns
        display_cols = []
        for col in ['BRAND', 'PRODUCT DESCRIPTION', 'COST  EX VAT', 'SUPPLIER SOH']:
            if col in df.columns:
                display_cols.append(col)

        if display_cols:
            print(sku_rows[display_cols].to_string(index=False))

    # Analyze if duplicates have different data
    print("\n" + "="*80)
    print("DUPLICATE VARIATION ANALYSIS")
    print("="*80)

    identical_duplicates = 0
    varying_duplicates = 0

    for sku in duplicated_skus.index[:100]:  # Analyze first 100 duplicates
        sku_rows = df[df[sku_col] == sku]

        # Check if all values are identical
        check_cols = []
        for col in ['BRAND', 'PRODUCT DESCRIPTION', 'COST  EX VAT', 'SUPPLIER SOH']:
            if col in df.columns:
                check_cols.append(col)

        if check_cols:
            is_identical = True
            for col in check_cols:
                if sku_rows[col].nunique() > 1:
                    is_identical = False
                    break

            if is_identical:
                identical_duplicates += 1
            else:
                varying_duplicates += 1

    print(f"\nOut of first 100 duplicated SKUs:")
    print(f"  Identical duplicates (exact copies): {identical_duplicates}")
    print(f"  Varying duplicates (different data): {varying_duplicates}")

    # Recommendation
    print("\n" + "="*80)
    print("RECOMMENDATION")
    print("="*80)

    if identical_duplicates > varying_duplicates:
        print("\n✅ FINDING: Majority of duplicates are EXACT COPIES")
        print("\n   RECOMMENDED ACTION:")
        print("   1. Remove duplicate rows (keep first occurrence)")
        print("   2. This is likely a data extraction error")
        print("   3. Safe to deduplicate without data loss")
    else:
        print("\n⚠️  FINDING: Duplicates have VARYING DATA")
        print("\n   RECOMMENDED ACTION:")
        print("   1. Manual review required")
        print("   2. May represent different variants/conditions")
        print("   3. Consult with Rockit supplier before deduplication")

    print("\n" + "="*80)


if __name__ == "__main__":
    analyze_rockit_duplicates()
