from pathlib import Path

path = Path("src/components/inventory/InventoryManagement.tsx")
text = path.read_text()
old = "  const formatCurrency = (amount: number) => {\n    return new Intl.NumberFormat('en-ZA', {\n      style: 'currency',\n      currency: 'ZAR',\n      minimumFractionDigits: 0\n    }).format(amount || 0)\n  }\n"
new = "  const formatCurrency = (amount: number | string | null | undefined) => {\n    const value = Number(amount)\n    return new Intl.NumberFormat('en-ZA', {\n      style: 'currency',\n      currency: 'ZAR',\n      minimumFractionDigits: 0\n    }).format(Number.isFinite(value) ? value : 0)\n  }\n"
if old not in text:
    raise SystemExit('format snippet not found')
text = text.replace(old, new, 1)
path.write_text(text)
