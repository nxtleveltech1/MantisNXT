#!/usr/bin/env python3
"""Quick inspection of Batch 2 MD Distribution to understand the issue."""

import pandas as pd

file_path = "/mnt/k/00Project/MantisNXT/database/Uploads/Consolidated_Supplier_Data_Batch2.xlsx"

# Read MD Distribution sheet
df = pd.read_excel(file_path, sheet_name='MD Distribution')

print("="*80)
print("MD DISTRIBUTION - DATA INSPECTION")
print("="*80)
print(f"\nTotal rows: {len(df)}")
print(f"\nColumns: {df.columns.tolist()}")
print(f"\nFirst 5 rows:\n")
print(df.head())

print("\n" + "="*80)
print("COLUMN VALUE COUNTS")
print("="*80)

# Check if Supplier Name and Supplier Code columns are empty
print(f"\nSupplier Name - Unique values: {df['Supplier Name '].nunique()}")
print(f"Supplier Name - Sample values: {df['Supplier Name '].unique()[:10].tolist()}")

print(f"\nSupplier Code - Unique values: {df['Supplier Code'].nunique()}")
print(f"Supplier Code - Sample values: {df['Supplier Code'].unique()[:10].tolist()}")

print("\n" + "="*80)
print("SKU/BRAND SAMPLE")
print("="*80)
print(df[['SKU / MODEL ', 'BRAND', 'PRODUCT DESCRIPTION']].head(10))
