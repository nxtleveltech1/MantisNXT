#!/usr/bin/env python3
"""Process inventory batch and insert into Neon pricelist_row table."""

import sys
import psycopg2
from psycopg2.extras import execute_batch

# Neon connection string
NEON_CONN = "postgresql://neondb_owner:npg_zlm4eKUgJTnY@ep-broad-dust-a9izrsvx-pooler.us-west-2.aws.neon.tech/neondb?sslmode=require"

# Load supplier mapping
supplier_map = {}
with open('K:/00Project/MantisNXT/tmp_supplier_mapping.txt', 'r') as f:
    for line in f:
        parts = line.strip().split('|')
        if len(parts) == 3:
            uuid, name, sid = parts
            supplier_map[uuid] = int(sid)

print(f"Loaded {len(supplier_map)} supplier mappings")

# Read inventory batch
inventory_file = sys.argv[1] if len(sys.argv) > 1 else 'K:/00Project/MantisNXT/tmp_inventory_batch1.txt'
upload_id = int(sys.argv[2]) if len(sys.argv) > 2 else 4

rows_to_insert = []
row_num = 1

print(f"Processing {inventory_file} for upload_id {upload_id}...")

with open(inventory_file, 'r') as f:
    for line in f:
        parts = line.strip().split('|')
        if len(parts) >= 8:
            # Format: item_id|sku|name|supplier_uuid|supplier_name|qty|price|currency|uom
            item_id = parts[0]
            sku = parts[1]
            name = parts[2]
            supplier_uuid = parts[3]
            supplier_name = parts[4]
            qty = parts[5]
            price = parts[6]
            currency = parts[7]
            uom = parts[8] if len(parts) > 8 else 'each'

            # Get supplier_id from mapping
            supplier_id = supplier_map.get(supplier_uuid)

            if supplier_id:
                rows_to_insert.append((
                    upload_id,
                    row_num,
                    sku,
                    name,
                    None,  # brand
                    uom,
                    None,  # pack_size
                    price,
                    currency,
                    None,  # category_raw
                    None,  # vat_code
                    None,  # barcode
                    None,  # attrs_json
                    'pending',  # validation_status
                    None   # validation_errors
                ))
                row_num += 1
            else:
                print(f"Warning: No mapping for supplier {supplier_uuid} ({supplier_name})")

print(f"Prepared {len(rows_to_insert)} rows for insertion")

# Insert into Neon
conn = psycopg2.connect(NEON_CONN)
try:
    with conn.cursor() as cur:
        insert_sql = """
            INSERT INTO spp.pricelist_row
            (upload_id, row_num, supplier_sku, name, brand, uom, pack_size, price, currency,
             category_raw, vat_code, barcode, attrs_json, validation_status, validation_errors)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        execute_batch(cur, insert_sql, rows_to_insert, page_size=100)
        conn.commit()

        print(f"Successfully inserted {len(rows_to_insert)} rows into pricelist_row")

        # Update upload row_count
        cur.execute("UPDATE spp.pricelist_upload SET row_count = %s WHERE upload_id = %s",
                   (len(rows_to_insert), upload_id))
        conn.commit()

finally:
    conn.close()

print("Done!")
