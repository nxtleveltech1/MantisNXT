from pathlib import Path

path = Path('src/lib/stores/inventory-store.ts')
text = path.read_text()
search = 'set({ items: normalizedItems, loading: false })'
if search not in text:
    raise SystemExit('snippet missing')
text = text.replace(search, "console.log('inventory-store normalized items', normalizedItems.length);\n          set({ items: normalizedItems, loading: false })", 1)
path.write_text(text)
