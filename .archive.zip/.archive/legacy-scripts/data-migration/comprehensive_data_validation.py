#!/usr/bin/env python3
"""
COMPREHENSIVE SUPPLIER DATA VALIDATION
======================================
Validates all supplier data batches against Master template requirements.

Author: Python Agent Beta-2
Date: 2025-10-01
Purpose: Pre-Master aggregation quality assurance
"""

import pandas as pd
import openpyxl
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple
import numpy as np


# Master template column specification
REQUIRED_COLUMNS = [
    'Supplier Name ',
    'Supplier Code',
    'Produt Category',
    'BRAND',
    'Brand Sub Tag',
    'SKU / MODEL ',
    'PRODUCT DESCRIPTION',
    'SUPPLIER SOH',
    'COST  EX VAT',
    'QTY ON ORDER',
    'NEXT SHIPMENT',
    'Tags',
    'LINKS'
]

NUMERIC_COLUMNS = ['SUPPLIER SOH', 'COST  EX VAT', 'QTY ON ORDER']
CRITICAL_COLUMNS = ['Supplier Name ', 'Supplier Code', 'SKU / MODEL ']


class SupplierDataValidator:
    """Comprehensive validation for supplier data batches."""

    def __init__(self, batch_files: List[str]):
        self.batch_files = batch_files
        self.validation_results = []
        self.critical_issues = []
        self.warnings = []
        self.supplier_metrics = []

    def validate_batch(self, file_path: str, batch_name: str) -> Dict:
        """Validate a single batch file."""
        print(f"\n{'='*80}")
        print(f"VALIDATING: {batch_name}")
        print(f"File: {file_path}")
        print(f"{'='*80}")

        try:
            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names

            batch_results = {
                'batch_name': batch_name,
                'file_path': file_path,
                'total_sheets': len(sheet_names),
                'valid_sheets': 0,
                'total_rows': 0,
                'suppliers': []
            }

            # Skip Master/Template sheets
            data_sheets = [s for s in sheet_names if 'Master' not in s and 'Template' not in s]

            for sheet_name in data_sheets:
                print(f"\n  Analyzing: {sheet_name}")
                supplier_result = self.validate_supplier_tab(excel_file, sheet_name)
                batch_results['suppliers'].append(supplier_result)
                batch_results['total_rows'] += supplier_result['row_count']

                if supplier_result['is_valid']:
                    batch_results['valid_sheets'] += 1

            return batch_results

        except Exception as e:
            self.critical_issues.append(f"CRITICAL: Failed to open {batch_name}: {str(e)}")
            return {'batch_name': batch_name, 'error': str(e)}

    def validate_supplier_tab(self, excel_file: pd.ExcelFile, sheet_name: str) -> Dict:
        """Validate single supplier tab against Master template."""
        try:
            df = pd.read_excel(excel_file, sheet_name=sheet_name)

            result = {
                'supplier_name': sheet_name,
                'row_count': len(df),
                'is_valid': True,
                'quality_score': 100.0,
                'issues': [],
                'warnings': [],
                'metrics': {}
            }

            # 1. Column Structure Validation
            actual_columns = list(df.columns)
            column_match = actual_columns == REQUIRED_COLUMNS

            if not column_match:
                result['is_valid'] = False
                result['quality_score'] -= 30

                missing = set(REQUIRED_COLUMNS) - set(actual_columns)
                extra = set(actual_columns) - set(REQUIRED_COLUMNS)

                if missing:
                    issue = f"Missing columns: {', '.join(missing)}"
                    result['issues'].append(issue)
                    self.critical_issues.append(f"{sheet_name}: {issue}")

                if extra:
                    issue = f"Extra columns: {', '.join(extra)}"
                    result['issues'].append(issue)
                    result['warnings'].append(issue)

                # Check column order
                matching_cols = [c for c in actual_columns if c in REQUIRED_COLUMNS]
                expected_order = [c for c in REQUIRED_COLUMNS if c in actual_columns]
                if matching_cols != expected_order:
                    result['warnings'].append("Column order does not match Master template")

            # 2. Critical Field Completeness
            for col in CRITICAL_COLUMNS:
                if col in df.columns:
                    completeness = (df[col].notna().sum() / len(df)) * 100
                    result['metrics'][f'{col}_completeness'] = round(completeness, 2)

                    if completeness < 100:
                        result['quality_score'] -= (100 - completeness) * 0.3
                        if completeness < 90:
                            issue = f"{col}: Only {completeness:.1f}% complete (Critical)"
                            result['issues'].append(issue)
                            self.critical_issues.append(f"{sheet_name}: {issue}")
                        else:
                            result['warnings'].append(f"{col}: {completeness:.1f}% complete")

            # 3. Data Type Validation for Numeric Columns
            for col in NUMERIC_COLUMNS:
                if col in df.columns:
                    # Check for non-numeric values (excluding NaN)
                    non_null = df[col].dropna()
                    if len(non_null) > 0:
                        try:
                            numeric_values = pd.to_numeric(non_null, errors='coerce')
                            invalid_count = numeric_values.isna().sum()

                            if invalid_count > 0:
                                result['quality_score'] -= min(10, invalid_count * 0.1)
                                result['warnings'].append(
                                    f"{col}: {invalid_count} non-numeric values found"
                                )

                            # Check for negative values
                            if (numeric_values < 0).any():
                                neg_count = (numeric_values < 0).sum()
                                result['warnings'].append(
                                    f"{col}: {neg_count} negative values found"
                                )
                        except Exception as e:
                            result['warnings'].append(f"{col}: Type validation error - {str(e)}")

            # 4. Duplicate SKU Detection
            if 'SKU / MODEL ' in df.columns:
                sku_col = df['SKU / MODEL '].dropna()
                duplicates = sku_col.duplicated().sum()
                result['metrics']['duplicate_skus'] = duplicates

                if duplicates > 0:
                    result['quality_score'] -= min(15, duplicates * 0.5)
                    result['warnings'].append(f"Found {duplicates} duplicate SKUs")

            # 5. Additional Data Quality Checks
            if 'PRODUCT DESCRIPTION' in df.columns:
                desc_completeness = (df['PRODUCT DESCRIPTION'].notna().sum() / len(df)) * 100
                result['metrics']['description_completeness'] = round(desc_completeness, 2)

                if desc_completeness < 70:
                    result['warnings'].append(
                        f"Product Description only {desc_completeness:.1f}% complete"
                    )

            if 'COST  EX VAT' in df.columns:
                cost_completeness = (df['COST  EX VAT'].notna().sum() / len(df)) * 100
                result['metrics']['cost_completeness'] = round(cost_completeness, 2)

                if cost_completeness < 50:
                    result['warnings'].append(
                        f"Cost data only {cost_completeness:.1f}% complete"
                    )

            # 6. Brand Completeness
            if 'BRAND' in df.columns:
                brand_completeness = (df['BRAND'].notna().sum() / len(df)) * 100
                result['metrics']['brand_completeness'] = round(brand_completeness, 2)

            # Ensure quality score doesn't go below 0
            result['quality_score'] = max(0, result['quality_score'])

            return result

        except Exception as e:
            error_msg = f"Error validating {sheet_name}: {str(e)}"
            self.critical_issues.append(error_msg)
            return {
                'supplier_name': sheet_name,
                'is_valid': False,
                'quality_score': 0,
                'error': str(e)
            }

    def run_validation(self) -> Dict:
        """Run validation on all batches."""
        print("\n" + "="*80)
        print("COMPREHENSIVE SUPPLIER DATA VALIDATION")
        print("="*80)
        print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        all_results = []

        for file_path, batch_name in self.batch_files:
            if Path(file_path).exists():
                batch_result = self.validate_batch(file_path, batch_name)
                all_results.append(batch_result)
            else:
                error = f"File not found: {file_path}"
                self.critical_issues.append(error)
                all_results.append({'batch_name': batch_name, 'error': error})

        # Generate summary metrics
        summary = self.generate_summary(all_results)

        return {
            'summary': summary,
            'batch_results': all_results,
            'critical_issues': self.critical_issues,
            'warnings': self.warnings
        }

    def generate_summary(self, all_results: List[Dict]) -> Dict:
        """Generate overall summary statistics."""
        total_suppliers = 0
        total_rows = 0
        valid_suppliers = 0
        quality_scores = []

        for batch in all_results:
            if 'error' not in batch:
                total_suppliers += len(batch.get('suppliers', []))
                total_rows += batch.get('total_rows', 0)

                for supplier in batch.get('suppliers', []):
                    if supplier.get('is_valid'):
                        valid_suppliers += 1
                    quality_scores.append(supplier.get('quality_score', 0))

        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0

        return {
            'total_batches': len(all_results),
            'total_suppliers': total_suppliers,
            'total_rows': total_rows,
            'valid_suppliers': valid_suppliers,
            'invalid_suppliers': total_suppliers - valid_suppliers,
            'average_quality_score': round(avg_quality, 2),
            'critical_issues_count': len(self.critical_issues),
            'warnings_count': len(self.warnings)
        }

    def generate_markdown_report(self, results: Dict, output_path: str):
        """Generate comprehensive validation report in Markdown."""

        report = []
        report.append("# COMPREHENSIVE SUPPLIER DATA VALIDATION REPORT\n")
        report.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        report.append(f"**Validator:** Python Agent Beta-2\n")
        report.append("---\n\n")

        # Executive Summary
        summary = results['summary']
        report.append("## EXECUTIVE SUMMARY\n\n")

        overall_score = summary['average_quality_score']
        status = "EXCELLENT" if overall_score >= 90 else "GOOD" if overall_score >= 75 else "NEEDS IMPROVEMENT" if overall_score >= 60 else "CRITICAL"

        report.append(f"### Overall Data Quality Score: **{overall_score:.1f}/100** - {status}\n\n")

        report.append("| Metric | Value |\n")
        report.append("|--------|-------|\n")
        report.append(f"| Total Batches Processed | {summary['total_batches']} |\n")
        report.append(f"| Total Suppliers | {summary['total_suppliers']} |\n")
        report.append(f"| Total Product Rows | {summary['total_rows']:,} |\n")
        report.append(f"| Valid Suppliers | {summary['valid_suppliers']} |\n")
        report.append(f"| Invalid Suppliers | {summary['invalid_suppliers']} |\n")
        report.append(f"| Critical Issues | {summary['critical_issues_count']} |\n")
        report.append(f"| Warnings | {summary['warnings_count']} |\n\n")

        # Critical Issues
        if self.critical_issues:
            report.append("## CRITICAL ISSUES\n\n")
            report.append("**These issues MUST be resolved before Master aggregation:**\n\n")
            for i, issue in enumerate(self.critical_issues, 1):
                report.append(f"{i}. {issue}\n")
            report.append("\n")
        else:
            report.append("## CRITICAL ISSUES\n\n")
            report.append("✅ **No critical issues found!**\n\n")

        # Batch-by-Batch Results
        report.append("## BATCH-BY-BATCH ANALYSIS\n\n")

        for batch in results['batch_results']:
            if 'error' in batch:
                report.append(f"### {batch['batch_name']}\n\n")
                report.append(f"❌ **ERROR:** {batch['error']}\n\n")
                continue

            report.append(f"### {batch['batch_name']}\n\n")
            report.append(f"- **File:** `{batch['file_path']}`\n")
            report.append(f"- **Total Sheets:** {batch['total_sheets']}\n")
            report.append(f"- **Valid Sheets:** {batch['valid_sheets']}\n")
            report.append(f"- **Total Rows:** {batch['total_rows']:,}\n\n")

            # Per-Supplier Metrics Table
            if batch.get('suppliers'):
                report.append("#### Supplier Quality Metrics\n\n")
                report.append("| Supplier | Rows | Quality Score | Status | Issues |\n")
                report.append("|----------|------|---------------|--------|--------|\n")

                for supplier in batch['suppliers']:
                    if 'error' in supplier:
                        report.append(f"| {supplier['supplier_name']} | - | 0 | ❌ ERROR | {supplier['error']} |\n")
                        continue

                    status_icon = "✅" if supplier['is_valid'] else "⚠️"
                    issue_count = len(supplier.get('issues', []))
                    warning_count = len(supplier.get('warnings', []))

                    report.append(
                        f"| {supplier['supplier_name']} | "
                        f"{supplier['row_count']:,} | "
                        f"{supplier['quality_score']:.1f} | "
                        f"{status_icon} | "
                        f"{issue_count} issues, {warning_count} warnings |\n"
                    )

                report.append("\n")

        # Detailed Supplier Issues
        report.append("## DETAILED SUPPLIER ANALYSIS\n\n")

        for batch in results['batch_results']:
            if 'error' in batch or not batch.get('suppliers'):
                continue

            for supplier in batch['suppliers']:
                if 'error' in supplier:
                    continue

                if supplier.get('issues') or supplier.get('warnings'):
                    report.append(f"### {supplier['supplier_name']}\n\n")

                    # Metrics
                    if supplier.get('metrics'):
                        report.append("**Data Completeness:**\n\n")
                        for metric, value in supplier['metrics'].items():
                            report.append(f"- {metric}: {value}%\n")
                        report.append("\n")

                    # Issues
                    if supplier.get('issues'):
                        report.append("**Issues:**\n\n")
                        for issue in supplier['issues']:
                            report.append(f"- ❌ {issue}\n")
                        report.append("\n")

                    # Warnings
                    if supplier.get('warnings'):
                        report.append("**Warnings:**\n\n")
                        for warning in supplier['warnings']:
                            report.append(f"- ⚠️ {warning}\n")
                        report.append("\n")

        # Recommendations
        report.append("## RECOMMENDATIONS\n\n")

        if summary['critical_issues_count'] == 0:
            report.append("### ✅ Ready for Master Aggregation\n\n")
            report.append("All batches meet minimum quality standards. Proceed with Master consolidation.\n\n")
        else:
            report.append("### ⚠️ Action Required Before Master Aggregation\n\n")
            report.append("1. **Resolve all critical issues** listed above\n")
            report.append("2. **Re-validate** affected supplier tabs after fixes\n")
            report.append("3. **Verify column structure** matches Master template exactly\n")
            report.append("4. **Address duplicate SKUs** where found\n\n")

        if summary['warnings_count'] > 0:
            report.append("### Suggested Improvements\n\n")
            report.append("While not blocking, consider addressing:\n\n")
            report.append("- Incomplete product descriptions\n")
            report.append("- Missing cost data\n")
            report.append("- Missing brand information\n")
            report.append("- Non-numeric values in numeric columns\n\n")

        report.append("---\n\n")
        report.append("**Next Steps:**\n\n")
        report.append("1. Review this report with data owners\n")
        report.append("2. Fix critical issues in source files\n")
        report.append("3. Re-run validation script\n")
        report.append("4. Proceed to Master aggregation when validation passes\n\n")

        report.append("---\n")
        report.append(f"*Report generated by comprehensive_data_validation.py*\n")

        # Write report
        with open(output_path, 'w', encoding='utf-8') as f:
            f.writelines(report)

        print(f"\n✅ Validation report saved to: {output_path}")


def main():
    """Main execution function."""

    # Define batch files
    base_path = "/mnt/k/00Project/MantisNXT/database/Uploads"
    batch_files = [
        (f"{base_path}/Consolidated_Supplier_Data_BATCH1.xlsx", "BATCH 1"),
        (f"{base_path}/Consolidated_Supplier_Data_Batch2.xlsx", "BATCH 2"),
        (f"{base_path}/Consolidated_Batch3_Final.xlsx", "BATCH 3")
    ]

    # Create validator
    validator = SupplierDataValidator(batch_files)

    # Run validation
    results = validator.run_validation()

    # Generate report
    output_path = f"{base_path}/COMPREHENSIVE_VALIDATION_REPORT.md"
    validator.generate_markdown_report(results, output_path)

    # Print summary to console
    print("\n" + "="*80)
    print("VALIDATION COMPLETE")
    print("="*80)
    print(f"\nOverall Quality Score: {results['summary']['average_quality_score']:.1f}/100")
    print(f"Critical Issues: {results['summary']['critical_issues_count']}")
    print(f"Warnings: {results['summary']['warnings_count']}")
    print(f"\nFull report: {output_path}")
    print("="*80 + "\n")

    return results


if __name__ == "__main__":
    main()
