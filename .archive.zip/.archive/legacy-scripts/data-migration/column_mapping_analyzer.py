#!/usr/bin/env python3
"""
Column Mapping Analysis and Auto-Fix Script
============================================
Identifies column name variations and creates mapping for standardization.
"""

import pandas as pd
from pathlib import Path
from collections import defaultdict


def analyze_column_variations(batch_files):
    """Analyze all column variations across batches."""

    print("\n" + "="*80)
    print("COLUMN VARIATION ANALYSIS")
    print("="*80)

    # Master template columns
    master_columns = [
        'Supplier Name ',
        'Supplier Code',
        'Produt Category',
        'BRAND',
        'Brand Sub Tag',
        'SKU / MODEL ',
        'PRODUCT DESCRIPTION',
        'SUPPLIER SOH',
        'COST  EX VAT',
        'QTY ON ORDER',
        'NEXT SHIPMENT',
        'Tags',
        'LINKS'
    ]

    column_variations = defaultdict(set)

    for file_path, batch_name in batch_files:
        if not Path(file_path).exists():
            continue

        print(f"\nAnalyzing {batch_name}...")
        excel_file = pd.ExcelFile(file_path)

        for sheet_name in excel_file.sheet_names:
            if 'Master' in sheet_name or 'Processing' in sheet_name or 'All_Products' in sheet_name:
                continue

            df = pd.read_excel(excel_file, sheet_name=sheet_name)

            # Find similar columns
            for actual_col in df.columns:
                for master_col in master_columns:
                    # Case-insensitive similarity check
                    if actual_col.lower().replace(' ', '').replace('_', '') == master_col.lower().replace(' ', '').replace('_', ''):
                        column_variations[master_col].add(actual_col)

    # Print variations
    print("\n" + "="*80)
    print("COLUMN NAME VARIATIONS DETECTED")
    print("="*80)

    for master_col in master_columns:
        variations = column_variations.get(master_col, set())
        if variations and master_col not in variations:
            print(f"\n{master_col}:")
            for var in sorted(variations):
                print(f"  - {var}")

    return column_variations


def create_column_mapping():
    """Create explicit column mapping dictionary."""

    mapping = {
        # Common variations found
        'Supplier Name': 'Supplier Name ',
        'SKU / MODEL': 'SKU / MODEL ',
        'COST EX VAT': 'COST  EX VAT',
        'Product Category': 'Produt Category',

        # Exact matches (no change needed)
        'Supplier Name ': 'Supplier Name ',
        'Supplier Code': 'Supplier Code',
        'Produt Category': 'Produt Category',
        'BRAND': 'BRAND',
        'Brand Sub Tag': 'Brand Sub Tag',
        'SKU / MODEL ': 'SKU / MODEL ',
        'PRODUCT DESCRIPTION': 'PRODUCT DESCRIPTION',
        'SUPPLIER SOH': 'SUPPLIER SOH',
        'COST  EX VAT': 'COST  EX VAT',
        'QTY ON ORDER': 'QTY ON ORDER',
        'NEXT SHIPMENT': 'NEXT SHIPMENT',
        'Tags': 'Tags',
        'LINKS': 'LINKS'
    }

    return mapping


def identify_missing_suppliers_in_batch2():
    """Check which Batch 2 suppliers are missing Supplier Name/Code."""

    file_path = "/mnt/k/00Project/MantisNXT/database/Uploads/Consolidated_Supplier_Data_Batch2.xlsx"
    excel_file = pd.ExcelFile(file_path)

    print("\n" + "="*80)
    print("BATCH 2 - MISSING SUPPLIER NAME/CODE ANALYSIS")
    print("="*80)

    problem_suppliers = []

    for sheet_name in excel_file.sheet_names:
        if 'Master' in sheet_name or 'Processing' in sheet_name or 'All_Products' in sheet_name:
            continue

        df = pd.read_excel(excel_file, sheet_name=sheet_name)

        supplier_name_completeness = 0
        supplier_code_completeness = 0

        if 'Supplier Name ' in df.columns:
            supplier_name_completeness = (df['Supplier Name '].notna().sum() / len(df)) * 100

        if 'Supplier Code' in df.columns:
            supplier_code_completeness = (df['Supplier Code'].notna().sum() / len(df)) * 100

        if supplier_name_completeness < 10 or supplier_code_completeness < 10:
            problem_suppliers.append({
                'sheet': sheet_name,
                'rows': len(df),
                'supplier_name_pct': supplier_name_completeness,
                'supplier_code_pct': supplier_code_completeness,
                'columns': list(df.columns)
            })

            print(f"\n{sheet_name}:")
            print(f"  Rows: {len(df)}")
            print(f"  Supplier Name completion: {supplier_name_completeness:.1f}%")
            print(f"  Supplier Code completion: {supplier_code_completeness:.1f}%")
            print(f"  Columns: {df.columns.tolist()[:5]}...")

    return problem_suppliers


if __name__ == "__main__":
    base_path = "/mnt/k/00Project/MantisNXT/database/Uploads"

    batch_files = [
        (f"{base_path}/Consolidated_Supplier_Data_BATCH1.xlsx", "BATCH 1"),
        (f"{base_path}/Consolidated_Supplier_Data_Batch2.xlsx", "BATCH 2"),
        (f"{base_path}/Consolidated_Batch3_Final.xlsx", "BATCH 3")
    ]

    # Analyze column variations
    variations = analyze_column_variations(batch_files)

    # Check Batch 2 supplier issues
    batch2_issues = identify_missing_suppliers_in_batch2()

    print("\n" + "="*80)
    print("ANALYSIS COMPLETE")
    print("="*80)
