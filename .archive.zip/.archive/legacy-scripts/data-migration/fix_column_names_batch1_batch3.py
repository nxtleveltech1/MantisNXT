#!/usr/bin/env python3
"""
Automated Column Name Fixing Script
====================================
Renames columns in Batch 1 and Batch 3 to match Master template exactly.

Author: Python Agent Beta-2
Purpose: Phase 1 fix - Column naming standardization
"""

import pandas as pd
import openpyxl
from pathlib import Path
from datetime import datetime


def fix_column_names(file_path, output_path, batch_name):
    """Fix column names to match Master template exactly."""

    print(f"\n{'='*80}")
    print(f"FIXING: {batch_name}")
    print(f"{'='*80}")

    # Column name mapping (variations → Master template)
    column_mapping = {
        # Common variations
        'Supplier Name': 'Supplier Name ',
        'SKU / MODEL': 'SKU / MODEL ',
        'SKU / Model': 'SKU / MODEL ',
        'COST EX VAT': 'COST  EX VAT',
        'Cost  Ex VAT': 'COST  EX VAT',
        'Product Category': 'Produt Category',
        'Product Description': 'PRODUCT DESCRIPTION',
        'Supplier SOH': 'SUPPLIER SOH',
        'Qty On Order': 'QTY ON ORDER',
        'Next Shipment': 'NEXT SHIPMENT',
        'Links': 'LINKS',

        # Already correct (pass-through)
        'Supplier Name ': 'Supplier Name ',
        'Supplier Code': 'Supplier Code',
        'Produt Category': 'Produt Category',
        'BRAND': 'BRAND',
        'Brand Sub Tag': 'Brand Sub Tag',
        'SKU / MODEL ': 'SKU / MODEL ',
        'PRODUCT DESCRIPTION': 'PRODUCT DESCRIPTION',
        'SUPPLIER SOH': 'SUPPLIER SOH',
        'COST  EX VAT': 'COST  EX VAT',
        'QTY ON ORDER': 'QTY ON ORDER',
        'NEXT SHIPMENT': 'NEXT SHIPMENT',
        'Tags': 'Tags',
        'LINKS': 'LINKS'
    }

    # Load workbook
    excel_file = pd.ExcelFile(file_path)
    writer = pd.ExcelWriter(output_path, engine='openpyxl')

    fixed_count = 0
    skipped_count = 0

    for sheet_name in excel_file.sheet_names:
        print(f"\n  Processing: {sheet_name}")

        # Skip utility sheets
        if sheet_name in ['All_Products', 'Processing_Log']:
            print(f"    ⏭️  Skipped (utility sheet)")
            skipped_count += 1
            continue

        df = pd.read_excel(excel_file, sheet_name=sheet_name)

        # Rename columns using mapping
        original_columns = df.columns.tolist()
        renamed_columns = []

        for col in original_columns:
            if col in column_mapping:
                renamed_columns.append(column_mapping[col])
            else:
                renamed_columns.append(col)

        df.columns = renamed_columns

        # Check if any changes were made
        if original_columns != renamed_columns:
            changes = []
            for orig, new in zip(original_columns, renamed_columns):
                if orig != new:
                    changes.append(f"{orig} → {new}")

            print(f"    ✅ Fixed {len(changes)} columns:")
            for change in changes:
                print(f"       - {change}")
            fixed_count += 1
        else:
            print(f"    ✓ Already correct")

        # Write to output file
        df.to_excel(writer, sheet_name=sheet_name, index=False)

    writer.close()

    print(f"\n{'='*80}")
    print(f"SUMMARY: {batch_name}")
    print(f"{'='*80}")
    print(f"  Sheets Fixed: {fixed_count}")
    print(f"  Sheets Skipped: {skipped_count}")
    print(f"  Output: {output_path}")
    print(f"{'='*80}\n")


def main():
    """Main execution function."""

    base_path = "/mnt/k/00Project/MantisNXT/database/Uploads"

    # Batch 1
    print("\n" + "="*80)
    print("PHASE 1: COLUMN NAME STANDARDIZATION")
    print("="*80)

    fix_column_names(
        file_path=f"{base_path}/Consolidated_Supplier_Data_BATCH1.xlsx",
        output_path=f"{base_path}/Consolidated_Supplier_Data_BATCH1_FIXED.xlsx",
        batch_name="BATCH 1"
    )

    # Batch 3
    fix_column_names(
        file_path=f"{base_path}/Consolidated_Batch3_Final.xlsx",
        output_path=f"{base_path}/Consolidated_Batch3_Final_FIXED.xlsx",
        batch_name="BATCH 3"
    )

    print("\n" + "="*80)
    print("PHASE 1 COMPLETE")
    print("="*80)
    print("\nNext Step: Run fix_supplier_metadata_batch2.py")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
