#!/usr/bin/env python3
"""
Supplier Metadata Population Script
====================================
Populates empty Supplier Name and Supplier Code columns in Batch 2.

Author: Python Agent Beta-2
Purpose: Phase 2 fix - Supplier metadata completion
"""

import pandas as pd
import openpyxl
from pathlib import Path
import re


def generate_supplier_code(supplier_name):
    """Generate standardized supplier code from name."""

    # Remove common words
    name = supplier_name.upper()
    name = name.replace('DISTRIBUTION', 'DIST')
    name = name.replace(' ', '_')

    # Limit to 10 characters
    if len(name) > 10:
        # Take first 10 chars or use abbreviation
        parts = name.split('_')
        if len(parts) > 1:
            # Use first letters of each word
            code = ''.join([p[:3] for p in parts])[:10]
        else:
            code = name[:10]
    else:
        code = name

    return code


def fix_supplier_metadata(file_path, output_path):
    """Populate Supplier Name and Supplier Code columns."""

    print(f"\n{'='*80}")
    print("FIXING: BATCH 2 - SUPPLIER METADATA")
    print(f"{'='*80}")

    # Supplier mapping with explicit codes
    supplier_mapping = {
        'MD Distribution': {'name': 'MD Distribution', 'code': 'MD_DIST'},
        'Music Power': {'name': 'Music Power', 'code': 'MUSIC_PWR'},
        'Planetworld': {'name': 'Planetworld', 'code': 'PLANETW'},
        'Rockit': {'name': 'Rockit', 'code': 'ROCKIT'},
        'Sennheiser': {'name': 'Sennheiser', 'code': 'SENNHEIS'},
        'Rolling Thunder': {'name': 'Rolling Thunder', 'code': 'ROLL_THUN'}
    }

    # Load workbook
    excel_file = pd.ExcelFile(file_path)
    writer = pd.ExcelWriter(output_path, engine='openpyxl')

    fixed_count = 0
    skipped_count = 0

    for sheet_name in excel_file.sheet_names:
        print(f"\n  Processing: {sheet_name}")

        # Skip utility sheets
        if sheet_name in ['MASTER', 'All_Products', 'Processing_Log', 'ApexPro Distribution', 'Active Music']:
            print(f"    ⏭️  Skipped (not in scope)")
            df = pd.read_excel(excel_file, sheet_name=sheet_name)
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            skipped_count += 1
            continue

        df = pd.read_excel(excel_file, sheet_name=sheet_name)

        # Check if Supplier Name and Code are empty
        if 'Supplier Name ' in df.columns and 'Supplier Code' in df.columns:
            supplier_name_empty = df['Supplier Name '].isna().sum() == len(df)
            supplier_code_empty = df['Supplier Code'].isna().sum() == len(df)

            if supplier_name_empty or supplier_code_empty:
                # Get supplier info from mapping or generate
                if sheet_name in supplier_mapping:
                    supplier_info = supplier_mapping[sheet_name]
                    supplier_name = supplier_info['name']
                    supplier_code = supplier_info['code']
                else:
                    # Fallback: use sheet name
                    supplier_name = sheet_name
                    supplier_code = generate_supplier_code(sheet_name)

                # Populate columns
                if supplier_name_empty:
                    df['Supplier Name '] = supplier_name
                    print(f"    ✅ Populated 'Supplier Name ': {supplier_name}")

                if supplier_code_empty:
                    df['Supplier Code'] = supplier_code
                    print(f"    ✅ Populated 'Supplier Code': {supplier_code}")

                fixed_count += 1
            else:
                print(f"    ✓ Already populated")
        else:
            print(f"    ⚠️  Missing Supplier Name/Code columns")

        # Write to output file
        df.to_excel(writer, sheet_name=sheet_name, index=False)

    writer.close()

    print(f"\n{'='*80}")
    print("SUMMARY: BATCH 2")
    print(f"{'='*80}")
    print(f"  Sheets Fixed: {fixed_count}")
    print(f"  Sheets Skipped: {skipped_count}")
    print(f"  Output: {output_path}")
    print(f"{'='*80}\n")


def main():
    """Main execution function."""

    base_path = "/mnt/k/00Project/MantisNXT/database/Uploads"

    print("\n" + "="*80)
    print("PHASE 2: SUPPLIER METADATA POPULATION")
    print("="*80)

    fix_supplier_metadata(
        file_path=f"{base_path}/Consolidated_Supplier_Data_Batch2.xlsx",
        output_path=f"{base_path}/Consolidated_Supplier_Data_Batch2_FIXED.xlsx"
    )

    print("\n" + "="*80)
    print("PHASE 2 COMPLETE")
    print("="*80)
    print("\nNext Step: Investigate Rockit duplicates (analyze_rockit_duplicates.py)")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
