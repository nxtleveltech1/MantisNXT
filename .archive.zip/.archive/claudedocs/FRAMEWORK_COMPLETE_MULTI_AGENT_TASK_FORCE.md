# COMPLETE MULTI-AGENT TASK FORCE METHODOLOGY
## Comprehensive Framework for Systematic Project Execution

**Version**: 2.0
**Date**: 2025-10-08
**Status**: Production-Ready
**Portability**: 100% (Self-Contained, Replicable)

---

## TABLE OF CONTENTS

1. [Framework Overview](#framework-overview)
2. [Core Methodology Rules](#core-methodology-rules)
3. [Agent Architecture](#agent-architecture)
4. [5-Phase Process](#5-phase-process)
5. [Validation Framework](#validation-framework)
6. [Deliverable Formats](#deliverable-formats)
7. [Execution Patterns](#execution-patterns)
8. [Tool Usage Guidelines](#tool-usage-guidelines)
9. [Quality Assurance](#quality-assurance)
10. [Troubleshooting & Recovery](#troubleshooting--recovery)
11. [Implementation Checklist](#implementation-checklist)
12. [Complete Examples](#complete-examples)

---

## 1. FRAMEWORK OVERVIEW

### 1.1 Purpose

The Multi-Agent Task Force Methodology is a systematic approach to complex software engineering projects using specialized AI agents coordinated through a rigorous, validated process.

### 1.2 Key Principles

1. **Specialization**: Each agent focuses on a specific domain (infrastructure, database, frontend, etc.)
2. **Parallelization**: Independent work streams execute concurrently for maximum efficiency
3. **Validation**: Objective compliance checks ensure quality and completeness
4. **Evidence-Based**: All claims supported by data, measurements, or documented standards
5. **Iterative**: Work proceeds through structured phases with validation gates

### 1.3 Success Metrics

- **Delivery Rate**: 100% of planned deliverables completed
- **Compliance Score**: ≥9/10 on all validation checks
- **Cross-Agent Coordination**: All dependencies documented and resolved
- **Evidence Quality**: Zero subjective ratings without supporting data
- **Implementation Timeline**: Predictable, phase-based delivery

---

## 2. CORE METHODOLOGY RULES

### RULE 0: Sequential-Thinking Planning (MANDATORY)

**Requirement**: Use `mcp__sequential-thinking__sequentialthinking` MCP tool BEFORE executing each phase.

**Why**: Prevents rushed execution, ensures proper planning, documents decision process.

**Implementation Steps**:
1. Invoke sequential-thinking MCP with 5-7 thoughts
2. Document planning in `ITERATION_X_[PHASE]_PLANNING.md`
3. Save planning file to disk BEFORE deploying agents
4. Include: objectives, constraints, agent responsibilities, success criteria

**Planning File Structure**:
```
ITERATION_X_[PHASE]_PLANNING.md
├─ THOUGHT 1/N: Objectives & Agent Responsibilities
├─ THOUGHT 2/N: Constraints & Dependencies
├─ THOUGHT 3/N: Specific Deliverables Per Agent
├─ THOUGHT 4/N: Critical Trade-offs
└─ THOUGHT N/N: Execution Approach & Success Criteria
```

**Validation**: Compliance-enforcer checks for planning file existence with sequential-thinking output.

**Failure Impact**: CRITICAL - Phase validation fails if planning not documented.

---

### RULE 1: Agent Structure (7 Agents Total)

**Requirement**: 6 working agents + 1 compliance enforcer.

**Working Agents** (execute tasks):
1. **production-incident-responder**
   - Domain: Error monitoring, incident response, API resilience
   - MCP Tools: Native tools, web search
   - Focus: Rate limiting, circuit breakers, health checks, error logging

2. **aster-fullstack-architect**
   - Domain: Schema design, API contracts, system architecture
   - MCP Tools: Neon, Context7, native tools
   - Focus: Database schema, API design, replication architecture

3. **data-oracle**
   - Domain: Database operations, data integrity, replication
   - MCP Tools: Neon, Postgres, native SQL tools
   - Focus: Logical replication, master data, referential integrity

4. **infra-config-reviewer**
   - Domain: Security, infrastructure config, deployment
   - MCP Tools: File system, Bash, Grep, native tools
   - Focus: Credential management, connection pools, git security

5. **ui-perfection-doer**
   - Domain: Frontend errors, UX, accessibility, testing
   - MCP Tools: Chrome DevTools, Playwright, shadcn, native tools
   - Focus: Error boundaries, WCAG compliance, form validation

6. **ml-architecture-expert**
   - Domain: Performance optimization, caching, query tuning
   - MCP Tools: Neon, Postgres, native tools
   - Focus: Cache integration, materialized views, index optimization

**Compliance Agent** (validates work, does NOT implement):
7. **compliance-enforcer**
   - Domain: Validation, quality assurance, rule enforcement
   - MCP Tools: Read, Grep, native tools
   - Focus: 10 objective validation checks (see Section 5)

**Why 6 Working Agents**: Covers all major domains without overlap:
- Infrastructure/Security (infra-config-reviewer)
- Backend Architecture (aster-fullstack-architect)
- Database Operations (data-oracle)
- Performance (ml-architecture-expert)
- Frontend/UX (ui-perfection-doer)
- Operations/Monitoring (production-incident-responder)

---

### RULE 1.3: Parallel Execution (ONE Message, Multiple Tasks)

**Requirement**: Deploy all 6 working agents in a SINGLE message with 6 Task tool calls.

**Why**: Maximize efficiency, ensure parallel execution, prevent sequential bottlenecks.

**Correct Pattern** (Single Message):
```
Message with 6 Task tool invocations:
- Task 1: production-incident-responder prompt
- Task 2: aster-fullstack-architect prompt
- Task 3: data-oracle prompt
- Task 4: infra-config-reviewer prompt
- Task 5: ui-perfection-doer prompt
- Task 6: ml-architecture-expert prompt
```

**Incorrect Pattern** (Multiple Messages):
```
❌ Message 1: Deploy production-incident-responder
❌ Wait for result
❌ Message 2: Deploy aster-fullstack-architect
❌ Wait for result
...
This is SEQUENTIAL, not PARALLEL - violates RULE 1.3
```

**Validation**: Compliance-enforcer verifies all 6 agents participated in same execution cycle.

---

### RULE 2: MCP Tool Usage with Logging

**Requirement**: All agents must use MCP tools and document tool usage in reports.

**MCP Tools Available**:
- **sequential-thinking**: Multi-step reasoning for complex analysis
- **neon**: Database operations on Neon serverless Postgres
- **postgres**: Direct PostgreSQL operations
- **chrome-devtools**: Browser automation and testing
- **playwright**: E2E testing and visual validation
- **context7**: Official library documentation lookup
- **shadcn**: UI component generation
- **fs**: File system operations (read, write, edit)

**Tool Usage Documentation Format**:
```markdown
## MCP TOOL USAGE LOG

1. **tool_name**: operation_description
   - Input: specific parameters
   - Output: result summary
   - Purpose: why this tool was used

Example:
1. **mcp__neon__describe_project**: Retrieved Neon project metadata
   - Input: project_id = proud-mud-50346856
   - Output: 2 CU autoscaling, wal_level=logical
   - Purpose: Verify replication readiness
```

**Validation**: Each agent report must include "MCP TOOL USAGE LOG" section.

---

### RULE 3: Report Persistence

**Requirement**: All agent reports must be written to markdown files on disk.

**File Naming Convention**:
```
ITERATION_[N]_[PHASE]_[agent-name].md

Examples:
- ITERATION_2_DISCOVERY_production-incident-responder.md
- ITERATION_2_DESIGN_aster-fullstack-architect.md
- ITERATION_2_DEVELOPMENT_data-oracle.md
```

**File Location**: Centralized documentation directory (e.g., `claudedocs/`, `docs/iterations/`)

**Why**: Conversation-only reports are ephemeral and lost. Disk persistence enables:
- Version control tracking
- Team review and collaboration
- Historical reference
- Compliance auditing

**Validation**: Compliance-enforcer verifies file existence using Read or Glob tools.

---

## 3. AGENT ARCHITECTURE

### 3.1 Agent Prompt Template

Each agent receives a structured prompt containing:

```markdown
**AGENT**: [agent-name]
**PHASE**: [DISCOVERY|DESIGN|DEVELOPMENT|DELIVERY|ASSESSMENT]
**ITERATION**: [N]
**DATE**: [YYYY-MM-DD]

---

## CONTEXT FROM PREVIOUS PHASE

[If DESIGN phase, include DISCOVERY findings]
[If DEVELOPMENT phase, include DESIGN ADRs]
[If DELIVERY phase, include DEVELOPMENT changes]
[If ASSESSMENT phase, include DELIVERY validation]

---

## YOUR MISSION

As **[agent-name]**, your mission is to [phase-specific objective]:

**DISCOVERY Phase**: Conduct comprehensive [domain] audit
- Identify P0/P1/P2/P3 issues
- Document evidence using MCP tools
- Minimum deliverable: ≥5 findings

**DESIGN Phase**: Propose Architecture Decision Records (ADRs)
- Analyze alternatives (Option A vs B vs C)
- Provide trade-off analysis (pros/cons, cost, complexity)
- Minimum deliverable: ≥5 ADRs

**DEVELOPMENT Phase**: Implement approved ADRs
- Execute P0 items first
- Validate implementation
- Minimum deliverable: Working code + tests

**DELIVERY Phase**: Validate deployment
- Test in staging/production
- Verify acceptance criteria
- Minimum deliverable: Deployment validation report

**ASSESSMENT Phase**: Self-evaluate and recommend
- Analyze outcomes vs objectives
- Identify improvements
- Minimum deliverable: Evaluation + 5 recommendations

---

## DELIVERABLE FORMAT

[Phase-specific format - see Section 6]

---

## CONSTRAINTS

- Use MCP tools: [list available tools for this agent]
- Document tool usage in "MCP TOOL USAGE LOG" section
- Reference specific findings/ADRs from previous phases
- No subjective ratings without evidence
- All performance claims must include measurements
- All cost estimates must include hourly breakdowns

---

## SUCCESS CRITERIA

- Minimum deliverable met (≥5 findings/ADRs)
- All deliverables include evidence
- MCP tool usage documented
- Cross-agent dependencies identified
- Report written to disk as markdown file

---

## COORDINATION

**Dependencies on other agents**:
[List which agents this agent depends on and why]

**Agents depending on you**:
[List which agents need your outputs and why]

---

BEGIN YOUR [PHASE] WORK NOW.
```

### 3.2 Agent-Specific Customization

Each agent receives customized guidance based on their domain:

**production-incident-responder**:
```markdown
Focus Areas:
- External error monitoring (Sentry, DataDog, alternatives)
- Rate limiting strategies (API gateway, middleware, database-level)
- Circuit breaker patterns (Resilience4j, Polly, Opossum, custom)
- Promise error isolation (Promise.allSettled vs try-catch)
- Health check endpoint design (fail-fast vs fallback)
- Error logging infrastructure (database-backed vs external-only)
- Query timeout configuration (connection-level vs statement-level)

MCP Tools Available:
- WebSearch (for industry best practices)
- Native tools (Grep, Read, Write)

Expected Deliverables:
- DISCOVERY: 5-10 findings about error handling gaps
- DESIGN: 5-7 ADRs for monitoring/resilience infrastructure
```

**aster-fullstack-architect**:
```markdown
Focus Areas:
- Database schema design and migration strategies
- API contract enforcement (direct queries vs view abstraction)
- Replication architecture (real-time vs batch vs hybrid)
- Constraint naming conventions
- Multi-schema governance policies
- Schema divergence detection

MCP Tools Available:
- mcp__neon__* (all Neon database operations)
- mcp__context7__* (framework documentation lookup)
- Native tools (Read, Write, Grep)

Expected Deliverables:
- DISCOVERY: 5-10 findings about schema/API issues
- DESIGN: 5-7 ADRs for schema migrations and architecture
```

**data-oracle**:
```markdown
Focus Areas:
- Logical replication configuration (publications, subscriptions)
- Master data seeding strategies
- Historical data architecture (backfill vs fresh start)
- Missing table creation (schema design)
- Replication monitoring and alerting
- Referential integrity enforcement (FK constraints, cascade rules)

MCP Tools Available:
- mcp__neon__* (Neon database operations)
- mcp__postgres__* (Direct PostgreSQL operations)
- Native SQL tools

Expected Deliverables:
- DISCOVERY: 5-10 findings about data integrity and replication
- DESIGN: 5-7 ADRs for database operations and replication
```

**infra-config-reviewer**:
```markdown
Focus Areas:
- Credential rotation protocols (git-tracked secrets)
- Secret management solutions (env vars, Vault, AWS Secrets Manager)
- Connection pool sizing (serverless optimization)
- Git history cleaning (BFG, git-filter-repo)
- Configuration centralization (single source of truth)
- Cryptographic secret generation (OpenSSL, UUID, custom)
- Database timeout configuration

MCP Tools Available:
- mcp__fs__* (file system operations)
- Bash (git operations, system commands)
- Grep (search for credentials, hardcoded values)
- Native tools (Read, Write, Edit)

Expected Deliverables:
- DISCOVERY: 5-10 findings about security and config issues
- DESIGN: 5-7 ADRs for infrastructure hardening
```

**ui-perfection-doer**:
```markdown
Focus Areas:
- Error boundary hierarchy (root, page, component levels)
- WCAG accessibility framework (AA vs AAA compliance)
- Loading state standardization (skeleton, spinner, progressive)
- Form validation UX (inline vs submit-only)
- Responsive breakpoint strategy (mobile-first vs desktop-first)
- React Query integration (data fetching patterns)
- Keyboard navigation enhancement (roving tabindex, skip links)

MCP Tools Available:
- mcp__chrome-devtools__* (browser testing and console logs)
- mcp__playwright__* (E2E testing and accessibility)
- mcp__shadcn__* (UI component generation)
- Native tools (Read, Write, Edit)

Expected Deliverables:
- DISCOVERY: 5-10 findings about UX and accessibility gaps
- DESIGN: 5-7 ADRs for frontend excellence
```

**ml-architecture-expert**:
```markdown
Focus Areas:
- Cache integration rollout (phased vs big-bang)
- Materialized view strategy (critical aggregations only)
- Index optimization priority (data-driven via EXPLAIN ANALYZE)
- Query optimization approach (rewrite vs add indexes)
- Performance monitoring infrastructure (Prometheus, Grafana)
- Cache invalidation strategy (event-driven vs time-based)
- Connection pool tuning (alignment with infrastructure)

MCP Tools Available:
- mcp__neon__* (query performance analysis)
- mcp__postgres__* (EXPLAIN ANALYZE, index creation)
- Native tools (Read, Write, Grep)

Expected Deliverables:
- DISCOVERY: 5-10 findings about performance gaps
- DESIGN: 5-7 ADRs for optimization strategies
```

### 3.3 Compliance-Enforcer Specification

**Role**: Validates phase deliverables against 10 objective criteria (does NOT implement).

**Prompt Template**:
```markdown
**AGENT**: compliance-enforcer
**PHASE VALIDATING**: [DISCOVERY|DESIGN|DEVELOPMENT|DELIVERY]
**ITERATION**: [N]
**DATE**: [YYYY-MM-DD]

---

## VALIDATION MISSION

You are the compliance-enforcer agent. Your role is to validate that the [PHASE] phase deliverables meet all 10 objective validation criteria defined in the methodology.

**IMPORTANT**: You do NOT implement features, write code, or create deliverables. You ONLY validate existing work.

---

## VALIDATION CRITERIA (10 CHECKS)

Perform the following 10 objective checks:

### CHECK 1: Agent Participation
**Criterion**: All 6 working agents participated
**Validation Method**: Verify 6 agent-specific report files exist
**Pass Condition**: 6 files found
**Fail Condition**: <6 files found

### CHECK 2: Minimum Deliverables
**Criterion**: Each agent delivered ≥5 [findings/ADRs/implementations]
**Validation Method**: Count deliverables in each report
**Pass Condition**: All agents ≥5 items
**Fail Condition**: Any agent <5 items

### CHECK 3: Trade-off Analysis (DESIGN phase only)
**Criterion**: Each ADR has "Alternatives Considered" section
**Validation Method**: Search for "Alternatives Considered" in each ADR
**Pass Condition**: All ADRs have alternatives with pros/cons
**Fail Condition**: Any ADR missing alternatives section

### CHECK 4: Cross-cutting Dependencies
**Criterion**: All reports document coordination requirements
**Validation Method**: Search for "CROSS-CUTTING CONCERNS" or "Coordination" section
**Pass Condition**: All reports have coordination section
**Fail Condition**: Any report missing coordination section

### CHECK 5: Previous Phase References
**Criterion**: All deliverables cite specific prior phase findings/ADRs
**Validation Method**: Search for "[DISCOVERY|DESIGN] Finding X" citations
**Pass Condition**: All deliverables reference previous work
**Fail Condition**: Deliverables lack context from prior phases

### CHECK 6: Objectivity
**Criterion**: No subjective ratings without supporting evidence
**Validation Method**: Search for subjective language ("excellent", "blazingly fast", percentage claims without data)
**Pass Condition**: All claims evidence-based
**Fail Condition**: Subjective ratings found without data

### CHECK 7: RULE 0 Compliance
**Criterion**: Sequential-thinking planning documented before phase execution
**Validation Method**: Verify ITERATION_X_[PHASE]_PLANNING.md exists with sequential-thinking output
**Pass Condition**: Planning file exists with 5+ thoughts
**Fail Condition**: Planning file missing or incomplete

### CHECK 8: File Persistence
**Criterion**: All reports written to markdown files on disk
**Validation Method**: Use Read or Glob to verify file existence
**Pass Condition**: All required files exist on disk
**Fail Condition**: Reports only in conversation, not on disk

### CHECK 9: MCP Tool Usage Documentation
**Criterion**: All reports document MCP tool usage
**Validation Method**: Search for "MCP TOOL USAGE LOG" or tool invocation descriptions
**Pass Condition**: Tool usage documented in all reports
**Fail Condition**: Tool usage not documented

### CHECK 10: Objective Validation Methodology
**Criterion**: All validation checks use objective, verifiable criteria
**Validation Method**: Self-check that all 10 checks are binary pass/fail
**Pass Condition**: All checks use objective criteria
**Fail Condition**: Any check relies on subjective judgment

---

## OUTPUT FORMAT

Produce a validation report with this exact structure:

```
ITERATION X - [PHASE] PHASE VALIDATION REPORT
============================================

CHECK 1: Agent Participation
Status: PASS/FAIL
Details: [Specific findings - list agents found/missing]

CHECK 2: Minimum Deliverables
Status: PASS/FAIL
Details: [ADR/finding counts per agent]

[... all 10 checks ...]

OVERALL COMPLIANCE SCORE: X/10 PASSED

VERDICT: PASS/FAIL
Recommendation: [PROCEED TO NEXT PHASE or REMEDIATE ISSUES]

[If FAIL, provide specific remediation guidance]
```

---

## VALIDATION EXECUTION STEPS

1. Read all required files from disk:
   - ITERATION_X_[PHASE]_PLANNING.md
   - ITERATION_X_[PHASE]_[agent-name].md (6 files)

2. Perform all 10 validation checks systematically

3. Document findings for each check (PASS/FAIL with evidence)

4. Calculate compliance score (X/10)

5. Output validation report

6. Provide final verdict: PASS (proceed) or FAIL (remediate)

---

BEGIN VALIDATION NOW.
```

---

## 4. 5-PHASE PROCESS

### 4.1 Phase Overview

Each iteration follows 5 sequential phases with validation gates:

```
ITERATION N
├─ PHASE 1: DISCOVERY
│  ├─ RULE 0: Sequential-thinking planning
│  ├─ Deploy 6 agents in parallel (RULE 1.3)
│  ├─ Each agent: Find ≥5 issues (P0/P1/P2/P3)
│  ├─ Write reports to disk
│  └─ Validation: compliance-enforcer (10 checks)
│
├─ PHASE 2: DESIGN
│  ├─ RULE 0: Sequential-thinking planning
│  ├─ Deploy 6 agents in parallel (RULE 1.3)
│  ├─ Each agent: Propose ≥5 ADRs with trade-offs
│  ├─ Write reports to disk
│  └─ Validation: compliance-enforcer (10 checks)
│
├─ PHASE 3: DEVELOPMENT
│  ├─ RULE 0: Sequential-thinking planning
│  ├─ Deploy 6 agents in parallel (RULE 1.3)
│  ├─ Each agent: Implement approved P0 ADRs
│  ├─ Write code + tests
│  └─ Validation: compliance-enforcer (10 checks)
│
├─ PHASE 4: DELIVERY
│  ├─ RULE 0: Sequential-thinking planning
│  ├─ Deploy 6 agents in parallel (RULE 1.3)
│  ├─ Each agent: Validate deployment
│  ├─ Test in staging/production
│  └─ Validation: compliance-enforcer (10 checks)
│
└─ PHASE 5: ASSESSMENT
   ├─ RULE 0: Sequential-thinking planning
   ├─ Deploy 6 agents in parallel (RULE 1.3)
   ├─ Each agent: Self-evaluate + 5 recommendations
   ├─ Write retrospective
   └─ Validation: compliance-enforcer (10 checks)
```

### 4.2 Phase 1: DISCOVERY

**Objective**: Conduct comprehensive audit across all 6 domains to identify issues.

**Agent Tasks**:
- Analyze current state using MCP tools
- Identify gaps, issues, and opportunities
- Classify findings by priority (P0/P1/P2/P3)
- Document evidence (tool outputs, measurements, examples)
- Minimum: ≥5 findings per agent

**Priority Classification**:
- **P0 (Critical)**: Blocks deployment, security risk, data corruption risk
- **P1 (High)**: Major functionality gap, significant performance issue
- **P2 (Medium)**: UX degradation, maintainability issue
- **P3 (Low)**: Nice-to-have, future enhancement

**Deliverable Format** (per agent):
```markdown
# ITERATION X - DISCOVERY - [agent-name]

## Agent: [agent-name]
**Date**: YYYY-MM-DD
**Phase**: DISCOVERY

---

## Executive Summary

[2-3 paragraph overview of discoveries]

---

## FINDINGS

### Finding 1: [Issue Title]
**Severity**: P0/P1/P2/P3
**Description**: [Detailed description of the issue]
**Evidence**:
```[code/data/tool output showing the issue]```
**Impact**:
- [Specific impact on users/system/team]
**Recommendation**: [High-level fix approach]

### Finding 2: [Issue Title]
... [repeat for ≥5 findings]

---

## MCP TOOL USAGE LOG

1. **tool_name**: operation_description
   - Purpose: why used
   - Result: what discovered

[Document all tool invocations]

---

## SUMMARY

**Total Findings**: X
**Critical (P0)**: X
**High (P1)**: X
**Medium (P2)**: X
**Low (P3)**: X

**Top 3 Priorities**:
1. [P0 finding summary]
2. [P0 finding summary]
3. [P1 finding summary]
```

**Validation Criteria**:
- ≥5 findings per agent
- All findings have severity classification
- Evidence included for each finding
- MCP tool usage documented
- Cross-agent dependencies noted

### 4.3 Phase 2: DESIGN

**Objective**: Propose Architecture Decision Records (ADRs) addressing DISCOVERY findings.

**Agent Tasks**:
- Analyze DISCOVERY findings (context)
- Research alternatives (3+ options per ADR)
- Perform trade-off analysis (pros/cons/cost/complexity)
- Select recommended approach with rationale
- Minimum: ≥5 ADRs per agent

**ADR Structure**:
```markdown
## ADR-N: [Decision Title]

**Status**: Proposed
**Priority**: P0/P1/P2

**Context**:
DISCOVERY Finding X identified [problem description with evidence].

**Decision**:
Implement **[Chosen Option]** with [key characteristics].

**Alternatives Considered**:

**Option A: [Chosen Option Name]**
- **Pros**:
  - [Specific benefit 1]
  - [Specific benefit 2]
- **Cons**:
  - [Specific drawback 1]
  - [Specific drawback 2]
- **Implementation Complexity**: Low/Medium/High ([time estimate])
- **Cost**: $[amount] ([cost breakdown])

**Option B: [Alternative Option Name]**
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Implementation Complexity**: [level]
- **Cost**: $[amount]

**Option C: [Another Alternative]**
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Implementation Complexity**: [level]
- **Cost**: $[amount]

**Rationale**:
[Chosen option] wins because:
1. [Reason 1 with evidence]
2. [Reason 2 with evidence]
3. [Reason 3 with evidence]

[Alternative X] rejected due to [specific reason with data].

**Consequences**:
- **Immediate Benefits**: [quantified benefits]
- **Dependencies**: [list of dependencies on other systems/agents]
- **Risks**: [identified risks and mitigation]
- **Technical Debt**: [debt introduced or eliminated]
- **Coordination**: [which agents need to coordinate]

**Implementation Notes**:
```[code examples, configuration samples, key technical details]```

**Cost Projection**:
- Development: $150/hr × Xhrs = $X,XXX (X days)
- Infrastructure: $X/month
- Total Year 1: $X,XXX
```

**Deliverable Format** (per agent):
```markdown
# ITERATION X - DESIGN PHASE REPORT
## Architecture Decision Records for [Domain]

**Agent**: [agent-name]
**Phase**: DESIGN
**Date**: YYYY-MM-DD
**Status**: Proposed (Awaiting Implementation Approval)

---

## Executive Summary

Based on DISCOVERY findings revealing [summary of key issues], I propose X comprehensive ADRs addressing [high-level themes].

**Key Design Decisions**:
- [ADR-1 topic]: [Chosen approach] (chosen) vs [alternatives]
- [ADR-2 topic]: [Chosen approach] (chosen) vs [alternatives]
...

---

## ADR-1: [Title]
[Full ADR structure as shown above]

## ADR-2: [Title]
[Full ADR structure]

... [repeat for ≥5 ADRs]

---

## CROSS-CUTTING CONCERNS

### Coordination with Other Agents

**[other-agent-name]**:
- ADR-X: [What coordination is needed and why]

[List all inter-agent dependencies]

---

## IMPLEMENTATION ROADMAP

### Phase 1: [Theme] (Weeks X-Y)
**Goal**: [High-level objective]

1. **Week X**: ADR-N ([description])
2. **Week Y**: ADR-M ([description])

[Organize ADRs into logical implementation phases]

---

## COST ANALYSIS

### One-Time Development Costs
| ADR | Description | Hours | Cost |
|-----|-------------|-------|------|
| ADR-1 | [desc] | X | $X,XXX |
| ADR-2 | [desc] | Y | $Y,YYY |
| **Total** | | **XX** | **$XX,XXX** |

### Recurring Monthly Costs
| Service | Plan | Cost/Month |
|---------|------|------------|
| [Service] | [Plan] | $XX |
| **Total** | | **$XX/month** |

### ROI Analysis
**Problem Cost** (current state):
- [Issue 1]: $X/month
- [Issue 2]: $Y/month
- **Total problem cost**: $Z/month = $W/year

**Solution Cost**:
- One-time: $X
- Recurring: $Y/month × 12 = $Z/year
- **Total Year 1**: $W

**ROI**:
- Year 1 savings: $X - $Y = **$Z profit**
- Break-even: Month X
- 3-year ROI: **$X profit**

---

## CONCLUSION

These X ADRs provide comprehensive [domain] improvements for [project]:

1. **ADR-1 ([Title])**: [One-line benefit summary]
2. **ADR-2 ([Title])**: [One-line benefit summary]
...

**Total Investment**: $X development + $Y/month recurring = **Z× ROI in Year 1**

**Implementation Timeline**: X weeks to production-ready [domain]

**Next Phase**: IMPLEMENT - Execute ADRs in priority order (P0 first)

---

**Report Status**: COMPLETE - Ready for IMPLEMENT phase
**Deliverable**: X comprehensive ADRs with trade-off analysis, cost projections, and implementation roadmap
**Cross-Agent Dependencies**: Documented for [list agents]
```

**Validation Criteria**:
- ≥5 ADRs per agent
- All ADRs reference DISCOVERY findings
- All ADRs have ≥3 alternatives with trade-offs
- Cost projections included (hourly breakdown + ROI)
- Cross-cutting dependencies documented
- Implementation roadmap provided

### 4.4 Phase 3: DEVELOPMENT

**Objective**: Implement approved P0 ADRs from DESIGN phase.

**Agent Tasks**:
- Review approved ADRs from DESIGN phase
- Implement P0 (Critical) items first
- Write production-ready code
- Add tests (unit, integration, E2E as appropriate)
- Document implementation
- Minimum: All P0 ADRs implemented + tested

**Prioritization**:
1. P0 ADRs (Critical - blocks deployment)
2. P1 ADRs (High - major impact)
3. P2 ADRs (Medium - nice to have)
4. P3 ADRs (Low - future enhancement)

**Deliverable Format** (per agent):
```markdown
# ITERATION X - DEVELOPMENT REPORT
## Implementation of [Domain] ADRs

**Agent**: [agent-name]
**Phase**: DEVELOPMENT
**Date**: YYYY-MM-DD
**Status**: Implemented (Awaiting Deployment Validation)

---

## Executive Summary

Implemented X P0 ADRs from DESIGN phase, addressing [high-level themes].

**Implementation Summary**:
- ADR-1 ([Title]): [Status - Implemented/Partial/Blocked]
- ADR-2 ([Title]): [Status]
...

**Test Coverage**: X% (X/Y tests passing)

---

## IMPLEMENTATION DETAILS

### ADR-1: [Title] Implementation

**Status**: ✅ COMPLETE / ⏳ IN PROGRESS / ❌ BLOCKED

**Files Changed**:
- `path/to/file1.ts` - [description of changes]
- `path/to/file2.sql` - [description of changes]

**Code Changes**:
```[language]
// Key implementation code with comments
```

**Tests Added**:
```[language]
// Test code demonstrating validation
```

**Validation**:
- [X] Unit tests passing (X/X)
- [X] Integration tests passing (X/X)
- [X] Manual testing completed
- [X] Performance benchmarks met ([before vs after])

**Issues Encountered**:
- [Issue description and resolution]

---

[Repeat for each ADR implemented]

---

## TEST RESULTS

### Unit Tests
```
Total: XX tests
Passed: XX
Failed: 0
Coverage: XX%
```

### Integration Tests
```
Total: XX tests
Passed: XX
Failed: 0
```

### Performance Tests
```
[Before vs After metrics]
API Response Time: 500ms → 50ms (90% improvement)
Database Query Time: 200ms → 20ms (90% improvement)
```

---

## DEPLOYMENT READINESS

**Checklist**:
- [X] All P0 ADRs implemented
- [X] All tests passing
- [X] Code review completed
- [X] Documentation updated
- [X] Migration scripts ready
- [X] Rollback plan documented

**Dependencies**:
- [List any infrastructure/environment requirements]

**Risks**:
- [Identified deployment risks and mitigation]

---

## NEXT STEPS

Ready for DELIVERY phase validation:
1. Deploy to staging environment
2. Run smoke tests
3. Performance validation
4. Security scan
5. Production deployment

---

**Report Status**: COMPLETE - Ready for DELIVERY phase
**Files Modified**: XX files across Y domains
**Test Coverage**: XX%
**Deployment Readiness**: [READY/NOT READY - explain]
```

**Validation Criteria**:
- All P0 ADRs implemented (or blocking issues documented)
- Tests written and passing
- Code changes documented
- Performance benchmarks met (if applicable)
- Deployment checklist complete

### 4.5 Phase 4: DELIVERY

**Objective**: Validate deployment in staging/production environments.

**Agent Tasks**:
- Deploy implementations from DEVELOPMENT phase
- Run smoke tests in staging
- Validate acceptance criteria
- Monitor for errors/performance issues
- Document deployment results
- Minimum: All P0 implementations validated

**Deliverable Format** (per agent):
```markdown
# ITERATION X - DELIVERY VALIDATION REPORT
## Deployment Validation for [Domain]

**Agent**: [agent-name]
**Phase**: DELIVERY
**Date**: YYYY-MM-DD
**Environment**: Staging/Production

---

## Executive Summary

Validated deployment of X implementations across [domain].

**Deployment Status**:
- Environment: [Staging/Production]
- Deployment Time: [timestamp]
- Status: ✅ SUCCESS / ⚠️ PARTIAL / ❌ FAILED

---

## DEPLOYMENT VALIDATION

### ADR-1: [Title] Validation

**Deployment Status**: ✅ SUCCESS / ⚠️ ISSUES / ❌ FAILED

**Smoke Tests**:
- [X] Feature accessible
- [X] No errors in logs
- [X] Performance within SLO
- [X] Data integrity verified

**Acceptance Criteria**:
- [X] [Criterion 1 from DESIGN phase]
- [X] [Criterion 2 from DESIGN phase]

**Metrics** (Before vs After):
- API Response Time: 500ms → 50ms ✅
- Error Rate: 5% → 0.1% ✅
- User Satisfaction: N/A → [if applicable]

**Issues Found**:
- [Issue description, severity, resolution status]

---

[Repeat for each ADR deployed]

---

## MONITORING RESULTS

**Period**: [Deployment time] to [Current time] ([X hours/days])

**System Health**:
- Uptime: XX.X%
- Error Rate: X.XX%
- Avg Response Time: XXXms
- Database Connections: X/Y (healthy)

**Alerts Triggered**:
- [Alert description, resolution]
- [None if no alerts]

**User Impact**:
- [Quantified impact if measurable]

---

## ROLLBACK READINESS

**Status**: READY / NOT NEEDED

**Rollback Plan**:
1. [Step 1 if rollback needed]
2. [Step 2]

**Rollback Tested**: YES / NO

---

## CONCLUSION

**Deployment Verdict**: ✅ SUCCESS / ⚠️ PARTIAL SUCCESS / ❌ FAILED

**Recommendations**:
- [Proceed to next phase / Fix issues / Rollback]

---

**Report Status**: COMPLETE - Ready for ASSESSMENT phase
**Deployment Success Rate**: XX%
**Issues Resolved**: XX/XX
**Production Readiness**: [READY/NOT READY]
```

**Validation Criteria**:
- All P0 implementations deployed
- Smoke tests passed
- Acceptance criteria met
- Monitoring shows healthy system
- Issues documented and resolved

### 4.6 Phase 5: ASSESSMENT

**Objective**: Self-evaluate iteration outcomes and provide recommendations.

**Agent Tasks**:
- Analyze iteration outcomes vs objectives
- Identify what worked well
- Identify what could improve
- Provide 5+ recommendations for next iteration
- Minimum: Evaluation + 5 recommendations

**Deliverable Format** (per agent):
```markdown
# ITERATION X - ASSESSMENT REPORT
## Self-Evaluation and Recommendations for [Domain]

**Agent**: [agent-name]
**Phase**: ASSESSMENT
**Date**: YYYY-MM-DD

---

## Executive Summary

[Summary of iteration outcomes, success rate, key learnings]

---

## OUTCOMES ANALYSIS

### Objectives vs Actuals

| Objective | Target | Actual | Status |
|-----------|--------|--------|--------|
| [Objective 1] | [Target metric] | [Actual metric] | ✅/⚠️/❌ |
| [Objective 2] | [Target metric] | [Actual metric] | ✅/⚠️/❌ |

**Success Rate**: XX% of objectives met

---

## WHAT WORKED WELL

1. **[Success 1]**: [Description with evidence]
2. **[Success 2]**: [Description with evidence]
3. **[Success 3]**: [Description with evidence]

---

## WHAT COULD IMPROVE

1. **[Issue 1]**: [Description with evidence]
   - Root Cause: [Analysis]
   - Impact: [Quantified impact]

2. **[Issue 2]**: [Description]
   - Root Cause: [Analysis]
   - Impact: [Impact]

---

## RECOMMENDATIONS (Next Iteration)

### Recommendation 1: [Title]
**Priority**: High/Medium/Low
**Description**: [Detailed recommendation]
**Rationale**: [Why this recommendation]
**Expected Impact**: [Quantified expected benefit]
**Implementation Effort**: [Time/cost estimate]

### Recommendation 2: [Title]
[Same structure]

... [≥5 recommendations total]

---

## METRICS SUMMARY

**Iteration X Metrics**:
- Time to Complete: X weeks (vs Y weeks estimated)
- Cost: $X (vs $Y budgeted)
- ROI Achieved: X× (vs Y× projected)
- Issues Found: X (P0: X, P1: X, P2: X, P3: X)
- ADRs Proposed: X
- ADRs Implemented: X (XX% completion)
- Test Coverage: XX%
- Deployment Success: XX%

---

## CONCLUSION

[Final summary of iteration, key takeaways, outlook for next iteration]

---

**Report Status**: COMPLETE
**Next Iteration Focus**: [Recommended focus areas]
```

**Validation Criteria**:
- Objectives vs actuals analyzed
- ≥5 recommendations provided
- Metrics summarized
- Evidence-based evaluation (no subjective claims)

---

## 5. VALIDATION FRAMEWORK

### 5.1 10 Objective Validation Checks

The compliance-enforcer performs these 10 checks after each phase:

**CHECK 1: Agent Participation**
- **What**: Verify all 6 working agents participated
- **How**: Count agent-specific report files
- **Pass**: 6 files exist
- **Fail**: <6 files exist

**CHECK 2: Minimum Deliverables**
- **What**: Each agent delivered ≥5 [findings/ADRs/implementations]
- **How**: Count deliverables in each report
- **Pass**: All agents ≥5 items
- **Fail**: Any agent <5 items

**CHECK 3: Trade-off Analysis** (DESIGN phase only)
- **What**: Each ADR has "Alternatives Considered" section
- **How**: Search for section presence and content (≥3 alternatives with pros/cons)
- **Pass**: All ADRs have comprehensive trade-offs
- **Fail**: Any ADR missing alternatives or trade-offs

**CHECK 4: Cross-cutting Dependencies**
- **What**: All reports document coordination requirements
- **How**: Search for "CROSS-CUTTING CONCERNS" or "Coordination" section
- **Pass**: All reports have coordination section
- **Fail**: Any report missing coordination section

**CHECK 5: Previous Phase References**
- **What**: All deliverables cite specific prior phase findings/ADRs
- **How**: Search for "[DISCOVERY|DESIGN] Finding X" or "ADR-X" citations
- **Pass**: All deliverables reference previous work with specifics
- **Fail**: Deliverables lack context from prior phases

**CHECK 6: Objectivity**
- **What**: No subjective ratings without supporting evidence
- **How**: Search for subjective language patterns:
  - "Excellent", "amazing", "blazingly fast" (without metrics)
  - Percentage claims without data sources
  - "100% secure", "perfectly optimized" (absolute claims)
  - X/10 ratings without criteria
- **Pass**: All claims evidence-based (measurements, citations, data)
- **Fail**: Subjective ratings found without supporting evidence

**CHECK 7: RULE 0 Compliance**
- **What**: Sequential-thinking planning documented before phase execution
- **How**: Verify `ITERATION_X_[PHASE]_PLANNING.md` exists with:
  - Sequential-thinking tool usage documented
  - 5+ thoughts present
  - Planning complete before agent deployment
- **Pass**: Planning file exists and complete
- **Fail**: Planning file missing or incomplete

**CHECK 8: File Persistence**
- **What**: All reports written to markdown files on disk
- **How**: Use Read or Glob to verify file existence
- **Pass**: All required files exist on disk (not just in conversation)
- **Fail**: Reports missing from disk

**CHECK 9: MCP Tool Usage Documentation**
- **What**: All reports document MCP tool usage
- **How**: Search for "MCP TOOL USAGE LOG" section or tool descriptions
- **Pass**: Tool usage documented with:
  - Tool name
  - Operation performed
  - Purpose/reason for use
- **Fail**: Tool usage not documented

**CHECK 10: Objective Validation Methodology**
- **What**: All validation checks use objective, verifiable criteria
- **How**: Self-check that all 9 checks above are binary pass/fail
- **Pass**: All checks use objective criteria (no subjective judgment)
- **Fail**: Any check relies on subjective evaluation

### 5.2 Validation Report Format

```markdown
ITERATION X - [PHASE] PHASE VALIDATION REPORT
============================================

**Date**: YYYY-MM-DD
**Validator**: compliance-enforcer
**Phase**: [DISCOVERY/DESIGN/DEVELOPMENT/DELIVERY/ASSESSMENT]

---

## CHECK 1: Agent Participation
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Files found: X/6
- [List of agent files found]
- [If FAIL: List missing agents]

---

## CHECK 2: Minimum Deliverables
**Status**: ✅ PASS / ❌ FAIL
**Details**:

| Agent | Deliverables | Required | Status |
|-------|--------------|----------|--------|
| Agent 1 | X | 5 | ✅/❌ |
| Agent 2 | Y | 5 | ✅/❌ |
...

**Total Deliverables**: XX (minimum: 30)

---

## CHECK 3: Trade-off Analysis
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- ADRs with trade-offs: XX/YY
- Sample evidence: [Quote from ADR showing alternatives]
- [If FAIL: List ADRs missing trade-offs]

---

## CHECK 4: Cross-cutting Dependencies
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Reports with coordination section: X/6
- [If FAIL: List reports missing coordination]

---

## CHECK 5: Previous Phase References
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Reports citing previous phase: X/6
- Sample citation: "[DISCOVERY Finding 1 identified...]"
- [If FAIL: List reports without references]

---

## CHECK 6: Objectivity
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Subjective language instances: X
- [If any found: Quote and location]
- Evidence-based claims: [Examples]

---

## CHECK 7: RULE 0 Compliance
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Planning file exists: YES/NO
- Sequential-thinking documented: YES/NO
- Thoughts present: X/5
- [If FAIL: Specific issue]

---

## CHECK 8: File Persistence
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Files on disk: X/7 (planning + 6 agent reports)
- [List of files verified]
- [If FAIL: List missing files]

---

## CHECK 9: MCP Tool Usage Documentation
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- Reports with tool usage log: X/6
- [If FAIL: List reports without tool documentation]

---

## CHECK 10: Objective Validation Methodology
**Status**: ✅ PASS / ❌ FAIL
**Details**:
- All checks objective: YES/NO
- [If FAIL: Identify subjective checks]

---

## OVERALL COMPLIANCE SCORE: X/10 PASSED

---

## VERDICT: ✅ PASS / ❌ FAIL

**Recommendation**:
- ✅ PASS: PROCEED TO [NEXT PHASE]
- ❌ FAIL: REMEDIATE ISSUES (see remediation guidance below)

### Remediation Guidance (if FAIL)

**CHECK X: [Failed Check Name]**
- Issue: [Specific problem]
- Fix: [Specific steps to remediate]
- Effort: [Time estimate]

---

**Validation Complete**: YYYY-MM-DD
**Validator**: compliance-enforcer
**Status**: [APPROVED / REQUIRES REMEDIATION]
```

### 5.3 Passing Criteria

**Overall Pass Threshold**: ≥9/10 checks must PASS

**Critical Checks** (Must pass, no exceptions):
- CHECK 1: Agent Participation (all 6 agents)
- CHECK 2: Minimum Deliverables (≥5 per agent)
- CHECK 7: RULE 0 Compliance (planning documented)
- CHECK 8: File Persistence (reports on disk)

**High-Priority Checks** (Should pass):
- CHECK 5: Previous Phase References
- CHECK 6: Objectivity
- CHECK 9: MCP Tool Usage

**Standard Checks** (Important but can be remediated):
- CHECK 3: Trade-off Analysis
- CHECK 4: Cross-cutting Dependencies
- CHECK 10: Objective Validation

**Failure Handling**:
- Score 10/10: PROCEED immediately
- Score 9/10: PROCEED with minor notes
- Score 7-8/10: REMEDIATE before proceeding
- Score <7/10: STOP, significant rework required

---

## 6. DELIVERABLE FORMATS

### 6.1 File Naming Convention

All deliverables follow strict naming:

```
ITERATION_[N]_[PHASE]_[COMPONENT].md

Examples:
- ITERATION_2_DISCOVERY_PLANNING.md
- ITERATION_2_DISCOVERY_production-incident-responder.md
- ITERATION_2_DESIGN_PLANNING.md
- ITERATION_2_DESIGN_aster-fullstack-architect.md
- ITERATION_2_DEVELOPMENT_data-oracle.md
- ITERATION_2_DELIVERY_infra-config-reviewer.md
- ITERATION_2_ASSESSMENT_ui-perfection-doer.md
```

### 6.2 Directory Structure

```
project_root/
├── claudedocs/                    # All methodology deliverables
│   ├── ITERATION_1_DISCOVERY_PLANNING.md
│   ├── ITERATION_1_DISCOVERY_agent1.md
│   ├── ITERATION_1_DISCOVERY_agent2.md
│   ├── ...
│   ├── ITERATION_2_DISCOVERY_PLANNING.md
│   ├── ITERATION_2_DISCOVERY_agent1.md
│   ├── ...
│   └── FRAMEWORK_COMPLETE_MULTI_AGENT_TASK_FORCE.md  # This document
├── src/                           # Application code
├── database/                      # Database migrations, seeds
│   ├── migrations/
│   └── seeds/
├── scripts/                       # Utility scripts
└── README.md
```

### 6.3 Document Metadata

Every deliverable includes standardized header:

```markdown
# ITERATION X - [PHASE] - [COMPONENT]

**Agent**: [agent-name] / PLANNING / VALIDATION
**Phase**: [DISCOVERY/DESIGN/DEVELOPMENT/DELIVERY/ASSESSMENT]
**Date**: YYYY-MM-DD
**Status**: [In Progress/Complete/Validated/Approved]

---

## [Phase-specific sections follow]
```

---

## 7. EXECUTION PATTERNS

### 7.1 Sequential-Thinking Planning Pattern

**When**: Before each phase (RULE 0 requirement)

**Process**:
1. Identify phase objectives
2. Map agent responsibilities
3. Define success criteria
4. Consider constraints and dependencies
5. Plan execution approach

**Tool Invocation**:
```
Tool: mcp__sequential-thinking__sequentialthinking
Parameters:
- thought: [Current thinking step]
- nextThoughtNeeded: true/false
- thoughtNumber: [1-N]
- totalThoughts: [estimated total]
```

**Output**: Save to `ITERATION_X_[PHASE]_PLANNING.md`

### 7.2 Parallel Agent Deployment Pattern

**When**: After planning complete (RULE 1.3 requirement)

**Process**:
1. Prepare prompts for all 6 agents
2. Deploy in SINGLE message with 6 Task calls
3. Wait for all agents to complete
4. Collect results from all agents
5. Write reports to disk

**Anti-Pattern** (INCORRECT):
```
❌ Deploy agent 1 → wait → deploy agent 2 → wait → ...
This is SEQUENTIAL, violates RULE 1.3
```

**Correct Pattern**:
```
✅ Single message with 6 Task calls → all agents execute in parallel
```

### 7.3 Report Writing Pattern

**When**: After agents complete their work

**Process**:
1. For each agent result:
   - Read existing file (if overwriting - required by Write tool)
   - Format report using phase-specific template
   - Write to disk using Write tool
   - Verify file written successfully

**Code Pattern**:
```
For each agent in [agent1, agent2, agent3, agent4, agent5, agent6]:
  1. Collect agent output from Task result
  2. Format as markdown using template
  3. Write(file_path=claudedocs/ITERATION_X_PHASE_agentN.md, content=report)
  4. Verify write succeeded
```

### 7.4 Validation Pattern

**When**: After all reports written to disk

**Process**:
1. Deploy compliance-enforcer agent
2. Provide validation prompt with file locations
3. Enforcer reads all files from disk
4. Enforcer performs 10 objective checks
5. Enforcer outputs validation report
6. Review compliance score (X/10)
7. If ≥9/10: Proceed to next phase
8. If <9/10: Remediate issues

**Tool Invocation**:
```
Tool: Task
Parameters:
- subagent_type: compliance-enforcer
- description: Validate [PHASE] phase compliance
- prompt: [Structured validation prompt with file locations]
```

---

## 8. TOOL USAGE GUIDELINES

### 8.1 MCP Tool Selection Matrix

| Task Type | Primary Tool | Alternative | When to Use |
|-----------|-------------|-------------|-------------|
| **Planning** | sequential-thinking | Native reasoning | Complex multi-step analysis, RULE 0 |
| **Database Ops** | mcp__neon__* | mcp__postgres__* | All database queries, schema inspection |
| **Browser Testing** | mcp__chrome-devtools__* | mcp__playwright__* | Frontend testing, console logs |
| **File Operations** | mcp__fs__* | Native Read/Write | Bulk file operations, file search |
| **UI Components** | mcp__shadcn__* | Manual coding | Component generation, design system |
| **Documentation** | mcp__context7__* | WebSearch | Official library docs, framework patterns |

### 8.2 Sequential-Thinking MCP Usage

**Purpose**: Multi-step reasoning for complex analysis

**When to Use**:
- RULE 0 planning (mandatory)
- Complex debugging (multi-component failures)
- Architectural analysis (system design decisions)
- Trade-off evaluation (comparing 3+ alternatives)

**Parameters**:
```javascript
{
  thought: "Current thinking step",
  nextThoughtNeeded: true,  // or false when done
  thoughtNumber: 1,          // Current thought index
  totalThoughts: 5,          // Estimated total (can adjust)
  isRevision: false,         // true if revising previous thought
  revisesThought: null,      // Thought number being revised
  branchFromThought: null,   // Branching point (optional)
  branchId: null,            // Branch identifier (optional)
  needsMoreThoughts: false   // true if need to increase totalThoughts
}
```

**Example Usage**:
```
Thought 1/5: Analyze current error handling gaps across 43 pages
Thought 2/5: Identify root causes (no error boundaries, missing try-catch)
Thought 3/5: Evaluate solutions (root-only vs page-level vs 3-tier boundaries)
Thought 4/5: Trade-off analysis (UX impact, implementation effort, maintenance)
Thought 5/5: Recommend 3-tier hierarchy with rationale and cost estimate
```

### 8.3 Neon MCP Tool Usage

**Available Operations**:
- `mcp__neon__list_projects`: List Neon projects
- `mcp__neon__describe_project`: Get project details (CU, wal_level, branches)
- `mcp__neon__get_database_tables`: List all tables/views in schemas
- `mcp__neon__describe_table_schema`: Get column definitions, constraints, indexes
- `mcp__neon__run_sql`: Execute single SQL statement
- `mcp__neon__run_sql_transaction`: Execute multiple SQL statements in transaction
- `mcp__neon__explain_sql_statement`: Get query execution plan (EXPLAIN ANALYZE)
- `mcp__neon__get_connection_string`: Get PostgreSQL connection URL
- `mcp__neon__create_branch`: Create Neon branch for testing
- `mcp__neon__delete_branch`: Delete Neon branch
- `mcp__neon__describe_branch`: Get complete schema tree view

**Usage Pattern**:
```
1. describe_project → Understand environment (CU, limits, features)
2. get_database_tables → Enumerate all tables/views
3. describe_table_schema → Inspect specific table structure
4. run_sql → Execute queries for analysis
5. explain_sql_statement → Analyze query performance
```

**Tool Logging**:
```markdown
## MCP TOOL USAGE LOG

1. **mcp__neon__describe_project**: Retrieved Neon project metadata
   - Project ID: proud-mud-50346856
   - Autoscaling: 2 CU max
   - WAL Level: logical (replication-ready)
   - Purpose: Verify replication configuration capability

2. **mcp__neon__run_sql**: Queried pg_stat_activity for connection count
   - Query: SELECT count(*) FROM pg_stat_activity
   - Result: 5 active connections
   - Purpose: Validate connection pool sizing recommendations
```

### 8.4 Chrome DevTools MCP Usage

**Available Operations**:
- `mcp__chrome-devtools__list_pages`: Get all open browser tabs
- `mcp__chrome-devtools__navigate_page`: Navigate to URL
- `mcp__chrome-devtools__take_snapshot`: Get text snapshot of page elements
- `mcp__chrome-devtools__take_screenshot`: Capture visual screenshot
- `mcp__chrome-devtools__list_console_messages`: Get console logs (errors, warnings)
- `mcp__chrome-devtools__click`: Click element by UID
- `mcp__chrome-devtools__fill`: Fill form input by UID
- `mcp__chrome-devtools__evaluate_script`: Run JavaScript in page context
- `mcp__chrome-devtools__wait_for`: Wait for text to appear

**Usage Pattern** (UI testing):
```
1. list_pages → Identify active page
2. navigate_page → Go to application URL
3. take_snapshot → Get element UIDs
4. list_console_messages → Check for errors
5. evaluate_script → Run validation checks
6. take_screenshot → Capture visual evidence
```

**Tool Logging**:
```markdown
## MCP TOOL USAGE LOG

1. **mcp__chrome-devtools__navigate_page**: Loaded dashboard
   - URL: http://localhost:3000/dashboard
   - Load time: 1.2s
   - Purpose: Test error boundary coverage

2. **mcp__chrome-devtools__list_console_messages**: Captured console logs
   - Errors found: 3
   - Error 1: "Uncaught TypeError: Cannot read property 'name' of undefined"
   - Location: InventoryWidget.tsx:45
   - Purpose: Identify unhandled errors
```

### 8.5 Tool Usage Best Practices

**DO**:
- Use MCP tools for their specialized operations (Neon for DB, Chrome for frontend)
- Document every tool invocation in "MCP TOOL USAGE LOG" section
- Include purpose/reason for each tool use
- Capture relevant output (errors, metrics, findings)
- Use sequential-thinking for RULE 0 planning (mandatory)

**DON'T**:
- Use Bash for tasks that have specialized MCP tools (use Neon, not Bash psql)
- Skip tool usage documentation
- Use tools without understanding their output
- Ignore errors or warnings from tools

---

## 9. QUALITY ASSURANCE

### 9.1 Evidence Standards

**All claims must be verifiable through**:
1. **Measurements**: "500ms → 50ms" (before/after data)
2. **Tool Outputs**: Paste actual tool results, not summaries
3. **Code Examples**: Real code snippets, not pseudocode
4. **Citations**: Link to docs, standards (WCAG, PostgreSQL docs)
5. **Statistics**: Counts, percentages with denominators ("5/10 = 50%")

**Banned Subjective Language**:
- ❌ "Excellent performance" → ✅ "90% faster (500ms → 50ms)"
- ❌ "Blazingly fast" → ✅ "10× speedup measured"
- ❌ "100% secure" → ✅ "Passes OWASP Top 10 checklist"
- ❌ "Production-ready" → ✅ "Tested with X test cases, 95% coverage"
- ❌ "X/10 rating" → ✅ "Meets 8/10 criteria: [list criteria]"

### 9.2 Cost Projection Standards

**All cost estimates must include**:
1. **Hourly Breakdown**: "$150/hr × 8hrs = $1,200 (1 day)"
2. **Time Estimate**: "2-3 days" or "16-24 hours"
3. **Recurring Costs**: "$29/month (Sentry) + $10/month (Redis) = $39/month"
4. **ROI Calculation**:
   - Problem cost (current state)
   - Solution cost (one-time + recurring)
   - Savings calculation (problem - solution)
   - Break-even point (month/quarter)
   - 3-year ROI projection

**Example**:
```markdown
**Cost Projection**:
- Development: $150/hr × 24hrs = $3,600 (3 days)
- Infrastructure: $29/month (Sentry)
- Total Year 1: $3,600 + ($29 × 12) = $3,948

**ROI Analysis**:
- Problem Cost: $10,000/year (debugging without monitoring)
- Solution Cost: $3,948 (Year 1)
- Savings: $10,000 - $3,948 = $6,052 profit (Year 1)
- Break-even: Month 5
- 3-year ROI: ($10,000 × 3) - $3,948 = $26,052 profit
```

### 9.3 Performance Benchmark Standards

**Required for performance claims**:
1. **Before/After Metrics**: "Before: 500ms, After: 50ms"
2. **Improvement Percentage**: "90% faster" (calculated: (500-50)/500 = 90%)
3. **Measurement Method**: "Measured with Chrome DevTools Network tab"
4. **Sample Size**: "Average of 10 requests"
5. **Environment**: "Staging environment, 2 CU Neon, Redis cache enabled"

**Example**:
```markdown
**Performance Impact**:
- Metric: API Response Time (dashboard route)
- Before: 500ms average (10 samples, Chrome DevTools)
- After: 50ms average (10 samples, Chrome DevTools)
- Improvement: 90% faster (450ms saved)
- Environment: Staging, 2 CU Neon, Redis cache hit rate 85%
- Date Measured: 2025-10-08
```

### 9.4 Trade-off Analysis Standards

**Each ADR alternative must specify**:
1. **Pros**: ≥3 specific benefits (not generic)
2. **Cons**: ≥2 specific drawbacks
3. **Implementation Complexity**: Low/Medium/High + time estimate
4. **Cost**: $ estimate with breakdown
5. **Risk Level**: Low/Medium/High/Critical + mitigation

**Example**:
```markdown
**Option A: Sentry Cloud ($29/mo)**
- **Pros**:
  - 5-minute setup time (vs 3 days self-hosted)
  - 50K events/month included ($0.00045/extra event)
  - Session replay for debugging (10K replays/month)
- **Cons**:
  - Monthly cost: $29/mo minimum
  - Data egress to external service (GDPR consideration)
- **Implementation Complexity**: Low (5 minutes)
- **Cost**: $348/year ($29 × 12)
- **Risk**: Low (proven SaaS, 99.9% uptime SLA)
```

---

## 10. TROUBLESHOOTING & RECOVERY

### 10.1 Common Validation Failures

**Failure: CHECK 7 (RULE 0 Compliance) - Planning Not Documented**

**Symptoms**:
- Compliance-enforcer reports FAIL on CHECK 7
- Planning file missing or incomplete
- Sequential-thinking not documented

**Remediation**:
1. STOP current phase immediately
2. Use sequential-thinking MCP to create planning (5+ thoughts)
3. Save planning to `ITERATION_X_[PHASE]_PLANNING.md`
4. Re-run validation
5. Only proceed if validation passes

**Prevention**:
- Always start each phase with RULE 0 planning
- Verify planning file exists before deploying agents

---

**Failure: CHECK 2 (Minimum Deliverables) - Agent Delivered <5 Items**

**Symptoms**:
- Compliance-enforcer reports agent delivered 3/5 findings
- Report exists but insufficient content

**Remediation**:
1. Identify which agent(s) under-delivered
2. Re-deploy specific agent(s) with explicit minimum requirement
3. Merge results with existing report
4. Re-run validation

**Prevention**:
- Include "Minimum: ≥5 [findings/ADRs]" in agent prompts
- Check agent output before writing to disk

---

**Failure: CHECK 3 (Trade-off Analysis) - Missing Alternatives**

**Symptoms**:
- ADRs missing "Alternatives Considered" section
- Only one option presented without comparison

**Remediation**:
1. For each affected ADR:
   - Research 2+ alternative approaches
   - Add "Alternatives Considered" section
   - Include pros/cons for each alternative
   - Add rationale explaining chosen option vs alternatives
2. Update report files
3. Re-run validation

**Prevention**:
- Use ADR template (see Section 6)
- Require ≥3 alternatives per ADR in agent prompts

---

**Failure: CHECK 6 (Objectivity) - Subjective Claims Found**

**Symptoms**:
- Compliance-enforcer flags subjective language
- Example: "Excellent performance" without metrics

**Remediation**:
1. Find all subjective claims in reports
2. Replace with evidence-based statements:
   - "Excellent" → "90% faster (500ms → 50ms)"
   - "Blazingly fast" → "10× query speedup measured"
   - "100% secure" → "Passes OWASP Top 10 checklist"
3. Update reports
4. Re-run validation

**Prevention**:
- Include objectivity requirement in agent prompts
- Review reports before validation for subjective language

---

**Failure: CHECK 8 (File Persistence) - Reports Not on Disk**

**Symptoms**:
- Compliance-enforcer cannot read files
- Reports exist in conversation only

**Remediation**:
1. For each missing report:
   - Extract report content from conversation
   - Use Write tool to save to disk
   - Verify file exists with Read tool
2. Re-run validation

**Prevention**:
- Always use Write tool after agent completes work
- Verify write succeeded before proceeding
- Use Read tool to confirm file persistence

---

### 10.2 Agent Deployment Issues

**Issue: Agents Deployed Sequentially Instead of Parallel**

**Symptoms**:
- Agents completed one at a time, not concurrently
- Total execution time = sum of individual times (not max)

**Diagnosis**:
- Multiple messages sent with individual Task calls (violates RULE 1.3)

**Fix**:
- Ensure SINGLE message contains ALL 6 Task calls
- Example:
  ```
  Message 1:
    - Task(agent1, prompt1)
    - Task(agent2, prompt2)
    - Task(agent3, prompt3)
    - Task(agent4, prompt4)
    - Task(agent5, prompt5)
    - Task(agent6, prompt6)

  Wait for all results before proceeding
  ```

---

**Issue: Agent Returns Empty or Incomplete Results**

**Symptoms**:
- Agent task completes but output is minimal
- Missing required sections (MCP tool usage, findings, etc.)

**Diagnosis**:
- Prompt unclear or missing requirements
- Agent scope too narrow

**Fix**:
1. Review agent prompt for clarity
2. Ensure prompt includes:
   - Phase-specific objective
   - Minimum deliverable (≥5 items)
   - Format requirements
   - MCP tools available
   - Success criteria
3. Re-deploy agent with enhanced prompt
4. Merge results

---

**Issue: Tool Invocation Errors**

**Symptoms**:
- Agent reports tool failures
- MCP tool returns errors

**Common Causes**:
1. **Invalid Parameters**: Check tool parameter requirements
2. **Missing Permissions**: Verify tool has access to resources
3. **Service Unavailable**: Check if MCP server running (e.g., Neon, Postgres)

**Fix**:
1. Review error message for specific issue
2. Correct parameter format/values
3. Verify service availability
4. Re-run tool invocation
5. If persistent, use alternative tool or manual approach

---

### 10.3 Recovery Procedures

**Scenario: Validation Fails with Score <7/10**

**Procedure**:
1. **STOP**: Do not proceed to next phase
2. **Analyze**: Review validation report for failed checks
3. **Prioritize**: Fix critical checks first (1, 2, 7, 8)
4. **Remediate**: Follow remediation guidance for each failed check
5. **Re-validate**: Deploy compliance-enforcer again
6. **Repeat**: Until score ≥9/10

**Escalation**: If after 2 remediation cycles score still <9/10:
- Review entire phase approach
- Consider restarting phase from RULE 0 planning
- Consult methodology documentation

---

**Scenario: Agent Produces Incorrect or Low-Quality Output**

**Procedure**:
1. **Diagnose**: Identify specific quality issues
   - Missing evidence?
   - Incorrect analysis?
   - Format violations?
2. **Root Cause**: Determine why
   - Prompt unclear?
   - Agent misunderstood scope?
   - Tool limitations?
3. **Correct**: Choose remediation approach
   - **Option A**: Re-deploy agent with corrected prompt
   - **Option B**: Manually enhance agent output
   - **Option C**: Split task across multiple agents
4. **Validate**: Ensure corrections meet quality standards
5. **Update**: Write corrected report to disk
6. **Re-validate**: Run compliance check

---

**Scenario: Cannot Proceed to Next Phase (Dependencies Blocking)**

**Procedure**:
1. **Identify**: What dependencies are blocking?
   - Infrastructure not ready? (Redis, database, etc.)
   - Code changes required first?
   - External approvals needed?
2. **Document**: Create blocking issue report
   ```markdown
   ## BLOCKER: [Title]
   **Blocking Phase**: [PHASE]
   **Dependencies**:
   - [Dependency 1]: [Status and resolution path]
   - [Dependency 2]: [Status and resolution path]

   **Resolution Plan**:
   1. [Step 1 with owner and timeline]
   2. [Step 2 with owner and timeline]

   **Expected Unblock Date**: YYYY-MM-DD
   ```
3. **Resolve**: Address blockers systematically
4. **Resume**: Return to blocked phase when ready

---

## 11. IMPLEMENTATION CHECKLIST

### 11.1 Pre-Iteration Setup

Before starting Iteration 1:

- [ ] Create `claudedocs/` directory for deliverables
- [ ] Verify all 6 working agent types available
- [ ] Verify compliance-enforcer agent type available
- [ ] Verify sequential-thinking MCP available
- [ ] Establish MCP tool availability:
  - [ ] mcp__neon__* (database operations)
  - [ ] mcp__chrome-devtools__* (frontend testing)
  - [ ] mcp__fs__* (file operations)
  - [ ] mcp__context7__* (documentation lookup)
  - [ ] Other project-specific MCP tools
- [ ] Review project structure and codebase
- [ ] Define iteration scope and objectives

### 11.2 Phase Execution Checklist

For each phase (DISCOVERY, DESIGN, DEVELOPMENT, DELIVERY, ASSESSMENT):

**Planning (RULE 0)**:
- [ ] Use sequential-thinking MCP (5+ thoughts)
- [ ] Document planning in `ITERATION_X_[PHASE]_PLANNING.md`
- [ ] Save planning file to disk BEFORE deploying agents
- [ ] Verify planning file written successfully

**Agent Deployment (RULE 1.3)**:
- [ ] Prepare prompts for all 6 agents
- [ ] Deploy in SINGLE message with 6 Task calls (parallel)
- [ ] Wait for all agents to complete
- [ ] Collect outputs from all 6 agents
- [ ] Verify all agents returned results

**Report Writing**:
- [ ] For each agent:
  - [ ] Format output using phase template
  - [ ] Include all required sections
  - [ ] Write to disk: `ITERATION_X_[PHASE]_[agent].md`
  - [ ] Verify file written successfully (use Read to confirm)
- [ ] Total files: 7 (planning + 6 agent reports)

**Validation**:
- [ ] Deploy compliance-enforcer agent
- [ ] Provide file locations in prompt
- [ ] Wait for validation report
- [ ] Review compliance score (X/10)
- [ ] If ≥9/10: Proceed to next phase
- [ ] If <9/10: Remediate and re-validate

**Phase Completion**:
- [ ] All reports on disk
- [ ] Validation passed (≥9/10)
- [ ] Next phase ready to start
- [ ] Update iteration status tracking

### 11.3 Quality Gate Checklist

Before proceeding from one phase to next:

**DISCOVERY → DESIGN**:
- [ ] All 6 agents delivered ≥5 findings
- [ ] Findings classified by priority (P0/P1/P2/P3)
- [ ] Evidence documented for all findings
- [ ] MCP tool usage logged
- [ ] Compliance score ≥9/10

**DESIGN → DEVELOPMENT**:
- [ ] All 6 agents delivered ≥5 ADRs
- [ ] All ADRs have ≥3 alternatives with trade-offs
- [ ] Cost projections included (hourly + ROI)
- [ ] Cross-agent dependencies documented
- [ ] Implementation roadmap provided
- [ ] Compliance score ≥9/10

**DEVELOPMENT → DELIVERY**:
- [ ] All P0 ADRs implemented
- [ ] Tests written and passing
- [ ] Code changes documented
- [ ] Performance benchmarks met (if applicable)
- [ ] Deployment checklist complete
- [ ] Compliance score ≥9/10

**DELIVERY → ASSESSMENT**:
- [ ] All P0 implementations deployed
- [ ] Smoke tests passed
- [ ] Acceptance criteria met
- [ ] Monitoring shows healthy system
- [ ] Issues documented and resolved
- [ ] Compliance score ≥9/10

**ASSESSMENT → Next Iteration**:
- [ ] Objectives vs actuals analyzed
- [ ] ≥5 recommendations provided per agent
- [ ] Metrics summarized
- [ ] Evidence-based evaluation
- [ ] Next iteration scope defined
- [ ] Compliance score ≥9/10

### 11.4 Post-Iteration Review

After completing all 5 phases:

- [ ] Review all deliverables (35+ files: 5 planning + 30 agent reports)
- [ ] Verify all validation reports passed
- [ ] Calculate overall metrics:
  - [ ] Total findings identified
  - [ ] Total ADRs proposed
  - [ ] Total ADRs implemented
  - [ ] Time to complete iteration
  - [ ] Cost vs budget
  - [ ] ROI achieved vs projected
- [ ] Document lessons learned
- [ ] Plan next iteration scope

---

## 12. COMPLETE EXAMPLES

### 12.1 Example: ITERATION 2 DISCOVERY Phase

**Step 1: RULE 0 Planning (Sequential-Thinking)**

File: `ITERATION_2_DISCOVERY_PLANNING.md` (205 lines)

Content:
```markdown
# ITERATION 2 DISCOVERY PHASE - PLANNING (RULE 0 COMPLIANCE)

**Date**: 2025-10-08
**Phase**: DISCOVERY
**Planning Method**: Sequential-Thinking MCP (5 thoughts)

---

## THOUGHT 1/5: Agent Responsibilities & Objectives

**Context**: Need comprehensive audit across 6 domains

**Agent Responsibilities**:
1. **production-incident-responder** → Error monitoring, rate limiting
2. **aster-fullstack-architect** → Schema analysis, API contracts
3. **data-oracle** → Database integrity, replication
4. **infra-config-reviewer** → Security audit, config validation
5. **ui-perfection-doer** → Frontend errors, accessibility
6. **ml-architecture-expert** → Performance analysis, caching

**Deliverable**: Each agent must deliver ≥5 findings

---

## THOUGHT 2/5: Constraints & Dependencies

**Constraints**:
- Database schema in production (cannot change without validation)
- 100+ API routes (must audit all)
- 43 pages (must check error coverage)
- Limited time (2-3 days for DISCOVERY)

**Dependencies**:
- MCP tools available (Neon, Chrome DevTools, etc.)
- File system access for reading code
- Database query permissions

---

## THOUGHT 3/5: Specific Findings Per Agent

**production-incident-responder** (≥5 findings):
- Finding 1: External error monitoring status
- Finding 2: Rate limiting presence
- Finding 3: Circuit breaker patterns
- Finding 4: Promise error handling
- Finding 5: Health check design

[Similar for other 5 agents...]

---

## THOUGHT 4/5: Critical Trade-offs

**Speed vs Thoroughness**:
- Fast audit (1 day) → May miss issues
- Thorough audit (3 days) → Complete coverage
- **Decision**: 2-day audit with prioritized domains

**Breadth vs Depth**:
- Shallow audit (many areas, less detail)
- Deep audit (fewer areas, more detail)
- **Decision**: Comprehensive breadth (all 6 domains)

---

## THOUGHT 5/5: Execution Approach & Success Criteria

**Execution**:
1. Deploy all 6 agents in parallel (ONE message, 6 Task calls)
2. Each agent uses MCP tools for evidence
3. Write all reports to disk
4. Deploy compliance-enforcer for validation

**Success Criteria**:
- All 6 agents participate
- Each agent delivers ≥5 findings
- Evidence included for all findings
- MCP tool usage documented
- Compliance score ≥9/10

---

**PLANNING STATUS**: COMPLETE
**Next Step**: Deploy all 6 agents in parallel for DISCOVERY execution
```

---

**Step 2: Parallel Agent Deployment**

Single message with 6 Task calls:

```
Deploying all 6 agents in parallel:

Task 1: production-incident-responder
Prompt: "AGENT: production-incident-responder, PHASE: DISCOVERY,
        Conduct comprehensive audit of error monitoring, rate limiting,
        circuit breakers. Minimum: ≥5 findings. Use native tools for
        API route analysis. Document tool usage."

Task 2: aster-fullstack-architect
Prompt: "AGENT: aster-fullstack-architect, PHASE: DISCOVERY,
        Conduct comprehensive audit of database schema, API contracts,
        replication infrastructure. Minimum: ≥5 findings. Use Neon MCP
        tools. Document tool usage."

[Tasks 3-6 similar...]
```

All agents execute concurrently.

---

**Step 3: Write Reports to Disk**

After all 6 agents complete:

```
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_production-incident-responder.md, content=...)
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_aster-fullstack-architect.md, content=...)
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_data-oracle.md, content=...)
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_infra-config-reviewer.md, content=...)
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_ui-perfection-doer.md, content=...)
Write(file_path=claudedocs/ITERATION_2_DISCOVERY_ml-architecture-expert.md, content=...)
```

Result: 6 reports on disk (+ 1 planning file = 7 total)

---

**Step 4: Compliance Validation**

Deploy compliance-enforcer:

```
Task: compliance-enforcer
Prompt: "Validate ITERATION 2 DISCOVERY phase compliance.
        Files location: K:\00Project\MantisNXT\claudedocs\
        Perform all 10 validation checks.
        Output compliance report."
```

Compliance-enforcer result:

```markdown
ITERATION 2 - DISCOVERY PHASE VALIDATION REPORT

CHECK 1: Agent Participation - ✅ PASS (6/6 agents)
CHECK 2: Minimum Deliverables - ✅ PASS (all agents ≥5 findings)
CHECK 3: Trade-off Analysis - N/A (DESIGN phase only)
CHECK 4: Cross-cutting Dependencies - ✅ PASS (all reports have coordination)
CHECK 5: Previous Phase References - N/A (first phase)
CHECK 6: Objectivity - ✅ PASS (evidence-based findings)
CHECK 7: RULE 0 Compliance - ✅ PASS (planning file exists)
CHECK 8: File Persistence - ✅ PASS (7 files on disk)
CHECK 9: MCP Tool Usage - ✅ PASS (all reports have tool logs)
CHECK 10: Objective Validation - ✅ PASS (all checks objective)

OVERALL COMPLIANCE SCORE: 10/10 PASSED

VERDICT: ✅ PASS - PROCEED TO DESIGN PHASE
```

---

**Result**: DISCOVERY phase complete, validated, ready for DESIGN.

---

### 12.2 Example: ITERATION 2 DESIGN Phase

**Step 1: RULE 0 Planning**

File: `ITERATION_2_DESIGN_PLANNING.md` (205 lines)

Content includes:
- 5 thoughts planning DESIGN execution
- ADR targets per agent (≥5 ADRs)
- Trade-off analysis requirements
- Success criteria

---

**Step 2: Parallel Agent Deployment**

All 6 agents deployed in parallel with prompts like:

```
Task: aster-fullstack-architect
Prompt: "AGENT: aster-fullstack-architect, PHASE: DESIGN,

        CONTEXT FROM DISCOVERY:
        - Finding 1: Cryptic constraint names (200+ constraints)
        - Finding 2: 40 API routes query public.* instead of core.*
        - Finding 3: UUID vs BIGINT migration divergence
        - Finding 5: Missing replication infrastructure
        ...

        YOUR MISSION:
        Propose ≥5 ADRs addressing DISCOVERY findings.

        Each ADR must include:
        - Context (reference DISCOVERY finding)
        - Decision (chosen approach)
        - Alternatives Considered (≥3 options with pros/cons)
        - Rationale (why chosen vs alternatives)
        - Consequences (dependencies, risks, debt)
        - Implementation Notes (code examples)
        - Cost Projection (hourly breakdown + ROI)

        MCP Tools Available: mcp__neon__*, mcp__context7__*, native tools

        Deliverable Format: [ADR template provided]

        BEGIN DESIGN WORK NOW."
```

---

**Step 3: Write Reports to Disk**

After agents complete:

```
Write(file_path=claudedocs/ITERATION_2_DESIGN_aster-fullstack-architect.md, content=...)
[...write all 6 reports...]
```

Result:
- aster-fullstack-architect delivered 5 ADRs (migration, API contracts, replication, constraints, multi-schema)
- All 6 agents delivered 39 total ADRs (exceeds 30 minimum)

---

**Step 4: Compliance Validation**

Compliance-enforcer validates:

```markdown
CHECK 1: Agent Participation - ✅ PASS (6/6)
CHECK 2: Minimum Deliverables - ✅ PASS (39 ADRs total, all agents ≥5)
CHECK 3: Trade-off Analysis - ✅ PASS (all 39 ADRs have ≥3 alternatives)
CHECK 4: Cross-cutting Dependencies - ✅ PASS (coordination documented)
CHECK 5: DISCOVERY References - ✅ PASS (all ADRs cite findings)
CHECK 6: Objectivity - ✅ PASS (no subjective ratings)
CHECK 7: RULE 0 Compliance - ✅ PASS (planning file exists)
CHECK 8: File Persistence - ✅ PASS (7 files on disk)
CHECK 9: MCP Tool Usage - ✅ PASS (tool usage logged)
CHECK 10: Objective Validation - ✅ PASS (all checks objective)

OVERALL COMPLIANCE SCORE: 10/10 PASSED

VERDICT: ✅ PASS - PROCEED TO DEVELOPMENT PHASE
```

---

**Result**: DESIGN phase complete, 39 ADRs proposed, ready for DEVELOPMENT.

---

## 13. CONCLUSION

### 13.1 Framework Summary

This Multi-Agent Task Force Methodology provides a complete, systematic approach to complex software engineering projects through:

1. **7-Agent Structure**: 6 specialized working agents + 1 compliance enforcer
2. **5-Phase Process**: DISCOVERY → DESIGN → DEVELOPMENT → DELIVERY → ASSESSMENT
3. **Rigorous Validation**: 10 objective checks ensure quality and completeness
4. **Evidence-Based**: All claims supported by measurements, data, or standards
5. **Parallel Execution**: Maximum efficiency through concurrent work streams
6. **Quality Assurance**: Objective criteria prevent subjective evaluation

### 13.2 Success Factors

**Critical Success Factors**:
1. **RULE 0 Compliance**: Always use sequential-thinking planning before each phase
2. **Parallel Deployment**: Deploy all 6 agents in SINGLE message (RULE 1.3)
3. **File Persistence**: Write all reports to disk, not just conversation
4. **Validation Gates**: Do not proceed with <9/10 compliance score
5. **Evidence Standards**: Support all claims with data, measurements, citations

**Common Pitfalls to Avoid**:
1. ❌ Skipping RULE 0 planning (results in validation failure)
2. ❌ Sequential agent deployment (violates RULE 1.3, wastes time)
3. ❌ Conversation-only reports (no disk persistence, lost work)
4. ❌ Subjective claims (violates CHECK 6, fails validation)
5. ❌ Proceeding with failed validation (compounds issues)

### 13.3 Portability Checklist

To replicate this methodology in another project:

**Setup (One-Time)**:
- [ ] Create documentation directory (e.g., `claudedocs/`)
- [ ] Verify agent types available (6 working + 1 enforcer)
- [ ] Verify MCP tools available (sequential-thinking, domain-specific)
- [ ] Review and customize agent domain assignments
- [ ] Establish file naming convention
- [ ] Define iteration scope

**Per Iteration**:
- [ ] Follow 5-phase process (DISCOVERY → DESIGN → DEVELOPMENT → DELIVERY → ASSESSMENT)
- [ ] Use RULE 0 planning before each phase
- [ ] Deploy agents in parallel (RULE 1.3)
- [ ] Write reports to disk
- [ ] Validate with compliance-enforcer
- [ ] Achieve ≥9/10 compliance score before proceeding

**Customization**:
- Agent domains can be customized to project needs
- Minimum deliverables can be adjusted (default: ≥5)
- Validation checks can be extended (keep 10 core checks)
- MCP tools can be substituted based on availability

### 13.4 Maintenance and Evolution

**Framework Versioning**:
- Current Version: 2.0
- Update this document when methodology changes
- Track changes in version history

**Continuous Improvement**:
- Capture lessons learned in ASSESSMENT phase
- Incorporate improvements in next iteration
- Update templates based on practical experience

**Scaling Considerations**:
- For larger projects: Increase minimum deliverables (≥10 findings/ADRs)
- For smaller projects: Reduce to 3-4 agents if domains not applicable
- For faster execution: Compress DESIGN → DEVELOPMENT into single phase (with caution)

---

## APPENDIX A: Quick Reference

### Agent Types
1. production-incident-responder (error monitoring, API resilience)
2. aster-fullstack-architect (schema, API contracts, architecture)
3. data-oracle (database operations, replication, integrity)
4. infra-config-reviewer (security, infrastructure, deployment)
5. ui-perfection-doer (frontend, UX, accessibility, testing)
6. ml-architecture-expert (performance, caching, optimization)
7. compliance-enforcer (validation only, no implementation)

### 5 Phases
1. DISCOVERY: Find ≥5 issues per agent (P0/P1/P2/P3)
2. DESIGN: Propose ≥5 ADRs per agent (with trade-offs)
3. DEVELOPMENT: Implement P0 ADRs (code + tests)
4. DELIVERY: Validate deployment (smoke tests, monitoring)
5. ASSESSMENT: Self-evaluate + 5 recommendations per agent

### 10 Validation Checks
1. Agent Participation (6/6)
2. Minimum Deliverables (≥5 per agent)
3. Trade-off Analysis (DESIGN: ≥3 alternatives)
4. Cross-cutting Dependencies
5. Previous Phase References
6. Objectivity (no subjective ratings)
7. RULE 0 Compliance (planning documented)
8. File Persistence (reports on disk)
9. MCP Tool Usage (documented)
10. Objective Validation (all checks verifiable)

### Critical Rules
- **RULE 0**: Sequential-thinking planning BEFORE each phase (mandatory)
- **RULE 1**: 6 working agents + 1 compliance enforcer
- **RULE 1.3**: Parallel deployment (ONE message, 6 Task calls)
- **RULE 2**: MCP tool usage with logging

### Passing Criteria
- Overall: ≥9/10 validation checks must PASS
- Critical checks (must pass): 1, 2, 7, 8
- Remediation required: <9/10 score

---

## APPENDIX B: File Templates

### Planning File Template
```markdown
# ITERATION X [PHASE] PHASE - PLANNING (RULE 0 COMPLIANCE)

**Date**: YYYY-MM-DD
**Phase**: [DISCOVERY/DESIGN/DEVELOPMENT/DELIVERY/ASSESSMENT]
**Planning Method**: Sequential-Thinking MCP (N thoughts)

---

## THOUGHT 1/N: [Topic]
[Content]

## THOUGHT 2/N: [Topic]
[Content]

... [≥5 thoughts total]

---

## PLANNING STATUS: COMPLETE

**Planning Method**: mcp__sequential-thinking__sequentialthinking
**Total Thoughts**: N
**Next Step**: Deploy all 6 agents in parallel for [PHASE] execution
```

### Agent Report Template (DISCOVERY)
```markdown
# ITERATION X - DISCOVERY - [agent-name]

## Agent: [agent-name]
**Date**: YYYY-MM-DD
**Phase**: DISCOVERY

---

## Executive Summary
[2-3 paragraphs]

---

## FINDINGS

### Finding 1: [Title]
**Severity**: P0/P1/P2/P3
**Description**: [Details]
**Evidence**: [Tool outputs, code snippets, data]
**Impact**: [User/system/team impact]
**Recommendation**: [Fix approach]

[Repeat for ≥5 findings]

---

## MCP TOOL USAGE LOG
1. **tool_name**: operation
   - Purpose: why
   - Result: what found

---

## SUMMARY
**Total Findings**: X
**Critical (P0)**: X
**High (P1)**: X
**Medium (P2)**: X
**Low (P3)**: X
```

### ADR Template (DESIGN)
```markdown
## ADR-N: [Decision Title]

**Status**: Proposed
**Priority**: P0/P1/P2

**Context**:
DISCOVERY Finding X identified [problem].

**Decision**:
Implement **[Chosen Option]** with [characteristics].

**Alternatives Considered**:

**Option A: [Chosen]**
- **Pros**: [≥3 benefits]
- **Cons**: [≥2 drawbacks]
- **Complexity**: Low/Medium/High (X days)
- **Cost**: $X,XXX

**Option B: [Alternative]**
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Complexity**: [level]
- **Cost**: $X,XXX

**Option C: [Alternative]**
- **Pros**: [benefits]
- **Cons**: [drawbacks]
- **Complexity**: [level]
- **Cost**: $X,XXX

**Rationale**:
[Chosen] wins because:
1. [Reason with evidence]
2. [Reason with evidence]

[Alternative] rejected due to [reason with data].

**Consequences**:
- **Benefits**: [quantified]
- **Dependencies**: [list]
- **Risks**: [identified + mitigation]
- **Debt**: [introduced or eliminated]
- **Coordination**: [agents involved]

**Implementation Notes**:
```[code examples]```

**Cost Projection**:
- Development: $150/hr × Xhrs = $X,XXX
- Infrastructure: $X/month
- Total Year 1: $X,XXX
```

---

**END OF FRAMEWORK DOCUMENTATION**

This document provides complete, portable specifications for replicating the Multi-Agent Task Force Methodology in any project or environment. Follow the rules, use the templates, and validate with the 10 objective checks to ensure consistent, high-quality delivery.

**Version**: 2.0
**Date**: 2025-10-08
**Maintained By**: Multi-Agent Task Force Team
