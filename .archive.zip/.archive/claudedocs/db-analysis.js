const { Pool } = require('pg');

const dbConfig = {
  user: "nxtdb_admin",
  password: "P@33w0rd-1",
  host: "62.169.20.53",
  port: 6600,
  database: "nxtprod-db_001",
  ssl: false
};

const pool = new Pool(dbConfig);

async function analyzeDatabase() {
  try {
    console.log('🔍 Analyzing MantisNXT Database Architecture...\n');

    // Get all tables
    const tables = await pool.query(`
      SELECT table_name, table_schema
      FROM information_schema.tables
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);

    console.log('=== DATABASE TABLES ===');
    const tableNames = tables.rows.map(row => row.table_name);
    tableNames.forEach(name => console.log(`- ${name}`));
    console.log(`Total: ${tableNames.length} tables\n`);

    // Analyze key inventory-related tables
    const keyTables = ['products', 'inventory_items', 'suppliers', 'pricelists', 'product_supplier_links'];

    for (const tableName of keyTables) {
      if (tableNames.includes(tableName)) {
        await analyzeTable(tableName);
      } else {
        console.log(`❌ Table '${tableName}' NOT FOUND\n`);
      }
    }

    // Check for supplier-inventory relationships
    await analyzeSuppilerInventoryRelationships();

    // Get sample data counts
    await getSampleCounts();

  } catch (error) {
    console.error('❌ Database analysis failed:', error.message);
  } finally {
    await pool.end();
  }
}

async function analyzeTable(tableName) {
  try {
    const columns = await pool.query(`
      SELECT
        column_name,
        data_type,
        is_nullable,
        column_default,
        character_maximum_length
      FROM information_schema.columns
      WHERE table_name = $1 AND table_schema = 'public'
      ORDER BY ordinal_position
    `, [tableName]);

    console.log(`=== ${tableName.toUpperCase()} TABLE STRUCTURE ===`);
    columns.rows.forEach(col => {
      const nullable = col.is_nullable === 'NO' ? 'NOT NULL' : 'NULL';
      const length = col.character_maximum_length ? `(${col.character_maximum_length})` : '';
      console.log(`  ${col.column_name}: ${col.data_type}${length} ${nullable}`);
    });

    // Get record count
    const count = await pool.query(`SELECT COUNT(*) FROM ${tableName}`);
    console.log(`  📊 Records: ${count.rows[0].count}\n`);

  } catch (error) {
    console.log(`❌ Error analyzing ${tableName}: ${error.message}\n`);
  }
}

async function analyzeSuppilerInventoryRelationships() {
  console.log('=== SUPPLIER-INVENTORY RELATIONSHIP ANALYSIS ===');

  try {
    // Check for foreign key relationships
    const fkeys = await pool.query(`
      SELECT
        tc.table_name,
        kcu.column_name,
        ccu.table_name AS foreign_table_name,
        ccu.column_name AS foreign_column_name
      FROM
        information_schema.table_constraints AS tc
        JOIN information_schema.key_column_usage AS kcu
          ON tc.constraint_name = kcu.constraint_name
        JOIN information_schema.constraint_column_usage AS ccu
          ON ccu.constraint_name = tc.constraint_name
      WHERE constraint_type = 'FOREIGN KEY'
        AND (tc.table_name LIKE '%inventory%' OR tc.table_name LIKE '%supplier%' OR tc.table_name = 'products')
    `);

    console.log('Foreign Key Relationships:');
    fkeys.rows.forEach(fk => {
      console.log(`  ${fk.table_name}.${fk.column_name} -> ${fk.foreign_table_name}.${fk.foreign_column_name}`);
    });
    console.log();

  } catch (error) {
    console.log(`❌ Error analyzing relationships: ${error.message}\n`);
  }
}

async function getSampleCounts() {
  console.log('=== SAMPLE DATA COUNTS ===');

  const queries = [
    { name: 'Total Products', query: 'SELECT COUNT(*) FROM products' },
    { name: 'Total Inventory Items', query: 'SELECT COUNT(*) FROM inventory_items' },
    { name: 'Total Suppliers', query: 'SELECT COUNT(*) FROM suppliers' },
    { name: 'Total Pricelists', query: 'SELECT COUNT(*) FROM pricelists' },
    { name: 'Products with Suppliers', query: 'SELECT COUNT(DISTINCT p.id) FROM products p JOIN inventory_items ii ON p.id = ii.product_id WHERE ii.supplier_id IS NOT NULL' },
    { name: 'Suppliers with Inventory', query: 'SELECT COUNT(DISTINCT supplier_id) FROM inventory_items WHERE supplier_id IS NOT NULL' }
  ];

  for (const q of queries) {
    try {
      const result = await pool.query(q.query);
      console.log(`  ${q.name}: ${result.rows[0].count}`);
    } catch (error) {
      console.log(`  ${q.name}: Error - ${error.message}`);
    }
  }
  console.log();
}

// Run the analysis
analyzeDatabase().catch(console.error);