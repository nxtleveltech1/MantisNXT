# MantisNXT Price List Integration - Technical Implementation Plan

**Project**: Complete Price List Data Integration
**Architecture Reference**: MANTISNXT_PRICE_LIST_INTEGRATION_ARCHITECTURE.md
**Implementation Start**: September 26, 2025
**Target Completion**: 4 weeks

---

## IMPLEMENTATION PHASES OVERVIEW

### Phase 1: Foundation & Validation (Week 1)
**Goal**: Validate infrastructure and establish baseline performance
**Success Criteria**: All systems ready for bulk data processing

### Phase 2: Data Integration & Processing (Week 2-3)
**Goal**: Process all 27 supplier files and integrate real data
**Success Criteria**: 100% price list data integrated, mock data removed

### Phase 3: Optimization & Production (Week 4)
**Goal**: Optimize performance and deploy production-ready system
**Success Criteria**: System handles 10+ concurrent users with <2s response times

---

## PHASE 1: FOUNDATION & VALIDATION

### Task 1.1: Database Infrastructure Validation
**Priority**: Critical | **Duration**: 2 days | **Assignee**: Backend Developer

#### Objectives
- Verify upload infrastructure tables exist and are properly configured
- Test database performance with concurrent operations
- Validate supplier-inventory relationships and constraints

#### Technical Tasks
```sql
-- 1. Verify upload infrastructure tables
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN ('upload_sessions', 'upload_temp_data', 'upload_backups');

-- 2. Test foreign key relationships
SELECT
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
AND tc.table_name IN ('inventory_items', 'upload_sessions', 'upload_temp_data');

-- 3. Performance baseline testing
EXPLAIN ANALYZE SELECT * FROM inventory_items i
JOIN suppliers s ON i.supplier_id = s.id
WHERE i.status = 'active'
ORDER BY i.updated_at DESC LIMIT 50;
```

#### Deliverables
- [ ] Database schema validation report
- [ ] Performance baseline metrics
- [ ] Connection pool configuration verification
- [ ] Index optimization recommendations

#### Acceptance Criteria
- All required tables exist with proper constraints
- Database can handle 15 concurrent connections without degradation
- Query response times < 500ms for standard operations

---

### Task 1.2: Price List File Analysis & Preprocessing
**Priority**: Critical | **Duration**: 3 days | **Assignee**: Full-stack Developer

#### Objectives
- Analyze all 27 supplier price list files for processing requirements
- Identify format-specific processing needs
- Create preprocessing pipeline for problematic files

#### Technical Implementation
```typescript
// File analysis script
interface PriceListAnalysis {
  fileName: string;
  fileSize: number;
  format: 'xlsx' | 'xls' | 'pdf' | 'csv';
  worksheets?: string[];
  estimatedRows: number;
  complexity: 'simple' | 'moderate' | 'complex';
  specialRequirements: string[];
}

const analyzeAllPriceListFiles = async (): Promise<PriceListAnalysis[]> => {
  const uploadDir = 'K:\\00Project\\MantisNXT\\database\\Uploads\\drive-download-20250904T012253Z-1-001';
  const files = await fs.readdir(uploadDir);

  const analyses: PriceListAnalysis[] = [];

  for (const file of files) {
    const analysis = await analyzePriceListFile(path.join(uploadDir, file));
    analyses.push(analysis);
  }

  return analyses;
};

// Special handling for large files
const processLargeFile = async (filePath: string): Promise<StreamProcessingResult> => {
  // Implement streaming processing for Pro Audio platinum.xlsx (213MB)
  const stream = createReadStream(filePath);
  const workbook = new StreamingWorkbook();

  return new Promise((resolve, reject) => {
    workbook.xlsx.read(stream)
      .on('worksheet', processWorksheetStream)
      .on('end', resolve)
      .on('error', reject);
  });
};
```

#### File Processing Strategy
```typescript
// Processing priority based on file characteristics
const processingStrategy = {
  batch1_simple: [
    'ApexPro Distribution pricelist 25-04-2025.xlsx',     // 47 rows
    'Audiolite PRICE LIST-WHOLESALE OUT.xlsx',           // 141 rows
    'Viva Afrika Dealer Price List 07 May 2025.xlsx'     // 1,317 rows
  ],

  batch2_moderate: [
    'YAMAHA RETAIL PRICELIST NOV 2024.xlsx',             // Multiple sheets
    'Alpha-Technologies-Pricelist-August-2025.xlsx',     // 13.8MB, complex
    'Music Power Pricelist (August 2025).xlsx'           // 5.6MB, many sheets
  ],

  batch3_complex: [
    'Pro Audio platinum.xlsx'                            // 213MB, requires streaming
  ],

  batch4_pdf: [
    '2025_BCE_Brands_Pricelist_June_Final.01.pdf',      // PDF extraction
    'BK_Percussion_August_Pricelist_2025.03.pdf',
    'Legacy Brands Consumables Price List - June 2024.pdf',
    'Legacy Brands Gear Price List - June 2024.pdf'
  ]
};
```

#### Deliverables
- [ ] Complete file analysis report with processing recommendations
- [ ] Preprocessing scripts for complex files
- [ ] Streaming processor for large files (>50MB)
- [ ] PDF extraction pipeline for Legacy Brands files

#### Acceptance Criteria
- All 27 files analyzed with processing complexity assessment
- Large file streaming processor handles 213MB Pro Audio file
- PDF extraction yields >90% accuracy for structured price data

---

### Task 1.3: Mock Data Audit & Replacement Strategy
**Priority**: High | **Duration**: 2 days | **Assignee**: Frontend Developer

#### Objectives
- Identify all components using mock data
- Create real data integration plan
- Implement gradual replacement strategy

#### Mock Data Assessment
```typescript
// Components requiring real data integration
const mockDataAudit = {
  critical_replacements: {
    'src/lib/mock-data/zar-dashboard-data.ts': {
      usage: ['AnalyticsDashboard', 'HomePage', 'InsightCards'],
      replacement: '/api/analytics/dashboard',
      impact: 'high',
      effort: 'medium'
    },

    'src/components/analytics/PredictiveCharts.tsx': {
      hardcoded_data: ['trend_analysis', 'forecast_data', 'performance_metrics'],
      replacement: ['/api/analytics/trends', '/api/analytics/predictions'],
      impact: 'high',
      effort: 'high'
    }
  },

  already_integrated: {
    'src/components/suppliers/SupplierManagement.tsx': {
      status: 'complete',
      api_endpoint: '/api/suppliers',
      real_data: true
    },

    'src/components/inventory/InventoryManagement.tsx': {
      status: 'partial',
      api_endpoint: '/api/inventory',
      improvements_needed: ['real_time_updates', 'better_caching']
    }
  }
};

// Real data replacement implementation
const createRealDataHooks = () => {
  // Replace mock dashboard data
  const useDashboardData = () => {
    return useQuery({
      queryKey: ['dashboard-analytics'],
      queryFn: async () => {
        const response = await fetch('/api/analytics/dashboard');
        return response.json();
      },
      refetchInterval: 30000 // 30 second refresh
    });
  };

  // Replace mock trends
  const useTrendAnalysis = () => {
    return useQuery({
      queryKey: ['trend-analysis'],
      queryFn: async () => {
        const response = await fetch('/api/analytics/trends');
        return response.json();
      },
      refetchInterval: 60000 // 1 minute refresh
    });
  };
};
```

#### Implementation Tasks
1. **Analytics Dashboard Replacement**
   ```typescript
   // Before: Mock data
   const mockAnalytics = {
     totalSuppliers: 45,
     totalValue: 2500000,
     // ... static values
   };

   // After: Real API integration
   const { data: analytics, isLoading } = useQuery({
     queryKey: ['analytics'],
     queryFn: () => fetch('/api/analytics/dashboard').then(r => r.json())
   });
   ```

2. **Chart Data Integration**
   ```typescript
   // Replace static chart data with dynamic queries
   const useSupplierPerformanceData = () => {
     return useQuery({
       queryKey: ['supplier-performance'],
       queryFn: async () => {
         const suppliers = await fetch('/api/suppliers').then(r => r.json());
         const inventory = await fetch('/api/inventory').then(r => r.json());
         return calculatePerformanceMetrics(suppliers.data, inventory.data);
       }
     });
   };
   ```

#### Deliverables
- [ ] Complete mock data inventory with replacement priorities
- [ ] Real data integration hooks for all dashboard components
- [ ] Migration plan with rollback procedures
- [ ] Performance comparison (before/after real data)

#### Acceptance Criteria
- Zero hardcoded/mock data in production dashboard components
- All charts and metrics display real data from database
- Dashboard load times remain under 3 seconds with real data

---

## PHASE 2: DATA INTEGRATION & PROCESSING

### Task 2.1: Bulk Price List Processing Pipeline
**Priority**: Critical | **Duration**: 5 days | **Assignee**: Backend + DevOps

#### Objectives
- Process all 27 supplier price list files through upload system
- Handle large files and complex formats
- Ensure data quality and validation

#### Implementation Strategy
```typescript
// Batch processing approach
interface BatchProcessingPlan {
  batches: Array<{
    name: string;
    files: string[];
    processing_method: 'standard' | 'streaming' | 'manual';
    expected_duration: string;
    validation_rules: string[];
  }>;
}

const processingPlan: BatchProcessingPlan = {
  batches: [
    {
      name: 'Simple Excel Files',
      files: [
        'ApexPro Distribution pricelist 25-04-2025.xlsx',
        'Audiolite PRICE LIST-WHOLESALE OUT.xlsx',
        'AV Distribution Pricelist - May 2025.xlsx'
        // ... 10 more simple files
      ],
      processing_method: 'standard',
      expected_duration: '30 minutes',
      validation_rules: ['sku_format', 'price_validation', 'supplier_mapping']
    },

    {
      name: 'Complex Multi-Sheet Files',
      files: [
        'Alpha-Technologies-Pricelist-August-2025.xlsx',
        'Music Power Pricelist (August 2025).xlsx',
        'YAMAHA RETAIL PRICELIST NOV 2024.xlsx'
        // ... 8 more complex files
      ],
      processing_method: 'streaming',
      expected_duration: '2 hours',
      validation_rules: ['sheet_mapping', 'category_normalization', 'currency_conversion']
    },

    {
      name: 'Large File Processing',
      files: ['Pro Audio platinum.xlsx'], // 213MB
      processing_method: 'streaming',
      expected_duration: '45 minutes',
      validation_rules: ['memory_management', 'progress_tracking', 'error_recovery']
    },

    {
      name: 'PDF Extraction',
      files: [
        '2025_BCE_Brands_Pricelist_June_Final.01.pdf',
        'BK_Percussion_August_Pricelist_2025.03.pdf'
        // ... 3 more PDF files
      ],
      processing_method: 'manual',
      expected_duration: '4 hours',
      validation_rules: ['ocr_accuracy', 'data_extraction', 'manual_verification']
    }
  ]
};

// Processing automation script
const executeProcessingPlan = async () => {
  const results = {
    total_files: 27,
    processed: 0,
    failed: 0,
    warnings: [],
    errors: []
  };

  for (const batch of processingPlan.batches) {
    console.log(`Processing batch: ${batch.name}`);

    for (const file of batch.files) {
      try {
        const result = await processFileWithMethod(file, batch.processing_method);
        results.processed++;

        // Validate results
        const validation = await validateProcessedData(result, batch.validation_rules);
        if (validation.warnings.length > 0) {
          results.warnings.push({ file, warnings: validation.warnings });
        }

      } catch (error) {
        results.failed++;
        results.errors.push({ file, error: error.message });
        console.error(`Failed to process ${file}:`, error);
      }
    }
  }

  return results;
};
```

#### Large File Processing Optimization
```typescript
// Streaming processor for large files
class LargeFileProcessor {
  private chunkSize = 1000; // Process 1000 rows at a time
  private maxMemory = 512 * 1024 * 1024; // 512MB memory limit

  async processLargeFile(filePath: string): Promise<ProcessingResult> {
    const workbook = new StreamingWorkbook();
    const stream = fs.createReadStream(filePath);

    let processedRows = 0;
    let validRows = 0;
    let errorRows = 0;
    const errors: ProcessingError[] = [];

    return new Promise((resolve, reject) => {
      workbook.xlsx.read(stream)
        .on('worksheet', async (worksheet, sheetId) => {
          const rows: any[] = [];

          worksheet.on('row', (row, rowNumber) => {
            rows.push({ data: row.values, rowNumber });

            // Process in chunks
            if (rows.length >= this.chunkSize) {
              this.processChunk(rows.splice(0, this.chunkSize))
                .then(result => {
                  processedRows += result.processed;
                  validRows += result.valid;
                  errorRows += result.errors.length;
                  errors.push(...result.errors);
                });
            }
          });

          worksheet.on('end', async () => {
            // Process remaining rows
            if (rows.length > 0) {
              const result = await this.processChunk(rows);
              processedRows += result.processed;
              validRows += result.valid;
              errorRows += result.errors.length;
              errors.push(...result.errors);
            }
          });
        })
        .on('end', () => {
          resolve({
            total: processedRows,
            valid: validRows,
            invalid: errorRows,
            errors
          });
        })
        .on('error', reject);
    });
  }

  private async processChunk(rows: any[]): Promise<ChunkResult> {
    // Implement chunk processing with database transactions
    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      const validRows = [];
      const errors = [];

      for (const row of rows) {
        try {
          const processed = await this.validateAndTransformRow(row);
          validRows.push(processed);
        } catch (error) {
          errors.push({ row: row.rowNumber, error: error.message });
        }
      }

      // Batch insert valid rows
      if (validRows.length > 0) {
        await this.batchInsert(client, validRows);
      }

      await client.query('COMMIT');

      return {
        processed: rows.length,
        valid: validRows.length,
        errors
      };

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
```

#### Deliverables
- [ ] Automated bulk processing pipeline
- [ ] Large file streaming processor (Pro Audio 213MB support)
- [ ] PDF extraction and validation system
- [ ] Comprehensive error handling and recovery
- [ ] Processing results dashboard

#### Acceptance Criteria
- 100% of 27 supplier files processed without system failures
- Large file processing completes within 1 hour
- Data validation accuracy >95%
- Zero data loss during processing
- Complete audit trail of all operations

---

### Task 2.2: Real-time Analytics API Development
**Priority**: High | **Duration**: 4 days | **Assignee**: Backend Developer

#### Objectives
- Create comprehensive analytics APIs to replace mock data
- Implement real-time metric calculations
- Optimize query performance for dashboard responsiveness

#### API Implementation
```typescript
// Enhanced Analytics Dashboard API
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const timeRange = searchParams.get('range') || '30d';
    const organizationId = searchParams.get('org') || 'default';

    // Parallel query execution for performance
    const [
      supplierMetrics,
      inventoryMetrics,
      costAnalysis,
      performanceTrends,
      recentActivities,
      alerts
    ] = await Promise.all([
      calculateSupplierMetrics(timeRange),
      calculateInventoryMetrics(),
      calculateCostAnalysis(timeRange),
      calculatePerformanceTrends(timeRange),
      getRecentActivities(50),
      getActiveAlerts()
    ]);

    // Real-time KPIs
    const kpis = {
      totalSuppliers: supplierMetrics.total,
      totalInventoryValue: inventoryMetrics.totalValue,
      lowStockAlerts: alerts.filter(a => a.type === 'low_stock').length,
      averageDeliveryTime: performanceTrends.delivery.average,
      costSavingsThisMonth: costAnalysis.savings.current,
      inventoryTurnover: inventoryMetrics.turnover,
      supplierPerformanceScore: supplierMetrics.avgPerformance,
      outOfStockItems: inventoryMetrics.outOfStock
    };

    return NextResponse.json({
      success: true,
      data: {
        kpis,
        trends: performanceTrends,
        activities: recentActivities,
        alerts: alerts,
        charts: {
          supplierPerformance: await generateSupplierPerformanceChart(timeRange),
          inventoryLevels: await generateInventoryLevelsChart(),
          costTrends: await generateCostTrendsChart(timeRange),
          categoryDistribution: await generateCategoryDistributionChart()
        }
      },
      metadata: {
        lastUpdated: new Date(),
        refreshInterval: 30000,
        dataRange: timeRange
      }
    });

  } catch (error) {
    console.error('Analytics API error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch analytics data'
    }, { status: 500 });
  }
}

// Optimized query functions
async function calculateSupplierMetrics(timeRange: string) {
  const query = `
    SELECT
      COUNT(*) as total,
      COUNT(*) FILTER (WHERE status = 'active') as active,
      COUNT(*) FILTER (WHERE preferred_supplier = true) as preferred,
      AVG(COALESCE(performance_score, 0)) as avg_performance,
      SUM(spend_last_12_months) as total_spend
    FROM suppliers
  `;

  const result = await pool.query(query);
  return result.rows[0];
}

async function calculateInventoryMetrics() {
  const query = `
    SELECT
      COUNT(*) as total_items,
      SUM(stock_qty * cost_price) as total_value,
      COUNT(*) FILTER (WHERE stock_qty = 0) as out_of_stock,
      COUNT(*) FILTER (WHERE stock_qty <= reorder_point AND stock_qty > 0) as low_stock,
      AVG(stock_qty * cost_price) as avg_item_value,
      -- Calculate inventory turnover (simplified)
      CASE
        WHEN SUM(stock_qty * cost_price) > 0
        THEN SUM(COALESCE(monthly_sales_value, 0)) / SUM(stock_qty * cost_price) * 12
        ELSE 0
      END as turnover
    FROM inventory_items
    WHERE status = 'active'
  `;

  const result = await pool.query(query);
  return result.rows[0];
}

async function calculatePerformanceTrends(timeRange: string) {
  const trends = await pool.query(`
    SELECT
      DATE_TRUNC('day', created_at) as date,
      COUNT(*) as daily_items,
      AVG(cost_price) as avg_cost,
      SUM(stock_qty * cost_price) as daily_value
    FROM inventory_items
    WHERE created_at >= NOW() - INTERVAL '${timeRange}'
    GROUP BY DATE_TRUNC('day', created_at)
    ORDER BY date ASC
  `);

  return {
    data: trends.rows,
    summary: {
      total_periods: trends.rows.length,
      avg_daily_items: trends.rows.reduce((sum, row) => sum + row.daily_items, 0) / trends.rows.length,
      trend_direction: calculateTrendDirection(trends.rows)
    }
  };
}

// Chart generation functions
async function generateSupplierPerformanceChart(timeRange: string) {
  const data = await pool.query(`
    SELECT
      s.name,
      s.performance_tier,
      COUNT(i.id) as product_count,
      AVG(i.cost_price) as avg_price,
      SUM(i.stock_qty * i.cost_price) as inventory_value
    FROM suppliers s
    LEFT JOIN inventory_items i ON s.id = i.supplier_id
    WHERE s.status = 'active'
    GROUP BY s.id, s.name, s.performance_tier
    ORDER BY inventory_value DESC
    LIMIT 20
  `);

  return {
    type: 'bar',
    data: data.rows,
    config: {
      xAxis: 'name',
      yAxis: 'inventory_value',
      title: 'Top Suppliers by Inventory Value'
    }
  };
}
```

#### Performance Optimization
```typescript
// Caching strategy for analytics
class AnalyticsCache {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  async getCachedOrCalculate<T>(
    key: string,
    calculator: () => Promise<T>,
    ttl: number = 300000 // 5 minutes
  ): Promise<T> {
    const cached = this.cache.get(key);

    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return cached.data;
    }

    const data = await calculator();
    this.cache.set(key, { data, timestamp: Date.now(), ttl });
    return data;
  }

  invalidatePattern(pattern: string) {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

const analyticsCache = new AnalyticsCache();

// Usage in API endpoints
const supplierMetrics = await analyticsCache.getCachedOrCalculate(
  'supplier_metrics_30d',
  () => calculateSupplierMetrics('30d'),
  300000 // 5 minute cache
);
```

#### Deliverables
- [ ] Complete analytics API with real-time calculations
- [ ] Optimized database queries with <500ms response times
- [ ] Comprehensive caching strategy
- [ ] Chart data generation functions
- [ ] Performance monitoring and alerting

#### Acceptance Criteria
- Analytics API response time <200ms for standard queries
- Real-time KPIs update within 30 seconds of data changes
- Dashboard charts display accurate real data
- Caching reduces database load by 70%
- Zero mock data remaining in analytics components

---

### Task 2.3: Dashboard Real Data Integration
**Priority**: High | **Duration**: 3 days | **Assignee**: Frontend Developer

#### Objectives
- Replace all mock data with real API calls
- Implement real-time updates and caching
- Optimize component rendering performance

#### Implementation Tasks

1. **Analytics Dashboard Conversion**
```typescript
// Before: Mock data usage
const AnalyticsDashboard = () => {
  const mockData = {
    totalSuppliers: 45,
    totalValue: 2500000,
    // ... hardcoded values
  };

  return <DashboardView data={mockData} />;
};

// After: Real API integration
const AnalyticsDashboard = () => {
  const {
    data: analytics,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['analytics-dashboard'],
    queryFn: async () => {
      const response = await fetch('/api/analytics/dashboard');
      if (!response.ok) throw new Error('Failed to fetch analytics');
      return response.json();
    },
    refetchInterval: 30000, // Auto-refresh every 30 seconds
    staleTime: 25000,       // Consider data stale after 25 seconds
    cacheTime: 600000       // Cache for 10 minutes
  });

  // Real-time updates via WebSocket
  useEffect(() => {
    const ws = new WebSocket(`${process.env.NEXT_PUBLIC_WS_URL}/analytics`);

    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      if (update.type === 'analytics_update') {
        refetch(); // Trigger data refresh
      }
    };

    return () => ws.close();
  }, [refetch]);

  if (isLoading) return <DashboardSkeleton />;
  if (error) return <ErrorBoundary error={error} retry={refetch} />;

  return <DashboardView data={analytics.data} lastUpdated={analytics.metadata.lastUpdated} />;
};
```

2. **Chart Components Integration**
```typescript
// Dynamic chart data loading
const useChartData = (chartType: string, timeRange: string = '30d') => {
  return useQuery({
    queryKey: ['chart-data', chartType, timeRange],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/charts/${chartType}?range=${timeRange}`);
      return response.json();
    },
    refetchInterval: 60000, // Refresh every minute
  });
};

// Optimized chart component
const SupplierPerformanceChart = ({ timeRange }: { timeRange: string }) => {
  const { data, isLoading, error } = useChartData('supplier-performance', timeRange);

  const chartData = useMemo(() => {
    if (!data?.data) return [];

    return data.data.map((item: any) => ({
      name: item.name,
      value: item.inventory_value,
      products: item.product_count,
      tier: item.performance_tier
    }));
  }, [data]);

  if (isLoading) return <ChartSkeleton />;
  if (error) return <ChartError error={error} />;

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
        <YAxis tickFormatter={(value) => formatCurrency(value)} />
        <Tooltip
          formatter={(value, name) => [formatCurrency(value), name]}
          labelFormatter={(label) => `Supplier: ${label}`}
        />
        <Bar dataKey="value" fill="#3b82f6" />
      </BarChart>
    </ResponsiveContainer>
  );
};
```

3. **Real-time Updates Implementation**
```typescript
// WebSocket integration for real-time updates
const useRealTimeUpdates = () => {
  const queryClient = useQueryClient();

  useEffect(() => {
    const ws = new WebSocket(`${process.env.NEXT_PUBLIC_WS_URL}/updates`);

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);

      switch (message.type) {
        case 'supplier_updated':
          queryClient.invalidateQueries(['suppliers']);
          queryClient.invalidateQueries(['analytics-dashboard']);
          break;

        case 'inventory_changed':
          queryClient.invalidateQueries(['inventory']);
          queryClient.invalidateQueries(['analytics-dashboard']);
          queryClient.invalidateQueries(['chart-data', 'inventory-levels']);
          break;

        case 'price_list_uploaded':
          queryClient.invalidateQueries(['suppliers']);
          queryClient.invalidateQueries(['inventory']);
          queryClient.invalidateQueries(['analytics-dashboard']);
          toast.success(`Price list uploaded for ${message.data.supplierName}`);
          break;
      }
    };

    ws.onclose = () => {
      // Attempt to reconnect after delay
      setTimeout(() => {
        useRealTimeUpdates();
      }, 5000);
    };

    return () => ws.close();
  }, [queryClient]);
};
```

4. **Performance Optimization**
```typescript
// Optimized component rendering
const MemoizedDashboardCard = React.memo(({ title, value, change, icon }: DashboardCardProps) => {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600">{title}</p>
          <p className="text-2xl font-semibold">{value}</p>
          {change && (
            <p className={`text-sm ${change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
              {change}
            </p>
          )}
        </div>
        <div className="text-blue-600">{icon}</div>
      </div>
    </Card>
  );
});

// Virtualized large lists for performance
const VirtualizedInventoryList = ({ items }: { items: InventoryItem[] }) => {
  const renderRow = useCallback(({ index, style }: { index: number; style: React.CSSProperties }) => (
    <div style={style}>
      <InventoryListItem item={items[index]} />
    </div>
  ), [items]);

  return (
    <FixedSizeList
      height={600}
      itemCount={items.length}
      itemSize={60}
      width="100%"
    >
      {renderRow}
    </FixedSizeList>
  );
};
```

#### Deliverables
- [ ] All dashboard components using real API data
- [ ] Real-time update system with WebSocket integration
- [ ] Optimized React Query configuration for caching
- [ ] Performance-optimized chart components
- [ ] Error boundaries and loading states

#### Acceptance Criteria
- Zero mock data usage in any dashboard component
- Dashboard loads within 3 seconds with real data
- Real-time updates appear within 30 seconds
- Chart components handle 1000+ data points smoothly
- Graceful error handling for API failures

---

## PHASE 3: OPTIMIZATION & PRODUCTION

### Task 3.1: Performance Optimization
**Priority**: High | **Duration**: 3 days | **Assignee**: Full-stack + DevOps

#### Objectives
- Optimize database queries and connection pooling
- Implement comprehensive caching strategy
- Ensure system handles concurrent operations efficiently

#### Database Optimization
```sql
-- Index optimization for frequently queried columns
CREATE INDEX CONCURRENTLY idx_inventory_supplier_status
ON inventory_items(supplier_id, status)
WHERE status = 'active';

CREATE INDEX CONCURRENTLY idx_suppliers_performance_category
ON suppliers(performance_tier, primary_category)
WHERE status = 'active';

CREATE INDEX CONCURRENTLY idx_inventory_stock_alerts
ON inventory_items(stock_qty, reorder_point, status)
WHERE status = 'active' AND stock_qty <= reorder_point;

-- Partial index for recent activities
CREATE INDEX CONCURRENTLY idx_upload_sessions_recent
ON upload_sessions(created_at DESC)
WHERE created_at >= NOW() - INTERVAL '30 days';

-- Composite index for analytics queries
CREATE INDEX CONCURRENTLY idx_inventory_analytics
ON inventory_items(category, status, created_at)
INCLUDE (stock_qty, cost_price);
```

#### Connection Pool Optimization
```typescript
// Enhanced database connection configuration
const optimizedDbConfig = {
  // Connection Pool Settings
  max: 20,              // Increased for concurrent operations
  min: 5,               // Higher minimum for consistent performance

  // Timeout Configuration
  connectionTimeoutMillis: 10000,
  idleTimeoutMillis: 30000,
  acquireTimeoutMillis: 20000,

  // Performance Settings
  keepAlive: true,
  keepAliveInitialDelayMillis: 5000,

  // Statement timeout
  statement_timeout: 45000,

  // Connection validation
  validateConnection: async (client: PoolClient) => {
    const result = await client.query('SELECT 1');
    return result.rows.length === 1;
  },

  // Connection lifecycle hooks
  onConnect: (client: PoolClient) => {
    client.query('SET application_name = $1', ['MantisNXT-Web']);
  }
};
```

#### Application-Level Caching
```typescript
// Multi-layer caching implementation
class PerformanceOptimizer {
  private nodeCache = new NodeCache({ stdTTL: 300 }); // 5 minutes
  private redisClient = new Redis(process.env.REDIS_URL);

  async getWithCache<T>(
    key: string,
    fetcher: () => Promise<T>,
    options: {
      localTTL?: number;
      redisTTL?: number;
      skipLocal?: boolean;
      skipRedis?: boolean;
    } = {}
  ): Promise<T> {
    const { localTTL = 300, redisTTL = 900, skipLocal = false, skipRedis = false } = options;

    // Try local cache first
    if (!skipLocal) {
      const localData = this.nodeCache.get<T>(key);
      if (localData) return localData;
    }

    // Try Redis cache
    if (!skipRedis) {
      const redisData = await this.redisClient.get(key);
      if (redisData) {
        const parsed = JSON.parse(redisData);
        if (!skipLocal) this.nodeCache.set(key, parsed, localTTL);
        return parsed;
      }
    }

    // Fetch fresh data
    const freshData = await fetcher();

    // Cache in both layers
    if (!skipLocal) this.nodeCache.set(key, freshData, localTTL);
    if (!skipRedis) await this.redisClient.setex(key, redisTTL, JSON.stringify(freshData));

    return freshData;
  }

  invalidatePattern(pattern: string) {
    // Invalidate local cache
    const keys = this.nodeCache.keys();
    keys.forEach(key => {
      if (key.includes(pattern)) {
        this.nodeCache.del(key);
      }
    });

    // Invalidate Redis cache
    this.redisClient.keys(`*${pattern}*`).then(keys => {
      if (keys.length > 0) {
        this.redisClient.del(...keys);
      }
    });
  }
}

// Usage in API endpoints
const optimizer = new PerformanceOptimizer();

export async function GET(request: NextRequest) {
  const cacheKey = `analytics-dashboard-${request.url}`;

  const data = await optimizer.getWithCache(
    cacheKey,
    () => calculateDashboardData(),
    { localTTL: 180, redisTTL: 300 } // 3min local, 5min Redis
  );

  return NextResponse.json(data);
}
```

#### Query Optimization
```typescript
// Optimized analytics queries
class OptimizedAnalyticsService {
  async getDashboardMetrics(timeRange: string = '30d'): Promise<DashboardMetrics> {
    // Single query with multiple aggregations for better performance
    const query = `
      WITH supplier_stats AS (
        SELECT
          COUNT(*) as total_suppliers,
          COUNT(*) FILTER (WHERE status = 'active') as active_suppliers,
          AVG(COALESCE(performance_score, 0)) as avg_performance
        FROM suppliers
      ),
      inventory_stats AS (
        SELECT
          COUNT(*) as total_items,
          SUM(stock_qty * cost_price) as total_value,
          COUNT(*) FILTER (WHERE stock_qty = 0) as out_of_stock,
          COUNT(*) FILTER (WHERE stock_qty <= reorder_point AND stock_qty > 0) as low_stock,
          AVG(stock_qty * cost_price) as avg_item_value
        FROM inventory_items
        WHERE status = 'active'
      ),
      recent_activity AS (
        SELECT COUNT(*) as recent_uploads
        FROM upload_sessions
        WHERE created_at >= NOW() - INTERVAL '24 hours'
        AND status = 'completed'
      )
      SELECT
        ss.*,
        ist.*,
        ra.recent_uploads
      FROM supplier_stats ss
      CROSS JOIN inventory_stats ist
      CROSS JOIN recent_activity ra;
    `;

    const result = await pool.query(query);
    return result.rows[0];
  }

  async getTopSuppliersByValue(limit: number = 10): Promise<SupplierValue[]> {
    // Optimized query with proper indexing
    const query = `
      SELECT
        s.id,
        s.name,
        s.performance_tier,
        COUNT(i.id) as product_count,
        COALESCE(SUM(i.stock_qty * i.cost_price), 0) as inventory_value,
        AVG(i.cost_price) as avg_price
      FROM suppliers s
      LEFT JOIN inventory_items i ON s.id = i.supplier_id AND i.status = 'active'
      WHERE s.status = 'active'
      GROUP BY s.id, s.name, s.performance_tier
      ORDER BY inventory_value DESC
      LIMIT $1;
    `;

    const result = await pool.query(query, [limit]);
    return result.rows;
  }
}
```

#### Deliverables
- [ ] Optimized database indexes for all critical queries
- [ ] Enhanced connection pool configuration
- [ ] Multi-layer caching system (local + Redis)
- [ ] Query performance monitoring
- [ ] Load testing results and optimization report

#### Acceptance Criteria
- API response times <200ms for 95% of requests
- Database connection pool efficiency >90%
- Cache hit ratio >80% for frequently accessed data
- System handles 20+ concurrent users without performance degradation
- Query execution times reduced by 50% from baseline

---

### Task 3.2: Production Deployment & Monitoring
**Priority**: Critical | **Duration**: 2 days | **Assignee**: DevOps + Backend

#### Objectives
- Deploy optimized system to production environment
- Implement comprehensive monitoring and alerting
- Establish performance baselines and SLAs

#### Production Configuration
```yaml
# Docker Compose Production Configuration
version: '3.8'
services:
  mantisnxt-web:
    image: mantisnxt:latest
    environment:
      NODE_ENV: production
      DATABASE_URL: postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001
      REDIS_URL: redis://redis:6379
      WS_PORT: 3001
    ports:
      - "3008:3000"
    deploy:
      replicas: 2
      resources:
        limits:
          memory: 2G
          cpus: '1.0'
        reservations:
          memory: 1G
          cpus: '0.5'
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '0.5'
    command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
```

#### Monitoring Implementation
```typescript
// Application monitoring and metrics
class ProductionMonitoring {
  private metrics = {
    requestCount: 0,
    errorCount: 0,
    responseTimeSum: 0,
    dbConnectionCount: 0,
    cacheHitCount: 0,
    cacheMissCount: 0
  };

  // Middleware for request monitoring
  requestMonitoring = (req: Request, res: Response, next: Function) => {
    const startTime = Date.now();

    res.on('finish', () => {
      const duration = Date.now() - startTime;

      this.metrics.requestCount++;
      this.metrics.responseTimeSum += duration;

      if (res.statusCode >= 400) {
        this.metrics.errorCount++;
      }

      // Log slow requests
      if (duration > 1000) {
        console.warn(`Slow request: ${req.method} ${req.path} - ${duration}ms`);
      }

      // Send metrics to monitoring service
      this.sendMetrics({
        endpoint: req.path,
        method: req.method,
        statusCode: res.statusCode,
        duration,
        timestamp: new Date()
      });
    });

    next();
  };

  // Database monitoring
  monitorDatabasePerformance = () => {
    pool.on('connect', () => {
      this.metrics.dbConnectionCount++;
    });

    pool.on('error', (err) => {
      console.error('Database error:', err);
      this.sendAlert({
        type: 'database_error',
        severity: 'high',
        message: err.message,
        timestamp: new Date()
      });
    });
  };

  // Health check endpoint
  healthCheck = async (): Promise<HealthStatus> => {
    const checks = await Promise.allSettled([
      this.checkDatabase(),
      this.checkRedis(),
      this.checkDiskSpace(),
      this.checkMemoryUsage()
    ]);

    const health: HealthStatus = {
      status: 'healthy',
      timestamp: new Date(),
      checks: {
        database: checks[0].status === 'fulfilled' ? checks[0].value : 'unhealthy',
        redis: checks[1].status === 'fulfilled' ? checks[1].value : 'unhealthy',
        disk: checks[2].status === 'fulfilled' ? checks[2].value : 'unhealthy',
        memory: checks[3].status === 'fulfilled' ? checks[3].value : 'unhealthy'
      },
      metrics: {
        uptime: process.uptime(),
        requestsPerSecond: this.metrics.requestCount / process.uptime(),
        averageResponseTime: this.metrics.responseTimeSum / this.metrics.requestCount,
        errorRate: this.metrics.errorCount / this.metrics.requestCount,
        cacheHitRatio: this.metrics.cacheHitCount / (this.metrics.cacheHitCount + this.metrics.cacheMissCount)
      }
    };

    // Determine overall status
    if (Object.values(health.checks).some(check => check === 'unhealthy')) {
      health.status = 'unhealthy';
    }

    return health;
  };
}
```

#### Alerting Configuration
```typescript
// Alert management system
interface AlertRule {
  name: string;
  condition: (metrics: SystemMetrics) => boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
  notification: 'email' | 'slack' | 'sms';
  cooldown: number; // Minutes between alerts
}

const alertRules: AlertRule[] = [
  {
    name: 'High Error Rate',
    condition: (metrics) => metrics.errorRate > 0.05, // 5% error rate
    severity: 'high',
    notification: 'slack',
    cooldown: 15
  },
  {
    name: 'Slow Response Time',
    condition: (metrics) => metrics.averageResponseTime > 2000, // 2 seconds
    severity: 'medium',
    notification: 'email',
    cooldown: 30
  },
  {
    name: 'Database Connection Issues',
    condition: (metrics) => metrics.dbConnectionFailures > 5,
    severity: 'critical',
    notification: 'sms',
    cooldown: 5
  },
  {
    name: 'Low Cache Hit Ratio',
    condition: (metrics) => metrics.cacheHitRatio < 0.6, // 60% hit ratio
    severity: 'low',
    notification: 'email',
    cooldown: 60
  }
];

class AlertManager {
  private lastAlerts = new Map<string, number>();

  async checkAlerts(metrics: SystemMetrics) {
    for (const rule of alertRules) {
      if (rule.condition(metrics)) {
        const lastAlert = this.lastAlerts.get(rule.name) || 0;
        const cooldownExpired = Date.now() - lastAlert > rule.cooldown * 60000;

        if (cooldownExpired) {
          await this.sendAlert(rule, metrics);
          this.lastAlerts.set(rule.name, Date.now());
        }
      }
    }
  }

  private async sendAlert(rule: AlertRule, metrics: SystemMetrics) {
    const alertData = {
      rule: rule.name,
      severity: rule.severity,
      timestamp: new Date(),
      metrics,
      runbook: `https://docs.mantisnxt.com/alerts/${rule.name.toLowerCase().replace(/ /g, '-')}`
    };

    switch (rule.notification) {
      case 'slack':
        await this.sendSlackAlert(alertData);
        break;
      case 'email':
        await this.sendEmailAlert(alertData);
        break;
      case 'sms':
        await this.sendSmsAlert(alertData);
        break;
    }
  }
}
```

#### Deliverables
- [ ] Production-ready deployment configuration
- [ ] Comprehensive monitoring dashboard
- [ ] Automated alerting system with escalation
- [ ] Performance baseline documentation
- [ ] Disaster recovery procedures

#### Acceptance Criteria
- Zero-downtime deployment process
- 99.5% uptime monitoring with alerts
- Response time monitoring with <200ms target
- Automated alerts for critical issues
- Complete system health visibility

---

## SUCCESS CRITERIA & VALIDATION

### Overall Project Success Metrics

```typescript
interface ProjectSuccessMetrics {
  technical: {
    file_processing_success: '100%';    // All 27 supplier files processed
    data_quality_score: '>95%';         // Validation accuracy
    api_response_time: '<200ms';        // Performance target
    system_uptime: '>99.5%';           // Availability target
    zero_data_loss: true;               // Data integrity
  };

  business: {
    mock_data_elimination: '100%';      // No hardcoded data
    real_time_updates: '<30s';          // Dashboard refresh time
    user_experience_score: '>4.5/5';   // Satisfaction rating
    process_automation: '80%';          // Manual effort reduction
    cost_optimization: 'enabled';       // Analytics insights
  };

  operational: {
    concurrent_users: 10;               // Simultaneous operations
    large_file_support: '213MB';        // Pro Audio file processing
    error_handling: 'comprehensive';    // Graceful failures
    monitoring_coverage: '100%';        // Full system visibility
    scalability_ready: '10x_growth';    // Future capacity
  };
}
```

### Testing & Validation Plan

```typescript
// Comprehensive testing strategy
const validationPlan = {
  unit_testing: {
    coverage_target: '>90%',
    focus_areas: [
      'price_list_parsing',
      'validation_rules',
      'data_transformation',
      'api_endpoints'
    ]
  },

  integration_testing: {
    scope: 'end_to_end_workflows',
    scenarios: [
      'complete_price_list_upload_process',
      'real_time_dashboard_updates',
      'error_handling_and_recovery',
      'concurrent_user_operations'
    ]
  },

  performance_testing: {
    load_scenarios: [
      '10_concurrent_uploads',
      '100_simultaneous_dashboard_users',
      'large_file_processing_213MB',
      'database_query_optimization'
    ],
    targets: {
      response_time: '<200ms',
      throughput: '>100_requests_per_second',
      memory_usage: '<2GB_per_instance',
      cpu_utilization: '<70%'
    }
  },

  user_acceptance_testing: {
    scenarios: [
      'price_list_upload_wizard_completion',
      'dashboard_navigation_and_insights',
      'error_handling_user_experience',
      'mobile_responsiveness'
    ],
    success_criteria: '>90%_task_completion_rate'
  }
};
```

---

## CONCLUSION

This implementation plan provides a comprehensive roadmap for integrating all supplier price list data into the MantisNXT platform. The plan leverages the existing sophisticated infrastructure while systematically replacing mock data with real, production-quality integration.

### Key Implementation Strengths
✅ **Phased Approach**: Minimizes risk with incremental delivery
✅ **Performance Focus**: Optimization built into every phase
✅ **Quality Assurance**: Comprehensive testing and validation
✅ **Production Ready**: Monitoring and alerting from day one
✅ **Scalable Architecture**: Designed for future growth

### Expected Outcomes
- **Technical Excellence**: 100% real data integration with <200ms response times
- **Business Value**: 80% reduction in manual processes, real-time insights
- **User Experience**: Intuitive interface with comprehensive error handling
- **Operational Excellence**: 99.5% uptime with proactive monitoring

The implementation follows a systematic approach that ensures data quality, system performance, and business value realization while maintaining the highest standards of software engineering practices.

**Next Step**: Begin Phase 1 implementation with database validation and file analysis.