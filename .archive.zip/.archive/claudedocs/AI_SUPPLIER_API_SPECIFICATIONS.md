# AI Supplier Services API Specifications

**Document Type**: API Technical Specification
**Version**: 1.0
**Date**: 2025-09-25
**Status**: Draft
**Project**: MantisNXT - AI Supplier Enhancement Phase

## Overview

This document defines the REST API endpoints for AI-powered supplier features in MantisNXT. All endpoints follow OpenAPI 3.0 specification standards and integrate with the existing authentication and authorization system.

## Base Configuration

**Base URL**: `/api/ai/suppliers`
**Authentication**: Bearer JWT Token required
**Content-Type**: `application/json`
**Rate Limiting**: 100 requests per minute per user

## Core AI Supplier Endpoints

### 1. Supplier Discovery

#### POST /api/ai/suppliers/discover

Intelligent supplier discovery using AI-powered search and enrichment.

**Request Body**
```typescript
interface DiscoverRequest {
  query: string;                           // Search query (company name, capability, description)
  searchType?: 'company_name' | 'capability' | 'semantic' | 'hybrid'; // Default: 'hybrid'
  filters?: {
    location?: string[];                   // Geographic filters
    categories?: string[];                 // Business categories
    tier?: ('strategic' | 'preferred' | 'approved')[];
    minRating?: number;                    // Minimum performance rating
    maxBudget?: number;                    // Budget constraints
    certifications?: string[];             // Required certifications
  };
  options?: {
    limit?: number;                        // Max results (default: 20, max: 100)
    includeEmbeddings?: boolean;           // Include embedding vectors (default: false)
    includeConfidence?: boolean;           // Include confidence scores (default: true)
    enrichmentLevel?: 'basic' | 'standard' | 'comprehensive'; // Default: 'standard'
    deduplication?: boolean;               // Remove similar suppliers (default: true)
  };
  context?: {
    procurementCategory?: string;          // Context for better matching
    projectBudget?: number;
    timeline?: string;
    currentSuppliers?: string[];           // IDs of existing suppliers to exclude/compare
  };
}
```

**Response**
```typescript
interface DiscoverResponse {
  suppliers: EnrichedSupplier[];
  metadata: {
    totalFound: number;
    processingTimeMs: number;
    searchType: string;
    aiProvider: string;
    queryExpansion?: string[];             // Additional terms used in search
    filters: Record<string, any>;
  };
  suggestions: {
    relatedQueries: string[];              // Suggested related searches
    refinements: SearchRefinement[];       // Suggested filter refinements
    alternativeTerms: string[];            // Alternative search terms
  };
  analytics: {
    confidence: number;                    // Overall result confidence (0-1)
    coverage: number;                      // Market coverage estimate (0-1)
    dataFreshness: number;                 // Data recency score (0-1)
  };
}

interface EnrichedSupplier {
  id: string;
  basicInfo: SupplierBasicInfo;
  enrichedData?: {
    aiGenerated: boolean;
    confidence: number;
    sources: string[];
    lastUpdated: string;
    website?: string;
    description?: string;
    specialties?: string[];
    certifications?: string[];
    socialMedia?: SocialMediaLinks;
    financialInfo?: PublicFinancialInfo;
  };
  matchingScore: number;                   // Relevance to search query (0-1)
  recommendationReason: string;            // AI-generated explanation
  competitiveAnalysis?: {
    strengths: string[];
    differentiators: string[];
    marketPosition: string;
  };
}

interface SearchRefinement {
  type: 'filter' | 'location' | 'category' | 'budget';
  suggestion: string;
  impact: 'narrow' | 'broaden';
  estimatedResults: number;
}
```

**Example Request**
```json
{
  "query": "sustainable packaging materials supplier California",
  "searchType": "hybrid",
  "filters": {
    "location": ["California", "Oregon"],
    "categories": ["packaging", "materials"],
    "certifications": ["ISO 14001"]
  },
  "options": {
    "limit": 15,
    "enrichmentLevel": "comprehensive",
    "includeConfidence": true
  },
  "context": {
    "procurementCategory": "packaging_materials",
    "projectBudget": 500000,
    "timeline": "Q2_2025"
  }
}
```

**Status Codes**
- `200`: Success
- `400`: Invalid request parameters
- `401`: Unauthorized
- `429`: Rate limit exceeded
- `500`: Internal server error

---

### 2. Supplier Matching

#### POST /api/ai/suppliers/match

AI-powered supplier matching based on specific requirements and preferences.

**Request Body**
```typescript
interface MatchRequest {
  requirements: {
    products?: string[];                   // Required products/services
    services?: string[];
    capabilities?: string[];               // Technical capabilities needed
    volume?: {
      quantity: number;
      unit: string;
      frequency: 'one_time' | 'monthly' | 'quarterly' | 'annually';
    };
    timeline?: {
      rfpDeadline?: string;
      projectStart?: string;
      deliveryDeadline?: string;
    };
    budget?: {
      min?: number;
      max?: number;
      currency: string;
      flexibility: 'strict' | 'moderate' | 'flexible';
    };
    location?: {
      preferred?: string[];
      excluded?: string[];
      proximityWeight?: number;            // 0-1 importance of proximity
    };
    compliance?: {
      certifications: string[];
      standards: string[];
      auditRequirements?: string[];
    };
  };
  preferences: {
    priorityFactors: {
      cost: number;                        // Weight 0-1
      quality: number;
      delivery: number;
      relationship: number;
      innovation: number;
      sustainability: number;
    };
    riskTolerance: 'low' | 'medium' | 'high';
    diversityPreference?: 'minority_owned' | 'women_owned' | 'small_business';
    relationshipType: 'transactional' | 'preferred' | 'strategic';
    incumbentSuppliers?: string[];         // Current suppliers to compare against
  };
  context?: {
    industry?: string;
    competitiveAdvantage?: string;
    criticalFactors?: string[];
    historicalPerformance?: HistoricalPreference[];
  };
}

interface HistoricalPreference {
  factor: string;
  weight: number;
  reasoning: string;
}
```

**Response**
```typescript
interface MatchResponse {
  matches: SupplierMatch[];
  alternatives: SupplierMatch[];
  benchmarking: {
    industryAverage: BenchmarkMetrics;
    topQuartile: BenchmarkMetrics;
    yourCurrentSuppliers: BenchmarkMetrics;
  };
  insights: {
    marketConditions: string;
    riskAssessment: string;
    costOptimization: string;
    recommendations: string[];
  };
  decisionMatrix: DecisionMatrixEntry[];
}

interface SupplierMatch {
  supplier: SupplierBasicInfo;
  scores: {
    overall: number;                       // 0-1 overall match score
    cost: number;
    quality: number;
    delivery: number;
    capability: number;
    relationship: number;
    risk: number;
  };
  strengths: string[];
  concerns: string[];
  recommendation: 'highly_recommended' | 'recommended' | 'consider' | 'not_recommended';
  reasoning: string;                       // AI-generated explanation
  estimatedCost: {
    min: number;
    max: number;
    currency: string;
    confidence: number;
  };
  riskFactors: RiskFactor[];
  nextSteps: string[];                     // Suggested actions
}

interface RiskFactor {
  type: 'financial' | 'operational' | 'compliance' | 'relationship';
  level: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  mitigation?: string;
}

interface DecisionMatrixEntry {
  criterion: string;
  weight: number;
  suppliers: Array<{
    supplierId: string;
    score: number;
    justification: string;
  }>;
}
```

---

### 3. Supplier Insights

#### GET /api/ai/suppliers/{supplierId}/insights

Retrieve AI-generated insights for a specific supplier.

**Path Parameters**
- `supplierId` (string, required): Unique identifier for the supplier

**Query Parameters**
```typescript
interface InsightsQuery {
  types?: ('performance' | 'risk' | 'opportunity' | 'prediction')[];
  timeRange?: {
    start: string;                         // ISO 8601 date
    end: string;
  };
  categories?: string[];                   // Filter by insight categories
  minConfidence?: number;                  // Minimum confidence threshold (0-1)
  status?: ('active' | 'acknowledged' | 'resolved')[];
  includeResolved?: boolean;               // Include resolved insights (default: false)
  limit?: number;                          // Max insights to return (default: 50)
}
```

**Response**
```typescript
interface InsightsResponse {
  supplier: SupplierBasicInfo;
  insights: {
    performance: PerformanceInsight[];
    risks: RiskInsight[];
    opportunities: OpportunityInsight[];
    predictions: PredictionInsight[];
  };
  summary: {
    overall: string;                       // Executive summary
    keyFindings: string[];
    actionItems: ActionItem[];
    trendAnalysis: string;
  };
  scores: {
    current: SupplierScores;
    historical: HistoricalScore[];
    benchmarks: BenchmarkScores;
  };
  metadata: {
    lastAnalyzed: string;
    dataQuality: number;                   // 0-1 quality score
    sourcesCovered: string[];
  };
}

interface PerformanceInsight {
  id: string;
  category: string;                        // 'delivery', 'quality', 'cost', 'communication'
  title: string;
  description: string;
  impact: 'positive' | 'negative' | 'neutral';
  severity: 'low' | 'medium' | 'high' | 'critical';
  trend: 'improving' | 'stable' | 'declining';
  metrics: Array<{
    name: string;
    current: number;
    previous?: number;
    target?: number;
    unit: string;
  }>;
  recommendations: string[];
  confidence: number;
  generatedAt: string;
}

interface RiskInsight {
  id: string;
  type: 'financial' | 'operational' | 'compliance' | 'reputation';
  title: string;
  description: string;
  probability: number;                     // 0-1 probability of occurrence
  impact: number;                          // 0-1 potential impact
  riskScore: number;                       // Combined risk score
  indicators: string[];                    // Warning signs
  mitigation: string[];                    // Suggested mitigation actions
  timeframe: 'immediate' | 'short_term' | 'medium_term' | 'long_term';
  confidence: number;
}

interface OpportunityInsight {
  id: string;
  type: 'cost_savings' | 'capability_expansion' | 'relationship_deepening' | 'innovation';
  title: string;
  description: string;
  potentialValue: {
    min: number;
    max: number;
    currency: string;
    timeframe: string;
  };
  feasibility: number;                     // 0-1 feasibility score
  requiredActions: string[];
  successFactors: string[];
  confidence: number;
}

interface PredictionInsight {
  id: string;
  type: 'performance' | 'cost' | 'capacity' | 'market_position';
  title: string;
  prediction: string;
  timeframe: {
    start: string;
    end: string;
  };
  accuracy: number;                        // Historical model accuracy
  factors: string[];                       // Key influencing factors
  scenarios: Array<{
    scenario: 'optimistic' | 'expected' | 'pessimistic';
    description: string;
    probability: number;
  }>;
  confidence: number;
}
```

---

### 4. Conversational Interface

#### POST /api/ai/suppliers/chat

Conversational interface for supplier-related queries.

**Request Body**
```typescript
interface ChatRequest {
  message: string;
  context?: {
    conversationId?: string;
    supplierId?: string;
    category?: string;
    intent?: 'search' | 'compare' | 'analyze' | 'recommend';
    previousMessages?: ChatMessage[];
  };
  preferences?: {
    responseStyle: 'concise' | 'detailed' | 'technical';
    includeData: boolean;                  // Include supporting data
    includeSuggestions: boolean;           // Include follow-up suggestions
  };
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  metadata?: Record<string, any>;
}
```

**Response**
```typescript
interface ChatResponse {
  response: string;
  conversationId: string;
  context: {
    intent: string;
    entities: ExtractedEntity[];
    confidence: number;
  };
  data?: {
    suppliers?: SupplierBasicInfo[];
    insights?: InsightSummary[];
    comparisons?: ComparisonData[];
  };
  suggestions: {
    followUp: string[];
    actions: ActionSuggestion[];
    relatedTopics: string[];
  };
  metadata: {
    processingTime: number;
    aiProvider: string;
    dataSourcesUsed: string[];
  };
}

interface ExtractedEntity {
  type: 'supplier' | 'location' | 'category' | 'metric' | 'timeframe';
  value: string;
  confidence: number;
}

interface ActionSuggestion {
  type: 'view_supplier' | 'compare_suppliers' | 'generate_report' | 'schedule_meeting';
  title: string;
  description: string;
  parameters?: Record<string, any>;
}
```

---

### 5. Bulk Operations

#### POST /api/ai/suppliers/bulk/enhance

Bulk AI enhancement of multiple suppliers.

**Request Body**
```typescript
interface BulkEnhanceRequest {
  supplierIds: string[];                   // Max 100 suppliers per request
  operations: {
    generateEmbeddings?: boolean;
    enrichData?: boolean;
    analyzePerformance?: boolean;
    calculateSimilarity?: boolean;
    generateInsights?: boolean;
  };
  options?: {
    priority: 'low' | 'normal' | 'high';
    notificationEmail?: string;
    batchSize?: number;                    // Suppliers per batch (default: 10)
  };
}
```

**Response**
```typescript
interface BulkEnhanceResponse {
  jobId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: {
    total: number;
    completed: number;
    failed: number;
    estimatedCompletion: string;
  };
  results?: {
    successful: string[];                  // Supplier IDs successfully processed
    failed: Array<{
      supplierId: string;
      error: string;
    }>;
  };
}
```

#### GET /api/ai/suppliers/bulk/jobs/{jobId}

Check status of bulk operation.

**Response**
```typescript
interface BulkJobStatus {
  jobId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: {
    total: number;
    completed: number;
    failed: number;
    currentBatch: number;
  };
  timing: {
    started: string;
    estimated: string;
    completed?: string;
  };
  results?: BulkEnhanceResponse['results'];
}
```

---

### 6. Analytics and Reporting

#### GET /api/ai/suppliers/analytics/market-trends

Market trend analysis for supplier categories.

**Query Parameters**
```typescript
interface MarketTrendsQuery {
  categories?: string[];
  region?: string;
  timeframe?: '30d' | '90d' | '1y' | '2y';
  metrics?: ('pricing' | 'capacity' | 'innovation' | 'sustainability')[];
}
```

**Response**
```typescript
interface MarketTrendsResponse {
  trends: {
    category: string;
    insights: TrendInsight[];
    forecast: ForecastData[];
    keyDrivers: string[];
  }[];
  market: {
    size: MarketSize;
    growth: GrowthMetrics;
    competitiveIntensity: number;
    barriers: string[];
  };
  recommendations: string[];
}
```

#### GET /api/ai/suppliers/analytics/performance-benchmarks

Performance benchmarking across supplier categories.

#### POST /api/ai/suppliers/analytics/risk-assessment

Comprehensive risk assessment for supplier portfolio.

---

### 7. Configuration and Management

#### GET /api/ai/suppliers/config

Get current AI configuration and model information.

#### POST /api/ai/suppliers/feedback

Provide feedback on AI recommendations and insights.

**Request Body**
```typescript
interface FeedbackRequest {
  type: 'insight' | 'recommendation' | 'search' | 'match';
  referenceId: string;                     // ID of the item being rated
  rating: 1 | 2 | 3 | 4 | 5;              // 1 = poor, 5 = excellent
  feedback?: string;                       // Optional detailed feedback
  improvements?: string[];                 // Suggested improvements
}
```

---

## Error Handling

All endpoints use consistent error response format:

```typescript
interface ErrorResponse {
  error: {
    code: string;                          // Error code (e.g., 'INVALID_QUERY')
    message: string;                       // Human-readable error message
    details?: string;                      // Additional error details
    field?: string;                        // Field that caused error (for validation)
    suggestions?: string[];                // Suggested corrections
  };
  timestamp: string;
  requestId: string;                       // For support tracking
}
```

**Common Error Codes**
- `INVALID_QUERY`: Malformed search query
- `INSUFFICIENT_DATA`: Not enough data for AI processing
- `RATE_LIMIT_EXCEEDED`: API rate limit exceeded
- `AI_SERVICE_UNAVAILABLE`: AI provider temporarily unavailable
- `EMBEDDING_GENERATION_FAILED`: Vector embedding generation failed
- `UNAUTHORIZED_ACCESS`: Insufficient permissions

## Rate Limiting

Different endpoints have different rate limits:

- **Discovery/Search**: 20 requests per minute
- **Matching**: 10 requests per minute
- **Insights**: 30 requests per minute
- **Chat**: 50 requests per minute
- **Bulk Operations**: 2 requests per hour
- **Analytics**: 10 requests per minute

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Request limit per window
- `X-RateLimit-Remaining`: Remaining requests in current window
- `X-RateLimit-Reset`: Timestamp when limit resets

## Authentication & Authorization

All endpoints require valid JWT authentication. Additional permissions:

- **Supplier Discovery**: `suppliers:read`, `ai:discover`
- **Supplier Matching**: `suppliers:read`, `ai:match`
- **Supplier Insights**: `suppliers:read`, `ai:insights`
- **Bulk Operations**: `suppliers:write`, `ai:bulk`
- **Analytics**: `analytics:read`, `ai:analytics`

## Webhook Support

For long-running operations (bulk enhancements, comprehensive analysis):

```typescript
interface WebhookPayload {
  eventType: 'bulk_enhance_completed' | 'analysis_ready' | 'insight_generated';
  data: Record<string, any>;
  timestamp: string;
  signature: string;                       // HMAC signature for verification
}
```

## SDK Integration

TypeScript SDK available for easy integration:

```typescript
import { AISupplierClient } from '@mantisnxt/ai-supplier-sdk';

const client = new AISupplierClient({
  apiKey: 'your-api-key',
  baseUrl: 'https://api.mantisnxt.com'
});

// Discover suppliers
const results = await client.discover({
  query: 'packaging suppliers',
  filters: { location: ['California'] }
});

// Get insights
const insights = await client.getInsights('supplier-id');
```

This comprehensive API specification provides the foundation for implementing AI-powered supplier features with proper error handling, authentication, and scalability considerations.