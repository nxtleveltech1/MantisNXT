# ITERATION 2 PHASE 0: ARCHITECTURAL ASSESSMENT
**Author**: Aster (Principal Full-Stack & Architecture Expert)
**Date**: 2025-10-08
**Context**: Post-Neon migration API failure analysis
**Mission**: Assess architectural gaps causing API failures

---

## EXECUTIVE SUMMARY

**Critical Finding**: API contract-schema mismatch causing multiple 500 errors.

**Root Cause**: APIs query `public.suppliers` view expecting columns that don't exist in the view definition. The schema bridge (migration 003) created views mapping `core.*` tables to `public.*` but these views have **incomplete column coverage** compared to what APIs expect.

**Impact**:
- Multiple API endpoints failing with 500 errors (suppliers, inventory, analytics)
- Frontend receiving undefined data due to missing fields
- Zero test coverage means failures go undetected until runtime

**Database Status**:
- ✅ Connected: Neon serverless PostgreSQL (proud-mud-50346856)
- ✅ Data volume: 25,624 inventory items, 22 suppliers, 76,568 total qty
- ❌ Schema alignment: APIs expect 30+ columns, views provide ~18 columns
- ⚠️ Performance: Sequential scans on 22-row table (no indexes on views)

---

## 1. API-TO-SCHEMA CONTRACT ANALYSIS

### 1.1 Suppliers API Contract Violations

**API Expectation** (`src/app/api/suppliers/route.ts`):
```typescript
// GET /api/suppliers expects these columns:
- status (text) ✅ PROVIDED
- performance_tier (text) ❌ MISSING
- primary_category (text) ❌ MISSING
- geographic_region (text) ❌ MISSING
- bee_level (text) ❌ MISSING
- preferred_supplier (boolean) ✅ PROVIDED (hardcoded false)
- spend_last_12_months (numeric) ❌ MISSING
- contact_person (text) ❌ MISSING
- tax_id (text) ❌ MISSING
- payment_terms (text) ❌ MISSING (only payment_terms_days provided)
```

**Actual View Definition** (`public.suppliers`):
```sql
SELECT
  supplier_id::text AS id,
  name,
  name AS supplier_code,  -- ⚠️ DUPLICATE: name used as code
  CASE WHEN active THEN 'active'::text ELSE 'inactive'::text END AS status,
  contact_email AS email,
  contact_phone AS phone,
  ''::text AS address,  -- ⚠️ EMPTY STRING: should be NULL
  ''::text AS city,
  ''::text AS state,
  ''::text AS postal_code,
  ''::text AS country,
  payment_terms_days,
  default_currency AS currency,
  terms,
  false AS preferred_supplier,  -- ⚠️ HARDCODED: should come from data
  75 AS rating,  -- ⚠️ HARDCODED: should come from data
  created_at,
  updated_at
FROM core.supplier s;
```

**Missing Columns Causing Filter Failures**:
1. `performance_tier` - Used in WHERE clause filtering
2. `primary_category` - Used in search and filtering
3. `geographic_region` - Used in regional filtering
4. `bee_level` - Used in compliance filtering
5. `spend_last_12_months` - Used in min/max spend filtering
6. `contact_person` - Used in search queries

**Impact**: API queries like `WHERE performance_tier = ANY($1)` fail because column doesn't exist, resulting in 500 errors.

---

### 1.2 Inventory API Contract Violations

**API Expectation** (`src/app/api/inventory/route.ts`):
```typescript
// GET /api/inventory expects:
- sku (text) ✅ PROVIDED
- name (text) ✅ PROVIDED
- category (text) ✅ PROVIDED (hardcoded 'Electronics')
- stock_qty (numeric) ✅ PROVIDED
- reserved_qty (numeric) ✅ PROVIDED (hardcoded 0)
- available_qty (numeric) ✅ PROVIDED (calculated)
- cost_price (numeric) ✅ PROVIDED (hardcoded 0)
- sale_price (numeric) ✅ PROVIDED (hardcoded 0)
- supplier_id (text) ✅ PROVIDED
- brand_id (text) ⚠️ PROVIDED (always NULL)
- reorder_point (numeric) ✅ PROVIDED (hardcoded 10)
```

**Actual View Definition** (`public.inventory_items`):
```sql
SELECT
  soh.soh_id::text AS id,
  sp.supplier_sku AS sku,
  sp.name_from_supplier AS name,
  ''::text AS description,  -- ⚠️ EMPTY STRING
  'Electronics'::text AS category,  -- ⚠️ HARDCODED
  ''::text AS subcategory,
  soh.qty AS stock_qty,
  0::numeric AS reserved_qty,  -- ⚠️ HARDCODED
  soh.qty - 0::numeric AS available_qty,
  0::numeric AS cost_price,  -- ⚠️ HARDCODED (should use soh.unit_cost)
  0::numeric AS sale_price,  -- ⚠️ HARDCODED
  sp.supplier_id::text AS supplier_id,
  NULL::text AS brand_id,  -- ⚠️ ALWAYS NULL
  sp.brand_from_supplier AS brand,
  10 AS reorder_point,  -- ⚠️ HARDCODED
  CASE WHEN sp.is_active THEN 'active'::text ELSE 'inactive'::text END AS status,
  sl.name AS location,
  soh.created_at,
  soh.as_of_ts AS updated_at
FROM core.stock_on_hand soh
JOIN core.supplier_product sp ON soh.supplier_product_id = sp.supplier_product_id
LEFT JOIN core.stock_location sl ON soh.location_id = sl.location_id
WHERE sp.is_active = true;
```

**Critical Issues**:
1. **cost_price = 0**: View ignores `soh.unit_cost` (actual cost data exists!)
2. **category = 'Electronics'**: Hardcoded, should come from product categorization
3. **reorder_point = 10**: Hardcoded, should come from business rules
4. **brand_id = NULL**: Should link to `core.brand` table via `core.product`

**Impact**: Analytics dashboard shows $0 inventory value despite having cost data in database.

---

### 1.3 Analytics API Contract Violations

**API Expectation** (`src/app/api/analytics/dashboard/route.ts`):
```typescript
// Queries expect:
1. suppliers.is_preferred (boolean) ❌ MISSING (view has preferred_supplier)
2. suppliers.rating (numeric) ✅ PROVIDED (hardcoded 75)
3. inventory_items.cost_price (numeric) ✅ PROVIDED (hardcoded 0)
4. inventory_items.reorder_point (numeric) ✅ PROVIDED (hardcoded 10)
```

**Query Execution**:
```sql
-- This query FAILS:
SELECT COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers
FROM suppliers;
-- Error: column "is_preferred" does not exist

-- Correct column name:
SELECT COUNT(*) FILTER (WHERE preferred_supplier = true) as preferred_suppliers
FROM suppliers;
```

**Impact**: Dashboard API returns 500 error because query references wrong column name.

---

## 2. DATA FLOW ARCHITECTURE ANALYSIS

### 2.1 Current Architecture (Broken)

```
┌─────────────┐
│  Frontend   │
│  (Next.js)  │
└──────┬──────┘
       │ HTTP GET /api/suppliers?performance_tier=gold
       ▼
┌─────────────────────────────────────────┐
│  API Route Handler                      │
│  src/app/api/suppliers/route.ts         │
│                                         │
│  Query: SELECT * FROM suppliers         │
│         WHERE performance_tier = $1     │ ❌ Column doesn't exist
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Unified Connection Pool                │
│  lib/database/unified-connection.ts     │
│  → enterprise-connection-manager.ts     │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Neon Serverless PostgreSQL             │
│  Project: proud-mud-50346856            │
│                                         │
│  public.suppliers (VIEW)                │
│    ├─ Columns: id, name, status, etc   │
│    └─ ❌ Missing: performance_tier     │
│                                         │
│  Underlying:                            │
│  core.supplier (TABLE)                  │
│    └─ ❌ Also missing performance_tier │
└─────────────────────────────────────────┘
```

### 2.2 Schema Bridge Gap

**Migration 003** created views but with **incomplete coverage**:

| Core Table | Public View | Coverage | Issues |
|------------|-------------|----------|--------|
| `core.supplier` | `public.suppliers` | 60% | Missing 12 expected columns |
| `core.stock_on_hand` | `public.inventory_items` | 70% | Wrong cost mapping, hardcoded values |
| `core.product` | `public.products` | Unknown | Not analyzed yet |
| `core.stock_movement` | `public.stock_movements` | Unknown | Not analyzed yet |

**Root Cause**: Views were created to match **old enterprise schema** column names, but APIs were written expecting **richer data model** that never existed in either schema.

---

## 3. PERFORMANCE BUDGET ANALYSIS

### 3.1 Current Query Performance

**Suppliers Query** (22 rows):
- Query plan: Sequential scan on `core.supplier`
- Cost: 0-1.29 (startup-total)
- Missing indexes on view
- **Issue**: Even with 22 rows, no index usage because view filters aren't indexed

**Inventory Query** (25,624 items):
- No EXPLAIN data yet (needs analysis)
- **Risk**: Full table scan on 25K+ rows without proper indexing
- Hardcoded `WHERE sp.is_active = true` not indexed

**Analytics Dashboard**:
```sql
-- Multiple parallel queries executed:
1. COUNT(*) FROM suppliers WHERE status = 'active'
2. COUNT(*) FROM inventory_items
3. SUM(stock_qty * cost_price) FROM inventory_items  -- ⚠️ Always 0
4. COUNT(*) FROM inventory_items WHERE stock_qty <= reorder_point
5. AVG(rating) FROM suppliers  -- ⚠️ Always 75
```

**Performance Metrics**:
- Slow query threshold: 1000ms
- Current dashboard query: Unknown (needs instrumentation)
- Target: <500ms for dashboard queries

### 3.2 Recommended Performance Budgets

| Endpoint | Target | Max Acceptable | Current | Status |
|----------|--------|----------------|---------|--------|
| GET /api/suppliers | 200ms | 500ms | Unknown | ⚠️ No metrics |
| GET /api/inventory | 300ms | 800ms | Unknown | ⚠️ No metrics |
| GET /api/analytics/dashboard | 400ms | 1000ms | Unknown | ⚠️ No metrics |
| POST /api/suppliers | 150ms | 400ms | Unknown | ⚠️ No metrics |

**Required Indexes**:
```sql
-- For suppliers view (public.suppliers):
CREATE INDEX idx_suppliers_status ON core.supplier(active) WHERE active = true;
CREATE INDEX idx_suppliers_name_search ON core.supplier USING gin(to_tsvector('english', name));

-- For inventory view (public.inventory_items):
CREATE INDEX idx_stock_on_hand_active_products ON core.stock_on_hand(supplier_product_id, qty)
  WHERE EXISTS (SELECT 1 FROM core.supplier_product sp
                WHERE sp.supplier_product_id = stock_on_hand.supplier_product_id
                AND sp.is_active = true);
```

**Issue**: Can't create indexes directly on views; must index underlying `core.*` tables.

---

## 4. ERROR HANDLING & OBSERVABILITY GAPS

### 4.1 Current Error Handling

**API Error Pattern**:
```typescript
// All APIs use same pattern:
catch (error) {
  console.error("Error fetching suppliers:", error);
  return NextResponse.json(
    { success: false, error: "Failed to fetch suppliers" },
    { status: 500 }
  );
}
```

**Issues**:
1. ❌ No error classification (DB error vs validation vs business logic)
2. ❌ No request correlation IDs for tracing
3. ❌ Console.error instead of structured logging
4. ❌ Generic error messages hide root cause from frontend
5. ❌ No retry logic for transient failures
6. ❌ No circuit breaker for database failures

### 4.2 Monitoring Gaps

**What's Missing**:
1. **Request tracing**: No correlation IDs across API → DB → response
2. **Slow query logging**: Threshold set (1000ms) but no aggregation
3. **Error rate metrics**: No tracking of 4xx vs 5xx rates
4. **Database metrics**: No query timing histograms
5. **Health checks**: `/api/health` exists but doesn't validate schema
6. **Alerting**: No automated alerts on error rate spikes

**What Exists**:
- ✅ Performance headers: `X-Query-Duration-Ms`, `X-Query-Fingerprint`
- ✅ Slow query console warnings
- ⚠️ Health endpoint (doesn't check schema alignment)

### 4.3 Frontend Error Handling

**Gap**: APIs return 500 with generic messages, frontend has no way to:
- Distinguish between retriable (connection timeout) vs permanent (schema mismatch) errors
- Show meaningful error messages to users
- Implement smart retry logic
- Track client-side error rates

---

## 5. COMPLIANCE & QUALITY STANDARDS

### 5.1 TypeScript Type Safety

**Current State**:
```typescript
// APIs have Zod schemas for POST validation:
const supplierSchema = z.object({
  name: z.string().min(1),
  email: z.string().email().optional(),
  // ...
});

// But NO schemas for GET response validation
// Frontend receives untyped data:
const response = await fetch('/api/suppliers');
const data = await response.json(); // ❌ Type: any
```

**Missing**:
1. Response schemas for GET endpoints
2. Shared types between API and frontend
3. Runtime validation of database query results
4. Type guards for nullable fields

### 5.2 Testing Coverage

**Current State**: **ZERO test coverage** for:
- API routes (no unit tests, no integration tests)
- Database queries (no contract tests)
- View definitions (no schema tests)
- Error scenarios (no failure mode tests)

**Impact**: Schema mismatches only discovered at runtime in production.

### 5.3 Data Quality Issues

**Hardcoded Values in Views**:
```sql
-- public.suppliers view:
false AS preferred_supplier  -- Should query actual preference data
75 AS rating                 -- Should calculate from performance metrics
''::text AS address          -- Should be NULL, not empty string

-- public.inventory_items view:
'Electronics'::text AS category  -- Should come from product.category
0::numeric AS cost_price         -- Should use soh.unit_cost
10 AS reorder_point             -- Should use business rules
```

**Consequence**:
- Analytics show fake data (all suppliers rated 75)
- Inventory value always $0 despite having cost data
- All items categorized as "Electronics"

---

## 6. CROSS-CUTTING CONCERNS

### 6.1 Security

**Current State**:
- ✅ Input validation with Zod on POST requests
- ✅ Parameterized queries (SQL injection protected)
- ⚠️ No rate limiting
- ⚠️ No authentication/authorization (all APIs public)
- ❌ No audit logging of data access

### 6.2 Caching Strategy

**Found in Code**:
```typescript
import { CacheInvalidator } from "@/lib/cache/invalidation";

CacheInvalidator.invalidateSupplier(
  insertResult.rows[0].id,
  validatedData.name
);
```

**Gap**: Cache invalidation exists but:
- No cache implementation found (Redis configured but not used?)
- No TTL strategy defined
- No cache hit/miss metrics

### 6.3 Scalability Concerns

**Database Connection Pooling**:
```typescript
// unified-connection.ts delegates to enterprise-connection-manager
export const pool = {
  query: query,
  connect: async () => {
    throw new Error('Direct pool.connect() access deprecated');
  }
};
```

**Issues**:
1. Pool size unknown (not visible in config)
2. No connection pool monitoring
3. Error message suggests migration in progress
4. Neon serverless should handle scaling, but pool config matters for latency

---

## 7. ARCHITECTURE DEBT IDENTIFIED

### 7.1 Critical (Fix Now)

| Debt Item | Impact | Effort | Priority |
|-----------|--------|--------|----------|
| View column mismatch | APIs failing | Medium | P0 |
| Hardcoded view values | Wrong analytics | Low | P0 |
| Zero test coverage | Runtime failures | High | P0 |
| Missing error classification | Poor debugging | Low | P0 |

### 7.2 Important (Fix Soon)

| Debt Item | Impact | Effort | Priority |
|-----------|--------|--------|----------|
| No performance indexes | Slow queries | Low | P1 |
| Missing type safety on responses | Type errors | Medium | P1 |
| No structured logging | Hard to debug | Medium | P1 |
| Cache not implemented | Higher DB load | Medium | P1 |

### 7.3 Nice to Have (Backlog)

| Debt Item | Impact | Effort | Priority |
|-----------|--------|--------|----------|
| Auth/authz | Security risk | High | P2 |
| Rate limiting | DoS risk | Low | P2 |
| Audit logging | Compliance | Medium | P2 |
| Health check improvements | Ops visibility | Low | P2 |

---

## 8. RECOMMENDED FIX STRATEGY

### Phase 1: Stop the Bleeding (1-2 hours)

1. **Fix view definitions** to include missing columns:
   - Add `performance_tier`, `primary_category`, etc. to `public.suppliers`
   - Fix `cost_price` mapping in `public.inventory_items` to use `soh.unit_cost`
   - Replace hardcoded values with actual data or NULL

2. **Fix API queries** to match actual column names:
   - Change `is_preferred` to `preferred_supplier` in analytics
   - Add fallbacks for missing columns

3. **Add basic error logging**:
   - Include SQL error codes in responses
   - Log full error stack traces server-side

### Phase 2: Stabilize (2-4 hours)

1. **Create essential indexes** on `core.*` tables:
   - Index for supplier status filtering
   - Index for inventory category filtering
   - Index for stock quantity comparisons

2. **Add response validation**:
   - Zod schemas for GET responses
   - Runtime checks for null/undefined critical fields

3. **Implement basic monitoring**:
   - Query duration tracking
   - Error rate metrics
   - Health check schema validation

### Phase 3: Harden (4-8 hours)

1. **Test coverage**:
   - API route integration tests
   - Database schema contract tests
   - Error scenario tests

2. **Type safety end-to-end**:
   - Shared types between API and frontend
   - Generated types from database schema

3. **Performance optimization**:
   - Query plan analysis
   - Index optimization
   - Cache implementation

---

## 9. MONITORING REQUIREMENTS

### 9.1 Metrics to Track

**Application Metrics**:
- Request rate (requests/sec) by endpoint
- Error rate (%) by endpoint and error type
- Response time p50, p95, p99 by endpoint
- Slow query count (>1000ms) per hour

**Database Metrics**:
- Active connections
- Query duration histograms
- Sequential scan count vs index scan count
- Cache hit ratio (when cache implemented)

**Business Metrics**:
- Total inventory value (should not be $0)
- Supplier count by status
- Out-of-stock item count
- Low stock alert count

### 9.2 Alerting Thresholds

| Metric | Warning | Critical |
|--------|---------|----------|
| Error rate | >1% | >5% |
| Response time p95 | >800ms | >2000ms |
| Slow queries | >10/hour | >50/hour |
| Database connections | >30 | >45 |
| Inventory value = 0 | Always alert | Always alert |

---

## 10. DELIVERABLES SUMMARY

### Assessment Artifacts

✅ **API-to-Schema Contract Analysis**: Documented 12+ missing columns
✅ **Performance Budget Recommendations**: <500ms target for dashboard
✅ **Error Handling Strategy**: Structured logging + error classification
✅ **Monitoring Requirements**: 15 metrics + 5 alert thresholds
✅ **Architecture Debt**: 12 items prioritized P0-P2

### Next Steps

**Immediate Actions** (ITERATION 2 PHASE 1):
1. Execute view fix migration (30 min)
2. Update API queries for column name alignment (15 min)
3. Add error logging improvements (15 min)
4. Deploy and verify (30 min)

**Follow-up Actions** (ITERATION 2 PHASE 2+):
1. Create performance indexes
2. Implement response validation
3. Add monitoring dashboards
4. Build test suite

---

## APPENDICES

### A. Schema Bridge View Definitions

**Current public.suppliers View**:
```sql
CREATE OR REPLACE VIEW public.suppliers AS
SELECT
  supplier_id::text AS id,
  name,
  name AS supplier_code,
  CASE WHEN active THEN 'active'::text ELSE 'inactive'::text END AS status,
  contact_email AS email,
  contact_phone AS phone,
  ''::text AS address,
  ''::text AS city,
  ''::text AS state,
  ''::text AS postal_code,
  ''::text AS country,
  payment_terms_days,
  default_currency AS currency,
  terms,
  false AS preferred_supplier,
  75 AS rating,
  created_at,
  updated_at
FROM core.supplier s;
```

**Current public.inventory_items View**:
```sql
CREATE OR REPLACE VIEW public.inventory_items AS
SELECT
  soh.soh_id::text AS id,
  sp.supplier_sku AS sku,
  sp.name_from_supplier AS name,
  ''::text AS description,
  'Electronics'::text AS category,
  ''::text AS subcategory,
  soh.qty AS stock_qty,
  0::numeric AS reserved_qty,
  soh.qty - 0::numeric AS available_qty,
  0::numeric AS cost_price,
  0::numeric AS sale_price,
  sp.supplier_id::text AS supplier_id,
  NULL::text AS brand_id,
  sp.brand_from_supplier AS brand,
  10 AS reorder_point,
  CASE WHEN sp.is_active THEN 'active'::text ELSE 'inactive'::text END AS status,
  sl.name AS location,
  soh.created_at,
  soh.as_of_ts AS updated_at
FROM core.stock_on_hand soh
JOIN core.supplier_product sp ON soh.supplier_product_id = sp.supplier_product_id
LEFT JOIN core.stock_location sl ON soh.location_id = sl.location_id
WHERE sp.is_active = true;
```

### B. Database Connection Details

**Neon Project**: proud-mud-50346856
**Region**: azure-gwc (Azure Germany West Central)
**PostgreSQL Version**: 17
**Compute**: 0.25-2 CU autoscaling
**Data Size**: 132.7 MB
**Active Time**: 36,036 seconds
**Last Active**: 2025-10-08 10:49:06 UTC

### C. API Endpoints Analyzed

1. `GET /api/suppliers` - Supplier list with filtering
2. `POST /api/suppliers` - Create supplier
3. `GET /api/inventory` - Inventory list with filtering
4. `GET /api/analytics/dashboard` - Dashboard metrics
5. Health endpoints (database-enterprise, database, frontend)

---

**END OF ASSESSMENT**
