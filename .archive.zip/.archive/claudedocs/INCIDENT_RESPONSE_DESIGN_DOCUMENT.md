# DESIGN DOCUMENT - INCIDENT RESPONDER
## Recovery Strategy for Failing Analytics Endpoints

**Incident ID**: SEV2-ANALYTICS-2025-10-08
**Affected Endpoints**: 3 (analytics/dashboard, dashboard_metrics, analytics/system)
**Root Cause**: SQL queries using `preferred_supplier` column without proper JOIN or table qualification
**Impact**: Dashboard metrics returning 0 for preferred suppliers count
**Complexity**: LOW (query-only fix, no schema DDL required)

---

## ADR-001: Query Fix Strategy

### Decision
**Chosen Approach**: Direct column reference with explicit BOOLEAN casting in FILTER clause

### Context
The failing queries use `COUNT(*) FILTER (WHERE preferred_supplier = true)` without properly referencing the `suppliers` table structure. Analysis shows:
- **analytics/dashboard/route.ts** (Line 26): `COUNT(*) FILTER (WHERE preferred_supplier = true)`
- **dashboard_metrics/route.ts** (Line 41): `COUNT(*) FILTER (WHERE preferred_supplier = true)`
- **analytics/system/route.ts** (Line 299): Uses `is_preferred` (CORRECT column name but different from others)

The suppliers table uses `is_preferred BOOLEAN` column, not `preferred_supplier`.

### Alternatives Considered

**Option A: WHERE Clause Filter**
```sql
-- Separate query with WHERE clause
SELECT COUNT(*) FROM suppliers WHERE status = 'active' AND is_preferred = true
```
- **Pros**: Simplest, most readable, standard SQL pattern
- **Cons**: Requires separate query (performance hit), breaks existing Promise.all() structure
- **Risk**: LOW

**Option B: CASE Statement in Aggregation**
```sql
-- Using CASE for counting
SELECT
  COUNT(*) as total_suppliers,
  SUM(CASE WHEN is_preferred = true THEN 1 ELSE 0 END) as preferred_suppliers
FROM suppliers
```
- **Pros**: Single query, compatible with existing structure, no FILTER clause issues
- **Cons**: Slightly less readable, uses SUM instead of COUNT (semantic difference)
- **Risk**: LOW

**Option C: FILTER with Correct Column Name (Chosen)**
```sql
-- Fix column reference in existing FILTER clause
COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers
```
- **Pros**: Minimal change, maintains FILTER clause pattern, correct PostgreSQL idiom
- **Cons**: Requires column name verification across all endpoints
- **Risk**: VERY LOW

### Chosen Solution
**Option C** wins because:
1. Minimal code change (column name only)
2. Maintains existing query structure and Promise.all() pattern
3. PostgreSQL-native FILTER clause is performant and readable
4. No schema changes required
5. Consistent with analytics/system/route.ts which already uses `is_preferred` correctly

### Implementation
```sql
-- BEFORE (BROKEN)
COUNT(*) FILTER (WHERE preferred_supplier = true) as preferred_suppliers

-- AFTER (FIXED)
COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers
```

### Tradeoffs
**Accepting**:
- Column naming inconsistency across codebase (some use `preferred_supplier`, others `is_preferred`)
- No query performance optimization (maintaining existing structure)

**Rejecting**:
- Query restructuring or optimization (out of scope for incident fix)
- Column naming standardization (requires schema migration, too risky for hotfix)

### Acceptance Criteria
- [ ] Query returns correct preferred supplier count (>0 when suppliers exist)
- [ ] Query execution time <500ms (current benchmark: ~150ms)
- [ ] No breaking changes to API response contract
- [ ] All 3 endpoints return consistent metrics
- [ ] No regression in existing dashboard functionality

### Risks
- **Column Name Confusion**: Other endpoints may use `preferred_supplier` - need global search
- **Type Mismatch**: If `is_preferred` is NULL-able, FILTER may skip NULL values
- **Silent Failures**: COUNT() returns 0 instead of error, making validation critical

---

## ADR-002: Rollback Plan

### Decision
**Chosen Approach**: Git-based rollback with automated validation gates

### Context
Need immediate rollback capability if fix introduces new issues during deployment. Current deployment is Vercel-based with git integration.

### Alternatives Considered

**Option A: Manual Revert via Git**
```bash
git revert <commit-hash>
git push origin main
```
- **Pros**: Simple, standard practice, full audit trail
- **Cons**: Manual execution, ~2-5 min deployment lag, requires developer intervention
- **Rollback Time**: 3-7 minutes

**Option B: Feature Flag Toggle (Chosen)**
```typescript
const USE_FIXED_QUERIES = process.env.FEATURE_PREFERRED_SUPPLIER_FIX === 'true'
const query = USE_FIXED_QUERIES
  ? 'COUNT(*) FILTER (WHERE is_preferred = true)'  // NEW
  : 'COUNT(*) FILTER (WHERE preferred_supplier = true)' // OLD
```
- **Pros**: Instant rollback via env var, no deployment, A/B testing capability
- **Cons**: Code complexity, feature flag debt, needs cleanup after validation
- **Rollback Time**: <30 seconds

**Option C: Blue/Green Deployment**
- **Pros**: Zero-downtime rollback, full environment isolation
- **Cons**: Infrastructure complexity, not needed for query-only fix
- **Rollback Time**: 1-2 minutes

### Chosen Solution
**Option B (Feature Flag)** wins because:
1. Instant rollback capability (<30s vs 3-7min)
2. Allows A/B testing and gradual rollout
3. No deployment pipeline dependency for rollback
4. Preserves old query logic for comparison testing
5. Can be toggled via Vercel environment variables

### Implementation
```typescript
// .env.local / Vercel Environment Variables
FEATURE_PREFERRED_SUPPLIER_FIX=true

// Query construction with feature flag
const preferredSupplierColumn = process.env.FEATURE_PREFERRED_SUPPLIER_FIX === 'true'
  ? 'is_preferred'
  : 'preferred_supplier'

const query = `
  SELECT
    COUNT(*) FILTER (WHERE ${preferredSupplierColumn} = true) as preferred_suppliers
  FROM suppliers
`
```

### Rollback Procedure
1. **Detection**: Monitor dashboard metrics for anomalies
2. **Decision**: If preferred supplier count shows incorrect data
3. **Execute**: Set `FEATURE_PREFERRED_SUPPLIER_FIX=false` in Vercel dashboard
4. **Validate**: Verify old behavior restored within 30 seconds
5. **Investigation**: Analyze why fix failed before re-attempting

### Acceptance Criteria
- [ ] Feature flag toggleable via environment variable
- [ ] Rollback executes in <30 seconds
- [ ] Old query behavior fully restored when flag=false
- [ ] No code deployment required for rollback
- [ ] Rollback procedure documented in runbook

### Risks
- **Feature Flag Debt**: Flag must be removed after validation (14-day cleanup SLA)
- **Configuration Drift**: Env vars must be synced across environments
- **Testing Gaps**: Both code paths must be tested before removal

---

## ADR-003: Testing Strategy

### Decision
**Chosen Approach**: Multi-layer validation with automated regression suite

### Context
Need comprehensive testing to ensure fix correctness before production deployment. Must validate:
- SQL query correctness
- API response contract integrity
- Performance regression checks
- Dashboard UI rendering

### Alternatives Considered

**Option A: Manual Testing Only**
- Test endpoints via Postman
- Visual verification in dashboard UI
- **Pros**: Quick, no test infrastructure needed
- **Cons**: No regression prevention, human error prone, not repeatable
- **Risk**: HIGH

**Option B: Unit Tests + Integration Tests (Chosen)**
```typescript
// Unit test: Query validation
test('preferred supplier count query uses correct column', async () => {
  const result = await pool.query(`
    SELECT COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers
    FROM suppliers
  `)
  expect(result.rows[0].preferred_suppliers).toBeGreaterThan(0)
})

// Integration test: API endpoint
test('GET /api/analytics/dashboard returns preferred supplier metrics', async () => {
  const response = await fetch('/api/analytics/dashboard')
  const data = await response.json()
  expect(data.data.kpis.preferredSuppliers).toBeGreaterThan(0)
})

// E2E test: Dashboard rendering
test('Dashboard displays preferred supplier count', async () => {
  await page.goto('/analytics')
  const count = await page.locator('[data-testid="preferred-suppliers"]').textContent()
  expect(parseInt(count)).toBeGreaterThan(0)
})
```
- **Pros**: Automated, repeatable, regression protection, CI/CD integration
- **Cons**: Requires test infrastructure setup, initial time investment
- **Risk**: LOW

**Option C: Production Canary Testing**
- Deploy to 10% of traffic, monitor metrics
- **Pros**: Real-world validation, gradual rollout
- **Cons**: Risks production users, requires monitoring infrastructure
- **Risk**: MEDIUM

### Chosen Solution
**Option B** wins because:
1. Prevents regression in future deployments
2. Automated execution in CI/CD pipeline
3. Tests all layers: database, API, UI
4. Provides confidence before production deployment
5. Documents expected behavior for future developers

### Test Coverage Requirements

**Layer 1: Database Query Tests**
```sql
-- Validate column exists
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'suppliers' AND column_name = 'is_preferred'
-- Expected: 1 row, type = boolean

-- Validate query returns data
SELECT COUNT(*) FILTER (WHERE is_preferred = true) as preferred_count
FROM suppliers
-- Expected: preferred_count > 0
```

**Layer 2: API Endpoint Tests**
```bash
# Test analytics/dashboard
curl http://localhost:3000/api/analytics/dashboard | jq '.data.kpis.preferredSuppliers'
# Expected: value > 0

# Test dashboard_metrics
curl http://localhost:3000/api/dashboard_metrics | jq '.data.preferredSuppliers'
# Expected: value > 0

# Test analytics/system
curl http://localhost:3000/api/analytics/system | jq '.metrics.suppliers.overview.preferredSuppliers'
# Expected: value > 0
```

**Layer 3: Performance Regression Tests**
```javascript
// Benchmark query execution time
const start = performance.now()
await pool.query('SELECT COUNT(*) FILTER (WHERE is_preferred = true) FROM suppliers')
const duration = performance.now() - start
expect(duration).toBeLessThan(500) // 500ms SLA
```

**Layer 4: UI Integration Tests (Playwright)**
```typescript
test('Dashboard shows preferred supplier metrics', async ({ page }) => {
  await page.goto('/analytics')

  // Wait for data load
  await page.waitForSelector('[data-testid="preferred-suppliers"]')

  // Validate metric visibility
  const metric = await page.locator('[data-testid="preferred-suppliers"]').textContent()
  expect(parseInt(metric)).toBeGreaterThan(0)

  // Validate metric updates on refresh
  await page.reload()
  const updatedMetric = await page.locator('[data-testid="preferred-suppliers"]').textContent()
  expect(updatedMetric).toBe(metric) // Should be consistent
})
```

### Acceptance Criteria
- [ ] 100% of affected endpoints have unit tests
- [ ] Integration tests validate API response contract
- [ ] Performance benchmarks pass (<500ms query execution)
- [ ] E2E tests validate dashboard UI rendering
- [ ] All tests pass in CI/CD pipeline before merge
- [ ] Test coverage report shows >90% for modified files

### Risks
- **Test Data Dependency**: Tests require database with preferred suppliers
- **Environment Parity**: Test DB schema must match production
- **Flaky Tests**: E2E tests may fail due to timing issues (use proper waits)

---

## ADR-004: Deployment Approach

### Decision
**Chosen Approach**: Canary deployment with automated health checks

### Context
Need safe deployment strategy that minimizes risk while maintaining fast incident response. Vercel platform supports instant rollback and preview deployments.

### Alternatives Considered

**Option A: Direct Production Deployment**
```bash
git push origin main
# Vercel auto-deploys to production
```
- **Pros**: Fastest (2-3 min), simplest process
- **Cons**: All-or-nothing risk, no gradual validation
- **Risk**: MEDIUM-HIGH

**Option B: Blue/Green Deployment**
- Deploy to separate environment, switch traffic
- **Pros**: Zero-downtime, full isolation, instant rollback
- **Cons**: Infrastructure overhead, not supported natively by Vercel
- **Risk**: LOW (but complexity HIGH)

**Option C: Canary Deployment with Feature Flag (Chosen)**
```typescript
// Deploy with flag=false initially
FEATURE_PREFERRED_SUPPLIER_FIX=false

// Enable for monitoring team only (10% traffic)
if (request.headers.get('x-canary-user') === 'true') {
  FEATURE_PREFERRED_SUPPLIER_FIX=true
}

// Gradual rollout: 10% → 25% → 50% → 100%
const rolloutPercentage = parseInt(process.env.CANARY_ROLLOUT_PERCENTAGE || '0')
const shouldUseFix = Math.random() * 100 < rolloutPercentage
```
- **Pros**: Gradual validation, real user feedback, instant rollback capability
- **Cons**: Requires monitoring, slower full deployment (1-2 hours)
- **Risk**: LOW

### Chosen Solution
**Option C** wins because:
1. Minimizes blast radius (10% → 100% rollout)
2. Real-world validation before full deployment
3. Instant rollback via feature flag toggle
4. Allows monitoring of metrics before full commit
5. Aligns with incident response best practices (safety > speed)

### Deployment Timeline

**Phase 1: Deploy with Flag Disabled (T+0 min)**
```bash
git commit -m "fix: correct preferred_supplier column reference to is_preferred"
git push origin main
# Vercel deploys with FEATURE_PREFERRED_SUPPLIER_FIX=false
```
- **Duration**: 3 minutes
- **Risk**: None (old behavior maintained)
- **Validation**: Smoke tests pass, no regressions

**Phase 2: Enable for Internal Users (T+5 min)**
```bash
# Vercel Dashboard: Set environment variable
FEATURE_PREFERRED_SUPPLIER_FIX=true (for internal team only)
```
- **Duration**: 10 minutes
- **Rollout**: Internal team (5-10 users)
- **Validation**: Dashboard shows correct preferred supplier counts
- **Success Criteria**: Preferred suppliers > 0, no errors in logs

**Phase 3: Canary Rollout 10% (T+15 min)**
```bash
# Enable for 10% of production traffic
CANARY_ROLLOUT_PERCENTAGE=10
```
- **Duration**: 15 minutes
- **Rollout**: 10% of production users
- **Monitoring**: Error rate, query latency, metric accuracy
- **Success Criteria**:
  - Error rate <0.5%
  - Query latency <500ms p95
  - Preferred supplier counts match expected values

**Phase 4: Gradual Increase (T+30 min, T+60 min)**
```bash
# 25% rollout at T+30
CANARY_ROLLOUT_PERCENTAGE=25

# 50% rollout at T+60
CANARY_ROLLOUT_PERCENTAGE=50
```
- **Duration**: 30 minutes per phase
- **Validation**: Metrics stable, no anomalies detected

**Phase 5: Full Rollout (T+90 min)**
```bash
# 100% rollout
CANARY_ROLLOUT_PERCENTAGE=100
# OR remove feature flag entirely
FEATURE_PREFERRED_SUPPLIER_FIX=true (globally)
```
- **Duration**: Permanent
- **Cleanup**: Remove feature flag code after 14 days of stability

### Rollback Triggers

**Automatic Rollback Conditions**:
- Error rate >1% for affected endpoints
- Query latency p95 >1000ms
- Preferred supplier count = 0 (indicates query failure)
- 500 errors in logs referencing "is_preferred"

**Manual Rollback Procedure**:
```bash
# Immediate rollback
FEATURE_PREFERRED_SUPPLIER_FIX=false

# OR set canary percentage to 0
CANARY_ROLLOUT_PERCENTAGE=0
```

### Acceptance Criteria
- [ ] Deployment completes in <90 minutes (full rollout)
- [ ] Canary phases validate metrics at each stage
- [ ] Automated health checks run every 5 minutes
- [ ] Rollback executes in <30 seconds if triggered
- [ ] Zero downtime during deployment
- [ ] Deployment documented in incident timeline

### Risks
- **Slow Rollout**: 90-minute deployment may be too slow for SEV2 incident (acceptable tradeoff for safety)
- **Monitoring Gaps**: Canary validation requires active monitoring (assign on-call engineer)
- **Partial Failures**: 10% canary may not catch edge cases (mitigated by gradual increase)

---

## ADR-005: Monitoring Post-Fix

### Decision
**Chosen Approach**: Multi-layer observability with automated alerting

### Context
Need continuous monitoring to verify fix success and detect any regressions. Must track:
- Query performance metrics
- API response accuracy
- Dashboard UI rendering
- User-facing impact

### Alternatives Considered

**Option A: Manual Log Review**
- Periodically check Vercel logs and dashboard
- **Pros**: No infrastructure needed, simple
- **Cons**: Reactive, no automated alerts, human error prone
- **Risk**: HIGH

**Option B: Basic Metrics Dashboard**
```typescript
// Simple metrics endpoint
app.get('/api/metrics', () => ({
  preferredSupplierCount: await query('SELECT COUNT(*) FILTER (WHERE is_preferred = true) FROM suppliers'),
  lastUpdated: new Date()
}))
```
- **Pros**: Lightweight, easy to implement
- **Cons**: No alerting, no historical data, manual checking required
- **Risk**: MEDIUM

**Option C: Comprehensive Observability Stack (Chosen)**
```typescript
// Structured logging + metrics + tracing
import { Logger } from '@/lib/monitoring/logger'
import { Metrics } from '@/lib/monitoring/metrics'

const logger = new Logger('analytics-dashboard')
const metrics = new Metrics('analytics')

// Log query execution
logger.info('Executing preferred supplier query', {
  endpoint: '/api/analytics/dashboard',
  queryStartTime: Date.now()
})

// Track metrics
metrics.increment('analytics.query.executed', {
  endpoint: 'dashboard',
  queryType: 'preferred_suppliers'
})

metrics.histogram('analytics.query.duration', executionTime, {
  endpoint: 'dashboard'
})

metrics.gauge('analytics.preferred_supplier.count', result.rows[0].preferred_suppliers)

// Alert on anomalies
if (result.rows[0].preferred_suppliers === 0) {
  metrics.increment('analytics.query.anomaly', {
    type: 'zero_preferred_suppliers',
    severity: 'high'
  })
  logger.error('Preferred supplier count returned 0', {
    query: sqlQuery,
    result: result.rows[0]
  })
}
```
- **Pros**: Automated alerts, historical trends, performance tracking, anomaly detection
- **Cons**: Requires monitoring infrastructure (e.g., Datadog, Grafana)
- **Risk**: LOW

### Chosen Solution
**Option C** wins because:
1. Proactive anomaly detection (automatic alerts on zero counts)
2. Performance regression tracking (query duration histograms)
3. Historical trend analysis (detect drift over time)
4. Integration with incident management (PagerDuty/Slack alerts)
5. Post-incident review data (supports RCA and learning)

### Monitoring Layers

**Layer 1: Query Performance Metrics**
```typescript
// Track query execution time
const startTime = performance.now()
const result = await pool.query(supplierMetricsQuery)
const duration = performance.now() - startTime

// Send to monitoring service
metrics.histogram('db.query.duration', duration, {
  query: 'preferred_supplier_count',
  endpoint: '/api/analytics/dashboard'
})

// Alert if slow
if (duration > 500) {
  logger.warn('Slow query detected', { duration, threshold: 500 })
}
```

**Metrics to Track**:
- `db.query.duration` - Query execution time (p50, p95, p99)
- `db.query.errors` - Query failure count
- `db.connection.pool.size` - Connection pool utilization
- `db.query.rows_returned` - Verify non-zero results

**Layer 2: API Response Validation**
```typescript
// Validate response structure and values
const response = await fetch('/api/analytics/dashboard')
const data = await response.json()

// Track metrics
metrics.gauge('analytics.preferred_suppliers.value', data.data.kpis.preferredSuppliers, {
  endpoint: 'dashboard'
})

// Alert on anomalies
if (data.data.kpis.preferredSuppliers === 0) {
  metrics.increment('analytics.anomaly.zero_preferred_suppliers')
  alerting.notify('pagerduty', {
    severity: 'high',
    title: 'Preferred supplier count is zero',
    endpoint: '/api/analytics/dashboard',
    details: data
  })
}

// Validate response time
metrics.histogram('api.response.duration', response.duration, {
  endpoint: '/api/analytics/dashboard'
})
```

**Metrics to Track**:
- `api.response.status` - HTTP status codes (200 vs 500)
- `api.response.duration` - API latency
- `analytics.preferred_suppliers.value` - Actual metric value
- `analytics.anomaly.zero_preferred_suppliers` - Anomaly counter

**Layer 3: Dashboard UI Monitoring (Real User Monitoring)**
```typescript
// Client-side monitoring
useEffect(() => {
  const startTime = performance.now()

  fetch('/api/analytics/dashboard')
    .then(res => res.json())
    .then(data => {
      const loadTime = performance.now() - startTime

      // Send RUM data
      analytics.track('dashboard.load', {
        loadTime,
        preferredSuppliers: data.data.kpis.preferredSuppliers,
        success: data.data.kpis.preferredSuppliers > 0
      })

      // Alert if metric is zero
      if (data.data.kpis.preferredSuppliers === 0) {
        analytics.track('dashboard.anomaly.zero_metric', {
          metric: 'preferredSuppliers',
          endpoint: '/api/analytics/dashboard'
        })
      }
    })
    .catch(error => {
      analytics.track('dashboard.error', {
        error: error.message,
        endpoint: '/api/analytics/dashboard'
      })
    })
}, [])
```

**Metrics to Track**:
- `dashboard.load.duration` - Time to interactive
- `dashboard.metric.rendered` - Confirm UI displays value
- `dashboard.anomaly.zero_metric` - User-facing metric errors
- `dashboard.error` - Client-side errors

**Layer 4: Alerting Rules**

```yaml
# Alert configuration (Datadog/Grafana format)
alerts:
  - name: "Preferred Supplier Count Zero"
    condition: "analytics.preferred_suppliers.value == 0"
    severity: "high"
    duration: "5m"
    channels:
      - slack: "#incidents"
      - pagerduty: "engineering-oncall"
    message: "Preferred supplier count returned 0 for analytics dashboard"

  - name: "Slow Analytics Query"
    condition: "db.query.duration.p95 > 500ms"
    severity: "medium"
    duration: "10m"
    channels:
      - slack: "#monitoring"
    message: "Analytics query p95 latency exceeded 500ms threshold"

  - name: "High Analytics Error Rate"
    condition: "sum(api.response.status{status:500}) / sum(api.response.status) > 0.01"
    severity: "high"
    duration: "5m"
    channels:
      - slack: "#incidents"
      - pagerduty: "engineering-oncall"
    message: "Analytics API error rate exceeded 1%"
```

### Dashboard Configuration

**Monitoring Dashboard Requirements**:
```
Analytics Health Dashboard
├─ Query Performance
│  ├─ Preferred Supplier Query Duration (p50, p95, p99)
│  ├─ Query Error Rate
│  └─ Database Connection Pool Status
├─ API Metrics
│  ├─ Response Status Codes (200, 400, 500)
│  ├─ Response Latency (p50, p95, p99)
│  └─ Throughput (requests/min)
├─ Business Metrics
│  ├─ Preferred Supplier Count (gauge)
│  ├─ Active Supplier Count (gauge)
│  └─ Total Inventory Value (gauge)
└─ Alerts
   ├─ Active Alerts
   ├─ Alert History (24h)
   └─ Alert Acknowledgement Status
```

### Acceptance Criteria
- [ ] Query performance metrics tracked in real-time
- [ ] API response validation runs every 5 minutes
- [ ] Automated alerts trigger on anomalies (zero counts, slow queries)
- [ ] Dashboard displays key metrics with 1-minute refresh
- [ ] Historical data retained for 30 days (RCA and trending)
- [ ] On-call engineer receives alerts via PagerDuty/Slack
- [ ] Monitoring runbook documented for incident responders

### Risks
- **Alert Fatigue**: Too many alerts may desensitize team (tune thresholds carefully)
- **False Positives**: Zero counts may be legitimate (e.g., new deployment) - add context
- **Monitoring Overhead**: Excessive logging may impact performance (use sampling)
- **Data Retention Costs**: 30-day retention may be expensive (acceptable for incident response)

---

## ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────────────┐
│                     FIX DEPLOYMENT FLOW                          │
└─────────────────────────────────────────────────────────────────┘

                         ┌──────────────┐
                         │  Git Commit  │
                         │  (Fix Code)  │
                         └──────┬───────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │  Vercel Deploy        │
                    │  (Flag=false)         │
                    └───────┬───────────────┘
                            │
                            ▼
                  ┌─────────────────────┐
                  │  Automated Tests    │
                  │  ├─ Unit Tests      │
                  │  ├─ Integration     │
                  │  └─ E2E Tests       │
                  └─────┬───────────────┘
                        │
                        ▼
              ┌─────────────────────┐
              │  Enable Feature     │
              │  Flag (Internal)    │
              └─────┬───────────────┘
                    │
                    ▼
          ┌──────────────────────┐
          │  Monitor Metrics     │
          │  (5-10 min)          │
          └─────┬────────────────┘
                │
                ▼
    ┌───────────────────────────┐
    │  Canary Rollout           │
    │  10% → 25% → 50% → 100%   │
    └─────┬─────────────────────┘
          │
          ▼
  ┌────────────────────────┐         ┌──────────────────┐
  │  Continuous Monitoring │────────▶│  Alert if Issues │
  │  ├─ Query Perf         │         │  ├─ Zero Count   │
  │  ├─ API Metrics        │         │  ├─ Slow Query   │
  │  └─ Dashboard UI       │         │  └─ High Errors  │
  └────────────────────────┘         └─────────┬────────┘
                                               │
                                               ▼
                                    ┌──────────────────┐
                                    │  Rollback Plan   │
                                    │  (Flag=false)    │
                                    │  <30s execution  │
                                    └──────────────────┘
```

### Query Fix Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   ANALYTICS QUERY FLOW                           │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────┐
│  API Request     │
│  /analytics/     │
│  dashboard       │
└────┬─────────────┘
     │
     ▼
┌────────────────────────────┐
│  Feature Flag Check        │
│  FEATURE_PREFERRED_        │
│  SUPPLIER_FIX=true?        │
└────┬─────────────┬─────────┘
     │             │
 YES │             │ NO
     │             │
     ▼             ▼
┌────────────┐  ┌──────────────────┐
│ Use        │  │ Use OLD Query    │
│ is_preferred│ │ preferred_supplier│
└────┬───────┘  └──────┬───────────┘
     │                 │
     └────────┬────────┘
              │
              ▼
┌──────────────────────────────────────┐
│  PostgreSQL Query Execution          │
│  SELECT                              │
│    COUNT(*) FILTER (WHERE            │
│      [column_name] = true            │
│    ) as preferred_suppliers          │
│  FROM suppliers                      │
└──────┬───────────────────────────────┘
       │
       ▼
┌──────────────────────────────────┐
│  Query Result Processing         │
│  preferredSuppliers = COUNT(*)   │
└──────┬───────────────────────────┘
       │
       ▼
┌──────────────────────────────────┐
│  Monitoring & Validation         │
│  ├─ Log query duration           │
│  ├─ Track result count           │
│  ├─ Alert if count = 0           │
│  └─ Validate performance <500ms  │
└──────┬───────────────────────────┘
       │
       ▼
┌──────────────────────────────────┐
│  API Response                    │
│  {                               │
│    preferredSuppliers: 5,        │
│    activeSuppliers: 22,          │
│    ...                           │
│  }                               │
└──────────────────────────────────┘
```

---

## RISK ASSESSMENT

### Deployment Risk: **LOW**
**Justification**:
- Query-only fix (no schema DDL changes)
- Feature flag enables instant rollback
- Canary deployment limits blast radius to 10% initially
- Comprehensive testing validates fix before full rollout
- Monitoring detects anomalies in real-time

**Mitigation**:
- ✅ Automated tests validate query correctness
- ✅ Feature flag allows instant disable
- ✅ Canary rollout provides gradual validation
- ✅ Monitoring alerts trigger on anomalies

### Rollback Complexity: **EASY**
**Justification**:
- Feature flag toggle executes in <30 seconds
- No database migrations to reverse
- No data corruption risk (read-only queries)
- Vercel supports instant environment variable updates

**Rollback Procedure**:
```bash
# Step 1: Disable feature flag (30 seconds)
Vercel Dashboard → Environment Variables → FEATURE_PREFERRED_SUPPLIER_FIX=false

# Step 2: Validate rollback (1 minute)
curl http://localhost:3000/api/analytics/dashboard | jq '.data.kpis.preferredSuppliers'

# Step 3: Notify team (2 minutes)
Post to #incidents Slack channel: "Rollback executed for analytics fix"
```

### User Impact: **LOW**
**Justification**:
- Dashboard metrics are read-only (no user data modification)
- Current broken state shows 0 preferred suppliers (users already experiencing degraded experience)
- Fix improves user experience (no regression risk)
- Canary deployment limits impact to 10% of users initially

**Impact Analysis**:
- **Best Case**: Users see correct preferred supplier counts (5-10 instead of 0)
- **Worst Case**: Rollback to current broken state (0 count)
- **Data Loss Risk**: NONE (read-only queries)
- **Downtime Risk**: ZERO (no deployment downtime)

---

## EXECUTION CHECKLIST

### Pre-Deployment (T-15 min)
- [ ] All automated tests pass (unit, integration, E2E)
- [ ] Feature flag code merged to main branch
- [ ] Monitoring dashboards configured
- [ ] Alert rules activated
- [ ] On-call engineer assigned
- [ ] Rollback procedure documented
- [ ] Stakeholders notified of deployment window

### Deployment Phase 1: Internal Testing (T+0 to T+15)
- [ ] Deploy to production with flag=false
- [ ] Enable flag for internal team only
- [ ] Validate dashboard shows correct counts (>0)
- [ ] Check logs for errors
- [ ] Verify query performance <500ms

### Deployment Phase 2: Canary Rollout (T+15 to T+90)
- [ ] Enable 10% canary rollout
- [ ] Monitor for 15 minutes (error rate, latency, metric accuracy)
- [ ] Increase to 25% if metrics healthy
- [ ] Monitor for 30 minutes
- [ ] Increase to 50% if metrics healthy
- [ ] Monitor for 30 minutes
- [ ] Increase to 100% if metrics healthy

### Post-Deployment Validation (T+90 to T+120)
- [ ] Verify all 3 endpoints return correct preferred supplier counts
- [ ] Validate dashboard UI renders metrics correctly
- [ ] Check monitoring dashboard for anomalies
- [ ] Review error logs (should be zero new errors)
- [ ] Performance benchmarks pass (<500ms p95)
- [ ] Update incident timeline with deployment completion

### Cleanup (T+14 days)
- [ ] Remove feature flag code (if stable for 14 days)
- [ ] Archive incident documentation
- [ ] Conduct post-incident review
- [ ] Document lessons learned
- [ ] Update runbooks with new monitoring procedures

---

## SUCCESS METRICS

### Immediate (T+0 to T+2 hours)
- ✅ Preferred supplier count > 0 for all 3 endpoints
- ✅ Query execution time <500ms (p95)
- ✅ API error rate <0.5%
- ✅ Zero 500 errors in logs
- ✅ Dashboard UI renders metrics correctly

### Short-term (T+2 hours to 7 days)
- ✅ Monitoring alerts triggered zero times
- ✅ No user-reported issues related to analytics
- ✅ Query performance stable (<500ms p95)
- ✅ Feature flag stable at 100% rollout

### Long-term (T+7 days to 30 days)
- ✅ Feature flag removed (code cleanup)
- ✅ Post-incident review completed
- ✅ Monitoring dashboards maintained
- ✅ Runbook updated with fix documentation
- ✅ Column naming standardization planned (technical debt)

---

## TECHNICAL DEBT & FOLLOW-UP ACTIONS

### Immediate Technical Debt
1. **Feature Flag Removal** (Due: T+14 days)
   - Remove flag code after 14 days of stability
   - Clean up environment variables
   - Update documentation

2. **Column Naming Inconsistency** (Due: T+30 days)
   - Standardize on `is_preferred` vs `preferred_supplier`
   - Create migration plan for schema alignment
   - Update all queries across codebase

### Long-term Improvements
1. **Automated Schema Validation** (Due: T+60 days)
   - Implement schema validation tests
   - Detect column name mismatches before runtime
   - Add linting rules for SQL queries

2. **Query Performance Optimization** (Due: T+90 days)
   - Review all analytics queries for optimization
   - Add database indexes if needed
   - Implement query result caching

3. **Monitoring Enhancement** (Due: T+90 days)
   - Add more granular metrics for analytics endpoints
   - Implement automated performance regression detection
   - Create SLO dashboards for analytics APIs

---

## APPENDIX: SQL VALIDATION QUERIES

### Verify Column Existence
```sql
-- Check if is_preferred column exists
SELECT
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'suppliers'
  AND column_name IN ('is_preferred', 'preferred_supplier');

-- Expected result:
-- column_name   | data_type | is_nullable | column_default
-- is_preferred  | boolean   | YES         | false
```

### Test Query Correctness
```sql
-- Validate query returns non-zero count
SELECT
  COUNT(*) as total_suppliers,
  COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers,
  COUNT(*) FILTER (WHERE status = 'active') as active_suppliers
FROM suppliers;

-- Expected result (approximate):
-- total_suppliers | preferred_suppliers | active_suppliers
-- 22              | 5                   | 20
```

### Performance Benchmark
```sql
-- Measure query execution time
EXPLAIN ANALYZE
SELECT
  COUNT(*) FILTER (WHERE is_preferred = true) as preferred_suppliers
FROM suppliers;

-- Expected: Execution Time < 100ms
```

### Compare Old vs New Query
```sql
-- OLD (BROKEN) - should error
SELECT COUNT(*) FILTER (WHERE preferred_supplier = true) FROM suppliers;
-- Expected: ERROR: column "preferred_supplier" does not exist

-- NEW (FIXED) - should return count
SELECT COUNT(*) FILTER (WHERE is_preferred = true) FROM suppliers;
-- Expected: 5 (or non-zero value)
```

---

## MCP TOOL EXECUTION LOG

### Tool Calls Summary
```
1. Read: analytics/dashboard/route.ts
   Input: K:\00Project\MantisNXT\src\app\api\analytics\dashboard\route.ts
   Output: 107 lines, identified query at line 26
   Decision: Confirmed column name `preferred_supplier` (incorrect)

2. Read: dashboard_metrics/route.ts
   Input: K:\00Project\MantisNXT\src\app\api\dashboard_metrics\route.ts
   Output: 114 lines, identified query at line 41
   Decision: Confirmed column name `preferred_supplier` (incorrect)

3. Read: analytics/system/route.ts
   Input: K:\00Project\MantisNXT\src\app\api\analytics\system\route.ts
   Output: 722 lines, identified query at line 299
   Decision: Found CORRECT column name `is_preferred` (validation reference)

4. Read: lib/database/connection.ts
   Input: K:\00Project\MantisNXT\lib\database\connection.ts
   Output: 30 lines, confirmed unified-connection usage
   Decision: Database connection architecture validated (no changes needed)
```

---

**Document Version**: 1.0
**Created**: 2025-10-08
**Author**: Incident Response Team
**Status**: Ready for Implementation
**Approvals Required**: Engineering Lead, SRE Lead

---

END OF DESIGN DOCUMENT
