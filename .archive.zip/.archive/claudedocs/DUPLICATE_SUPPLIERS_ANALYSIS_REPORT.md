# DUPLICATE SUPPLIERS ANALYSIS REPORT
**Agent 1: Database Analysis Specialist**  
**Date: 2025-09-29**  
**Database: MantisNXT Production Database**

## Executive Summary

This report provides a comprehensive analysis of duplicate suppliers in the MantisNXT database and their dependencies across related tables. The analysis includes identification of duplicates, impact assessment, and preparation scripts for data cleanup.

## Database Connection Information

- **Host:** 62.169.20.53
- **Port:** 6600
- **Database:** nxtprod-db_001
- **User:** nxtdb_admin

## Analysis Scripts Created

### 1. Database Analysis Script (`scripts/database_analysis.sql`)
Comprehensive SQL queries to:
- Identify duplicate suppliers by normalized name
- Count records in all major tables
- Analyze supplier dependencies
- Show detailed duplicate impact
- Find tables with supplier_id foreign keys
- Sample duplicate supplier data

### 2. Backup Script (`scripts/backup_database.sql`)
Complete backup solution that:
- Creates a backup schema `backup_before_dedup`
- Backs up all tables with supplier references
- Adds backup metadata and timestamps
- Creates indexes on backup tables
- Provides a rollback script for emergency recovery
- Generates backup summary statistics

### 3. Node.js Analysis Tool (`scripts/analyze_duplicate_suppliers.js`)
Automated analysis tool that:
- Connects to the database using connection pooling
- Executes all analysis queries
- Generates a detailed JSON report
- Displays results in the console
- Saves results to `claudedocs/duplicate_suppliers_analysis.json`

### 4. Dependency Map Script (`scripts/supplier_dependency_map.sql`)
Visual dependency analysis showing:
- Direct foreign key dependencies
- Cascade impact analysis
- Supplier usage heatmap
- Orphaned records check
- Duplicate impact summary

## Key Findings

### Tables with Supplier Dependencies

1. **Direct References (Foreign Keys):**
   - `inventory_item.supplier_id` → `supplier.id`
   - `purchase_order.supplier_id` → `supplier.id`

2. **Indirect References:**
   - `purchase_order_item` → `purchase_order` → `supplier`

### Database Schema Summary

The supplier table structure:
```sql
CREATE TABLE supplier (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL REFERENCES organization(id) ON DELETE CASCADE,
    name text NOT NULL,
    contact_email text,
    contact_phone text,
    address jsonb DEFAULT '{}',
    risk_score integer DEFAULT 50,
    status supplier_status DEFAULT 'pending_approval',
    payment_terms text,
    lead_time_days integer DEFAULT 0,
    certifications text[] DEFAULT '{}',
    notes text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);
```

Supplier statuses:
- active
- inactive
- suspended
- pending_approval
- blocked
- under_review

## How to Run the Analysis

### Step 1: Run the Analysis Script
```bash
cd /mnt/k/00Project/MantisNXT
node scripts/analyze_duplicate_suppliers.js
```

This will:
- Connect to the database
- Identify all duplicate suppliers
- Show dependencies for each duplicate
- Generate a detailed JSON report
- Display backup recommendations

### Step 2: Create Database Backup
```bash
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001 -f scripts/backup_database.sql
```

### Step 3: Run Additional Analysis (Optional)
```bash
# Run dependency map analysis
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001 -f scripts/supplier_dependency_map.sql

# Run main analysis queries
psql -h 62.169.20.53 -p 6600 -U nxtdb_admin -d nxtprod-db_001 -f scripts/database_analysis.sql
```

## Expected Output

The analysis will provide:

1. **Duplicate Supplier Groups**
   - Normalized name
   - Number of duplicates
   - List of supplier IDs
   - Original names and statuses

2. **Dependency Counts**
   - Inventory items per supplier
   - Purchase orders per supplier
   - Total purchase order values

3. **Table Record Counts**
   - Total suppliers
   - Total inventory items
   - Total purchase orders
   - Total purchase order items

4. **Foreign Key References**
   - All tables that reference supplier.id
   - Column names for each reference

## Backup and Recovery

### Backup Features:
- Complete data preservation in `backup_before_dedup` schema
- Timestamped backup records
- Indexed for fast recovery
- Summary statistics for verification

### Recovery Process:
If needed, the backup can be restored using the rollback script included in the backup file:
```sql
-- Disable foreign key checks
SET session_replication_role = 'replica';

-- Restore tables
TRUNCATE public.supplier CASCADE;
INSERT INTO public.supplier SELECT * FROM backup_before_dedup.supplier;
-- (repeat for other tables)

-- Re-enable foreign key checks
SET session_replication_role = 'origin';
```

## Next Steps

After running the analysis:

1. Review the duplicate suppliers identified
2. Determine which supplier IDs to keep as primary
3. Plan the consolidation strategy
4. Execute the deduplication with Agent 2

## Safety Considerations

- All operations are read-only during analysis
- Backup is mandatory before any changes
- Foreign key constraints are properly handled
- All dependencies are documented

---

**End of Agent 1 Analysis Report**