# NXT-SPP Database Quick Reference Card

**Neon Project:** `proud-mud-50346856` | **Database:** `neondb` | **Status:** ✅ PRODUCTION-READY

---

## 🎯 Most Important Changes

### ✨ IS-SOH Filter Support (NEW!)
```sql
-- IS-SOH Report: Show only selected inventory
SELECT * FROM serve.v_soh_by_supplier
WHERE supplier_id = 123 AND is_selected = true;

-- IS-SOH Rolled Up: Show only selected products
SELECT * FROM serve.v_soh_rolled_up
WHERE is_selected = true;
```

### 🚀 New Performance Indexes
1. `idx_supplier_product_supplier_active` - ISI Wizard optimization
2. `idx_stock_on_hand_composite` - SOH view optimization
3. `idx_supplier_product_covering` - Index-only scans

---

## 📋 Schema Overview

| Schema | Tables | Views | Functions | Purpose |
|--------|--------|-------|-----------|---------|
| `spp` | 2 | 0 | 2 | Pricelist staging |
| `core` | 12+1mv | 0 | 3 | Operational data |
| `serve` | 0 | 4 | 0 | Application views |

**Total:** 14 tables, 1 materialized view, 4 views, 5 stored procedures, 56 indexes

---

## 🔑 Key Tables

### Supplier & Products
```sql
core.supplier                    -- Supplier master
core.supplier_product            -- Supplier catalog (SKU level)
core.product                     -- Global product master
core.brand, core.category        -- Dimensions
```

### Pricing
```sql
core.price_history               -- SCD Type-2 price tracking
core.current_price               -- Materialized view (fast lookups)
```

### Inventory Selection
```sql
core.inventory_selection         -- Selection header (active/draft)
core.inventory_selected_item     -- Line items (selected/deselected)
```

### Stock Management
```sql
core.stock_location              -- Warehouses/locations
core.stock_on_hand               -- Point-in-time balances
core.stock_movement              -- Transactions (receipt/sale/adjust)
```

### Pricelist Staging
```sql
spp.pricelist_upload             -- Upload metadata
spp.pricelist_row                -- Raw pricelist rows
```

---

## 🎬 Common Operations

### 1. Upload Pricelist
```sql
-- Step 1: Insert upload record
INSERT INTO spp.pricelist_upload (supplier_id, filename, received_at, status)
VALUES (123, 'supplier_123_2025_10.csv', NOW(), 'received')
RETURNING upload_id;

-- Step 2: Bulk insert rows (use COPY or INSERT)
INSERT INTO spp.pricelist_row (upload_id, row_num, supplier_sku, product_name, price, currency)
VALUES (:upload_id, 1, 'SKU-001', 'Product Name', 10.50, 'USD');

-- Step 3: Validate
SELECT * FROM spp.validate_upload(:upload_id);

-- Step 4: Merge (if validation passed)
SELECT * FROM spp.merge_pricelist(:upload_id);

-- Step 5: Refresh prices
REFRESH MATERIALIZED VIEW CONCURRENTLY core.current_price;
```

### 2. Create Inventory Selection
```sql
-- Step 1: Create selection
INSERT INTO core.inventory_selection (selection_name, status, created_at)
VALUES ('Q4 2025 Selection', 'draft', NOW())
RETURNING selection_id;

-- Step 2: Add items
INSERT INTO core.inventory_selected_item (selection_id, supplier_product_id, status)
SELECT :selection_id, supplier_product_id, 'selected'
FROM core.supplier_product
WHERE supplier_id = 123 AND is_active = true;

-- Step 3: Activate selection
UPDATE core.inventory_selection
SET status = 'active'
WHERE selection_id = :selection_id;
```

### 3. Query IS-SOH Reports
```sql
-- By Supplier (with selected_only filter)
SELECT
  supplier_sku,
  name_from_supplier,
  qty_on_hand,
  current_price,
  inventory_value,
  selection_name
FROM serve.v_soh_by_supplier
WHERE supplier_id = 123
  AND is_selected = true  -- Filter for selected items only
ORDER BY supplier_sku;

-- Rolled Up (by product)
SELECT
  product_name,
  total_qty_on_hand,
  supplier_count,
  avg_price,
  total_inventory_value
FROM serve.v_soh_rolled_up
WHERE is_selected = true  -- Filter for products with selected items
ORDER BY total_inventory_value DESC;
```

### 4. Apply Category Mapping
```sql
-- Create mappings
INSERT INTO core.category_map (supplier_id, category_raw, category_id)
VALUES
  (123, 'Electronics > Computers', 100),
  (123, 'Office > Supplies', 200);

-- Apply mappings
SELECT core.apply_category_mapping(123);
```

### 5. Record Stock Movement
```sql
-- Receipt
SELECT core.record_stock_movement(
  p_supplier_product_id := 456,
  p_location_id := 10,
  p_movement_type := 'receipt',
  p_qty := 100.0,
  p_movement_ts := NOW()
);

-- Sale
SELECT core.record_stock_movement(
  p_supplier_product_id := 456,
  p_location_id := 10,
  p_movement_type := 'sale',
  p_qty := -25.0,
  p_movement_ts := NOW()
);
```

---

## 📊 Monitoring Queries

### Check Database Size
```sql
SELECT pg_size_pretty(pg_database_size(current_database())) as size;
```

### Check Table Sizes
```sql
SELECT
  schemaname,
  relname as tablename,
  n_live_tup as rows,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||relname)) as size
FROM pg_stat_user_tables
WHERE schemaname IN ('spp', 'core')
ORDER BY pg_total_relation_size(schemaname||'.'||relname) DESC;
```

### Check Index Usage
```sql
SELECT
  schemaname,
  relname as tablename,
  indexrelname as indexname,
  idx_scan as times_used,
  pg_size_pretty(pg_relation_size(indexrelid)) as size
FROM pg_stat_user_indexes
WHERE schemaname IN ('spp', 'core')
ORDER BY idx_scan DESC
LIMIT 20;
```

### Check Slow Queries
```sql
SELECT
  query,
  mean_exec_time,
  calls
FROM pg_stat_statements
WHERE mean_exec_time > 1000
ORDER BY mean_exec_time DESC
LIMIT 10;
```

### Check Materialized View Freshness
```sql
SELECT
  schemaname,
  matviewname,
  ispopulated,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||matviewname)) as size
FROM pg_matviews
WHERE schemaname = 'core';
```

---

## 🛠️ Maintenance Commands

### Analyze Tables (after data load)
```sql
ANALYZE spp.pricelist_upload;
ANALYZE core.supplier_product;
ANALYZE core.price_history;
ANALYZE core.stock_on_hand;
```

### Refresh Materialized View
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY core.current_price;
```

### Vacuum Dead Tuples
```sql
VACUUM ANALYZE core.supplier_product;
VACUUM ANALYZE core.price_history;
```

### Check for Bloat
```sql
SELECT
  schemaname,
  relname,
  n_live_tup,
  n_dead_tup,
  ROUND(n_dead_tup::float / NULLIF(n_live_tup, 0) * 100, 2) as dead_pct
FROM pg_stat_user_tables
WHERE schemaname IN ('spp', 'core')
  AND n_dead_tup > 1000
ORDER BY dead_pct DESC;
```

---

## 🔒 Data Integrity Checks

### Check for Orphaned Records
```sql
-- Orphaned supplier_product
SELECT COUNT(*)
FROM core.supplier_product sp
WHERE NOT EXISTS (
  SELECT 1 FROM core.supplier s WHERE s.supplier_id = sp.supplier_id
);
```

### Validate Price History Integrity (SCD Type-2)
```sql
-- Check for overlapping periods (should return 0)
SELECT COUNT(*)
FROM core.price_history ph1
JOIN core.price_history ph2
  ON ph1.supplier_product_id = ph2.supplier_product_id
  AND ph1.price_history_id < ph2.price_history_id
WHERE daterange(ph1.valid_from, ph1.valid_to, '[)')
   && daterange(ph2.valid_from, ph2.valid_to, '[)');
```

---

## 🎯 Performance Benchmarks (Expected)

| Query | Expected Time | Notes |
|-------|--------------|-------|
| ISI Wizard product table | <50ms | 10K products per supplier |
| IS-SOH by supplier | <100ms | 5K items with selection filter |
| IS-SOH rolled up | <200ms | 20K products |
| Price history lookup | <5ms | Index-only scan |
| Current price refresh | <10ms | 100K products |

---

## 📞 Troubleshooting

### View Returns No Data
```sql
-- Check if selection is active
SELECT * FROM core.inventory_selection WHERE status = 'active';

-- Check if items are selected
SELECT COUNT(*) FROM core.inventory_selected_item WHERE status = 'selected';

-- Check if stock exists
SELECT COUNT(*) FROM core.stock_on_hand WHERE qty > 0;
```

### Price Not Showing
```sql
-- Check price_history
SELECT * FROM core.price_history
WHERE supplier_product_id = :id
ORDER BY valid_from DESC;

-- Check current_price materialized view
SELECT * FROM core.current_price
WHERE supplier_product_id = :id;

-- Refresh if stale
REFRESH MATERIALIZED VIEW core.current_price;
```

### Pricelist Merge Failed
```sql
-- Check validation results
SELECT * FROM spp.validate_upload(:upload_id);

-- Check for duplicate SKUs
SELECT supplier_sku, COUNT(*)
FROM spp.pricelist_row
WHERE upload_id = :upload_id
GROUP BY supplier_sku
HAVING COUNT(*) > 1;
```

---

## 📚 Documentation Files

1. **NXT_SPP_DATABASE_VALIDATION_AND_OPTIMIZATION_REPORT.md** - Full validation report
2. **NXT_SPP_VALIDATION_TEST_QUERIES.sql** - Comprehensive test queries
3. **NXT_SPP_OPTIMIZATION_SUMMARY.md** - Executive summary
4. **NXT_SPP_QUICK_REFERENCE.md** - This file

---

**Last Updated:** 2025-10-06 by DATA-ORACLE Agent
**Status:** ✅ PRODUCTION-READY
