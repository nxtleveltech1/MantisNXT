# Price List Analysis Summary

**Analysis Date:** 2025-09-26T09:20:00.772Z
**Total Files:** 28

## File Type Distribution
- Excel Files: 22
- PDF Files: 5
- Other Files: 1

## Data Overview
- Total Data Rows: 761 991
- Unique Suppliers: 28

## Supplier List
1. 0 PlusPortal Login details.docx
2. BCE Brands  June Final.01
3. ACTIVE MUSIC DISTRIBUTION    AUGUST
4. Alpha Technologies  August    (2)
5. ApexPro Distribution  25 04   (1)
6. Audiolite  WHOLESALE OUT
7. Audiosure StockFile
8. AV Distribution    May   (1)
9. BK Percussion August   .03
10. GLOBAL MUSIC SUGGESTED ONLINE ADVERTISED  NOVEMBER   SKU LIST FORMAT
11. Legacy Brands Cables & Connectors   June
12. Legacy Brands Consumables    June
13. Legacy Brands Gear    June
14. MD External Stock   08 25
15. MM  August   18.08.
16. Music Power  (August  )
17. Planetworld SOH 20 June
18. Pro Audio platinum
19. Rockit  25.08. .01
20. Rolling Thunder July
21. Sennheiser   (2)
22. SonicInformed    I
23. Stage Audio Works SOH info
24. Stage one FullPL DP (7)
25. Tuerk Multimedia  Studio   JULY
26. Tuerk Tech General  JULY
27. Viva Afrika Dealer  07 May
28. YAMAHA RETAIL  NOV   (2)

## Processing Recommendations

### Excel Files Ready for Processing (22)

**ACTIVE MUSIC DISTRIBUTION PRICELIST - AUGUST 2025.xlsx**
- Sheet: August Pricelist v3 (331 rows)
  - Price Column: Active Music Distribution Pricelist - August

**Alpha-Technologies-Pricelist-August-2025- (2).xlsx**
- Sheet: Front Page (52 rows)
- Sheet: Alfatron Audio (221 rows)
- Sheet: Alfatron AV Cables & Connectors (116 rows)
- Sheet: Alfatron Display & UC  (42 rows)
- Sheet: Alfatron PTZ & Controllers (53 rows)
- Sheet: Alfatron Signal Management (80 rows)
- Sheet: Arec (66 rows)
- Sheet: Audio-Technica (527 rows)
- Sheet: Barix (61 rows)
- Sheet: Beyerdynamic (146 rows)
- Sheet: Biamp Apprimo, Impera, Vidi (82 rows)
  - Price Column: Biamp Price List 
- Sheet: Biamp Atom, Modena, Vocia (60 rows)
  - Price Column: Biamp Price List 
- Sheet: Biamp Cambridge (89 rows)
  - Price Column: Biamp Pricelist
- Sheet: Biamp Commercial Audio (147 rows)
  - Price Column: Biamp Price List
- Sheet: Biamp Community (517 rows)
  - Price Column: Biamp Price List 
- Sheet: Biamp Desono & Active Sets (176 rows)
  - Price Column: Biamp Price List
- Sheet: Biamp Devio, Parle, Tesira (195 rows)
  - Price Column: Biamp Price List 
- Sheet: Bose Professional (276 rows)
- Sheet: Catchbox (74 rows)
- Sheet: Cloud   (116 rows)
- Sheet: Denon & AKG (41 rows)
- Sheet: Evoko & Workplace (34 rows)
- Sheet: Grandview (323 rows)
- Sheet: InFocus (81 rows)
- Sheet: Lenovo (67 rows)
- Sheet: Niveo (17 rows)
- Sheet: Powerlite (166 rows)
- Sheet:  Procab & ANSR (16 rows)
- Sheet: Rolls (66 rows)
- Sheet: Smartbus (335 rows)
- Sheet: Wyrestorm (69 rows)
  - Price Column: WyreStorm Price List

**ApexPro Distribution pricelist 25-04-2025 (1).xlsx**
- Sheet: Sheet1 (47 rows)
  - SKU Column: SKU
  - Description Column: Description
  - Price Column: Dealer Cost inc VAT

**Audiolite PRICE LIST-WHOLESALE OUT.xlsx**
- Sheet: Sheet1 (141 rows)

**Audiosure StockFile 30072025.xlsx**
- Sheet: Sheet1 (1064 rows)
  - Description Column: ItemNumber
  - Price Column: Retail Incl.

**AV Distribution Pricelist - May 2025 (1).xlsx**
- Sheet: Disclaimer  (3 rows)
- Sheet: ATLONA (154 rows)
- Sheet: AUDAC (363 rows)
- Sheet: XILICA (27 rows)
- Sheet: PROCAB (1084 rows)
- Sheet: SENNHEISER  (177 rows)
- Sheet: HOLLYLAND (215 rows)
- Sheet: CASES (344 rows)
- Sheet: EPOS (162 rows)
- Sheet: RYCOTE (622 rows)
- Sheet: AIDA  IMAGING (66 rows)
- Sheet: HIVE Industries (3278 rows)
- Sheet: FORTINGE (148 rows)
- Sheet: AXXENT (54 rows)

**GLOBAL MUSIC SUGGESTED ONLINE ADVERTISED PRICELIST NOVEMBER 2024 SKU LIST FORMAT .xlsx**
- Sheet: Sheet1 (1348 rows)
  - Price Column: GLOBAL MUSIC SUGGESTED ONLINE ADVERTISED PRICELIST NOVEMBER 2024

**MD External Stock 2025-08-25.xlsx**
- Sheet: Sheet1 (2791 rows)

**MM Pricelist August - 18.08.2025.xlsm**
- Sheet: Index (25 rows)
- Sheet: HOME (18 rows)
- Sheet: DISCOUNTS (17 rows)
- Sheet: BEHRINGER (113 rows)
- Sheet: HOTONE (17 rows)
- Sheet: CRAFTER (13 rows)
- Sheet: TANNOY (11 rows)
- Sheet: TC ELEC (36 rows)
- Sheet: ASTON (6 rows)
- Sheet: ELECTRO HARM (22 rows)
- Sheet: BUGERA (1 rows)
- Sheet: LEWITT (8 rows)
- Sheet: KLARK TEK (3 rows)
- Sheet: JINBAO (42 rows)
- Sheet: QUIKLOK (26 rows)
- Sheet: AGUILAR (11 rows)
- Sheet: AHEAD & KICKPORT (33 rows)
- Sheet: HARDCASE (16 rows)
- Sheet: PREMIER (21 rows)
- Sheet: Sheet1 (2 rows)

**Music Power Pricelist (August 2025).xlsx**
- Sheet: Index (402 rows)
- Sheet: Order Sheet (2178 rows)
- Sheet: Aquarian (120 rows)
- Sheet: Arturia (52 rows)
- Sheet: Saga (12 rows)
- Sheet: Dixon Guitar (8 rows)
- Sheet: Dixon Drums  (82 rows)
- Sheet: DW (16 rows)
- Sheet: Elixir  (39 rows)
- Sheet: F-Zone HiTech (4 rows)
- Sheet: F-Zone Key's  (7 rows)
- Sheet: F-Zone Orchestral (4 rows)
- Sheet: F-Zone Guitar (21 rows)
- Sheet: F-Zone Drums (7 rows)
- Sheet: Gibraltar (93 rows)
- Sheet: Gator - Orchestral (14 rows)
- Sheet: Gator - Drums (20 rows)
- Sheet: Gator - Guitar (57 rows)
- Sheet: Gator - HiTech (16 rows)
- Sheet: Gator - Keys (22 rows)
- Sheet: Gewa (50 rows)
- Sheet: Halifax (14 rows)
- Sheet: Han Flag Percussion (30 rows)
- Sheet: Hidersine (706572 rows)
- Sheet: Jargar (14 rows)
- Sheet: Joseph Teller (49 rows)
- Sheet: Jupiter  (18 rows)
- Sheet: Kaotica (7 rows)
- Sheet: KZ-Audio (15 rows)
- Sheet: Kyser (13 rows)
- Sheet: Latin Groove (20 rows)
- Sheet: Lanikai (5 rows)
- Sheet: Levy's  (188 rows)
- Sheet: LP (31 rows)
- Sheet: Mahalo (80 rows)
- Sheet: Mooer (83 rows)
- Sheet: Mypad (92 rows)
- Sheet:  Nomad Music  (37 rows)
- Sheet: Nuova (4 rows)
- Sheet: Omete (12 rows)
- Sheet: Optech (24 rows)
- Sheet: Orange (25 rows)
- Sheet: PDP (54 rows)
- Sheet: Sadowsky (6 rows)
- Sheet: SHURE (10 rows)
- Sheet: Sabian (46 rows)
- Sheet: SSL (8 rows)
- Sheet: Slate Digital (1 rows)
- Sheet: Sandner (52 rows)
- Sheet: Power Percussion (22 rows)
- Sheet: Santa Fe Guitars (8 rows)
- Sheet: Santa Fe Brass (81 rows)
- Sheet: Superlux (29 rows)
- Sheet: SX & DR Parts (38 rows)
- Sheet: Taylor (14 rows)
- Sheet: Thomastik (62 rows)
- Sheet: Valencia (12 rows)
- Sheet: Vandoren (146 rows)
- Sheet: Vater (52 rows)
- Sheet: Warwick - Bass (87 rows)
- Sheet: Warick Hi-Tech (18 rows)
- Sheet: Warwick Drums (10 rows)
- Sheet: Warwick (5 rows)
- Sheet: Wolf (8 rows)
- Sheet: XVive (24 rows)

**Planetworld SOH 20 June.xlsx**
- Sheet: Sheet1 (1495 rows)
  - Description Column: Item No.
  - Price Column: Retail (Incl)

**Pro Audio platinum .xlsx**
- Sheet: CONTENT (40 rows)
- Sheet: AEROBAND (69 rows)
- Sheet: ATIES & LDA & EVAC (131 rows)
- Sheet: ATIES & PENTON (125 rows)
- Sheet: AUDIO TECHNICA CONSUMER (137 rows)
- Sheet: AUDIO TECHNICA PRO (275 rows)
- Sheet: BLACKSTAR (154 rows)
- Sheet: CARRY-ON (139 rows)
- Sheet: CMX (129 rows)
- Sheet: dB TECHNOLOGIES (82 rows)
- Sheet: ENOVA (58 rows)
- Sheet: EPIPHONE (324 rows)
- Sheet: GIBSON USA (135 rows)
- Sheet: HK AUDIO (141 rows)
- Sheet: KRAMER (26 rows)
- Sheet: KRK (122 rows)
- Sheet: LAB GRUPPEN & LAKE PROCESSING (147 rows)
- Sheet: MIDAS (132 rows)
- Sheet: MONACOR (118 rows)
- Sheet: NORD (133 rows)
- Sheet: PIONEER DJ (159 rows)
- Sheet: POWERSOFT (140 rows)
- Sheet: POWERWORKS (232 rows)
- Sheet: POWERWORKS LINE ARRAY (138 rows)
- Sheet: RCF (38 rows)
- Sheet: SONANCE (141 rows)
- Sheet: SOUND TOWN (48 rows)
- Sheet: SWIFF (26 rows)
- Sheet: TANNOY COMMERCIAL (56 rows)
- Sheet: TURBOSOUND (91 rows)

**Rockit Price_List_25.08.2025.01.xlsx**
- Sheet: Sheet1 (2067 rows)
  - Price Column:                                    SRP Price List

**Rolling Thunder July 2025 Pricelist .xlsx**
- Sheet: Odyssey (999 rows)
  - Description Column: Item Name
  - Price Column: Retail Excluding VAT
- Sheet: UDG (999 rows)
  - Description Column: Item Name
  - Price Column: Retail Excluding VAT
- Sheet: Ortofon (999 rows)
  - Description Column: Item Name
  - Price Column: Retail Incl
- Sheet: Hercules DJ  (999 rows)
  - Description Column: Item Name
  - Price Column: Retail Excluding VAT

**Sennheiser 2025 (2).xlsx**
- Sheet: 17th June Full Run Out (1708 rows)
  - Description Column: Item No.
  - Price Column: Retail Ex Vat
- Sheet: Product Breakdown Best Sellers (204 rows)
  - Description Column: Item No.
  - Price Column: Retail Ex Vat

**SonicInformed_20250808_I.xlsx**
- Sheet: MENU (66 rows)
- Sheet: ADVANTECH (64 rows)
  - Description Column: ITEM NUMBER
  - Price Column: PRICE LIST
- Sheet: ALL (968 rows)
  - SKU Column: BARCODE/EAN
  - Description Column: ITEM NUMBER
  - Price Column: PRICE LIST

**Stage Audio Works SOH info_20250826_0247.xlsx**
- Sheet: Data (6059 rows)
  - Description Column: Product No.
  - Price Column: Price Before Discount Ex Vat

**Stage one FullPL-DP (7).xlsx**
- Sheet: Sheet1 (2605 rows)
  - Price Column: ALL PRICES EXCLUDE VAT

**Tuerk Multimedia  Studio Price List_ JULY 2025.xlsx**
- Sheet: ABLETON  (30 rows)
- Sheet: AUDIENT (22 rows)
- Sheet: Sheet1 (0 rows)
- Sheet: Avid_ SIBELIUS (27 rows)
- Sheet: Avid_PRO TOOLS (34 rows)
- Sheet: Avid- SIBELIUS  Teams& Multi Ed (43 rows)
- Sheet: Avid_PRO TOOLS Hardware (88 rows)
- Sheet: Decksaver Product List (430 rows)
- Sheet: Decksaver Price List (46 rows)
- Sheet: ESI AUDIO  (39 rows)
- Sheet: FOCAL PRO (31 rows)
  - Description Column: Products
- Sheet: Fruityloops (39 rows)
- Sheet: HEADLINER (53 rows)
  - Description Column: PRODUCT NAME
- Sheet: HOSA (271 rows)
- Sheet: IK Multimedia (159 rows)
- Sheet: ISOACOUSTICS (28 rows)
- Sheet: MAGMA  (188 rows)
- Sheet: Native Instruments (136 rows)
- Sheet: Sheet3 (0 rows)
- Sheet: Sheet4 (0 rows)
- Sheet: Sheet5 (0 rows)
- Sheet: NEKTAR USB KEYBOARDS (42 rows)
- Sheet: PRESONUS (193 rows)
- Sheet: Sheet6 (0 rows)
- Sheet: Prodipe (94 rows)
- Sheet: Sheet2 (0 rows)
- Sheet: RME (95 rows)
  - Description Column: Item
- Sheet: SE ELECTRONICS MICS (105 rows)
- Sheet: STANDS (37 rows)
- Sheet: Sheet7 (0 rows)
- Sheet: REASON STUDIOS  (32 rows)
- Sheet: Steinberg  (49 rows)
- Sheet: STYLOPHONE (42 rows)
- Sheet: Universal Audio (89 rows)
- Sheet: WARM AUDIO (91 rows)

**Tuerk Tech General Price List JULY 2025.xls**
- Sheet: CONTENTS (175 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: HOHNER (268 rows)
- Sheet: Sheet1 (0 rows)
- Sheet: TUNERS & METRONOMES (201 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: KORG (224 rows)
  - Price Column: KORG RETAIL PRICE LIST
- Sheet: SAKAE DRUMS & ACCESSORIES (5 rows)
- Sheet: HOSA CABLES, CONNECTORS & ADAPT (573 rows)
- Sheet: PRODIPE (194 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: VOX AMPS (155 rows)
- Sheet: UNIVERSAL AUDIO _ UAFX PEDALS (28 rows)
- Sheet: MXR,DUNLOP & WAY HUGE PEDALS (303 rows)
- Sheet: DUNLOP STRINGS (223 rows)
  - Price Column: GENERAL PRICELIST 
- Sheet: DUNLOP GUITAR STRAPS (212 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: DUNLOP CAPOS, SLIDES & SHIRTS (194 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: DUNLOP ACCESSORIES (203 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: DUNLOP PICKS (477 rows)
  - Price Column: GENERAL PRICELIST
- Sheet: SCHALLER (160 rows)
  - Price Column: GENERAL PRICELIST

**Viva Afrika Dealer Price List 07 May 2025.xlsx**
- Sheet: Table 1 (1317 rows)
  - Price Column: Price List

**YAMAHA RETAIL PRICELIST NOV 2024 (2).xlsx**
- Sheet: EL (12 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Digital Piano (114 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Portable Keyboard (53 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: W&B (716 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Education (81 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Percussion (412 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Strings (77 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: SYDE (49 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: Guitars (529 rows)
  - Price Column: GLOBAL PRICELIST NOV 2024
- Sheet: Drums (842 rows)
  - Price Column: GLOBAL MUSIC PRICELIST NOV 2024
- Sheet: MI-PA (128 rows)
  - Price Column: GLOBAL PRICELIST NOV 2024
- Sheet: MI-PA PT2 (70 rows)
  - Price Column: GLOBAL PRICELIST NOV 2024
- Sheet: MPP (24 rows)
  - Price Column: GLOBAL PRICELIST NOV 2024

### PDF Files Requiring Manual Processing (5)
- 2025_BCE_Brands_Pricelist_June_Final.01.pdf (2.22 MB)
- BK_Percussion_August_Pricelist_2025.03.pdf (8.02 MB)
- Legacy Brands Cables & Connectors - June 2024.pdf (1.19 MB)
- Legacy Brands Consumables Price List - June 2024.pdf (1.28 MB)
- Legacy Brands Gear Price List - June 2024.pdf (3.12 MB)

## Next Steps
1. **Database Schema Enhancement**: Add columns for price lists, SKU variations, supplier mappings
2. **Data Import Pipeline**: Create automated import for Excel files
3. **PDF Processing**: Implement PDF parsing for manual price lists
4. **Data Validation**: Implement SKU validation and duplicate detection
5. **Supplier Mapping**: Map price list data to existing supplier records
