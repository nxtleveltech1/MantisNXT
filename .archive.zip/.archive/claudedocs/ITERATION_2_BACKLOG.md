# ITERATION 2 BACKLOG

**Date Created**: 2025-10-08
**Source**: Rolled forward from ITERATION 1 + new requirements
**Status**: Ready for ITERATION 2 DISCOVERY

---

## P0 ITEMS (CRITICAL - MUST FIX IN ITERATION 2)

### Infrastructure Security (From ITERATION 1 - infra-config-reviewer)

**P0-1: Remove Hardcoded Database IPs**
- **Issue**: 6 API routes have hardcoded `62.169.20.53:6600` references
- **Files**:
  - `src/app/api/dashboard/real-stats/route.ts` (lines 5-6)
  - `src/app/api/suppliers/real-data/route.ts` (lines 5-6)
  - `src/app/api/products/catalog/route.ts` (lines 5-6)
  - `src/app/api/test/live/route.ts` (lines 205-207)
  - `src/app/api/health/route.ts` (line 51)
  - `src/app/api/health/database/route.ts` (lines 126-127, 155-156)
- **Fix**: Replace with `import { pool } from '@/lib/database'`
- **Owner**: infra-config-reviewer + aster-fullstack-architect

**P0-2: Secure Git-Tracked Secrets**
- **Issue**: `.env.local` and `.claude/mcp-config.json` are git-tracked with exposed credentials
- **Fix**:
  - `git rm --cached .env.local .claude/mcp-config.json`
  - Rotate ALL credentials (Neon password, JWT_SECRET, SESSION_SECRET, Context7 API key)
- **Owner**: infra-config-reviewer

**P0-3: Generate Cryptographic Secrets**
- **Issue**: Predictable JWT/SESSION secrets
- **Current**: `enterprise_jwt_secret_key_2024_production`
- **Fix**: Generate with `openssl rand -base64 64`
- **Owner**: infra-config-reviewer

**P0-4: Fix Connection Pool for Serverless**
- **Issue**: `DB_POOL_MAX=50` incompatible with Neon serverless
- **Fix**: Change to `DB_POOL_MAX=1` for serverless mode
- **Owner**: infra-config-reviewer + data-oracle

**P0-5: Add Statement Timeout**
- **Issue**: Missing statement timeout can exhaust connection pool
- **Fix**: Add `&statement_timeout=30000` to DATABASE_URL
- **Owner**: infra-config-reviewer + data-oracle

**P0-6: Move API Keys to Secure Location**
- **Issue**: Context7 API key in `.claude/mcp-config.json` (git-tracked)
- **Fix**: Move to `.claude/.env` (git-ignored)
- **Owner**: infra-config-reviewer

### Database Constraints & APIs (NEW - USER REQUESTED)

**P0-7: Sort Out Database Constraints**
- **Issue**: Missing constraints, foreign keys, or validation rules
- **Action**: Audit all tables, add missing constraints
- **Owner**: data-oracle + aster-fullstack-architect

**P0-8: Fix Outstanding API Issues**
- **Issue**: API errors from ITERATION 1 logs
- **Errors**:
  - API 500 on analytics endpoints
  - API 400 on suppliers endpoint
  - Frontend crash: PortfolioDashboard.tsx:330
- **Owner**: production-incident-responder + aster-fullstack-architect

### Neon Production Readiness (NEW - USER REQUESTED)

**P0-9: Make Neon Fully PRODUCTION Ready**
- **Issue**: Align everything to Neon as primary database
- **Actions**:
  - Verify all APIs using Neon connection
  - Remove all references to old database
  - Production-grade error handling
  - Monitoring and alerting configured
  - Backup strategy in place
- **Owner**: data-oracle + infra-config-reviewer + production-incident-responder

**P0-10: Build Neon → Postgres OLD Replication Function**
- **Issue**: Need backup/replication from Neon (primary) to Postgres OLD (backup)
- **Requirements**:
  - Backend function that replicates Neon data to Postgres OLD
  - Trickle-feed or batch replication
  - Error handling and retry logic
  - Monitoring and alerting
  - Configurable replication frequency
  - **END-TO-END**: Full integration with both databases, error handling, logging, monitoring, documentation
- **Owner**: data-oracle + aster-fullstack-architect

---

## P1 ITEMS (HIGH PRIORITY - SHOULD FIX IN ITERATION 2)

### Frontend (From ITERATION 1 - ui-perfection-doer)

**P1-1: Add 3 High-Priority ARIA Attributes**
- **Issue**: Missing ARIA attributes on error boundaries
- **Owner**: ui-perfection-doer

**P1-2: Add Page-Level Error Boundaries**
- **Issue**: Inventory and suppliers pages need error boundaries
- **Owner**: ui-perfection-doer

**P1-3: Add Suspense Wrappers**
- **Issue**: Dynamic imports need Suspense wrappers
- **Owner**: ui-perfection-doer

**P1-4: Fix Frontend Crash**
- **Issue**: PortfolioDashboard.tsx:330 - undefined `metrics?.selected_products`
- **Fix**: Change to `(metrics?.selected_products ?? 0).toLocaleString()`
- **Owner**: ui-perfection-doer

### Performance (From ITERATION 1 - ml-architecture-expert)

**P1-5: Optimize Slow View**
- **Issue**: `v_product_table_by_supplier` takes 217ms (target <50ms)
- **Fix**: Create materialized view with refresh strategy
- **Owner**: ml-architecture-expert + data-oracle

**P1-6: Deploy Caching Layer to Production**
- **Issue**: 4-tier LRU caching system exists but not deployed
- **Fix**: Deploy and configure caching
- **Owner**: ml-architecture-expert + infra-config-reviewer

**P1-7: Enable Query Performance Monitoring**
- **Issue**: No active query monitoring
- **Fix**: Enable pg_stat_statements, set up slow query alerts
- **Owner**: ml-architecture-expert + data-oracle

### API Monitoring (From ITERATION 1 - production-incident-responder)

**P1-8: Monitor API Response Times**
- **Issue**: Currently 21-165ms, target <100ms
- **Fix**: Set up monitoring with alerts for >100ms
- **Owner**: production-incident-responder

**P1-9: Enable 24-Hour Post-Deployment Monitoring**
- **Issue**: Need intensive monitoring after production deployment
- **Owner**: production-incident-responder + infra-config-reviewer

### Schema Completion (From ITERATION 1 - aster-fullstack-architect)

**P1-10: Migrate 41 API Routes to core.* Schema**
- **Issue**: 41 API routes still using public.* views
- **Fix**: Gradual migration to core.* for better performance
- **Owner**: aster-fullstack-architect + data-oracle

---

## P2 ITEMS (MEDIUM PRIORITY - FIX IF TIME PERMITS)

### Data Import (From ITERATION 1 - data-oracle)

**P2-1: Import Stock Movement Historical Data**
- **Issue**: stock_movement table is empty
- **Owner**: data-oracle

**P2-2: Import Missing purchase_orders Table**
- **Issue**: Table doesn't exist, causing API failures
- **Owner**: data-oracle

**P2-3: Fix Zero Pricing Issue**
- **Issue**: cost_price=0, sale_price=0 hardcoded in views
- **Owner**: data-oracle + aster-fullstack-architect

### Analytics Enhancement (From ITERATION 1 - ml-architecture-expert)

**P2-4: Implement Redis Distributed Caching**
- **Issue**: Current caching is in-memory, need distributed for scaling
- **Owner**: ml-architecture-expert + infra-config-reviewer

**P2-5: Performance Regression Testing**
- **Issue**: No automated performance testing
- **Owner**: ml-architecture-expert

**P2-6: Capacity Planning for Autoscaling**
- **Issue**: Need metrics for scaling decisions
- **Owner**: ml-architecture-expert + infra-config-reviewer

### Schema Improvements (From ITERATION 1 - aster-fullstack-architect)

**P2-7: Add Missing Columns to Schema Bridge Views**
- **Issue**: 12+ columns missing (performance_tier, primary_category, etc.)
- **Owner**: aster-fullstack-architect + data-oracle

**P2-8: Remove Hardcoded Values in Views**
- **Issue**: category='Electronics', rating=75 hardcoded
- **Owner**: aster-fullstack-architect + data-oracle

---

## P3 ITEMS (LOW PRIORITY - DEFER TO FUTURE ITERATIONS)

**P3-1: Complete WCAG AAA Compliance**
- **Issue**: Currently at WCAG AA (78/100), need AAA (95+/100)
- **Owner**: ui-perfection-doer

**P3-2: Third-Party Security Audit**
- **Issue**: Need external penetration testing
- **Owner**: infra-config-reviewer

**P3-3: Implement Secrets Rotation Policy**
- **Issue**: Need automated credential rotation
- **Owner**: infra-config-reviewer

---

## SUMMARY

**Total Backlog Items**: 31

**By Priority**:
- P0 (Critical): 10 items
- P1 (High): 10 items
- P2 (Medium): 8 items
- P3 (Low): 3 items

**By Agent**:
- data-oracle: 12 items
- infra-config-reviewer: 11 items
- aster-fullstack-architect: 9 items
- ml-architecture-expert: 8 items
- production-incident-responder: 6 items
- ui-perfection-doer: 5 items

**Target for ITERATION 2**: Complete all P0 items (10) + as many P1 items as possible

---

## ITERATION 2 FOCUS

Based on priority and user requirements, ITERATION 2 will focus on:

1. **Infrastructure Security** (P0-1 through P0-6)
2. **Database Production Readiness** (P0-7, P0-9)
3. **Neon → Postgres OLD Replication** (P0-10) - **END-TO-END delivery required**
4. **Critical API Fixes** (P0-8)
5. **Performance Optimization** (P1-5, P1-6, P1-7)

All deliverables MUST follow **RULE 12: END-TO-END DELIVERY** - no isolated components.

---

**STATUS**: Ready for ITERATION 2 DISCOVERY phase
