# MantisNXT System Architecture

## System Stabilization Architecture

### Resource Management
- **Process Management**: Automated cleanup of duplicate dev servers
- **Memory Monitoring**: Real-time memory usage tracking with emergency cleanup
- **Port Management**: Automated port conflict resolution
- **Connection Pooling**: Database connection pool optimization

### Health Monitoring
- **Database Health**: Connection testing and pool status monitoring
- **Dev Server Health**: HTTP endpoint availability checking
- **Resource Health**: CPU and memory usage monitoring
- **Port Health**: Network port availability monitoring

### Recovery Mechanisms
- **Automatic Cleanup**: Orphaned process detection and termination
- **Emergency Procedures**: High resource usage mitigation
- **Health Endpoints**: RESTful health check APIs
- **Process Registry**: Tracked process management

### Database Architecture Separation

#### Current Structure:
```
lib/database/                    # Legacy compatibility layer
├── connection.ts               # Re-exports from unified-connection
├── unified-connection.ts       # Uses enterprise-connection-manager
└── enterprise-connection-manager.ts  # Core implementation

src/lib/database/               # Application-specific implementation
├── connection.ts              # Direct pool implementation
└── connection-resolver.ts     # Environment-based resolution
```

#### Recommended Consolidation:
```
lib/database/                   # Core database infrastructure
├── enterprise-connection-manager.ts  # Main connection manager
├── connection-pool.ts         # Pool management
├── health-monitor.ts          # Database health monitoring
└── migration-manager.ts       # Schema management

src/lib/database/              # Application interface
├── index.ts                   # Main export interface
├── queries/                   # Application queries
└── types/                     # Database types
```

### System Recovery Procedures

1. **Process Cleanup**: Kill duplicate dev servers and orphaned processes
2. **Resource Recovery**: Memory cleanup and garbage collection
3. **Connection Reset**: Database pool recreation and port cleanup
4. **Health Restoration**: Service restart and health verification

### Monitoring Intervals
- Health checks: Every 30 seconds
- Resource monitoring: Every 10 seconds
- Emergency thresholds: Memory > 90%, CPU > 95%

### API Endpoints
- `GET /api/health/system` - Overall system health
- `GET /api/health/database` - Database connectivity
- `GET /api/health/resources` - Resource usage

### NPM Scripts
- `npm run stabilize` - Complete system setup
- `npm run stabilize:cleanup` - Clean duplicate processes
- `npm run stabilize:monitor` - Start health monitoring
- `npm run stabilize:health` - Check system health
- `npm run stabilize:emergency` - Emergency cleanup

## Process Management Strategy

### Duplicate Process Detection
The system automatically identifies and eliminates duplicate development processes by:

1. **Port Scanning**: Checking for processes using development ports (3000-3003, 5432)
2. **Process Analysis**: Examining Node.js processes for legitimacy
3. **Command Line Inspection**: Verifying process purposes through command line arguments
4. **Parent Process Validation**: Ensuring processes have valid parent relationships

### Resource Contention Resolution

#### Before Stabilization:
- Multiple dev server instances competing for resources
- Connection pool exhaustion from duplicate database connections
- Memory leaks from orphaned processes
- Port conflicts causing service failures

#### After Stabilization:
- Single managed dev server instance
- Optimized connection pooling with health monitoring
- Automatic cleanup of orphaned processes
- Clear port allocation and monitoring

### Health Check Architecture

```typescript
interface SystemHealth {
  timestamp: string;
  database: {
    healthy: boolean;
    poolStatus: ConnectionPoolStatus;
    error?: string;
  };
  devServer: {
    healthy: boolean;
    status: string;
    error?: string;
  };
  resources: {
    memory: number;
    cpu: number;
    error?: string;
  };
  ports: {
    [port: number]: {
      listening: boolean;
      connections: number;
    };
  };
}
```

### Database Connection Management

#### Enterprise Connection Manager Features:
- **Connection Pooling**: Configurable pool size with monitoring
- **Health Checks**: Automatic connection validation
- **Failover Support**: Graceful handling of connection failures
- **Resource Tracking**: Memory and connection usage monitoring

#### Separation of Concerns:
- `lib/database/`: Core infrastructure and connection management
- `src/lib/database/`: Application-specific database interface
- Health monitoring integrated across both layers

### System Recovery Mechanisms

#### Automatic Recovery:
1. **Process Resurrection**: Restart failed critical processes
2. **Connection Recovery**: Recreate failed database connections
3. **Resource Cleanup**: Free memory and clear caches
4. **Service Validation**: Verify all services are operational

#### Manual Recovery:
- Emergency cleanup scripts for critical situations
- Health check endpoints for manual verification
- Resource monitoring tools for performance analysis

Generated: ${new Date().toISOString()}