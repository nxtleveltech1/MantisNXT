# ITERATION 2 DEVELOPMENT PHASE PLANNING

**Phase**: DEVELOPMENT (Implement P0 ADRs)
**Planning Tool**: sequential-thinking MCP
**Timestamp**: 2025-10-09
**Planning Thoughts**: 6

---

## THOUGHT 1/6: P0 ADR Inventory from DESIGN Phase

From DESIGN reports, identified **14 P0 ADRs** across all 6 agents:

### production-incident-responder (3 P0 ADRs):
- **ADR-1**: External Error Monitoring (Sentry integration) - P0
- **ADR-2**: API Rate Limiting (middleware-based) - P0
- **ADR-3**: Circuit Breakers (Opossum library) - P0

### aster-fullstack-architect (2 P0 ADRs):
- **ADR-1**: Migration File Rewrite (BIGINT-first strategy) - P0 CRITICAL
- **ADR-2**: API Schema Contract Enforcement (direct core.* queries) - P0

### data-oracle (2 P0 ADRs):
- **ADR-1**: Logical Replication Configuration (Neon → Postgres OLD) - P0 CRITICAL
- **ADR-4**: Missing Table Creation (purchase_orders) - P0

### infra-config-reviewer (3 P0 ADRs):
- **ADR-1**: Credential Rotation Protocol (immediate rotation + git cleaning) - P0 CRITICAL
- **ADR-2**: Secret Management (environment variables + .gitignore) - P0 CRITICAL
- **ADR-3**: Connection Pool Sizing (5 connections for serverless) - P0

### ui-perfection-doer (2 P0 ADRs):
- **ADR-1**: Error Boundary Hierarchy (3-tier implementation) - P0
- **ADR-6**: React Query Integration (replace native fetch) - P0

### ml-architecture-expert (2 P0 ADRs):
- **ADR-1**: Cache Integration Rollout (phased 4-week rollout) - P0
- **ADR-6**: Cache Invalidation Strategy (event-driven) - P0

**Total**: 14 P0 ADRs requiring implementation with tests, evidence, and documentation.

---

## THOUGHT 2/6: Implementation Order and Dependencies

Established 5-tier dependency hierarchy for sequential execution:

### TIER 1 - SECURITY FOUNDATION (Execute First)
**Why first**: Active security vulnerabilities block all other work.

1. **infra-config-reviewer ADR-1**: Credential Rotation Protocol
   - Impact: Active security vulnerability (credentials in git)
   - Dependencies: None
   - Blocks: All database operations until resolved

2. **infra-config-reviewer ADR-2**: Secret Management
   - Impact: Required for all database connections
   - Dependencies: ADR-1 completion
   - Enables: Safe configuration for all agents

### TIER 2 - DATABASE FOUNDATION (Infrastructure Layer)
**Why second**: Schema integrity required before application changes.

3. **aster-fullstack-architect ADR-1**: Migration File Rewrite (BIGINT-first)
   - Impact: Current migrations unexecutable
   - Dependencies: Credential rotation complete
   - Blocks: All schema-dependent work

4. **data-oracle ADR-4**: Missing Table Creation (purchase_orders)
   - Impact: Schema completeness
   - Dependencies: Migration rewrite complete
   - Enables: Replication setup

5. **data-oracle ADR-1**: Logical Replication Configuration
   - Impact: P0-10 requirement (data redundancy)
   - Dependencies: Schema complete (items 3-4)
   - Enables: Production-ready database infrastructure

6. **infra-config-reviewer ADR-3**: Connection Pool Sizing
   - Impact: Performance optimization for serverless
   - Dependencies: Schema and replication stable
   - Enables: Optimal database performance

### TIER 3 - APPLICATION RESILIENCE (Service Layer)
**Why third**: Error monitoring and API protection required before frontend work.

7. **production-incident-responder ADR-1**: Sentry Integration
   - Impact: Error visibility for all subsequent work
   - Dependencies: Credential management complete
   - Enables: Error tracking for frontend and backend

8. **production-incident-responder ADR-2**: API Rate Limiting
   - Impact: API protection
   - Dependencies: Error monitoring active
   - Enables: Protected API endpoints

9. **production-incident-responder ADR-3**: Circuit Breakers
   - Impact: Resilience patterns
   - Dependencies: Rate limiting established
   - Enables: Fault-tolerant service layer

10. **aster-fullstack-architect ADR-2**: API Schema Contract Enforcement
    - Impact: Query correctness
    - Dependencies: Schema migrations complete
    - Enables: Type-safe API layer

### TIER 4 - FRONTEND INFRASTRUCTURE (UI Layer)
**Why fourth**: Frontend improvements require backend resilience in place.

11. **ui-perfection-doer ADR-1**: Error Boundary Hierarchy
    - Impact: 43 pages, 0% → 100% error coverage
    - Dependencies: Sentry integration complete
    - Enables: User-facing error handling

12. **ui-perfection-doer ADR-6**: React Query Integration
    - Impact: Data fetching standardization
    - Dependencies: Error boundaries established
    - Enables: Efficient data management

### TIER 5 - PERFORMANCE OPTIMIZATION (Enhancement Layer)
**Why last**: Performance enhancements require stable foundation.

13. **ml-architecture-expert ADR-6**: Cache Invalidation Strategy
    - Impact: Foundation for cache system
    - Dependencies: React Query integration complete
    - Enables: Cache integration rollout

14. **ml-architecture-expert ADR-1**: Cache Integration Rollout
    - Impact: 70-90% response time improvement
    - Dependencies: Invalidation strategy implemented
    - Delivers: Final performance target

**Implementation Order**: 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 → 10 → 11 → 12 → 13 → 14

---

## THOUGHT 3/6: Agent Responsibilities and Deliverable Specifications

Each agent must deliver complete implementations with evidence-based validation.

### production-incident-responder (3 implementations)

**ADR-1: Sentry Integration**
- Deliverables: Sentry configuration, middleware integration, error boundary connection
- Tests: Error capture scenarios, source map upload verification
- Evidence: Sentry dashboard screenshots, error tracking logs

**ADR-2: Rate Limiting Middleware**
- Deliverables: Redis integration, rate limiting middleware, API route protection
- Tests: Rate limit enforcement, 429 response handling, Redis connection tests
- Evidence: Rate limit test results, Redis metrics

**ADR-3: Circuit Breakers**
- Deliverables: Opossum configuration, circuit breaker wrappers, service integration
- Tests: Circuit state transitions, failure thresholds, auto-recovery
- Evidence: Circuit breaker logs, state transition metrics

### aster-fullstack-architect (2 implementations)

**ADR-1: Migration File Rewrite**
- Deliverables: Rewritten migrations (001, 002) with BIGINT-first, rollback scripts
- Tests: Migration execution tests, schema validation, rollback verification
- Evidence: Migration success logs, schema comparison reports

**ADR-2: API Schema Contract Enforcement**
- Deliverables: Validation middleware, schema contract definitions, query pattern updates
- Tests: API contract validation tests, schema enforcement tests
- Evidence: API test coverage reports, schema violation logs

### data-oracle (2 implementations)

**ADR-1: Logical Replication Setup**
- Deliverables: Publication/subscription configuration, replication scripts, monitoring queries
- Tests: Replication lag tests, data consistency validation, failover tests
- Evidence: Replication status queries, data sync validation reports

**ADR-4: purchase_orders Table Creation**
- Deliverables: Table migration, relationships, indexes, constraints
- Tests: Table structure validation, relationship integrity tests
- Evidence: Schema verification, table structure reports

### infra-config-reviewer (3 implementations)

**ADR-1: Credential Rotation Protocol**
- Deliverables: New credential generation, git history cleaning, rotation scripts
- Tests: Credential security tests, git history verification
- Evidence: Git history audit, credential strength validation

**ADR-2: Secret Management**
- Deliverables: .env.example template, .gitignore updates, config loader module
- Tests: Configuration loading tests, .gitignore effectiveness tests
- Evidence: .gitignore verification, environment variable loading tests

**ADR-3: Connection Pool Configuration**
- Deliverables: Pool size optimization (5 connections), timeout settings
- Tests: Connection pool stress tests, timeout handling tests
- Evidence: Connection pool metrics, performance benchmarks

### ui-perfection-doer (2 implementations)

**ADR-1: Error Boundary Hierarchy**
- Deliverables: Global boundary, page-level boundaries, component-level boundaries, Sentry integration
- Tests: Error boundary rendering tests, error propagation tests
- Evidence: Error boundary coverage report (43 pages), fallback UI screenshots

**ADR-6: React Query Integration**
- Deliverables: React Query provider, query hooks, cache configuration, error handling
- Tests: Query hook tests, cache invalidation tests, error handling tests
- Evidence: React Query DevTools screenshots, cache hit rate metrics

### ml-architecture-expert (2 implementations)

**ADR-6: Cache Invalidation Strategy**
- Deliverables: Event-driven invalidation system, webhook handlers, invalidation patterns
- Tests: Cache invalidation tests, event handling tests, consistency tests
- Evidence: Cache invalidation logs, consistency validation results

**ADR-1: Cache Integration Rollout (Phase 1)**
- Deliverables: Dashboard metrics caching, inventory list caching, monitoring, rollback plan
- Tests: Cache hit/miss ratio tests, performance benchmarks
- Evidence: Before/after response time comparisons, cache hit rate analytics

**Total Deliverables**: 14 P0 implementations, 14 test suites, 14 evidence packages

---

## THOUGHT 4/6: Constraints and Risk Management

### Technical Constraints

**Database State**:
- Production Neon database is live with active data
- Constraint: Cannot execute destructive migrations on production
- Mitigation: Use Neon branching for migration testing before main branch application

**Git History**:
- .env.local and .claude/mcp-config.json tracked with credentials
- Constraint: Must clean git history without losing legitimate commits
- Mitigation: Use BFG Repo-Cleaner with careful file targeting

**Active Users**:
- MantisNXT may have active users during implementation
- Constraint: Zero-downtime deployment required
- Mitigation: Feature flags, gradual rollout, backward compatibility

**Dependency Order**:
- 14 P0 items with strict dependencies (Tier 1 → Tier 5)
- Constraint: Cannot parallelize within same agent if dependencies exist
- Mitigation: Execute in defined tier order, validate each tier before proceeding

### Resource Constraints

**Token Budget**:
- Current usage: ~71K tokens (35.5% of 200K budget)
- Remaining: ~129K tokens
- Constraint: Must manage context efficiently
- Mitigation: Write reports to disk immediately, avoid re-reading large files

**MCP Tool Availability**:
- Available tools: neon, postgres, sequential-thinking, chrome-devtools, playwright, fs
- Constraint: Respect tool usage guidelines
- Mitigation: Use appropriate tool for each task (e.g., neon for migrations, fs for file operations)

### Quality Constraints

**Test Coverage**:
- All P0 implementations must have tests
- Constraint: No partial implementations allowed (RULE: Implementation Completeness)
- Mitigation: Each agent delivers tests + evidence alongside code

**Evidence-Based Validation**:
- All claims must be verifiable
- Constraint: No subjective "looks good" assessments
- Mitigation: Screenshots, logs, test results, metrics for each deliverable

### Risk Assessment

**HIGH RISK**:
- Credential rotation (ADR-1): Potential lockout if credentials fail
- Migration rewrite (ADR-1): Schema corruption if executed incorrectly

**MEDIUM RISK**:
- Replication setup (ADR-1): Data loss if misconfigured
- Connection pool sizing (ADR-3): Performance degradation if incorrect

**LOW RISK**:
- Error monitoring: Additive changes only
- UI improvements: Isolated frontend changes

---

## THOUGHT 5/6: Success Criteria and Validation Gates

### Phase Success Criteria

1. All 14 P0 ADRs implemented with working code
2. Test coverage ≥80% for new implementations
3. Zero breaking changes to existing functionality
4. All implementations validated with evidence (logs, screenshots, metrics)
5. Documentation updated (README, inline comments, migration guides)
6. Compliance-enforcer validation passes 10/10 checks

### Per-ADR Acceptance Criteria

**TIER 1 - Security**:
- ADR-1 (Credential Rotation): New credentials generated, git history clean, no old credentials in codebase
- ADR-2 (Secret Management): .env.local in .gitignore, .env.example created, config module working

**TIER 2 - Database**:
- ADR-1 (Migration Rewrite): Migrations executable on Neon branch, schema matches production
- ADR-4 (purchase_orders): Table created with all relationships, indexes, constraints
- ADR-1 (Replication): Subscription active, replication lag <5s, data consistency 100%
- ADR-3 (Connection Pool): Pool size = 5, connections stable, no timeout errors

**TIER 3 - Application Resilience**:
- ADR-1 (Sentry): Errors captured, source maps uploaded, Sentry dashboard active
- ADR-2 (Rate Limiting): Rate limits enforced, Redis operational, 429 responses working
- ADR-3 (Circuit Breakers): Circuit opens on failure, auto-recovery working, metrics tracked
- ADR-2 (Schema Contracts): API queries use core.* schema, validation middleware active

**TIER 4 - Frontend**:
- ADR-1 (Error Boundaries): 43 pages covered, errors caught and logged, fallback UI renders
- ADR-6 (React Query): All data fetching uses React Query, cache working, DevTools enabled

**TIER 5 - Performance**:
- ADR-6 (Cache Invalidation): Events trigger invalidation, cache stays consistent, no stale data
- ADR-1 (Cache Rollout): Phase 1 endpoints cached, response time reduced 70-90%, rollback tested

### Validation Gates

- **After Tier 1**: Run security audit, verify no credentials in git
- **After Tier 2**: Run migration tests on Neon branch, verify replication working
- **After Tier 3**: Run API tests, verify error monitoring capturing issues
- **After Tier 4**: Run UI tests, verify error boundaries catching errors
- **After Tier 5**: Run performance benchmarks, verify cache improvements
- **Final**: Compliance-enforcer validation (10 checks)

---

## THOUGHT 6/6: Execution Approach and Deployment Strategy

### Parallel Deployment Strategy (RULE 1.3 Compliance)

Deploy all 6 agents in **ONE message** with **6 Task calls**:
- Each agent receives: specific P0 ADRs, tier dependencies, acceptance criteria
- Agents work independently on their implementations
- Reports written to disk immediately after completion

### Agent Deployment Prompts

**production-incident-responder**:
```
Implement 3 P0 ADRs from DESIGN phase:
1. ADR-1: Sentry integration (external error monitoring)
2. ADR-2: Rate limiting middleware (Redis-based)
3. ADR-3: Circuit breakers (Opossum library)

Dependencies: Credential management complete (Tier 1)
Deliverables: Working code + tests + evidence (Sentry dashboard, rate limit logs, circuit metrics)
Tier: 3 (Application Resilience)
```

**aster-fullstack-architect**:
```
Implement 2 P0 ADRs from DESIGN phase:
1. ADR-1: Migration file rewrite (BIGINT-first strategy, fix UUID mismatch)
2. ADR-2: API schema contract enforcement (direct core.* queries)

Dependencies: Credential management complete (Tier 1)
Deliverables: Rewritten migrations + validation middleware + tests + evidence
Tier: 2 (Database Foundation)
```

**data-oracle**:
```
Implement 2 P0 ADRs from DESIGN phase:
1. ADR-1: Logical replication setup (Neon → Postgres OLD)
2. ADR-4: purchase_orders table creation (missing schema)

Dependencies: Migration rewrite complete (Tier 2)
Deliverables: Replication config + table migration + monitoring + tests + evidence
Tier: 2 (Database Foundation)
```

**infra-config-reviewer**:
```
Implement 3 P0 ADRs from DESIGN phase:
1. ADR-1: Credential rotation protocol (immediate rotation + git cleaning)
2. ADR-2: Secret management (environment variables + .gitignore)
3. ADR-3: Connection pool sizing (5 connections for serverless optimization)

Dependencies: None (Tier 1 foundation)
Deliverables: Rotation scripts + .env config + pool config + tests + evidence
Tier: 1 (Security Foundation)
```

**ui-perfection-doer**:
```
Implement 2 P0 ADRs from DESIGN phase:
1. ADR-1: Error boundary hierarchy (3-tier: global, page, component)
2. ADR-6: React Query integration (replace native fetch)

Dependencies: Sentry integration complete (Tier 3)
Deliverables: Error boundaries (43 pages) + React Query setup + tests + evidence
Tier: 4 (Frontend Infrastructure)
```

**ml-architecture-expert**:
```
Implement 2 P0 ADRs from DESIGN phase:
1. ADR-6: Cache invalidation strategy (event-driven)
2. ADR-1: Cache integration rollout (Phase 1: dashboard metrics, inventory lists)

Dependencies: React Query integration complete (Tier 4)
Deliverables: Invalidation system + cached endpoints + monitoring + tests + evidence
Tier: 5 (Performance Optimization)
```

### Post-Deployment Workflow

1. All 6 agents complete and return implementation reports
2. Write each report to `ITERATION_2_DEVELOPMENT_[agent-name].md` (6 files)
3. Deploy compliance-enforcer for validation (10 checks)
4. If validation passes (10/10): proceed to DELIVERY phase
5. If validation fails: analyze failures, remediate, re-validate

### Quality Assurance Standards

- Each agent must provide **evidence** (not just code)
- No subjective claims ("looks good", "should work")
- Objective validation: test results, logs, screenshots, metrics
- Compliance check: Implementation Completeness rule (no TODOs, no mocks, no stubs)

---

## EXECUTION SUMMARY

**Planning Complete**: DEVELOPMENT phase execution plan ready
**Total P0 ADRs**: 14 implementations across 6 agents
**Implementation Tiers**: 5 tiers with strict dependency management
**Validation Gates**: 6 tier-based gates + final compliance check
**Success Criteria**: 14 working implementations + tests + evidence + 10/10 compliance

**Next Step**: Deploy all 6 agents in parallel (ONE message, 6 Task calls) following RULE 1.3.
