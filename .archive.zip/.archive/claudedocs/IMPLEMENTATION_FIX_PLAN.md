# MantisNXT System Fix Implementation Plan

**Date**: September 26, 2025
**Priority**: CRITICAL - System Stability Recovery
**Estimated Implementation Time**: 24-72 hours

## Priority Classification

### 🔴 CRITICAL (Deploy within 24 hours)
- Database connection unification
- API endpoint compatibility fixes
- Connection pool standardization

### 🟡 HIGH (Deploy within 72 hours)
- Build system optimization
- Environment configuration cleanup
- Missing API endpoints creation

### 🟢 MEDIUM (Deploy within 1 week)
- Monitoring implementation
- Documentation updates
- Automated testing setup

---

## PHASE 1: CRITICAL FIXES (24 Hour Timeline)

### Fix 1.1: Database Connection Unification
**Problem**: Two conflicting database connection systems
**Impact**: Connection timeouts, pool exhaustion
**Solution**: Consolidate to single connection manager

#### Implementation Steps:
1. **Update all imports to use unified connection**
   ```typescript
   // BEFORE (conflicting imports)
   import { pool } from '@/lib/database/connection'
   import { db } from 'src/lib/database.ts'

   // AFTER (unified import)
   import { pool, db } from '@/lib/database/connection'
   ```

2. **Remove duplicate database.ts file**
   - Archive `src/lib/database.ts` as backup
   - Update all references to use `lib/database/connection.ts`

3. **Environment variable integration**
   ```typescript
   // Update connection.ts to use env vars with fallbacks
   const dbConfig = {
     user: process.env.DB_USER || "nxtdb_admin",
     password: process.env.DB_PASSWORD || "P@33w0rd-1",
     host: process.env.DB_HOST || "62.169.20.53",
     port: parseInt(process.env.DB_PORT || "6600"),
     // ... existing config
   }
   ```

#### Files to Modify:
- `lib/database/connection.ts` - Add environment variable support
- All API routes importing from `src/lib/database.ts`
- Frontend hooks and components using database connections

#### Validation:
- [ ] All API routes use same connection pool
- [ ] Connection pool metrics show single instance
- [ ] Database timeout errors eliminated

### Fix 1.2: API Endpoint Compatibility
**Problem**: Frontend expects different API paths
**Impact**: 404 errors, failed data loading
**Solution**: Create compatibility endpoints and update frontend

#### Implementation Steps:
1. **Create missing API compatibility routes**
   ```typescript
   // Create /api/dashboard_metrics/route.ts
   export { GET } from '../analytics/dashboard/route'

   // Create /api/inventory_items/route.ts
   export { GET } from '../inventory/items/route'
   ```

2. **Update WebSocket table references**
   ```typescript
   // In useRealTimeData.ts - Update table mapping
   const tableEndpointMap = {
     'dashboard_metrics': 'analytics/dashboard',
     'inventory_items': 'inventory/items',
     'suppliers': 'suppliers'
   }
   ```

3. **Standardize API response formats**
   - Ensure all endpoints return consistent `{ success, data, error }` format
   - Add pagination metadata where missing

#### Files to Create:
- `src/app/api/dashboard_metrics/route.ts`
- `src/app/api/inventory_items/route.ts`

#### Files to Modify:
- `src/hooks/useRealTimeData.ts`
- All API routes to standardize response format

#### Validation:
- [ ] Frontend dashboard loads without 404 errors
- [ ] Inventory page displays data correctly
- [ ] WebSocket connections establish successfully

### Fix 1.3: Connection Pool Standardization
**Problem**: "pool.connect is not a function" errors
**Impact**: Random API failures
**Solution**: Ensure consistent pool usage patterns

#### Implementation Steps:
1. **Audit all pool.connect() calls**
   ```bash
   grep -r "pool\.connect" src/ --include="*.ts" --include="*.tsx"
   ```

2. **Standardize connection patterns**
   ```typescript
   // BEFORE (inconsistent)
   const client = await pool.connect()
   const result = await pool.query(sql, params)

   // AFTER (consistent)
   import { query } from '@/lib/database/connection'
   const result = await query(sql, params)
   ```

3. **Update error handling**
   - Use circuit breaker pattern consistently
   - Add connection retry logic
   - Implement proper client.release() in all finally blocks

#### Files to Modify:
- All API routes with direct pool usage
- Database connection helper functions
- Error handling middleware

#### Validation:
- [ ] Zero "pool.connect is not a function" errors
- [ ] Connection pool utilization < 80%
- [ ] All database connections properly released

---

## PHASE 2: HIGH PRIORITY FIXES (72 Hour Timeline)

### Fix 2.1: Build System Optimization
**Problem**: Webpack module loading errors
**Impact**: Build failures, runtime errors
**Solution**: Clear cache and optimize webpack config

#### Implementation Steps:
1. **Clear Next.js cache completely**
   ```bash
   rm -rf .next
   rm -rf node_modules/.cache
   npm run build
   ```

2. **Update webpack configuration** (ALREADY IMPLEMENTED)
   - Filesystem cache for production
   - Memory cache for development
   - Proper module resolution aliases
   - PostgreSQL externals configuration

3. **Build validation**
   - Ensure all routes compile successfully
   - Verify static generation works
   - Test production build startup

#### Validation:
- [ ] Clean build completes without errors
- [ ] All API routes accessible in production
- [ ] No webpack module resolution errors

### Fix 2.2: Environment Configuration Cleanup
**Problem**: Configuration mismatches
**Impact**: Different behavior across environments
**Solution**: Align all configuration sources

#### Implementation Steps:
1. **Update .env.local values**
   ```env
   # Align with actual connection.ts values
   DB_POOL_CONNECTION_TIMEOUT=8000
   DB_POOL_IDLE_TIMEOUT=45000
   DB_POOL_ACQUIRE_TIMEOUT=15000
   ```

2. **Remove hardcoded credentials**
   - Move sensitive data to environment variables
   - Add environment variable validation
   - Create .env.example with all required variables

3. **Environment validation**
   ```typescript
   // Add to startup
   const requiredEnvVars = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME']
   requiredEnvVars.forEach(envVar => {
     if (!process.env[envVar]) {
       console.error(`Missing required environment variable: ${envVar}`)
     }
   })
   ```

#### Files to Modify:
- `.env.local`
- `lib/database/connection.ts`
- Add `.env.example`

#### Validation:
- [ ] All environments use consistent configuration
- [ ] No hardcoded credentials in source code
- [ ] Environment validation passes on startup

### Fix 2.3: Missing API Endpoints Creation
**Problem**: Some frontend features expect non-existent endpoints
**Impact**: Incomplete functionality
**Solution**: Create missing endpoints with proper implementation

#### Implementation Steps:
1. **Health check endpoints**
   ```typescript
   // /api/health/complete/route.ts
   export async function GET() {
     const checks = await Promise.all([
       testDatabaseConnection(),
       checkMemoryUsage(),
       validateEnvironment()
     ])
     return NextResponse.json({ status: 'healthy', checks })
   }
   ```

2. **Real-time status endpoints**
   ```typescript
   // /api/status/realtime/route.ts
   export async function GET() {
     return NextResponse.json({
       websocketConnections: getActiveConnections(),
       databasePool: pool.getStatus(),
       systemMetrics: await getSystemMetrics()
     })
   }
   ```

#### Files to Create:
- `src/app/api/health/complete/route.ts`
- `src/app/api/status/realtime/route.ts`
- `src/app/api/monitoring/connections/route.ts`

#### Validation:
- [ ] All health check endpoints respond correctly
- [ ] Real-time status provides accurate metrics
- [ ] Monitoring endpoints accessible

---

## PHASE 3: MEDIUM PRIORITY IMPROVEMENTS (1 Week Timeline)

### Fix 3.1: Monitoring Implementation
**Goal**: Proactive system health monitoring
**Components**: Database monitoring, API performance tracking, error alerting

#### Implementation:
1. **Connection pool monitoring dashboard**
2. **API response time tracking**
3. **Error rate alerting system**
4. **Real-time system health display**

### Fix 3.2: Automated Testing Suite
**Goal**: Prevent regression of fixes
**Components**: API endpoint tests, database connection tests, integration tests

#### Implementation:
1. **Database connection test suite**
2. **API endpoint contract testing**
3. **Frontend/backend integration tests**
4. **Performance regression testing**

### Fix 3.3: Documentation Updates
**Goal**: Maintain accurate system documentation
**Components**: API documentation, architecture diagrams, troubleshooting guides

#### Implementation:
1. **API endpoint documentation generation**
2. **Database schema documentation**
3. **System architecture diagrams**
4. **Troubleshooting runbooks**

---

## Implementation Checklist

### Pre-Implementation (30 minutes)
- [ ] Create backup of current system state
- [ ] Document current API response times
- [ ] Export current database pool metrics
- [ ] Verify test environment setup

### Phase 1 Implementation (8-12 hours)
- [ ] Fix 1.1: Database connection unification
- [ ] Fix 1.2: API endpoint compatibility
- [ ] Fix 1.3: Connection pool standardization
- [ ] Validate all Phase 1 fixes working

### Phase 1 Validation (2-4 hours)
- [ ] All API endpoints respond successfully
- [ ] Database connection errors eliminated
- [ ] Frontend loads all data correctly
- [ ] Connection pool stable under load

### Phase 2 Implementation (8-16 hours)
- [ ] Fix 2.1: Build system optimization
- [ ] Fix 2.2: Environment configuration cleanup
- [ ] Fix 2.3: Missing API endpoints creation
- [ ] Validate all Phase 2 fixes working

### Phase 2 Validation (2-4 hours)
- [ ] Clean builds complete successfully
- [ ] Environment consistency verified
- [ ] All expected endpoints exist
- [ ] Performance metrics improved

## Risk Mitigation

### Rollback Plan
- Database backup before connection changes
- Git commits for each phase completion
- Environment variable backup
- Build artifact preservation

### Monitoring During Implementation
- Real-time connection pool status
- API endpoint availability monitoring
- Error rate tracking
- Performance metric collection

### Success Criteria
- **Database Connection Success**: >98%
- **API Response Time**: <2 seconds average
- **Build Success Rate**: 100%
- **Error Rate**: <1% for critical endpoints

## Post-Implementation

### Immediate Monitoring (24 hours)
- Watch for connection pool exhaustion
- Monitor API error rates
- Verify real-time updates working
- Check build process stability

### Performance Validation (72 hours)
- Measure system performance improvement
- Validate user experience improvements
- Confirm all identified issues resolved
- Document lessons learned

### Long-term Monitoring (1 week)
- Establish baseline performance metrics
- Create alerts for system degradation
- Implement automated health checks
- Plan preventive maintenance schedule

---

**Implementation Status**: READY TO DEPLOY
**Next Action**: Begin Phase 1 implementation immediately
**Owner**: Development Team
**Reviewer**: Technical Lead