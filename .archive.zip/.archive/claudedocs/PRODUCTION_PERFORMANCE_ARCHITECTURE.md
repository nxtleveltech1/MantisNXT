# Production Performance Architecture

## Overview

This document outlines a comprehensive performance optimization strategy for the MantisNXT system in production environment, focusing on handling large-scale supplier data operations, real-time synchronization, and enterprise-grade performance requirements.

## 1. Database Performance Optimization

### 1.1 Advanced Indexing Strategy

```sql
-- High-performance composite indexes for complex queries
-- Execute these in production database

-- Supplier inventory performance index
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_inventory_supplier_performance
ON inventory_items(supplier_id, status, updated_at DESC, stock_qty)
WHERE status = 'active'
INCLUDE (cost_price, name, sku);

-- Price list upload optimization
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_upload_sessions_active
ON upload_sessions(status, created_at DESC, supplier_id)
WHERE status IN ('processing', 'validating', 'importing');

-- Fast supplier lookup with category filtering
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_suppliers_category_performance
ON suppliers(primary_category, status, performance_tier, preferred_supplier)
WHERE status = 'active'
INCLUDE (name, contact_person, email);

-- Inventory stock analysis optimization
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_inventory_stock_analysis
ON inventory_items USING GIN (
  (CASE WHEN stock_qty <= reorder_point THEN 'low_stock'
        WHEN stock_qty = 0 THEN 'out_of_stock'
        WHEN stock_qty > max_stock THEN 'overstocked'
        ELSE 'normal' END)
)
WHERE status = 'active';

-- Multi-column statistics for query optimization
CREATE STATISTICS IF NOT EXISTS inventory_supplier_correlation
ON supplier_id, category, cost_price, stock_qty
FROM inventory_items;

ANALYZE inventory_items;

-- Partial indexes for frequently filtered data
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_products_active_supplier
ON "Product"("supplierId", active, "categoryId", "basePrice")
WHERE active = true;

-- Text search optimization for product names
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_inventory_name_search
ON inventory_items USING gin(to_tsvector('english', name))
WHERE status = 'active';

-- Time-based partitioning indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_stock_movements_time_item
ON stock_movements(created_at DESC, item_id, movement_type)
WHERE created_at >= CURRENT_DATE - INTERVAL '1 year';
```

### 1.2 Query Optimization and Materialized Views

```sql
-- High-performance materialized views for dashboard data
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_supplier_dashboard_metrics AS
SELECT
    s.id as supplier_id,
    s.name as supplier_name,
    s.performance_tier,
    s.primary_category,

    -- Inventory metrics
    COALESCE(inv.total_items, 0) as total_inventory_items,
    COALESCE(inv.total_value, 0) as total_inventory_value,
    COALESCE(inv.low_stock_items, 0) as low_stock_items,
    COALESCE(inv.out_of_stock_items, 0) as out_of_stock_items,
    COALESCE(inv.overstocked_items, 0) as overstocked_items,
    COALESCE(inv.avg_cost_price, 0) as average_item_cost,

    -- Activity metrics
    COALESCE(act.recent_uploads, 0) as recent_file_uploads,
    act.last_upload_date,
    act.last_inventory_update,

    -- Performance indicators
    CASE
        WHEN inv.total_items = 0 THEN 'no_inventory'
        WHEN inv.out_of_stock_items::decimal / inv.total_items > 0.1 THEN 'high_stockouts'
        WHEN inv.low_stock_items::decimal / inv.total_items > 0.2 THEN 'low_stock_warning'
        ELSE 'healthy'
    END as inventory_health_status,

    NOW() as last_updated

FROM suppliers s

-- Inventory aggregations
LEFT JOIN (
    SELECT
        supplier_id,
        COUNT(*) as total_items,
        SUM(stock_qty * cost_price) as total_value,
        COUNT(CASE WHEN stock_qty <= reorder_point AND stock_qty > 0 THEN 1 END) as low_stock_items,
        COUNT(CASE WHEN stock_qty = 0 THEN 1 END) as out_of_stock_items,
        COUNT(CASE WHEN max_stock IS NOT NULL AND stock_qty > max_stock THEN 1 END) as overstocked_items,
        AVG(cost_price) as avg_cost_price,
        MAX(updated_at) as last_inventory_update
    FROM inventory_items
    WHERE status = 'active'
    GROUP BY supplier_id
) inv ON s.id = inv.supplier_id

-- Activity aggregations
LEFT JOIN (
    SELECT
        detected_supplier_id as supplier_id,
        COUNT(*) as recent_uploads,
        MAX(created_at) as last_upload_date,
        MAX(processing_end_time) as last_processing_completion
    FROM file_processing_status
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
        AND status = 'completed'
    GROUP BY detected_supplier_id
) act ON s.id = act.supplier_id

WHERE s.status = 'active';

-- Create index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_supplier_dashboard_supplier_id
ON mv_supplier_dashboard_metrics(supplier_id);

CREATE INDEX IF NOT EXISTS idx_mv_supplier_dashboard_category
ON mv_supplier_dashboard_metrics(primary_category, inventory_health_status);

-- Inventory movements aggregation view
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_inventory_movements_summary AS
SELECT
    ii.id as item_id,
    ii.sku,
    ii.name,
    ii.supplier_id,

    -- Movement statistics (last 90 days)
    COALESCE(moves.total_movements, 0) as movement_count_90d,
    COALESCE(moves.total_inbound, 0) as inbound_quantity_90d,
    COALESCE(moves.total_outbound, 0) as outbound_quantity_90d,
    COALESCE(moves.avg_monthly_usage, 0) as avg_monthly_usage,
    moves.last_movement_date,

    -- Stock turn calculation
    CASE
        WHEN ii.stock_qty > 0 AND moves.avg_monthly_usage > 0 THEN
            moves.avg_monthly_usage * 12 / ii.stock_qty
        ELSE 0
    END as annual_stock_turns,

    -- Reorder recommendations
    CASE
        WHEN ii.stock_qty <= ii.reorder_point THEN 'reorder_now'
        WHEN moves.avg_monthly_usage > 0 AND
             ii.stock_qty / moves.avg_monthly_usage < 1 THEN 'reorder_soon'
        ELSE 'adequate_stock'
    END as reorder_recommendation,

    NOW() as last_updated

FROM inventory_items ii

LEFT JOIN (
    SELECT
        sm.item_id,
        COUNT(*) as total_movements,
        SUM(CASE WHEN sm.movement_type = 'in' THEN sm.quantity ELSE 0 END) as total_inbound,
        SUM(CASE WHEN sm.movement_type = 'out' THEN sm.quantity ELSE 0 END) as total_outbound,
        AVG(CASE WHEN sm.movement_type = 'out' THEN sm.quantity ELSE 0 END) as avg_monthly_usage,
        MAX(sm.created_at) as last_movement_date
    FROM stock_movements sm
    WHERE sm.created_at >= CURRENT_DATE - INTERVAL '90 days'
    GROUP BY sm.item_id
) moves ON ii.id = moves.item_id

WHERE ii.status = 'active';

-- Index for movements summary
CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_movements_summary_item_id
ON mv_inventory_movements_summary(item_id);

CREATE INDEX IF NOT EXISTS idx_mv_movements_summary_supplier
ON mv_inventory_movements_summary(supplier_id, reorder_recommendation);
```

### 1.3 Automated Maintenance and Statistics

```sql
-- Automated vacuum and analyze schedule
CREATE OR REPLACE FUNCTION maintain_performance_tables()
RETURNS void AS $$
BEGIN
    -- Vacuum and analyze high-activity tables
    EXECUTE 'VACUUM ANALYZE inventory_items';
    EXECUTE 'VACUUM ANALYZE stock_movements';
    EXECUTE 'VACUUM ANALYZE upload_sessions';
    EXECUTE 'VACUUM ANALYZE file_processing_status';
    EXECUTE 'VACUUM ANALYZE suppliers';

    -- Refresh materialized views
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_supplier_dashboard_metrics;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_inventory_movements_summary;

    -- Update table statistics
    EXECUTE 'ANALYZE inventory_items';
    EXECUTE 'ANALYZE suppliers';

    -- Log maintenance completion
    INSERT INTO system_maintenance_log (operation, completed_at, notes)
    VALUES ('performance_maintenance', NOW(), 'Automated maintenance completed');

END;
$$ LANGUAGE plpgsql;

-- Schedule maintenance (run via cron or pg_cron extension)
-- SELECT cron.schedule('performance-maintenance', '0 2 * * *', 'SELECT maintain_performance_tables()');
```

## 2. Application-Level Performance Optimization

### 2.1 Advanced Caching Strategy

```typescript
// src/lib/cache/ProductionCacheManager.ts
import Redis from 'ioredis';
import NodeCache from 'node-cache';

interface CacheConfig {
  redis: {
    host: string;
    port: number;
    password?: string;
    db: number;
    maxRetriesPerRequest: 3;
    retryDelayOnFailover: 100;
    keyPrefix: string;
  };
  nodeCache: {
    stdTTL: number;
    checkperiod: number;
    maxKeys: number;
  };
  strategies: {
    supplierData: CacheStrategy;
    inventoryData: CacheStrategy;
    analyticsData: CacheStrategy;
    userSessions: CacheStrategy;
  };
}

interface CacheStrategy {
  ttl: number;
  refreshThreshold: number; // Percentage of TTL when to refresh
  warmupOnMiss: boolean;
  compressionEnabled: boolean;
  tags: string[];
}

export class ProductionCacheManager {
  private redis: Redis;
  private nodeCache: NodeCache;
  private config: CacheConfig;
  private metrics: CacheMetrics;

  constructor(config: CacheConfig) {
    this.config = config;
    this.initializeRedis();
    this.initializeNodeCache();
    this.metrics = new CacheMetrics();
  }

  private initializeRedis(): void {
    this.redis = new Redis({
      ...this.config.redis,
      lazyConnect: true,
      maxRetriesPerRequest: 3,
      retryDelayOnFailover: 100,
      enableOfflineQueue: false,
      // Connection pool settings
      maxLoadingTimeout: 2000,
      connectTimeout: 10000,
      commandTimeout: 5000,
    });

    // Redis event handlers for monitoring
    this.redis.on('connect', () => {
      console.log('✅ Redis connected for caching');
    });

    this.redis.on('error', (error) => {
      console.error('❌ Redis cache error:', error);
      this.metrics.recordError('redis_connection', error);
    });

    this.redis.on('ready', () => {
      console.log('🚀 Redis cache ready for operations');
    });
  }

  // Multi-layer cache retrieval with intelligent fallback
  async get<T>(
    key: string,
    fetcher: () => Promise<T>,
    strategy: CacheStrategy
  ): Promise<T> {
    const startTime = Date.now();
    const fullKey = this.generateKey(key);

    try {
      // Level 1: Node.js memory cache (fastest)
      const nodeData = this.nodeCache.get<T>(fullKey);
      if (nodeData !== undefined) {
        this.metrics.recordHit('node_cache', Date.now() - startTime);
        return nodeData;
      }

      // Level 2: Redis cache (fast)
      const redisData = await this.redis.get(fullKey);
      if (redisData !== null) {
        let parsedData: T;

        if (strategy.compressionEnabled) {
          parsedData = this.decompress(redisData);
        } else {
          parsedData = JSON.parse(redisData);
        }

        // Warm up node cache for next request
        const nodeTtl = Math.min(strategy.ttl / 4, 300); // Max 5 minutes in node cache
        this.nodeCache.set(fullKey, parsedData, nodeTtl);

        this.metrics.recordHit('redis_cache', Date.now() - startTime);

        // Proactive refresh if near expiration
        const ttl = await this.redis.ttl(fullKey);
        if (ttl > 0 && ttl < (strategy.ttl * strategy.refreshThreshold)) {
          this.refreshInBackground(fullKey, fetcher, strategy);
        }

        return parsedData;
      }

      // Level 3: Fetch from source
      const freshData = await fetcher();

      // Cache in both layers
      await this.set(fullKey, freshData, strategy);

      this.metrics.recordMiss('cache_miss', Date.now() - startTime);
      return freshData;

    } catch (error) {
      this.metrics.recordError('cache_get', error);

      // Fallback to direct fetch on cache errors
      console.warn(`Cache error for key ${key}, falling back to direct fetch:`, error);
      return await fetcher();
    }
  }

  async set<T>(key: string, data: T, strategy: CacheStrategy): Promise<void> {
    const fullKey = this.generateKey(key);

    try {
      let serializedData: string;

      if (strategy.compressionEnabled) {
        serializedData = this.compress(data);
      } else {
        serializedData = JSON.stringify(data);
      }

      // Set in Redis with TTL
      await this.redis.setex(fullKey, strategy.ttl, serializedData);

      // Set in node cache with shorter TTL
      const nodeTtl = Math.min(strategy.ttl / 4, 300);
      this.nodeCache.set(fullKey, data, nodeTtl);

      // Add to cache tags for selective invalidation
      if (strategy.tags.length > 0) {
        await this.addToTags(fullKey, strategy.tags);
      }

    } catch (error) {
      this.metrics.recordError('cache_set', error);
      console.error(`Failed to cache data for key ${key}:`, error);
    }
  }

  // Intelligent cache invalidation by tags
  async invalidateByTags(tags: string[]): Promise<void> {
    try {
      const pipeline = this.redis.pipeline();

      for (const tag of tags) {
        const tagKey = `tag:${tag}`;
        const taggedKeys = await this.redis.smembers(tagKey);

        for (const key of taggedKeys) {
          pipeline.del(key);
          this.nodeCache.del(key);
        }

        pipeline.del(tagKey);
      }

      await pipeline.exec();
      console.log(`🗑️  Invalidated cache for tags: ${tags.join(', ')}`);

    } catch (error) {
      this.metrics.recordError('cache_invalidation', error);
      console.error('Cache invalidation failed:', error);
    }
  }

  // Background refresh to prevent cache stampede
  private async refreshInBackground<T>(
    key: string,
    fetcher: () => Promise<T>,
    strategy: CacheStrategy
  ): Promise<void> {
    try {
      const freshData = await fetcher();
      await this.set(key, freshData, strategy);
      console.log(`🔄 Background refresh completed for key: ${key}`);
    } catch (error) {
      console.error(`Background refresh failed for key ${key}:`, error);
    }
  }

  // Compression utilities for large datasets
  private compress<T>(data: T): string {
    const json = JSON.stringify(data);
    // Implement compression (e.g., using zlib or similar)
    return json; // Placeholder - implement actual compression
  }

  private decompress(compressedData: string): any {
    // Implement decompression
    return JSON.parse(compressedData); // Placeholder
  }

  // Cache warming for critical data
  async warmCache(keys: Array<{ key: string, fetcher: () => Promise<any>, strategy: CacheStrategy }>): Promise<void> {
    console.log('🔥 Starting cache warming process...');

    const promises = keys.map(async ({ key, fetcher, strategy }) => {
      try {
        const data = await fetcher();
        await this.set(key, data, strategy);
        return { key, status: 'success' };
      } catch (error) {
        console.error(`Failed to warm cache for key ${key}:`, error);
        return { key, status: 'failed', error };
      }
    });

    const results = await Promise.allSettled(promises);
    const successful = results.filter(r => r.status === 'fulfilled' && r.value.status === 'success').length;

    console.log(`🔥 Cache warming completed: ${successful}/${keys.length} keys warmed`);
  }

  // Cache metrics and monitoring
  getMetrics(): CacheMetricsReport {
    return this.metrics.getReport();
  }

  private generateKey(key: string): string {
    return `${this.config.redis.keyPrefix}:${key}`;
  }
}

// Cache metrics tracking
class CacheMetrics {
  private hits: Map<string, number> = new Map();
  private misses: Map<string, number> = new Map();
  private errors: Map<string, number> = new Map();
  private responseTimes: Map<string, number[]> = new Map();

  recordHit(source: string, responseTime: number): void {
    this.hits.set(source, (this.hits.get(source) || 0) + 1);
    this.recordResponseTime(source, responseTime);
  }

  recordMiss(source: string, responseTime: number): void {
    this.misses.set(source, (this.misses.get(source) || 0) + 1);
    this.recordResponseTime(source, responseTime);
  }

  recordError(operation: string, error: any): void {
    this.errors.set(operation, (this.errors.get(operation) || 0) + 1);
  }

  private recordResponseTime(source: string, time: number): void {
    if (!this.responseTimes.has(source)) {
      this.responseTimes.set(source, []);
    }

    const times = this.responseTimes.get(source)!;
    times.push(time);

    // Keep only last 1000 measurements
    if (times.length > 1000) {
      times.shift();
    }
  }

  getReport(): CacheMetricsReport {
    const report: CacheMetricsReport = {
      hitRates: {},
      avgResponseTimes: {},
      errorCounts: Object.fromEntries(this.errors),
      totalOperations: 0
    };

    // Calculate hit rates
    for (const [source, hits] of this.hits) {
      const misses = this.misses.get(source) || 0;
      const total = hits + misses;
      report.hitRates[source] = total > 0 ? (hits / total) * 100 : 0;
      report.totalOperations += total;
    }

    // Calculate average response times
    for (const [source, times] of this.responseTimes) {
      if (times.length > 0) {
        report.avgResponseTimes[source] = times.reduce((a, b) => a + b) / times.length;
      }
    }

    return report;
  }
}

interface CacheMetricsReport {
  hitRates: Record<string, number>;
  avgResponseTimes: Record<string, number>;
  errorCounts: Record<string, number>;
  totalOperations: number;
}
```

### 2.2 Connection Pool Optimization

```typescript
// src/lib/database/ProductionConnectionManager.ts
import { Pool, PoolConfig, PoolClient } from 'pg';

interface ProductionPoolConfig extends PoolConfig {
  // Connection pool sizing
  min: number;
  max: number;

  // Performance tuning
  acquireTimeoutMillis: number;
  createTimeoutMillis: number;
  destroyTimeoutMillis: number;
  idleTimeoutMillis: number;
  reapIntervalMillis: number;
  createRetryIntervalMillis: number;

  // Health monitoring
  healthCheckIntervalMs: number;
  connectionHealthQuery: string;

  // Load balancing (for read replicas)
  readReplicas?: string[];
  writePreference: 'primary' | 'primary_preferred';
}

export class ProductionConnectionManager {
  private primaryPool: Pool;
  private readPools: Pool[];
  private config: ProductionPoolConfig;
  private healthMetrics: ConnectionMetrics;
  private isHealthy: boolean = true;

  constructor(config: ProductionPoolConfig) {
    this.config = config;
    this.healthMetrics = new ConnectionMetrics();
    this.initializePools();
    this.startHealthMonitoring();
  }

  private initializePools(): void {
    // Primary connection pool (read/write)
    this.primaryPool = new Pool({
      ...this.config,
      // Production-optimized settings
      min: this.config.min || 5,
      max: this.config.max || 20,
      acquireTimeoutMillis: this.config.acquireTimeoutMillis || 30000,
      createTimeoutMillis: this.config.createTimeoutMillis || 30000,
      idleTimeoutMillis: this.config.idleTimeoutMillis || 60000,

      // Connection validation
      query_timeout: 30000,
      statement_timeout: 45000,

      // SSL configuration for production
      ssl: process.env.NODE_ENV === 'production' ? {
        rejectUnauthorized: false // Configure based on your SSL setup
      } : false
    });

    // Read replica pools (if configured)
    this.readPools = [];
    if (this.config.readReplicas) {
      this.readPools = this.config.readReplicas.map(replica =>
        new Pool({
          ...this.config,
          host: replica,
          // Read pools can have different sizing
          min: Math.max(1, this.config.min - 2),
          max: Math.max(5, this.config.max - 5),
        })
      );
    }

    this.setupPoolEventHandlers();
  }

  private setupPoolEventHandlers(): void {
    // Primary pool events
    this.primaryPool.on('connect', (client) => {
      this.healthMetrics.recordConnection('primary', 'connect');
      console.log(`🔗 Primary DB client connected (${this.primaryPool.totalCount} total)`);
    });

    this.primaryPool.on('acquire', (client) => {
      this.healthMetrics.recordConnection('primary', 'acquire');
    });

    this.primaryPool.on('error', (err, client) => {
      this.healthMetrics.recordConnection('primary', 'error');
      console.error('❌ Primary pool error:', err);
      this.isHealthy = false;
    });

    // Read pool events
    this.readPools.forEach((pool, index) => {
      pool.on('connect', (client) => {
        this.healthMetrics.recordConnection(`read_${index}`, 'connect');
      });

      pool.on('error', (err, client) => {
        this.healthMetrics.recordConnection(`read_${index}`, 'error');
        console.error(`❌ Read pool ${index} error:`, err);
      });
    });
  }

  // Intelligent connection routing
  async getConnection(operation: 'read' | 'write' = 'read'): Promise<PoolClient> {
    const startTime = Date.now();

    try {
      let pool: Pool;

      if (operation === 'write' || this.readPools.length === 0) {
        pool = this.primaryPool;
      } else {
        // Load balance across read replicas
        pool = this.selectOptimalReadPool();
      }

      const client = await pool.connect();

      this.healthMetrics.recordAcquisition(
        operation,
        Date.now() - startTime,
        'success'
      );

      return client;
    } catch (error) {
      this.healthMetrics.recordAcquisition(
        operation,
        Date.now() - startTime,
        'failure'
      );
      throw error;
    }
  }

  private selectOptimalReadPool(): Pool {
    if (this.readPools.length === 1) {
      return this.readPools[0];
    }

    // Simple round-robin for now, could implement more sophisticated load balancing
    const poolIndex = Math.floor(Math.random() * this.readPools.length);
    return this.readPools[poolIndex];
  }

  // Execute query with automatic retry and failover
  async executeQuery<T = any>(
    text: string,
    params?: any[],
    operation: 'read' | 'write' = 'read',
    retries: number = 2
  ): Promise<T> {
    let lastError: Error;

    for (let attempt = 0; attempt <= retries; attempt++) {
      const client = await this.getConnection(operation);

      try {
        const result = await client.query(text, params);
        return result;
      } catch (error) {
        lastError = error as Error;
        console.error(`Query attempt ${attempt + 1} failed:`, error);

        // Don't retry on syntax errors or constraint violations
        if (this.shouldNotRetry(error as Error)) {
          throw error;
        }

        // Wait before retry with exponential backoff
        if (attempt < retries) {
          const delay = Math.min(1000 * Math.pow(2, attempt), 5000);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      } finally {
        client.release();
      }
    }

    throw lastError!;
  }

  private shouldNotRetry(error: Error): boolean {
    const nonRetryableErrors = [
      'syntax error',
      'column does not exist',
      'relation does not exist',
      'duplicate key value',
      'violates not-null constraint',
      'violates unique constraint',
      'violates foreign key constraint'
    ];

    return nonRetryableErrors.some(pattern =>
      error.message.toLowerCase().includes(pattern)
    );
  }

  // Health monitoring
  private startHealthMonitoring(): void {
    setInterval(async () => {
      await this.performHealthCheck();
    }, this.config.healthCheckIntervalMs || 30000);
  }

  private async performHealthCheck(): Promise<void> {
    try {
      // Check primary pool
      const client = await this.primaryPool.connect();
      await client.query(this.config.connectionHealthQuery || 'SELECT 1');
      client.release();

      // Check read pools
      const readChecks = this.readPools.map(async (pool, index) => {
        try {
          const client = await pool.connect();
          await client.query('SELECT 1');
          client.release();
          return { index, healthy: true };
        } catch (error) {
          console.error(`Read pool ${index} health check failed:`, error);
          return { index, healthy: false };
        }
      });

      await Promise.all(readChecks);
      this.isHealthy = true;

    } catch (error) {
      console.error('Primary pool health check failed:', error);
      this.isHealthy = false;
    }
  }

  // Graceful shutdown
  async shutdown(): Promise<void> {
    console.log('🛑 Shutting down database connections...');

    try {
      await this.primaryPool.end();

      const readShutdowns = this.readPools.map(pool => pool.end());
      await Promise.all(readShutdowns);

      console.log('✅ Database connections closed gracefully');
    } catch (error) {
      console.error('❌ Error during database shutdown:', error);
    }
  }

  // Metrics and monitoring
  getHealthMetrics(): ConnectionHealthReport {
    return {
      isHealthy: this.isHealthy,
      primaryPool: {
        totalCount: this.primaryPool.totalCount,
        idleCount: this.primaryPool.idleCount,
        waitingCount: this.primaryPool.waitingCount
      },
      readPools: this.readPools.map(pool => ({
        totalCount: pool.totalCount,
        idleCount: pool.idleCount,
        waitingCount: pool.waitingCount
      })),
      metrics: this.healthMetrics.getReport()
    };
  }
}

// Connection metrics tracking
class ConnectionMetrics {
  private connections: Map<string, ConnectionStat[]> = new Map();
  private acquisitions: Map<string, AcquisitionStat[]> = new Map();

  recordConnection(pool: string, event: string): void {
    if (!this.connections.has(pool)) {
      this.connections.set(pool, []);
    }

    this.connections.get(pool)!.push({
      event,
      timestamp: Date.now()
    });

    this.pruneOldMetrics();
  }

  recordAcquisition(operation: string, duration: number, status: string): void {
    if (!this.acquisitions.has(operation)) {
      this.acquisitions.set(operation, []);
    }

    this.acquisitions.get(operation)!.push({
      duration,
      status,
      timestamp: Date.now()
    });

    this.pruneOldMetrics();
  }

  private pruneOldMetrics(): void {
    const cutoff = Date.now() - (24 * 60 * 60 * 1000); // 24 hours

    for (const stats of this.connections.values()) {
      const index = stats.findIndex(stat => stat.timestamp >= cutoff);
      if (index > 0) stats.splice(0, index);
    }

    for (const stats of this.acquisitions.values()) {
      const index = stats.findIndex(stat => stat.timestamp >= cutoff);
      if (index > 0) stats.splice(0, index);
    }
  }

  getReport(): ConnectionMetricsReport {
    // Implementation details for metrics reporting
    return {
      connectionEvents: Object.fromEntries(this.connections),
      acquisitionStats: Object.fromEntries(this.acquisitions)
    };
  }
}

interface ConnectionStat {
  event: string;
  timestamp: number;
}

interface AcquisitionStat {
  duration: number;
  status: string;
  timestamp: number;
}

interface ConnectionHealthReport {
  isHealthy: boolean;
  primaryPool: {
    totalCount: number;
    idleCount: number;
    waitingCount: number;
  };
  readPools: Array<{
    totalCount: number;
    idleCount: number;
    waitingCount: number;
  }>;
  metrics: ConnectionMetricsReport;
}

interface ConnectionMetricsReport {
  connectionEvents: Record<string, ConnectionStat[]>;
  acquisitionStats: Record<string, AcquisitionStat[]>;
}
```

## 3. Real-time Monitoring and Alerting

### 3.1 Comprehensive System Monitoring

```typescript
// src/lib/monitoring/ProductionMonitor.ts
import { EventEmitter } from 'events';

interface MonitoringConfig {
  metrics: {
    collectionInterval: number; // milliseconds
    retentionPeriod: number;    // hours
    aggregationWindows: number[]; // [1m, 5m, 15m, 1h]
  };

  alerts: {
    thresholds: AlertThresholds;
    channels: AlertChannel[];
    suppressionRules: SuppressionRule[];
  };

  performance: {
    responseTimeThresholds: ResponseTimeThresholds;
    errorRateThresholds: ErrorRateThresholds;
    resourceThresholds: ResourceThresholds;
  };
}

interface SystemMetrics {
  timestamp: number;

  // Application metrics
  api: {
    requestCount: number;
    avgResponseTime: number;
    errorRate: number;
    activeConnections: number;
  };

  // Database metrics
  database: {
    connectionCount: number;
    queryCount: number;
    avgQueryTime: number;
    slowQueryCount: number;
    lockWaitTime: number;
  };

  // Cache metrics
  cache: {
    hitRate: number;
    missRate: number;
    avgResponseTime: number;
    memoryUsage: number;
  };

  // Business metrics
  business: {
    filesProcessedPerMinute: number;
    dataQualityScore: number;
    supplierDataFreshness: number;
    inventoryAccuracy: number;
  };

  // System resources
  system: {
    cpuUsage: number;
    memoryUsage: number;
    diskUsage: number;
    networkLatency: number;
  };
}

export class ProductionMonitor extends EventEmitter {
  private config: MonitoringConfig;
  private metrics: SystemMetrics[] = [];
  private alertManager: AlertManager;
  private metricsCollector: MetricsCollector;
  private isMonitoring: boolean = false;

  constructor(config: MonitoringConfig) {
    super();
    this.config = config;
    this.alertManager = new AlertManager(config.alerts);
    this.metricsCollector = new MetricsCollector();
  }

  async startMonitoring(): Promise<void> {
    if (this.isMonitoring) return;

    console.log('📊 Starting production monitoring...');
    this.isMonitoring = true;

    // Start metrics collection
    const collectionInterval = setInterval(async () => {
      try {
        const metrics = await this.collectMetrics();
        this.processMetrics(metrics);
        this.emit('metrics_collected', metrics);
      } catch (error) {
        console.error('Metrics collection failed:', error);
        this.emit('metrics_error', error);
      }
    }, this.config.metrics.collectionInterval);

    // Start alert processing
    this.alertManager.startProcessing();

    // Cleanup old metrics
    const cleanupInterval = setInterval(() => {
      this.cleanupOldMetrics();
    }, 60000); // Every minute

    // Graceful shutdown handler
    process.on('SIGTERM', async () => {
      clearInterval(collectionInterval);
      clearInterval(cleanupInterval);
      await this.stopMonitoring();
    });
  }

  private async collectMetrics(): Promise<SystemMetrics> {
    const timestamp = Date.now();

    // Collect metrics from various sources
    const [apiMetrics, dbMetrics, cacheMetrics, businessMetrics, systemMetrics] =
      await Promise.all([
        this.metricsCollector.collectAPIMetrics(),
        this.metricsCollector.collectDatabaseMetrics(),
        this.metricsCollector.collectCacheMetrics(),
        this.metricsCollector.collectBusinessMetrics(),
        this.metricsCollector.collectSystemMetrics()
      ]);

    return {
      timestamp,
      api: apiMetrics,
      database: dbMetrics,
      cache: cacheMetrics,
      business: businessMetrics,
      system: systemMetrics
    };
  }

  private processMetrics(metrics: SystemMetrics): void {
    // Store metrics
    this.metrics.push(metrics);

    // Check alert conditions
    this.checkAlertConditions(metrics);

    // Emit specific events for different metric types
    this.emitMetricEvents(metrics);
  }

  private checkAlertConditions(metrics: SystemMetrics): void {
    const alerts: Alert[] = [];

    // API performance alerts
    if (metrics.api.avgResponseTime > this.config.performance.responseTimeThresholds.critical) {
      alerts.push({
        type: 'performance',
        severity: 'critical',
        metric: 'api_response_time',
        value: metrics.api.avgResponseTime,
        threshold: this.config.performance.responseTimeThresholds.critical,
        message: `API response time is critically high: ${metrics.api.avgResponseTime}ms`
      });
    }

    if (metrics.api.errorRate > this.config.performance.errorRateThresholds.critical) {
      alerts.push({
        type: 'reliability',
        severity: 'critical',
        metric: 'api_error_rate',
        value: metrics.api.errorRate,
        threshold: this.config.performance.errorRateThresholds.critical,
        message: `API error rate is critically high: ${(metrics.api.errorRate * 100).toFixed(2)}%`
      });
    }

    // Database performance alerts
    if (metrics.database.avgQueryTime > this.config.performance.responseTimeThresholds.database) {
      alerts.push({
        type: 'performance',
        severity: 'warning',
        metric: 'db_query_time',
        value: metrics.database.avgQueryTime,
        threshold: this.config.performance.responseTimeThresholds.database,
        message: `Database query time is elevated: ${metrics.database.avgQueryTime}ms`
      });
    }

    // Business metric alerts
    if (metrics.business.dataQualityScore < this.config.alerts.thresholds.dataQuality) {
      alerts.push({
        type: 'data_quality',
        severity: 'warning',
        metric: 'data_quality_score',
        value: metrics.business.dataQualityScore,
        threshold: this.config.alerts.thresholds.dataQuality,
        message: `Data quality score is below threshold: ${(metrics.business.dataQualityScore * 100).toFixed(1)}%`
      });
    }

    // Resource utilization alerts
    if (metrics.system.cpuUsage > this.config.performance.resourceThresholds.cpu) {
      alerts.push({
        type: 'resource',
        severity: 'warning',
        metric: 'cpu_usage',
        value: metrics.system.cpuUsage,
        threshold: this.config.performance.resourceThresholds.cpu,
        message: `CPU usage is high: ${(metrics.system.cpuUsage * 100).toFixed(1)}%`
      });
    }

    // Process alerts
    alerts.forEach(alert => {
      this.alertManager.processAlert(alert);
    });
  }

  private emitMetricEvents(metrics: SystemMetrics): void {
    // Emit granular events for different components
    this.emit('api_metrics', metrics.api);
    this.emit('database_metrics', metrics.database);
    this.emit('cache_metrics', metrics.cache);
    this.emit('business_metrics', metrics.business);
    this.emit('system_metrics', metrics.system);
  }

  // Get aggregated metrics for dashboards
  getAggregatedMetrics(
    timeRange: number, // milliseconds
    aggregationWindow: number // minutes
  ): AggregatedMetrics {
    const cutoff = Date.now() - timeRange;
    const relevantMetrics = this.metrics.filter(m => m.timestamp >= cutoff);

    if (relevantMetrics.length === 0) {
      return this.getEmptyAggregatedMetrics();
    }

    // Group metrics by time windows
    const windowSize = aggregationWindow * 60 * 1000; // Convert to milliseconds
    const windows = new Map<number, SystemMetrics[]>();

    relevantMetrics.forEach(metric => {
      const windowStart = Math.floor(metric.timestamp / windowSize) * windowSize;
      if (!windows.has(windowStart)) {
        windows.set(windowStart, []);
      }
      windows.get(windowStart)!.push(metric);
    });

    // Calculate aggregations for each window
    const aggregatedWindows = Array.from(windows.entries()).map(([windowStart, windowMetrics]) => {
      return {
        timestamp: windowStart,
        api: this.aggregateAPIMetrics(windowMetrics),
        database: this.aggregateDatabaseMetrics(windowMetrics),
        cache: this.aggregateCacheMetrics(windowMetrics),
        business: this.aggregateBusinessMetrics(windowMetrics),
        system: this.aggregateSystemMetrics(windowMetrics)
      };
    });

    return {
      timeRange,
      aggregationWindow,
      dataPoints: aggregatedWindows.length,
      windows: aggregatedWindows,
      summary: this.calculateSummaryStats(aggregatedWindows)
    };
  }

  private cleanupOldMetrics(): void {
    const cutoff = Date.now() - (this.config.metrics.retentionPeriod * 60 * 60 * 1000);
    this.metrics = this.metrics.filter(m => m.timestamp >= cutoff);
  }

  async stopMonitoring(): Promise<void> {
    this.isMonitoring = false;
    await this.alertManager.stopProcessing();
    console.log('📊 Production monitoring stopped');
  }

  // Health check endpoint data
  getHealthStatus(): HealthStatus {
    const latestMetrics = this.metrics[this.metrics.length - 1];

    if (!latestMetrics) {
      return { status: 'unknown', message: 'No metrics available' };
    }

    const checks = [
      {
        name: 'api_response_time',
        healthy: latestMetrics.api.avgResponseTime < this.config.performance.responseTimeThresholds.warning,
        value: latestMetrics.api.avgResponseTime,
        threshold: this.config.performance.responseTimeThresholds.warning
      },
      {
        name: 'api_error_rate',
        healthy: latestMetrics.api.errorRate < this.config.performance.errorRateThresholds.warning,
        value: latestMetrics.api.errorRate * 100,
        threshold: this.config.performance.errorRateThresholds.warning * 100
      },
      {
        name: 'database_performance',
        healthy: latestMetrics.database.avgQueryTime < this.config.performance.responseTimeThresholds.database,
        value: latestMetrics.database.avgQueryTime,
        threshold: this.config.performance.responseTimeThresholds.database
      },
      {
        name: 'cache_performance',
        healthy: latestMetrics.cache.hitRate > 0.8, // 80% hit rate threshold
        value: latestMetrics.cache.hitRate * 100,
        threshold: 80
      },
      {
        name: 'data_quality',
        healthy: latestMetrics.business.dataQualityScore > this.config.alerts.thresholds.dataQuality,
        value: latestMetrics.business.dataQualityScore * 100,
        threshold: this.config.alerts.thresholds.dataQuality * 100
      }
    ];

    const failedChecks = checks.filter(check => !check.healthy);

    if (failedChecks.length === 0) {
      return {
        status: 'healthy',
        message: 'All systems operational',
        checks: checks
      };
    } else if (failedChecks.some(check =>
      check.name === 'api_error_rate' && check.value > this.config.performance.errorRateThresholds.critical * 100
    )) {
      return {
        status: 'critical',
        message: `Critical issues detected: ${failedChecks.map(c => c.name).join(', ')}`,
        checks: checks
      };
    } else {
      return {
        status: 'degraded',
        message: `Performance issues detected: ${failedChecks.map(c => c.name).join(', ')}`,
        checks: checks
      };
    }
  }
}
```

This production performance architecture provides enterprise-grade optimization for the MantisNXT system, ensuring it can handle large-scale supplier data operations efficiently while maintaining high availability and performance standards.