const { Pool } = require('pg');

const dbConfig = {
  user: "nxtdb_admin",
  password: "P@33w0rd-1",
  host: "62.169.20.53",
  port: 6600,
  database: "nxtprod-db_001",
  ssl: false
};

const pool = new Pool(dbConfig);

async function analyzeSupplierInventoryGaps() {
  try {
    console.log('🔍 SUPPLIER INVENTORY MANAGEMENT GAP ANALYSIS\n');

    // 1. Current Supplier-Inventory Data Structure
    await analyzeCuurentStructure();

    // 2. Sample data to understand current state
    await getSampleData();

    // 3. Identify missing functionality
    await identifyMissingFunctionality();

    // 4. Check existing views and aggregations
    await checkExistingViews();

    // 5. Assess data quality and completeness
    await assessDataQuality();

  } catch (error) {
    console.error('❌ Analysis failed:', error.message);
  } finally {
    await pool.end();
  }
}

async function analyzeCuurentStructure() {
  console.log('=== CURRENT DATA STRUCTURE ===');

  // Check inventory_items with supplier info
  const inventoryWithSuppliers = await pool.query(`
    SELECT
      ii.id,
      ii.name,
      ii.sku,
      ii.supplier_id,
      ii.supplier_sku,
      ii.cost_price,
      ii.stock_qty,
      ii.available_qty,
      s.name as supplier_name,
      s.supplier_code
    FROM inventory_items ii
    LEFT JOIN suppliers s ON ii.supplier_id = s.id
    ORDER BY ii.name
    LIMIT 5
  `);

  console.log('Sample Inventory Items with Supplier Info:');
  inventoryWithSuppliers.rows.forEach(item => {
    console.log(`  📦 ${item.name} (${item.sku})`);
    console.log(`     Supplier: ${item.supplier_name || 'None'} (${item.supplier_code || 'N/A'})`);
    console.log(`     Stock: ${item.stock_qty || 0} | Available: ${item.available_qty || 0}`);
    console.log(`     Cost: R${item.cost_price || 0}\n`);
  });
}

async function getSampleData() {
  console.log('=== DATA SUMMARY ===');

  const queries = [
    {
      name: 'Inventory Items by Supplier Status',
      query: `
        SELECT
          CASE
            WHEN supplier_id IS NOT NULL THEN 'Has Supplier'
            ELSE 'No Supplier'
          END as supplier_status,
          COUNT(*) as count
        FROM inventory_items
        GROUP BY (supplier_id IS NOT NULL)
      `
    },
    {
      name: 'Top Suppliers by Item Count',
      query: `
        SELECT
          s.name as supplier_name,
          s.supplier_code,
          COUNT(ii.id) as item_count,
          SUM(ii.stock_qty * ii.cost_price) as total_value
        FROM suppliers s
        LEFT JOIN inventory_items ii ON s.id = ii.supplier_id
        GROUP BY s.id, s.name, s.supplier_code
        HAVING COUNT(ii.id) > 0
        ORDER BY item_count DESC
      `
    },
    {
      name: 'Stock Value by Supplier',
      query: `
        SELECT
          COALESCE(s.name, 'No Supplier') as supplier_name,
          COUNT(ii.id) as item_count,
          SUM(COALESCE(ii.stock_qty, 0) * COALESCE(ii.cost_price, 0)) as total_stock_value,
          AVG(COALESCE(ii.stock_qty, 0)) as avg_stock_qty
        FROM inventory_items ii
        LEFT JOIN suppliers s ON ii.supplier_id = s.id
        GROUP BY s.id, s.name
        ORDER BY total_stock_value DESC
      `
    }
  ];

  for (const q of queries) {
    console.log(`\n--- ${q.name} ---`);
    try {
      const result = await pool.query(q.query);
      result.rows.forEach((row, index) => {
        console.log(`  ${index + 1}. ${JSON.stringify(row, null, 2)}`);
      });
    } catch (error) {
      console.log(`  Error: ${error.message}`);
    }
  }
  console.log();
}

async function identifyMissingFunctionality() {
  console.log('=== MISSING FUNCTIONALITY ANALYSIS ===');

  console.log('❌ MISSING FEATURES:');
  console.log('1. Per Supplier Inventory Views');
  console.log('   - No dedicated supplier inventory management interface');
  console.log('   - No supplier-specific stock monitoring');
  console.log('   - No supplier inventory performance metrics\n');

  console.log('2. Product to Full Inventory "In Stock" Lists');
  console.log('   - No comprehensive in-stock inventory views');
  console.log('   - No product-centric inventory management');
  console.log('   - No cross-supplier product availability tracking\n');

  console.log('3. Supplier Performance on Inventory');
  console.log('   - No inventory-specific supplier performance tracking');
  console.log('   - No supplier stock reliability metrics');
  console.log('   - No supplier delivery performance against inventory needs\n');

  console.log('4. Missing Database Objects:');

  // Check for missing tables that would support supplier inventory management
  const missingTables = [
    'supplier_inventory_metrics',
    'supplier_stock_performance',
    'inventory_supplier_mapping',
    'supplier_delivery_history'
  ];

  missingTables.forEach(table => {
    console.log(`   - ${table} (recommended for comprehensive supplier inventory management)`);
  });

  console.log();
}

async function checkExistingViews() {
  console.log('=== EXISTING VIEWS AND AGGREGATIONS ===');

  // Check for existing views
  const views = await pool.query(`
    SELECT table_name, view_definition
    FROM information_schema.views
    WHERE table_schema = 'public'
      AND (table_name LIKE '%inventory%' OR table_name LIKE '%supplier%' OR table_name LIKE '%stock%')
    ORDER BY table_name
  `);

  console.log('Existing Views:');
  if (views.rows.length === 0) {
    console.log('  ❌ No inventory/supplier-related views found');
  } else {
    views.rows.forEach(view => {
      console.log(`  ✅ ${view.table_name}`);
    });
  }
  console.log();
}

async function assessDataQuality() {
  console.log('=== DATA QUALITY ASSESSMENT ===');

  const qualityChecks = [
    {
      name: 'Inventory Items Missing Supplier',
      query: `
        SELECT COUNT(*) as count
        FROM inventory_items
        WHERE supplier_id IS NULL
      `
    },
    {
      name: 'Suppliers Without Inventory Items',
      query: `
        SELECT COUNT(*) as count
        FROM suppliers s
        WHERE NOT EXISTS (
          SELECT 1 FROM inventory_items ii WHERE ii.supplier_id = s.id
        )
      `
    },
    {
      name: 'Inventory Items Missing Cost Price',
      query: `
        SELECT COUNT(*) as count
        FROM inventory_items
        WHERE cost_price IS NULL OR cost_price = 0
      `
    },
    {
      name: 'Inventory Items with Zero Stock',
      query: `
        SELECT COUNT(*) as count
        FROM inventory_items
        WHERE stock_qty IS NULL OR stock_qty = 0
      `
    }
  ];

  for (const check of qualityChecks) {
    try {
      const result = await pool.query(check.query);
      const count = result.rows[0].count;
      const status = count > 0 ? '⚠️' : '✅';
      console.log(`  ${status} ${check.name}: ${count}`);
    } catch (error) {
      console.log(`  ❌ ${check.name}: Error - ${error.message}`);
    }
  }

  // Calculate total inventory value
  try {
    const totalValue = await pool.query(`
      SELECT
        SUM(COALESCE(stock_qty, 0) * COALESCE(cost_price, 0)) as total_value,
        COUNT(*) as total_items
      FROM inventory_items
    `);

    console.log(`\n📊 INVENTORY SUMMARY:`);
    console.log(`  Total Items: ${totalValue.rows[0].total_items}`);
    console.log(`  Total Value: R${Number(totalValue.rows[0].total_value || 0).toLocaleString()}`);
  } catch (error) {
    console.log(`  ❌ Error calculating totals: ${error.message}`);
  }

  console.log();
}

// Run the analysis
analyzeSupplierInventoryGaps().catch(console.error);