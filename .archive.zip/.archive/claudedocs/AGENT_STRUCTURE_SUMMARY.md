# 7-AGENT STRUCTURE FOR ITERATION 2

**Date**: 2025-10-08
**Status**: ACTIVE CONFIGURATION

---

## THE 6 WORKING AGENTS (Do the Work)

Deploy in PARALLEL at start of each phase:

1. **production-incident-responder**
   - API health monitoring
   - Incident triage and response
   - Error pattern analysis
   - Performance degradation detection

2. **aster-fullstack-architect**
   - System architecture design
   - Schema design and API contracts
   - Full-stack integration patterns
   - Technical decision making (ADRs)

3. **data-oracle**
   - Database operations via Neon MCP ONLY
   - Data integrity validation
   - Query performance optimization
   - Migration execution and validation

4. **infra-config-reviewer**
   - Infrastructure configuration audit
   - Security validation and hardening
   - Deployment readiness assessment
   - Environment configuration review

5. **ui-perfection-doer**
   - Frontend error handling and boundaries
   - UX and accessibility (WCAG AAA)
   - E2E testing via Chrome DevTools MCP
   - Component design and implementation

6. **ml-architecture-expert**
   - Analytics pipeline design
   - Performance profiling and optimization
   - Data aggregation correctness
   - Query optimization and caching strategies

---

## THE 7TH AGENT: compliance-enforcer (Validates Everything)

Deploy AFTER each phase completes (5 times per iteration):

**Role**: Rule enforcement and quality gate validation

**What it checks (10 validation items)**:
1. ✅ All 6 working agents participated
2. ✅ Each agent delivered ≥5 items
3. ✅ sequential-thinking MCP used for planning
4. ✅ MCP tools used with complete logging
5. ✅ No rule violations (made-up scores, skipped steps)
6. ✅ Quality standards met (no TODOs, no incomplete code, no hardcoded values)
7. ✅ Agile backlog updated with rolled-forward issues
8. ✅ All required documentation created
9. ✅ Flags any violations immediately
10. ✅ Recommends corrective actions

**What it does NOT do**:
- ❌ Does NOT write code
- ❌ Does NOT design architecture
- ❌ Does NOT run queries
- ❌ Does NOT replace any working agent

**Output**: Compliance validation report with ✅ PASS or ❌ FAIL

---

## PHASE EXECUTION FLOW

### Example: Discovery Phase

**STEP 1**: Use sequential-thinking MCP to plan Discovery phase

**STEP 2**: Deploy all 6 working agents in parallel (ONE message, 6 Task calls)
```
production-incident-responder: Enumerate ≥5 API health requirements
aster-fullstack-architect: Enumerate ≥5 architecture gaps
data-oracle: Enumerate ≥5 data contract issues
infra-config-reviewer: Enumerate ≥5 config vulnerabilities
ui-perfection-doer: Enumerate ≥5 UX/accessibility issues
ml-architecture-expert: Enumerate ≥5 performance bottlenecks
```

**STEP 3**: Wait for all 6 agents to complete

**STEP 4**: Deploy compliance-enforcer to validate Discovery phase
```
compliance-enforcer:
- Verify all 6 agents delivered ≥5 findings each
- Verify sequential-thinking was used
- Verify MCP tools were used with logging
- Check for rule violations
- Output: Discovery Phase Compliance Report
```

**STEP 5**: If compliance FAILS → Stop and fix violations before proceeding

**STEP 6**: If compliance PASSES → Proceed to Design phase

---

## ITERATION 2 DELIVERABLES STRUCTURE

### Per Phase (5 phases)

**Working Agent Deliverables** (6 per phase = 30 total):
- `ITERATION_2_DISCOVERY_production-incident-responder.md`
- `ITERATION_2_DISCOVERY_aster-fullstack-architect.md`
- `ITERATION_2_DISCOVERY_data-oracle.md`
- `ITERATION_2_DISCOVERY_infra-config-reviewer.md`
- `ITERATION_2_DISCOVERY_ui-perfection-doer.md`
- `ITERATION_2_DISCOVERY_ml-architecture-expert.md`

**Compliance Validation** (1 per phase = 5 total):
- `ITERATION_2_DISCOVERY_COMPLIANCE_REPORT.md`

### Total Deliverables per Iteration

- **Working agent outputs**: 30 documents (6 agents × 5 phases)
- **Compliance reports**: 5 documents (1 per phase)
- **Consolidated docs**: 5 documents (1 per phase)
- **Final assessment**: 1 document
- **Next iteration backlog**: 1 document

**Grand Total**: 42 documents per iteration

---

## KEY DIFFERENCES FROM ITERATION 1

### What Changed

**ITERATION 1** (WRONG):
- 6 agents worked
- No validation after phases
- I made up scores (dishonest)
- Issues from I1 might not roll forward

**ITERATION 2** (CORRECT):
- 6 agents work
- compliance-enforcer validates AFTER every phase
- No made-up scores (objective facts only)
- compliance-enforcer ensures all issues roll forward
- compliance-enforcer catches rule violations immediately

### Why This Matters

**Prevents**:
- Skipping sequential-thinking planning
- Deploying agents sequentially instead of parallel
- Forgetting to use MCP tools
- Incomplete deliverables (< 5 items per agent)
- Made-up scores without objective criteria
- Rule violations going unnoticed
- Issues not rolling forward to next iteration
- Low-quality deliverables (TODOs, incomplete code)

**Ensures**:
- Every phase validated before proceeding
- Methodology compliance enforced automatically
- Quality gates respected
- Agile backlog maintained properly
- No violations slip through

---

## WHEN TO USE compliance-enforcer

**MANDATORY - After every phase**:
1. AFTER Discovery → compliance-enforcer validates Discovery
2. AFTER Design → compliance-enforcer validates Design
3. AFTER Development → compliance-enforcer validates Development
4. AFTER Delivery → compliance-enforcer validates Delivery
5. AFTER Assessment → compliance-enforcer validates Assessment

**OPTIONAL - Proactive validation**:
- If I suspect I violated rules → Run compliance-enforcer immediately
- Before declaring iteration complete → Final compliance check
- After major changes → Spot-check compliance

---

## COMPLIANCE-ENFORCER PROMPT TEMPLATE

When deploying compliance-enforcer, use this prompt structure:

```
# COMPLIANCE VALIDATION - [PHASE NAME]

## Context
ITERATION: 2
PHASE: Discovery/Design/Development/Delivery/Assessment
WORKING AGENTS: 6 (list names)

## Validation Required

Check ALL of the following (10 items):

1. ✅/❌ All 6 working agents participated
2. ✅/❌ Each agent delivered ≥5 items
3. ✅/❌ sequential-thinking MCP used for phase planning
4. ✅/❌ MCP tools used with complete logging
5. ✅/❌ No made-up scores or subjective ratings
6. ✅/❌ Quality standards met (no TODOs, no incomplete implementations)
7. ✅/❌ Agile backlog updated with new issues
8. ✅/❌ All required documentation created
9. ✅/❌ No rule violations detected
10. ✅/❌ Objective pass/fail criteria used

## Agent Outputs to Review

[List the 6 agent output files/reports to validate]

## Output Required

Create: `ITERATION_2_[PHASE]_COMPLIANCE_REPORT.md` with:
- ✅ PASS or ❌ FAIL for each of 10 checks
- List of violations found (if any)
- Recommended corrective actions (if violations)
- Overall compliance status: PASS/FAIL
```

---

**END OF AGENT STRUCTURE SUMMARY**

This 7-agent structure is now ACTIVE for ITERATION 2 and all future iterations.
