# AI Frontend Integration Guide

## Overview

This guide provides step-by-step instructions for integrating the AI-enhanced frontend components into your existing MantisNXT supplier management system.

## Quick Start

### 1. Import AI Components

```typescript
// In your existing supplier dashboard
import {
  AISupplierDiscoveryPanel,
  AISupplierInsightsPanel,
  AIPredictiveAnalyticsDashboard,
  AIEnhancedSupplierForm,
  useAISupplier,
  useAISupplierRecommendations,
  useAISupplierInsights
} from '@/components/suppliers/ai'
```

### 2. Basic Integration Example

```typescript
// Enhanced existing component
export default function YourSupplierDashboard() {
  const [showAI, setShowAI] = useState(true)
  const { state, refreshAll } = useAISupplier({
    autoFetch: true,
    enableRealTimeUpdates: true
  })

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Your existing dashboard - 3 columns */}
      <div className="lg:col-span-3">
        <YourExistingDashboard />
      </div>

      {/* AI Enhancement Panel - 1 column */}
      {showAI && (
        <div className="lg:col-span-1">
          <AISupplierInsightsPanel
            onInsightAction={(insight, action) => {
              // Handle AI recommendations
              console.log('AI Action:', action)
            }}
          />
        </div>
      )}
    </div>
  )
}
```

## Component Integration Patterns

### Pattern 1: Side Panel Enhancement

**Use Case**: Add AI insights alongside existing supplier dashboard

```typescript
// components/suppliers/EnhancedSupplierDashboard.tsx
import { AISupplierInsightsPanel } from '@/components/suppliers/ai'

export default function EnhancedSupplierDashboard() {
  const [aiPanelOpen, setAiPanelOpen] = useState(true)

  return (
    <div className="flex gap-6">
      {/* Main Dashboard */}
      <div className={aiPanelOpen ? "flex-1" : "w-full"}>
        {/* Your existing supplier dashboard */}
        <YourExistingDashboard />
      </div>

      {/* AI Side Panel */}
      {aiPanelOpen && (
        <div className="w-96">
          <AISupplierInsightsPanel
            supplierId={selectedSupplier}
            onInsightAction={handleAIAction}
          />
        </div>
      )}
    </div>
  )
}
```

### Pattern 2: Tab-Based Integration

**Use Case**: Add AI features as separate tabs

```typescript
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AISupplierDiscoveryPanel } from '@/components/suppliers/ai'

export default function SupplierManagementTabs() {
  return (
    <Tabs defaultValue="suppliers">
      <TabsList>
        <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
        <TabsTrigger value="ai-discovery">
          <Brain className="h-4 w-4 mr-2" />
          AI Discovery
        </TabsTrigger>
        <TabsTrigger value="analytics">Analytics</TabsTrigger>
      </TabsList>

      <TabsContent value="suppliers">
        <YourExistingSupplierTable />
      </TabsContent>

      <TabsContent value="ai-discovery">
        <AISupplierDiscoveryPanel
          onSupplierRecommend={(supplier) => {
            // Handle AI supplier recommendation
            addSupplierToShortlist(supplier)
          }}
        />
      </TabsContent>
    </Tabs>
  )
}
```

### Pattern 3: Form Enhancement

**Use Case**: Enhance supplier creation forms with AI assistance

```typescript
import { AIEnhancedSupplierForm } from '@/components/suppliers/ai'

export default function CreateSupplierPage() {
  const handleSubmit = async (formData) => {
    // Your existing form submission logic
    await createSupplier(formData)
  }

  return (
    <AIEnhancedSupplierForm
      mode="create"
      onSubmit={handleSubmit}
      onCancel={() => router.back()}
    />
  )
}
```

### Pattern 4: Modal Integration

**Use Case**: AI insights in modal/dialog format

```typescript
import { Dialog } from '@/components/ui/dialog'
import { AISupplierInsightsPanel } from '@/components/suppliers/ai'

export default function SupplierRow({ supplier }) {
  const [showAI, setShowAI] = useState(false)

  return (
    <>
      <TableRow>
        {/* Your existing supplier row */}
        <TableCell>
          <Button onClick={() => setShowAI(true)}>
            <Brain className="h-4 w-4 mr-2" />
            AI Insights
          </Button>
        </TableCell>
      </TableRow>

      <Dialog open={showAI} onOpenChange={setShowAI}>
        <DialogContent className="max-w-4xl">
          <AISupplierInsightsPanel
            supplierId={supplier.id}
            onInsightAction={(insight, action) => {
              handleInsightAction(insight, action)
              if (action === 'close') setShowAI(false)
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
```

## Hook Integration Examples

### Using AI Supplier Hooks

```typescript
import { useAISupplierRecommendations, useAISupplierInsights } from '@/hooks/useAISupplier'

export default function SupplierSearch() {
  // AI-powered recommendations
  const {
    recommendations,
    loading: recLoading,
    search: searchSuppliers
  } = useAISupplierRecommendations()

  // AI insights for selected supplier
  const {
    insights,
    loading: insightsLoading,
    refresh: refreshInsights
  } = useAISupplierInsights(selectedSupplierId)

  const handleSearch = async (query: string) => {
    // AI-enhanced search
    await searchSuppliers(query, {
      categories: ['technology', 'manufacturing'],
      region: 'South Africa'
    })
  }

  return (
    <div className="space-y-4">
      {/* Search Interface */}
      <SearchInput
        onSearch={handleSearch}
        placeholder="Describe what type of supplier you need..."
      />

      {/* AI Recommendations */}
      {recommendations.map(rec => (
        <RecommendationCard
          key={rec.id}
          recommendation={rec}
          onSelect={() => handleSupplierSelect(rec)}
        />
      ))}

      {/* AI Insights */}
      {selectedSupplierId && insights.map(insight => (
        <InsightCard
          key={insight.id}
          insight={insight}
          onAction={handleInsightAction}
        />
      ))}
    </div>
  )
}
```

## API Integration

### Required Backend Endpoints

Create these API endpoints to support the AI frontend components:

```typescript
// pages/api/ai/suppliers/discover.ts
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { query, filters, analysisDepth } = req.body

  try {
    // Your AI supplier discovery logic
    const recommendations = await aiSupplierService.discover({
      query,
      filters,
      analysisDepth
    })

    res.status(200).json({
      success: true,
      recommendations,
      metadata: {
        processingTime: Date.now() - startTime,
        confidence: 95
      }
    })
  } catch (error) {
    res.status(500).json({ success: false, error: error.message })
  }
}
```

### API Client Setup

```typescript
// lib/api/ai-supplier.ts
export class AISupplierAPI {
  static async discover(query: string, options = {}) {
    const response = await fetch('/api/ai/suppliers/discover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, ...options })
    })
    return response.json()
  }

  static async getInsights(supplierId: string, categories = []) {
    const response = await fetch('/api/ai/suppliers/insights', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ supplierId, categories })
    })
    return response.json()
  }

  static async chat(message: string, context = {}) {
    const response = await fetch('/api/ai/suppliers/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context })
    })
    return response.json()
  }
}
```

## State Management Integration

### With Existing Zustand Stores

```typescript
// lib/stores/ai-enhanced-supplier-store.ts
import { create } from 'zustand'
import type { AISupplierState, AISupplierAction } from '@/types/ai-supplier'

interface EnhancedSupplierStore {
  // Existing supplier state
  suppliers: Supplier[]
  loading: boolean

  // AI enhancement state
  aiRecommendations: AISupplierRecommendation[]
  aiInsights: AISupplierInsight[]

  // Actions
  fetchSuppliers: () => Promise<void>
  fetchAIRecommendations: (query: string) => Promise<void>
  fetchAIInsights: (supplierId: string) => Promise<void>
}

export const useEnhancedSupplierStore = create<EnhancedSupplierStore>((set, get) => ({
  // State
  suppliers: [],
  loading: false,
  aiRecommendations: [],
  aiInsights: [],

  // Actions
  fetchSuppliers: async () => {
    set({ loading: true })
    try {
      const suppliers = await supplierAPI.getSuppliers()
      set({ suppliers, loading: false })
    } catch (error) {
      set({ loading: false })
      console.error('Error fetching suppliers:', error)
    }
  },

  fetchAIRecommendations: async (query) => {
    const { recommendations } = await AISupplierAPI.discover(query)
    set({ aiRecommendations: recommendations })
  },

  fetchAIInsights: async (supplierId) => {
    const { insights } = await AISupplierAPI.getInsights(supplierId)
    set({ aiInsights: insights })
  }
}))
```

## Accessibility Integration

### Ensuring WCAG Compliance

```typescript
// components/suppliers/AccessibleAIComponent.tsx
import { useAnnounceToScreenReader } from '@/hooks/useAccessibility'

export default function AccessibleAISupplierInsights() {
  const announce = useAnnounceToScreenReader()

  const handleInsightGenerated = (insight: AISupplierInsight) => {
    // Announce new insights to screen readers
    announce(`New AI insight generated: ${insight.title}. Confidence level ${insight.confidence} percent.`)
  }

  return (
    <div
      role="region"
      aria-label="AI Supplier Insights"
      aria-live="polite"
    >
      {/* AI insights content */}
      {insights.map(insight => (
        <div
          key={insight.id}
          role="article"
          aria-labelledby={`insight-title-${insight.id}`}
          tabIndex={0}
          className="focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <h3 id={`insight-title-${insight.id}`}>
            {insight.title}
          </h3>
          <div aria-label={`Confidence level: ${insight.confidence} percent`}>
            <Progress
              value={insight.confidence}
              aria-describedby={`confidence-${insight.id}`}
            />
            <span id={`confidence-${insight.id}`} className="sr-only">
              AI confidence level is {insight.confidence} percent
            </span>
          </div>
        </div>
      ))}
    </div>
  )
}
```

## Performance Optimization

### Lazy Loading AI Components

```typescript
// Lazy load AI components to reduce initial bundle size
import { lazy, Suspense } from 'react'

const AISupplierDiscoveryPanel = lazy(() =>
  import('@/components/suppliers/ai/AISupplierDiscoveryPanel')
)

const AIPredictiveAnalyticsDashboard = lazy(() =>
  import('@/components/analytics/ai/AIPredictiveAnalyticsDashboard')
)

export default function SupplierDashboard() {
  const [showAI, setShowAI] = useState(false)

  return (
    <div>
      {/* Your existing dashboard */}
      <YourExistingDashboard />

      {/* Conditionally load AI components */}
      {showAI && (
        <Suspense fallback={<AILoadingSkeleton />}>
          <AISupplierDiscoveryPanel />
        </Suspense>
      )}
    </div>
  )
}
```

### Caching AI Responses

```typescript
// hooks/useAICache.ts
import { useMemo } from 'react'

export function useAICache() {
  const cache = useMemo(() => new Map(), [])

  const getCachedResponse = (key: string) => {
    const cached = cache.get(key)
    if (cached && Date.now() - cached.timestamp < 5 * 60 * 1000) { // 5 min TTL
      return cached.data
    }
    return null
  }

  const setCachedResponse = (key: string, data: any) => {
    cache.set(key, { data, timestamp: Date.now() })
  }

  return { getCachedResponse, setCachedResponse }
}
```

## Error Handling

### AI-Specific Error Boundaries

```typescript
// components/ai/AIErrorBoundary.tsx
import { ErrorBoundary } from 'react-error-boundary'

function AIErrorFallback({ error, resetErrorBoundary }) {
  return (
    <div className="p-6 border border-red-200 rounded-lg bg-red-50">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="h-5 w-5 text-red-600" />
        <h3 className="font-medium text-red-900">AI Service Unavailable</h3>
      </div>
      <p className="text-red-700 mb-4">
        The AI features are temporarily unavailable. You can continue using the standard features.
      </p>
      <Button onClick={resetErrorBoundary} variant="outline">
        Retry AI Services
      </Button>
    </div>
  )
}

export function AIErrorBoundary({ children }) {
  return (
    <ErrorBoundary
      FallbackComponent={AIErrorFallback}
      onError={(error) => {
        console.error('AI Component Error:', error)
        // Optional: Send to error tracking service
      }}
    >
      {children}
    </ErrorBoundary>
  )
}
```

## Testing Integration

### Component Testing with AI Features

```typescript
// __tests__/AISupplierDiscoveryPanel.test.tsx
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { AISupplierDiscoveryPanel } from '@/components/suppliers/ai'

// Mock AI API
jest.mock('@/lib/api/ai-supplier', () => ({
  AISupplierAPI: {
    discover: jest.fn().mockResolvedValue({
      recommendations: [
        {
          id: '1',
          supplier: { name: 'Test Supplier' },
          confidenceScore: 95
        }
      ]
    })
  }
}))

describe('AISupplierDiscoveryPanel', () => {
  it('should search and display AI recommendations', async () => {
    render(<AISupplierDiscoveryPanel />)

    // Enter search query
    const searchInput = screen.getByPlaceholderText(/describe what type of supplier/i)
    await userEvent.type(searchInput, 'sustainable packaging suppliers')

    // Click search
    const searchButton = screen.getByRole('button', { name: /ai search/i })
    await userEvent.click(searchButton)

    // Wait for recommendations to appear
    await waitFor(() => {
      expect(screen.getByText('Test Supplier')).toBeInTheDocument()
      expect(screen.getByText('95%')).toBeInTheDocument()
    })
  })

  it('should handle AI errors gracefully', async () => {
    // Mock API error
    jest.mocked(AISupplierAPI.discover).mockRejectedValue(new Error('AI service down'))

    render(<AISupplierDiscoveryPanel />)

    const searchButton = screen.getByRole('button', { name: /ai search/i })
    await userEvent.click(searchButton)

    await waitFor(() => {
      expect(screen.getByText(/ai service unavailable/i)).toBeInTheDocument()
    })
  })
})
```

## Migration Checklist

### Phase 1: Setup (Week 1)
- [ ] Install required dependencies
- [ ] Set up AI provider configuration
- [ ] Create AI type definitions
- [ ] Implement basic error boundaries

### Phase 2: Core Integration (Week 2-3)
- [ ] Integrate `useAISupplier` hooks
- [ ] Add AI components to existing dashboards
- [ ] Implement API endpoints
- [ ] Set up state management

### Phase 3: Enhancement (Week 4-5)
- [ ] Add accessibility features
- [ ] Implement performance optimizations
- [ ] Add comprehensive error handling
- [ ] Create user preferences system

### Phase 4: Testing & Deployment (Week 6)
- [ ] Write comprehensive tests
- [ ] Perform accessibility audit
- [ ] Load testing with AI components
- [ ] Production deployment

## Best Practices

### 1. Progressive Enhancement
```typescript
// Always provide fallbacks for AI features
const SupplierSearch = () => {
  const [aiEnabled, setAiEnabled] = useState(false)

  return (
    <div>
      {/* Standard search always available */}
      <StandardSupplierSearch />

      {/* AI enhancement opt-in */}
      <Button onClick={() => setAiEnabled(true)}>
        Enable AI Search
      </Button>

      {aiEnabled && (
        <AISupplierDiscoveryPanel />
      )}
    </div>
  )
}
```

### 2. User Feedback Integration
```typescript
// Always collect user feedback on AI features
const handleAIRecommendation = (recommendation) => {
  // Show recommendation to user
  showRecommendation(recommendation)

  // Collect feedback
  collectUserFeedback({
    recommendationId: recommendation.id,
    onFeedback: (rating) => {
      // Send feedback to improve AI models
      AISupplierAPI.provideFeedback(recommendation.id, rating)
    }
  })
}
```

### 3. Performance Monitoring
```typescript
// Monitor AI performance
const useAIPerformanceTracking = () => {
  const trackAIInteraction = (action: string, duration: number) => {
    analytics.track('ai_interaction', {
      action,
      duration,
      timestamp: Date.now()
    })
  }

  return { trackAIInteraction }
}
```

This integration guide provides a comprehensive approach to adding AI capabilities to your existing MantisNXT supplier management system while maintaining performance, accessibility, and user experience standards.