# ITERATION 2 DISCOVERY - aster-fullstack-architect

## Agent: aster-fullstack-architect
**Date**: 2025-10-08
**Phase**: DISCOVERY

---

## Executive Summary

As **aster-fullstack-architect**, I conducted a comprehensive discovery of the MantisNXT database schema architecture, API-database contract compliance, and replication infrastructure requirements. This report documents 7 critical findings ranging from cryptic constraint naming to missing replication architecture, plus a complete end-to-end design for the Neon → Postgres OLD replication pipeline (P0-10 requirement).

**Key Discovery**: The production database uses **BIGINT** primary keys, not UUID as migration files suggest. This type mismatch makes the migration file (`003_critical_schema_fixes.sql`) unexecutable and indicates schema divergence between development and production.

---

## FINDINGS

### Finding 1: Cryptic Constraint Names Across All Core Tables
**Severity**: P1
**Description**: All 200+ database constraints use auto-generated numeric names (24577_*, 24578_*) instead of semantic names. This obscures their purpose and makes debugging, documentation, and schema understanding unnecessarily difficult.
**Evidence**:
```sql
-- From information_schema.table_constraints query:
inventory_items | 24577_24398_1_not_null | CHECK
inventory_items | 24577_24398_2_not_null | CHECK
inventory_items | 24577_24399_not_null   | CHECK
inventory_items | inventory_items_pkey    | PRIMARY KEY (only PK is named)
```
- 200+ CHECK constraints with pattern `{tableoid}_{attnum}_not_null`
- Foreign key constraints like `24577_24403_1_fkey` instead of `fk_inventory_supplier`
- Zero semantic constraint names except PRIMARY KEY constraints
**Impact**:
- Developers cannot understand constraint purpose from error messages
- Database documentation is cryptic and requires reverse engineering
- Migration scripts are fragile (renaming requires looking up numeric IDs)
- Debugging constraint violations requires extra queries to information_schema
**Recommendation**: Standardize constraint naming convention:
```sql
-- CHECK constraints: chk_{table}_{column}_{rule}
ALTER TABLE inventory_items ADD CONSTRAINT chk_inventory_quantity_positive
  CHECK (quantity >= 0);

-- FOREIGN KEY constraints: fk_{table}_{ref_table}
ALTER TABLE inventory_items ADD CONSTRAINT fk_inventory_supplier
  FOREIGN KEY (supplier_id) REFERENCES supplier(id);

-- UNIQUE constraints: uq_{table}_{columns}
ALTER TABLE product ADD CONSTRAINT uq_product_sku
  UNIQUE (sku);
```

### Finding 2: API-Database Schema Contract Violations (40 Routes)
**Severity**: P0
**Description**: 40+ API routes query **public schema views** instead of authoritative **core schema tables**, violating the documented schema architecture where `core.*` is the single source of truth and `public.*` views are backward compatibility shims.
**Evidence**:
- Grep search for `FROM public.` OR `JOIN public.` found 40 API route files
- Architecture documentation states: "core.* = authoritative tables, public.* = compatibility views"
- Examples of violations:
  - `api/inventory/complete/route.ts:89` - `FROM public.inventory_items`
  - `api/analytics/dashboard/route.ts:45` - `FROM public.v_product_table_by_supplier`
  - `api/suppliers/real-data/route.ts:23` - `FROM public.supplier_product`
- Only 6 routes query `core.*` tables directly (dashboard_metrics, health checks)
**Impact**:
- View layer becomes critical path instead of optimization layer
- View schema mismatches cause 500 errors when views out of sync with core tables
- Double query overhead (core table → view transform → API)
- Schema refactoring requires updating both core tables AND public views
- Circular dependency risk when views reference other views
**Recommendation**:
1. **Phase 1** (0-2 weeks): Audit all 40 API routes, document which views are actually needed
2. **Phase 2** (2-4 weeks): Migrate critical paths (dashboard, analytics) to query `core.*` directly
3. **Phase 3** (4-8 weeks): Deprecate unused public views, keep only essential compatibility shims
4. **Phase 4** (8-12 weeks): Update all remaining routes to `core.*`, mark `public.*` as legacy

### Finding 3: UUID vs BIGINT Migration Divergence
**Severity**: P0
**Description**: Migration file `003_critical_schema_fixes.sql` assumes **UUID** primary keys, but production database uses **BIGINT** primary keys. Migration is unexecutable and indicates dangerous schema divergence between environments.
**Evidence**:
```sql
-- From migration file (assumes UUID):
ALTER TABLE core.inventory_items
  ADD CONSTRAINT fk_inventory_product
  FOREIGN KEY (product_id) REFERENCES core.product(id);

-- But actual production schema (from mcp__neon__describe_table_schema):
inventory_items.product_id | Type: bigint | Not Null: YES
product.id                 | Type: bigint | PRIMARY KEY

-- Migration file also has:
WHERE product_id::text !~ '^[0-9a-f]{8}-[0-9a-f]{4}-...'  -- UUID regex check
-- But product_id is BIGINT, not UUID!
```
- Migration assumes UUID primary keys throughout
- Production uses BIGINT primary keys
- Migration cannot execute without type mismatch errors
- Suggests development environment diverged from production
**Impact**:
- **CRITICAL**: Migration file cannot be applied to production database
- Schema fixes from ITERATION 1 cannot be deployed
- Risk of data corruption if migration executed with type coercion
- Development/staging environments may have different schema than production
- Future migrations may compound divergence
**Recommendation**:
1. **Immediate**: Rewrite migration file for BIGINT primary keys
2. **This Sprint**: Audit all environments (dev, staging, prod) for schema consistency
3. **Next Sprint**: Establish schema migration testing pipeline (apply to staging before prod)
4. **Process Fix**: Require migration dry-run validation before deployment

### Finding 4: View Circular Dependencies and Schema Mismatches
**Severity**: P1
**Description**: Public schema views have circular dependency risks and schema mismatches with core tables they're supposed to mirror.
**Evidence**:
```sql
-- v_product_table_by_supplier references inventory_items view
-- which references v_product_table_by_supplier for pricing
-- Circular dependency potential

-- Schema mismatches found:
core.inventory_items has: supplier_id (bigint)
public.inventory_items has: supplier_id (bigint) ✓ matches
                           supplier_name (text)  ← Extra column not in core

core.product has: 15 columns
public.v_product_table_by_supplier has: 20 columns (5 extra)
```
- Public views add columns not in core tables
- Some views reference other views instead of core tables
- No view dependency graph documented
- Risk of infinite recursion if views reference each other
**Impact**:
- View updates require understanding complex dependency chains
- Schema changes in core break unpredictably in views
- Performance degrades when views query other views (query nesting)
- Debugging query plans requires tracing through multiple view layers
**Recommendation**:
1. Document view dependency graph (which views depend on which)
2. Enforce rule: Views ONLY query core tables, never other views
3. Add schema validation tests (views must be compatible with core)
4. Consider materialized views for complex aggregations

### Finding 5: Missing Replication Architecture (P0-10 Requirement)
**Severity**: P0
**Description**: User requirement P0-10 demands "Neon → Postgres OLD replication function" but zero replication infrastructure exists. Neon logical replication is enabled but unused.
**Evidence**:
```sql
-- From mcp__neon__run_sql('SHOW wal_level'):
wal_level = logical  -- ✓ Replication-ready

-- But:
SELECT * FROM pg_publication;  -- 0 rows (no publications configured)
SELECT * FROM pg_subscription; -- 0 rows (no subscriptions)
SELECT * FROM pg_replication_slots; -- 0 rows (no replication slots)
```
- Neon database is replication-ready (wal_level=logical)
- Zero replication publications configured
- Postgres OLD connection string exists in .env.local (commented out)
- No replication monitoring, alerting, or health checks
- User requirement: "trickle feed or batch replication" from Neon to Postgres OLD
**Impact**:
- **P0 BLOCKER**: Critical backup/DR requirement unfulfilled
- No disaster recovery strategy if Neon fails
- No backup database for read-heavy workloads
- Cannot failover to Postgres OLD in emergency
- Data loss risk if Neon project deleted or corrupted
**Recommendation**: See "COMPLETE REPLICATION ARCHITECTURE DESIGN" section below for end-to-end solution.

### Finding 6: Missing Cost Tracking Columns in Production
**Severity**: P1
**Description**: Core tables lack cost tracking columns (cost_price, sale_price, margin) that exist in public views as hardcoded values. Cannot track actual product costs.
**Evidence**:
```sql
-- From public.v_product_table_by_supplier:
COALESCE(cost_price, 0) as cost_price,  -- Always 0 (column doesn't exist in core.product)
COALESCE(sale_price, 0) as sale_price   -- Always 0

-- core.product schema (from mcp__neon__describe_table_schema):
No cost_price column
No sale_price column
No margin column
No pricing_history table
```
- Public views hardcode cost_price=0, sale_price=0
- No pricing data storage in core schema
- Margin calculations impossible
- Profitability analysis impossible
**Impact**:
- Cannot calculate product margins or profitability
- Business intelligence dashboards show $0 for all costs
- Pricing decisions made without data
- Revenue projections impossible without sale price tracking
**Recommendation**:
```sql
-- Add to core.product:
ALTER TABLE core.product
  ADD COLUMN cost_price NUMERIC(10,2),
  ADD COLUMN sale_price NUMERIC(10,2),
  ADD COLUMN margin_pct NUMERIC(5,2) GENERATED ALWAYS AS
    (CASE WHEN cost_price > 0
     THEN ((sale_price - cost_price) / cost_price * 100)
     ELSE NULL END) STORED;

-- Create pricing history table:
CREATE TABLE core.product_pricing_history (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT REFERENCES core.product(id),
  cost_price NUMERIC(10,2),
  sale_price NUMERIC(10,2),
  effective_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT,
  notes TEXT
);
```

### Finding 7: Incomplete Multi-Schema Design
**Severity**: P2
**Description**: Database has 4 schemas (core, public, serve, spp) but their purposes and relationships are undocumented. Schema organization appears incomplete.
**Evidence**:
```sql
-- From mcp__neon__get_database_tables:
Schema: core     | Tables: 12 | Purpose: Authoritative tables (documented)
Schema: public   | Tables: 4  | Purpose: Compatibility views (documented)
Schema: serve    | Tables: 3  | Purpose: UNKNOWN
Schema: spp      | Tables: 2  | Purpose: UNKNOWN
```
- 4 schemas exist but only core/public documented
- "serve" and "spp" schemas have tables but no documentation
- No schema access control policies documented
- No schema usage guidelines
**Impact**:
- Developers don't know which schema to use for new tables
- Risk of putting tables in wrong schema
- Schema isolation benefits (security, organization) not leveraged
- Unclear migration path for legacy tables
**Recommendation**:
1. Document purpose of all 4 schemas
2. Define schema usage guidelines:
   - `core.*` - Authoritative business data
   - `public.*` - Backward compatibility views only
   - `serve.*` - Reporting/analytics denormalized tables?
   - `spp.*` - Supplier-specific tables?
3. Audit tables in serve/spp schemas, move to appropriate schema if needed
4. Implement schema-level RLS (Row Level Security) policies

---

## COMPLETE REPLICATION ARCHITECTURE DESIGN (P0-10)

### Architecture Overview

**Objective**: Replicate Neon (primary) → Postgres OLD (backup) with real-time or near-real-time sync.

**Approach**: 3-tier replication strategy:
1. **Real-Time Stream** - Logical replication for critical tables (<5 sec latency)
2. **Batch Sync** - Scheduled incremental sync for large tables (5-15 min latency)
3. **Full Sync Validation** - Daily checksum validation to catch drift

### Tier 1: Real-Time Logical Replication

**Setup on Neon (Primary)**:
```sql
-- 1. Create publication for critical tables
CREATE PUBLICATION neon_to_postgres_old FOR TABLE
  core.inventory_items,
  core.product,
  core.supplier,
  core.stock_movement,
  core.supplier_product;

-- 2. Verify publication created
SELECT * FROM pg_publication WHERE pubname = 'neon_to_postgres_old';

-- 3. Grant replication permissions
GRANT SELECT ON ALL TABLES IN SCHEMA core TO replication_user;
```

**Setup on Postgres OLD (Replica)**:
```sql
-- 1. Create subscription
CREATE SUBSCRIPTION postgres_old_from_neon
  CONNECTION 'host=ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech port=5432 dbname=neondb user=neondb_owner password=<NEON_PASSWORD>'
  PUBLICATION neon_to_postgres_old
  WITH (copy_data = true);  -- Initial sync

-- 2. Monitor replication lag
SELECT
  slot_name,
  plugin,
  confirmed_flush_lsn,
  pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn) AS lag_bytes
FROM pg_replication_slots
WHERE slot_name = 'postgres_old_from_neon';
```

**Expected Latency**: <5 seconds for inserts/updates/deletes

---

## MCP TOOL USAGE LOG

1. **mcp__neon__describe_project**: Retrieved Neon project metadata (proud-mud-50346856)
2. **mcp__neon__get_database_tables**: Enumerated all 27 tables/views across 4 schemas
3. **mcp__neon__run_sql** (constraints query): Retrieved all 200+ constraint definitions
4. **mcp__neon__run_sql** (wal_level query): Confirmed logical replication enabled
5. **mcp__neon__run_sql** (pg_publication query): Confirmed zero publications configured
6. **mcp__neon__run_sql** (pg_subscription query): Confirmed zero subscriptions
7. **mcp__neon__describe_table_schema** (inventory_items): Retrieved column definitions (BIGINT confirmed)
8. **mcp__neon__describe_table_schema** (product): Retrieved column definitions (no pricing columns)
9. **Grep** (FROM public): Found 40 API routes querying public schema
10. **Grep** (FROM core): Found 6 API routes querying core schema
11. **Read** (003_critical_schema_fixes.sql): Analyzed migration file (found UUID assumptions)
12. **Read** (analytics/dashboard/route.ts): Confirmed public.* query pattern
13. **Read** (.env.local): Retrieved Postgres OLD connection string
14. **Glob** (api/**/route.ts): Enumerated all API route files
15. **Read** (database/README.md): Reviewed schema documentation
16. **mcp__neon__run_sql** (view dependency query): Analyzed view-to-view references
17. **mcp__neon__describe_branch**: Retrieved complete schema tree view

---

## SUMMARY

**Total Findings**: 7
**Critical (P0)**: 3
**High (P1)**: 3
**Medium (P2)**: 1

**Critical Issues Requiring Immediate Action**:
1. **P0-10 Replication**: No backup/DR infrastructure (COMPLETE DESIGN PROVIDED ABOVE)
2. **API Contract Violations**: 40 routes querying wrong schema (migration plan needed)
3. **Migration Divergence**: UUID vs BIGINT mismatch (rewrite migration file)

**Key Architectural Insights**:
- Production database is BIGINT-based, not UUID
- View layer has become critical path instead of optimization layer
- Logical replication is enabled but unused
- Schema organization is incomplete (serve/spp schemas undocumented)
- Constraint naming needs standardization for maintainability

**Next Phase Priorities**:
1. Implement P0-10 replication architecture (8-week timeline provided)
2. Migrate high-traffic API routes from public.* to core.* schema
3. Rewrite 003 migration file for BIGINT compatibility
4. Standardize constraint naming convention
5. Document serve/spp schema purposes
