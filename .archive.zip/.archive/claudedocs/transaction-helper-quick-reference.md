# Transaction Helper - Quick Reference Guide

> **TL;DR:** Use `TransactionHelper.withTransaction()` for all database transactions. Never use `pool.query('BEGIN')`.

---

## Basic Usage

### Simple Transaction

```typescript
import { TransactionHelper } from '@/lib/database/transaction-helper'

const result = await TransactionHelper.withTransaction(async (client) => {
  await client.query('INSERT INTO users (name, email) VALUES ($1, $2)', ['John', 'john@example.com'])
  await client.query('INSERT INTO profiles (user_id, bio) VALUES ($1, $2)', [userId, 'Software developer'])
  return { success: true }
})
```

**Automatic handling:**
- ✅ BEGIN executed
- ✅ COMMIT on success
- ✅ ROLLBACK on error
- ✅ Connection released

---

## Common Patterns

### 1. Bulk Insert

```typescript
async function createInventoryItems(items: InventoryItem[]) {
  return TransactionHelper.withTransaction(async (client) => {
    const results = []

    for (const item of items) {
      const result = await client.query(
        'INSERT INTO inventory_items (sku, name, stock_qty) VALUES ($1, $2, $3) RETURNING *',
        [item.sku, item.name, item.stock_qty]
      )
      results.push(result.rows[0])
    }

    return results
  })
}
```

### 2. Update with Validation

```typescript
async function transferStock(fromId: string, toId: string, quantity: number) {
  return TransactionHelper.withTransaction(async (client) => {
    // Check source has enough stock
    const source = await client.query(
      'SELECT stock_qty FROM inventory WHERE id = $1 FOR UPDATE',
      [fromId]
    )

    if (source.rows[0].stock_qty < quantity) {
      throw new Error('Insufficient stock')
    }

    // Perform transfer
    await client.query(
      'UPDATE inventory SET stock_qty = stock_qty - $1 WHERE id = $2',
      [quantity, fromId]
    )

    await client.query(
      'UPDATE inventory SET stock_qty = stock_qty + $1 WHERE id = $2',
      [quantity, toId]
    )

    return { success: true }
  })
}
```

### 3. Read-Only Operations (No Transaction)

```typescript
async function getUsers() {
  return TransactionHelper.withClient(async (client) => {
    const result = await client.query('SELECT * FROM users')
    return result.rows
  })
}
```

### 4. Optional Operations with Savepoint

```typescript
async function createOrderWithOptionalLoyalty(order: Order, userId: string) {
  return TransactionHelper.withTransaction(async (client) => {
    // Create order (required)
    const orderResult = await client.query(
      'INSERT INTO orders (...) VALUES (...) RETURNING *',
      [...]
    )

    // Update loyalty points (optional - don't fail entire order)
    try {
      await TransactionHelper.withSavepoint(client, 'loyalty_update', async (sp) => {
        await sp.query(
          'UPDATE loyalty_points SET points = points + $1 WHERE user_id = $2',
          [order.total * 0.1, userId]
        )
      })
    } catch (error) {
      console.warn('Loyalty points update failed:', error)
      // Order still succeeds
    }

    return orderResult.rows[0]
  })
}
```

### 5. Parallel Queries (Same Transaction)

```typescript
async function getDashboardData(userId: string) {
  return TransactionHelper.withTransaction(async (client) => {
    const [orders, profile, notifications] = await TransactionHelper.parallel(client, [
      (c) => c.query('SELECT * FROM orders WHERE user_id = $1', [userId]),
      (c) => c.query('SELECT * FROM profiles WHERE user_id = $1', [userId]),
      (c) => c.query('SELECT * FROM notifications WHERE user_id = $1 LIMIT 10', [userId])
    ])

    return {
      orders: orders.rows,
      profile: profile.rows[0],
      notifications: notifications.rows
    }
  })
}
```

---

## API Route Examples

### Next.js API Route

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { TransactionHelper } from '@/lib/database/transaction-helper'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const result = await TransactionHelper.withTransaction(async (client) => {
      // Validate input
      const existing = await client.query(
        'SELECT id FROM suppliers WHERE code = $1',
        [body.code]
      )

      if (existing.rows.length > 0) {
        throw new Error('Supplier code already exists')
      }

      // Create supplier
      const supplier = await client.query(
        'INSERT INTO suppliers (...) VALUES (...) RETURNING *',
        [...]
      )

      // Create contacts
      for (const contact of body.contacts) {
        await client.query(
          'INSERT INTO supplier_contacts (...) VALUES (...)',
          [supplier.rows[0].id, ...]
        )
      }

      return supplier.rows[0]
    })

    return NextResponse.json({
      success: true,
      data: result
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
```

---

## Anti-Patterns (DON'T DO THIS)

### ❌ Using pool.query('BEGIN')

```typescript
// WRONG - Uses random connections, breaks transaction isolation
await pool.query('BEGIN')
await pool.query('INSERT...') // Different connection!
await pool.query('COMMIT')    // Different connection!
```

### ❌ Forgetting to use client parameter

```typescript
// WRONG - Queries outside transaction
await TransactionHelper.withTransaction(async (client) => {
  await pool.query('INSERT...') // Using pool instead of client!
})
```

### ❌ Long-running transactions

```typescript
// WRONG - Will timeout after 90 seconds
await TransactionHelper.withTransaction(async (client) => {
  for (let i = 0; i < 1000000; i++) {
    await client.query('INSERT INTO items VALUES ($1)', [i])
  }
})

// CORRECT - Use batching
await TransactionHelper.withTransaction(async (client) => {
  const batchSize = 1000
  for (let i = 0; i < 1000000; i += batchSize) {
    const values = Array.from({ length: batchSize }, (_, j) => `(${i + j})`).join(',')
    await client.query(`INSERT INTO items (id) VALUES ${values}`)
  }
})
```

### ❌ Nested transactions without savepoints

```typescript
// WRONG - Can't nest transactions
await TransactionHelper.withTransaction(async (client1) => {
  await TransactionHelper.withTransaction(async (client2) => {
    // This will fail - different clients
  })
})

// CORRECT - Use savepoints
await TransactionHelper.withTransaction(async (client) => {
  await TransactionHelper.withSavepoint(client, 'nested', async (sp) => {
    // Same client, proper nesting
  })
})
```

---

## Error Handling

### Automatic Rollback

```typescript
try {
  await TransactionHelper.withTransaction(async (client) => {
    await client.query('INSERT INTO users...')
    throw new Error('Something went wrong')
    // Automatic ROLLBACK happens here
  })
} catch (error) {
  console.error('Transaction failed:', error)
  // Handle error, transaction already rolled back
}
```

### Custom Error Messages

```typescript
await TransactionHelper.withTransaction(async (client) => {
  const result = await client.query('SELECT stock_qty FROM inventory WHERE id = $1', [itemId])

  if (result.rows[0].stock_qty < quantity) {
    throw new Error(`Insufficient stock. Available: ${result.rows[0].stock_qty}, Required: ${quantity}`)
  }

  // Continue with transaction...
})
```

### Validation Before Transaction

```typescript
// Validate outside transaction (more efficient)
if (!isValidEmail(email)) {
  throw new Error('Invalid email format')
}

// Then start transaction
await TransactionHelper.withTransaction(async (client) => {
  // Only validated data reaches here
})
```

---

## Performance Tips

### 1. Keep Transactions Short

```typescript
// ✅ GOOD - Quick transaction
await TransactionHelper.withTransaction(async (client) => {
  await client.query('UPDATE inventory SET stock_qty = $1 WHERE id = $2', [qty, id])
})

// ❌ BAD - Long transaction holding locks
await TransactionHelper.withTransaction(async (client) => {
  const result = await client.query('SELECT * FROM inventory')
  // Process 10,000 rows - holding transaction open
  for (const row of result.rows) {
    await processItem(row) // External API calls, etc.
  }
})
```

### 2. Use FOR UPDATE Wisely

```typescript
// Use FOR UPDATE only when actually updating
await TransactionHelper.withTransaction(async (client) => {
  // Lock row for update
  const item = await client.query(
    'SELECT * FROM inventory WHERE id = $1 FOR UPDATE',
    [itemId]
  )

  // Immediately update
  await client.query(
    'UPDATE inventory SET stock_qty = $1 WHERE id = $2',
    [newQty, itemId]
  )
})
```

### 3. Batch Operations

```typescript
// ✅ GOOD - Single query for multiple inserts
await TransactionHelper.withTransaction(async (client) => {
  await client.query(`
    INSERT INTO items (sku, name)
    SELECT * FROM unnest($1::text[], $2::text[])
  `, [skus, names])
})

// ❌ BAD - Individual inserts
await TransactionHelper.withTransaction(async (client) => {
  for (const item of items) {
    await client.query('INSERT INTO items (sku, name) VALUES ($1, $2)', [item.sku, item.name])
  }
})
```

---

## Testing

### Unit Test Example

```typescript
import { TransactionHelper } from '@/lib/database/transaction-helper'

describe('TransactionHelper', () => {
  it('should rollback on error', async () => {
    await expect(async () => {
      await TransactionHelper.withTransaction(async (client) => {
        await client.query('INSERT INTO test_users (id, name) VALUES (999, $1)', ['Test'])
        throw new Error('Intentional error')
      })
    }).rejects.toThrow('Intentional error')

    // Verify rollback
    const result = await pool.query('SELECT * FROM test_users WHERE id = 999')
    expect(result.rows.length).toBe(0)
  })
})
```

---

## Migration Checklist

When converting existing code:

- [ ] Replace `pool.query('BEGIN')` with `TransactionHelper.withTransaction()`
- [ ] Replace `pool.query()` with `client.query()` inside transaction
- [ ] Remove manual BEGIN/COMMIT/ROLLBACK
- [ ] Remove try/catch/finally for connection management
- [ ] Keep error handling for business logic
- [ ] Test transaction rollback scenarios
- [ ] Verify no connection leaks under load

---

## Quick Reference Card

| Operation | Method | Use Case |
|-----------|--------|----------|
| Atomic transaction | `withTransaction(callback)` | CREATE, UPDATE, DELETE operations |
| Read-only query | `withClient(callback)` | SELECT queries, no transaction needed |
| Nested transaction | `withSavepoint(client, name, callback)` | Optional operations within transaction |
| Parallel queries | `parallel(client, operations)` | Multiple independent SELECTs |
| Direct pool access | `getPool()` | Read-only, non-critical queries |

---

## Need Help?

**Documentation:**
- Full API: `/src/lib/database/transaction-helper.ts`
- This guide: `/claudedocs/transaction-helper-quick-reference.md`
- Complete report: `/claudedocs/transaction-management-fixes-report.md`

**Common Issues:**
- Transaction timeout → Batch operations, reduce work in transaction
- Deadlock → Use consistent lock order, avoid long transactions
- Connection leak → Always use TransactionHelper, never manual pool.connect()

---

**Last Updated:** 2025-09-30