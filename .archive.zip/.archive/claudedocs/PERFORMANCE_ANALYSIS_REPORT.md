# PERFORMANCE ANALYSIS REPORT
## MantisNXT Database Connection Pool & Query Optimization

**Analysis Date:** 2025-09-30
**Database:** PostgreSQL @ 62.169.20.53:6600
**Current Environment:** Development with production database
**Critical Issue:** Pool showing 100% utilization (1/1 connections in previous reports)

---

## EXECUTIVE SUMMARY

### Critical Findings
1. **Pool Configuration Mismatch** - Current pool size (max: 20, min: 5) significantly exceeds historical utilization (1/1), suggesting either:
   - Configuration was recently increased but issues persist
   - Connection leaks are exhausting the pool before it can grow
   - Slow queries are holding connections for extended periods

2. **N+1 Query Patterns Detected** - Multiple files exhibit sequential query execution in loops
3. **Missing Query Batching** - Batch operations execute queries sequentially rather than in parallel
4. **Direct Pool Access** - 226 instances of direct `pool.connect()` usage across 111 files
5. **Extensive Indexing** - 468 indexes exist, but query patterns may not leverage them optimally

### Performance Impact
- **Connection Exhaustion Risk**: HIGH - System cannot handle concurrent load
- **Query Performance**: MEDIUM - Some N+1 patterns, mostly well-structured queries
- **Resource Utilization**: HIGH - Pool configuration vs actual usage mismatch
- **Scalability**: LOW - Current architecture cannot scale beyond minimal concurrent users

---

## 1. CONNECTION POOL BOTTLENECK ANALYSIS

### Current Configuration
**Location:** `/mnt/k/00Project/MantisNXT/lib/database/enterprise-connection-manager.ts:14-56`

```typescript
// Environment-aware configuration
const getEnvironmentConfig = (): PoolConfig => {
  return {
    // Connection Pool Settings
    max: isDevelopment ? 5 : parseInt(process.env.DB_POOL_MAX || '20'),     // Production: 20
    min: isDevelopment ? 1 : parseInt(process.env.DB_POOL_MIN || '5'),      // Production: 5

    // Timeout Configuration
    connectionTimeoutMillis: parseInt(process.env.DB_POOL_CONNECTION_TIMEOUT || '30000'),  // 30s
    idleTimeoutMillis: parseInt(process.env.DB_POOL_IDLE_TIMEOUT || '300000'),           // 5min
    acquireTimeoutMillis: parseInt(process.env.DB_POOL_ACQUIRE_TIMEOUT || '45000'),      // 45s

    // Query Constraints
    query_timeout: 120000,        // 2 minutes
    statement_timeout: 90000,     // 90 seconds

    // Connection Lifecycle
    max_lifetime: 1800000,        // 30 minutes
    idle_in_transaction_session_timeout: 300000,  // 5 minutes
  };
};
```

**From .env.local:**
```bash
DB_POOL_MIN=5
DB_POOL_MAX=20
DB_POOL_IDLE_TIMEOUT=60000          # 60s (conflicts with code: 300000ms)
DB_POOL_CONNECTION_TIMEOUT=15000    # 15s (conflicts with code: 30000ms)
DB_POOL_ACQUIRE_TIMEOUT=20000       # 20s (conflicts with code: 45000ms)
```

### Configuration Issues

#### Issue 1: Environment Variable Override Inconsistency
**Severity:** HIGH
**Location:** enterprise-connection-manager.ts:14-56

**Problem:**
- Code defaults (30s, 300s, 45s) differ from .env.local values (15s, 60s, 20s)
- Environment variables may not be loading correctly
- Actual runtime configuration unclear

**Impact:**
- Aggressive timeouts (15s) may cause premature failures
- Short idle timeout (60s) causes excessive connection churn
- Connection acquisition failures under load

**Recommendation:**
```typescript
// Validate environment variables and log actual configuration
const config = {
  max: parseInt(process.env.DB_POOL_MAX || '20'),
  min: parseInt(process.env.DB_POOL_MIN || '5'),
  connectionTimeoutMillis: parseInt(process.env.DB_POOL_CONNECTION_TIMEOUT || '30000'),
  idleTimeoutMillis: parseInt(process.env.DB_POOL_IDLE_TIMEOUT || '300000'),
  acquireTimeoutMillis: parseInt(process.env.DB_POOL_ACQUIRE_TIMEOUT || '45000'),
};

console.log('📊 Pool Configuration:', {
  max: config.max,
  min: config.min,
  connectionTimeout: `${config.connectionTimeoutMillis}ms`,
  idleTimeout: `${config.idleTimeoutMillis}ms`,
  acquireTimeout: `${config.acquireTimeoutMillis}ms`
});
```

#### Issue 2: Optimal Pool Size Analysis
**Severity:** HIGH
**Current:** max: 20, min: 5

**Analysis:**
Based on application workload characteristics:
- **Application Type:** Web application with real-time features
- **Expected Concurrent Users:** Unknown (needs monitoring)
- **Database Server Capacity:** PostgreSQL supports 100+ connections typically
- **Query Complexity:** Mix of simple and complex queries (up to 120s timeout)
- **Transaction Duration:** 5-minute idle transaction timeout suggests long-running operations

**Recommended Configuration:**

```bash
# Optimal Pool Configuration (Update .env.local)

# For Development Environment (low concurrency)
DB_POOL_MIN=2
DB_POOL_MAX=10
DB_POOL_IDLE_TIMEOUT=180000        # 3 minutes (reduced from 5min)
DB_POOL_CONNECTION_TIMEOUT=30000   # 30 seconds
DB_POOL_ACQUIRE_TIMEOUT=45000      # 45 seconds

# For Production Environment (moderate concurrency)
# DB_POOL_MIN=5
# DB_POOL_MAX=20
# DB_POOL_IDLE_TIMEOUT=300000      # 5 minutes
# DB_POOL_CONNECTION_TIMEOUT=30000 # 30 seconds
# DB_POOL_ACQUIRE_TIMEOUT=45000    # 45 seconds

# For High-Concurrency Production (>50 concurrent users)
# DB_POOL_MIN=10
# DB_POOL_MAX=40
# DB_POOL_IDLE_TIMEOUT=300000      # 5 minutes
# DB_POOL_CONNECTION_TIMEOUT=30000 # 30 seconds
# DB_POOL_ACQUIRE_TIMEOUT=60000    # 60 seconds
```

**Justification:**
- **Development (max: 10):** Matches typical concurrent request pattern (3-5 simultaneous requests + buffer)
- **Production (max: 20):** Current setting is reasonable for 10-15 concurrent users
- **High-Concurrency (max: 40):** For scaling beyond 50 concurrent users
- **Min connections:** Set to 25% of max to maintain warm connections without waste

#### Issue 3: Connection Lifecycle Issues
**Severity:** MEDIUM
**Location:** Multiple repository files

**Problem Pattern - Direct Pool Access:**
```typescript
// ❌ BAD: Direct pool.connect() usage (226 instances across codebase)
const client = await this.pool.connect()
try {
  await client.query('BEGIN')
  // ... operations ...
  await client.query('COMMIT')
} finally {
  client.release()
}
```

**Impact:**
- Manual connection management prone to leaks
- No automatic retry on transient failures
- Difficult to track connection lifecycle
- 226 potential leak points

**Files Affected (Sample):**
- `/src/lib/suppliers/core/SupplierRepository.ts` (heavy usage: lines 45, 74, 99, 185, 286, 340, 371)
- `/src/lib/api/suppliers.ts` (lines 121, 172, 237)
- `/src/app/api/inventory/route.ts`
- 108 additional files with database queries

**Recommendation:**
Use enterprise manager's query methods (already available):
```typescript
// ✅ GOOD: Use enterprise manager methods
import { query, withTransaction } from '@/lib/database';

// For read queries
const result = await query<Supplier>('SELECT * FROM suppliers WHERE id = $1', [id]);

// For transactions
await withTransaction(async (client) => {
  await client.query('INSERT INTO suppliers ...');
  await client.query('INSERT INTO supplier_contacts ...');
  // Automatic commit/rollback
});
```

---

## 2. SLOW QUERY ANALYSIS

### Query Execution Patterns

#### Pattern 1: N+1 Query Problem
**Severity:** HIGH
**Location:** `/src/lib/suppliers/core/SupplierRepository.ts`

**Problem - Sequential Batch Operations:**
```typescript
// ❌ BAD: N+1 pattern in createMany (lines 311-319)
async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
  const results: Supplier[] = []

  for (const supplierData of data) {
    const supplier = await this.create(supplierData)  // Each iteration acquires connection
    results.push(supplier)
  }

  return results
}

// Similar patterns in:
// - updateMany() lines 322-330
// - deleteMany() lines 333-337
```

**Impact:**
- For 10 suppliers: 10 sequential transactions holding connections
- Total time: 10 × (query_time + connection_acquire_time)
- Connection pool exhaustion under load
- Each create() operation includes 4-6 queries in a transaction

**Expected Performance:**
- Per-supplier transaction time: ~200-500ms
- 10 suppliers sequential: 2-5 seconds total
- Pool utilization: 1 connection held for entire duration

**Recommendation:**
```typescript
// ✅ GOOD: Batch insertion with single transaction
async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
  return await withTransaction(async (client) => {
    const results: Supplier[] = [];

    // Use Promise.all for parallel operations where possible
    // Or optimize with bulk INSERT using unnest
    const insertQuery = `
      INSERT INTO suppliers (name, code, legal_name, ...)
      SELECT * FROM unnest($1::text[], $2::text[], $3::text[], ...)
      RETURNING id
    `;

    const ids = await client.query(insertQuery, [
      data.map(d => d.name),
      data.map(d => d.code),
      data.map(d => d.legalName),
      // ... other fields
    ]);

    // Batch insert contacts and addresses
    // ... similar pattern

    return results;
  });
}
```

**Expected Improvement:**
- Single transaction: ~500ms-1s total (vs 2-5s)
- 60-80% reduction in total execution time
- Pool held for 1/10th the duration
- 4-5x throughput improvement

#### Pattern 2: Sequential Contact/Address Insertion
**Severity:** MEDIUM
**Location:** `/src/lib/suppliers/core/SupplierRepository.ts:124-156`

**Problem:**
```typescript
// ❌ BAD: Sequential inserts in loop (lines 124-139)
if (data.contacts && data.contacts.length > 0) {
  for (const contact of data.contacts) {
    await client.query(
      `INSERT INTO supplier_contacts (...)`,
      [supplierId, contact.type, contact.name, ...]
    )
  }
}

// Similar pattern for addresses (lines 141-156)
```

**Impact:**
- Each contact/address = separate round trip to database
- Network latency × number of items
- Transaction holds connection longer

**Recommendation:**
```typescript
// ✅ GOOD: Batch insert with unnest
if (data.contacts && data.contacts.length > 0) {
  await client.query(
    `INSERT INTO supplier_contacts (
      supplier_id, type, name, title, email, phone, mobile,
      department, is_primary, is_active, created_at
    )
    SELECT * FROM unnest(
      $1::uuid[], $2::text[], $3::text[], $4::text[],
      $5::text[], $6::text[], $7::text[], $8::text[],
      $9::boolean[], $10::boolean[], $11::timestamptz[]
    )`,
    [
      data.contacts.map(() => supplierId),
      data.contacts.map(c => c.type),
      data.contacts.map(c => c.name),
      data.contacts.map(c => c.title),
      data.contacts.map(c => c.email),
      data.contacts.map(c => c.phone),
      data.contacts.map(c => c.mobile),
      data.contacts.map(c => c.department),
      data.contacts.map(c => c.isPrimary),
      data.contacts.map(c => c.isActive),
      data.contacts.map(() => new Date()),
    ]
  );
}
```

**Expected Improvement:**
- 5 contacts: 5 round trips → 1 round trip
- 80-90% reduction in insertion time for contacts/addresses
- Reduced transaction duration

#### Pattern 3: Delete-Then-Insert Updates
**Severity:** MEDIUM
**Location:** `/src/lib/suppliers/core/SupplierRepository.ts:230-266`

**Problem:**
```typescript
// ❌ BAD: Delete all, then insert all (lines 230-246)
if (data.contacts) {
  await client.query('DELETE FROM supplier_contacts WHERE supplier_id = $1', [id])

  for (const contact of data.contacts) {
    await client.query(`INSERT INTO supplier_contacts (...)`, [...])
  }
}
```

**Impact:**
- Deletes all contacts even if only 1 changed
- Regenerates all IDs, breaking any external references
- More database writes than necessary
- Inefficient for minor updates

**Recommendation:**
```typescript
// ✅ GOOD: Upsert pattern or selective update
if (data.contacts) {
  // Option 1: UPSERT (PostgreSQL 9.5+)
  await client.query(`
    INSERT INTO supplier_contacts (id, supplier_id, ...)
    VALUES (unnest($1::uuid[]), $2, ...)
    ON CONFLICT (id) DO UPDATE SET
      name = EXCLUDED.name,
      email = EXCLUDED.email,
      updated_at = NOW()
  `, [...]);

  // Option 2: Selective delete + insert only new records
  const existingIds = data.contacts.filter(c => c.id).map(c => c.id);
  const newContacts = data.contacts.filter(c => !c.id);

  // Delete only removed contacts
  await client.query(
    `DELETE FROM supplier_contacts
     WHERE supplier_id = $1 AND id != ALL($2)`,
    [id, existingIds]
  );

  // Update existing
  // Insert new only
}
```

**Expected Improvement:**
- 50-70% reduction in write operations for updates
- Preserves IDs for external references
- Better audit trail

#### Pattern 4: Complex JOIN Queries
**Severity:** LOW (Well-Optimized)
**Location:** `/src/lib/suppliers/core/SupplierRepository.ts:47-59`

**Current Implementation:**
```typescript
// ✅ GOOD: Well-structured query with proper JOINs
const query = `
  SELECT
    s.*,
    json_agg(DISTINCT sc.*) FILTER (WHERE sc.id IS NOT NULL) as contacts,
    json_agg(DISTINCT sa.*) FILTER (WHERE sa.id IS NOT NULL) as addresses,
    json_agg(DISTINCT sp.*) FILTER (WHERE sp.id IS NOT NULL) as performance_data
  FROM suppliers s
  LEFT JOIN supplier_contacts sc ON s.id = sc.supplier_id AND sc.is_active = true
  LEFT JOIN supplier_addresses sa ON s.id = sa.supplier_id AND sa.is_active = true
  LEFT JOIN supplier_performance sp ON s.id = sp.supplier_id
  WHERE s.id = $1
  GROUP BY s.id
`
```

**Analysis:**
- ✅ Single query to fetch related data (no N+1)
- ✅ Uses json_agg for aggregation (PostgreSQL-optimized)
- ✅ Filtered JOINs (is_active = true)
- ✅ Proper indexing should support this query

**Potential Optimization:**
Add composite indexes if not present (check migration files):
```sql
-- Check if these exist in 0009_indexes_perf.sql or 0012_inventory_performance_indexes.sql
CREATE INDEX IF NOT EXISTS idx_supplier_contacts_supplier_active
ON supplier_contacts(supplier_id, is_active) WHERE is_active = true;

CREATE INDEX IF NOT EXISTS idx_supplier_addresses_supplier_active
ON supplier_addresses(supplier_id, is_active) WHERE is_active = true;

CREATE INDEX IF NOT EXISTS idx_supplier_performance_supplier
ON supplier_performance(supplier_id);
```

#### Pattern 5: Analytics Service Sequential Processing
**Severity:** MEDIUM
**Location:** `/src/lib/analytics/analytics-service.ts:105-138`

**Problem:**
```typescript
// ❌ MEDIUM: Sequential processing in loop (lines 105-138)
for (const supplier of suppliersResult.rows) {
  const supplierPerformance = performanceResult.rows.filter(
    p => p.supplier_id === supplier.id
  );

  if (supplierPerformance.length > 0) {
    // Generate performance prediction (CPU-bound, not I/O)
    const prediction = mlModels.supplierPredictor.predictPerformance(
      supplier.id,
      supplierPerformance,
      supplierPerformance[0]
    );

    const riskScore = this.calculateSupplierRiskScore(...);
    const supplierRecommendations = this.generateSupplierRecommendations(...);

    predictions.push(prediction);
    riskScores.push(riskScore);
    recommendations.push(...supplierRecommendations);
  }
}
```

**Impact:**
- CPU-bound operations executed sequentially
- No database connection held (good!)
- Missed parallelization opportunity for ML calculations

**Recommendation:**
```typescript
// ✅ BETTER: Parallel processing of CPU-bound operations
const analysisPromises = suppliersResult.rows.map(async (supplier) => {
  const supplierPerformance = performanceResult.rows.filter(
    p => p.supplier_id === supplier.id
  );

  if (supplierPerformance.length === 0) return null;

  // Parallelize CPU-bound operations
  const [prediction, riskScore] = await Promise.all([
    mlModels.supplierPredictor.predictPerformance(
      supplier.id,
      supplierPerformance,
      supplierPerformance[0]
    ),
    this.calculateSupplierRiskScore(
      supplier.id,
      supplierPerformance,
      prediction // Note: This creates a dependency, may need to sequence
    )
  ]);

  const recommendations = this.generateSupplierRecommendations(
    supplier,
    riskScore,
    prediction
  );

  return { prediction, riskScore, recommendations };
});

const results = await Promise.all(analysisPromises);
// Filter nulls and aggregate
```

**Expected Improvement:**
- 40-60% reduction in total processing time
- Better CPU utilization
- No change in database load (already fetching all data upfront)

---

## 3. DATABASE ACCESS PATTERN OPTIMIZATION

### Pattern Analysis Summary

| Pattern | Severity | Files | Impact | Fix Priority |
|---------|----------|-------|--------|--------------|
| Direct pool.connect() | HIGH | 111 files | Connection leaks, no retry | P0 - Immediate |
| N+1 in batch operations | HIGH | SupplierRepository | 4-5x slower bulk operations | P0 - Immediate |
| Sequential inserts | MEDIUM | SupplierRepository | 2-3x slower inserts | P1 - High |
| Delete-then-insert updates | MEDIUM | SupplierRepository | 2x unnecessary writes | P2 - Medium |
| Sequential ML processing | MEDIUM | analytics-service | 2x slower analytics | P2 - Medium |
| Complex JOINs | LOW | SupplierRepository | Already optimized | P3 - Monitor |

### Repository Pattern Issues

#### Issue 1: PostgreSQLSupplierRepository Constructor
**Location:** `/src/lib/suppliers/core/SupplierRepository.ts:41-42`

**Problem:**
```typescript
export class PostgreSQLSupplierRepository implements SupplierRepository {
  constructor(private pool: Pool) {}  // Requires Pool injection

  async findById(id: string): Promise<Supplier | null> {
    const client = await this.pool.connect()  // Direct pool access
    // ...
  }
}
```

**Issue:**
- Requires Pool injection, creating tight coupling
- All methods use `pool.connect()` directly
- No use of enterprise manager's automatic retry
- No use of circuit breaker

**Recommendation:**
```typescript
// ✅ BETTER: Use enterprise manager functions
import { query, withTransaction } from '@/lib/database';

export class PostgreSQLSupplierRepository implements SupplierRepository {
  // No constructor needed - use global query functions

  async findById(id: string): Promise<Supplier | null> {
    const queryText = `
      SELECT s.*, /* ... json_agg ... */
    `;

    const result = await query<any>(queryText, [id]);

    if (result.rows.length === 0) return null;
    return this.mapRowToSupplier(result.rows[0]);
  }

  async create(data: CreateSupplierData): Promise<Supplier> {
    return await withTransaction(async (client) => {
      // All operations within single transaction
      const supplierResult = await client.query(/* ... */);
      const supplierId = supplierResult.rows[0].id;

      // Batch insert contacts
      if (data.contacts?.length > 0) {
        await client.query(/* bulk insert */);
      }

      // Batch insert addresses
      if (data.addresses?.length > 0) {
        await client.query(/* bulk insert */);
      }

      // Return created supplier
      const created = await client.query(/* fetch with joins */);
      return this.mapRowToSupplier(created.rows[0]);
    });
  }
}
```

**Benefits:**
- ✅ Automatic retry on transient failures
- ✅ Circuit breaker protection
- ✅ Consistent timeout handling
- ✅ Better logging and monitoring
- ✅ No Pool injection required
- ✅ Reduced connection leak risk

#### Issue 2: SupplierAPI Uses Old Pool Pattern
**Location:** `/src/lib/api/suppliers.ts`

**Problem:**
```typescript
import { pool } from '@/lib/database'  // Old pool import

export class SupplierAPI {
  static async getSuppliers(filters?: SupplierSearchFilters): Promise<Supplier[]> {
    try {
      const result = await pool.query(query, params)  // Direct pool.query
      return result.rows.map(row => this.mapRowToSupplier(row))
    } catch (error) {
      console.error('Error fetching suppliers:', error)
      throw new Error('Failed to fetch suppliers')  // Generic error
    }
  }

  static async createSupplier(data: CreateSupplierData): Promise<Supplier> {
    const client = await pool.connect()  // Manual connection management
    try {
      await client.query('BEGIN')
      // ... operations ...
      await client.query('COMMIT')
      return createdSupplier
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }
}
```

**Issues:**
- Uses deprecated `pool` import
- Manual transaction management prone to errors
- No retry logic
- Generic error handling loses important details

**Recommendation:**
```typescript
import { query, withTransaction } from '@/lib/database'

export class SupplierAPI {
  static async getSuppliers(filters?: SupplierSearchFilters): Promise<Supplier[]> {
    // Simple queries use query() directly
    const result = await query<any>(queryText, params);
    return result.rows.map(row => this.mapRowToSupplier(row));
  }

  static async createSupplier(data: CreateSupplierData): Promise<Supplier> {
    // Transactions use withTransaction
    return await withTransaction(async (client) => {
      const supplierResult = await client.query(/* ... */);
      const supplierId = supplierResult.rows[0].id;
      // ... other operations ...

      // Fetch and return
      const created = await client.query(/* ... */);
      return this.mapRowToSupplier(created.rows[0]);
    });
    // Automatic commit/rollback, no finally needed
  }
}
```

### Connection-Hungry Code Patterns

#### Pattern 1: Loop with Queries (N+1)
**Files Affected:**
- `/src/lib/suppliers/core/SupplierRepository.ts` (createMany, updateMany, deleteMany)

**Already covered in Section 2 - Pattern 1**

#### Pattern 2: Separate Queries Instead of Joins
**Location:** `/src/lib/api/suppliers.ts:264-298`

**Problem:**
```typescript
static async getDashboardMetrics(): Promise<DashboardMetrics> {
  // ❌ BAD: 4 separate queries that could be combined
  const countsResult = await pool.query(`SELECT COUNT(*) ...`)

  const performanceResult = await pool.query(`SELECT AVG(...) FROM supplier_performance`)

  const financialResult = await pool.query(`SELECT SUM(...) FROM supplier_performance`)

  const contractsResult = await pool.query(`SELECT COUNT(...) FROM supplier_contracts ...`)

  // Combine results
  return { ... }
}
```

**Impact:**
- 4 separate queries acquire/release connections
- 4x network round trips
- Could be optimized to 1-2 queries

**Recommendation:**
```typescript
static async getDashboardMetrics(): Promise<DashboardMetrics> {
  // ✅ GOOD: Single query with CTEs
  const result = await query<any>(`
    WITH supplier_counts AS (
      SELECT
        COUNT(*) as total_suppliers,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_suppliers,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_approvals
      FROM suppliers
    ),
    performance_metrics AS (
      SELECT
        AVG(overall_rating) as avg_performance_rating,
        AVG(on_time_delivery_rate) as on_time_delivery_rate,
        AVG(quality_acceptance_rate) as quality_acceptance_rate,
        COALESCE(SUM(total_purchase_value), 0) as total_purchase_value
      FROM supplier_performance
    ),
    contract_counts AS (
      SELECT COUNT(*) as contracts_expiring_soon
      FROM supplier_contracts
      WHERE status = 'active'
      AND end_date BETWEEN NOW() AND NOW() + INTERVAL '30 days'
    )
    SELECT * FROM supplier_counts, performance_metrics, contract_counts
  `);

  const row = result.rows[0];
  return {
    totalSuppliers: parseInt(row.total_suppliers) || 0,
    activeSuppliers: parseInt(row.active_suppliers) || 0,
    // ... map other fields
  };
}
```

**Expected Improvement:**
- 75% reduction in queries (4 → 1)
- 60-70% faster execution (eliminate network latency)
- Single connection acquire/release

---

## 4. PERFORMANCE OPTIMIZATION ROADMAP

### Immediate Fixes (Week 1) - P0 Priority

#### Fix 1: Correct Environment Variable Loading
**File:** `/mnt/k/00Project/MantisNXT/.env.local`
**Impact:** HIGH - Fixes timeout inconsistencies

**Action:**
```bash
# Update .env.local with consistent values
DB_POOL_MIN=2
DB_POOL_MAX=10
DB_POOL_IDLE_TIMEOUT=180000        # 3 minutes (align with code or vice versa)
DB_POOL_CONNECTION_TIMEOUT=30000   # 30 seconds
DB_POOL_ACQUIRE_TIMEOUT=45000      # 45 seconds

# Add logging to verify
DB_LOG_POOL_CONFIG=true
```

**File:** `/mnt/k/00Project/MantisNXT/lib/database/enterprise-connection-manager.ts`

**Add configuration logging:**
```typescript
const config = getEnvironmentConfig();

if (process.env.DB_LOG_POOL_CONFIG === 'true') {
  console.log('🔧 Database Pool Configuration:', {
    environment: process.env.NODE_ENV,
    pool: {
      min: config.min,
      max: config.max,
      connectionTimeout: `${config.connectionTimeoutMillis}ms`,
      idleTimeout: `${config.idleTimeoutMillis}ms`,
      acquireTimeout: `${config.acquireTimeoutMillis}ms`,
    },
    query: {
      queryTimeout: `${config.query_timeout}ms`,
      statementTimeout: `${config.statement_timeout}ms`,
    },
    lifecycle: {
      maxLifetime: `${config.max_lifetime}ms`,
      idleInTransactionTimeout: `${config.idle_in_transaction_session_timeout}ms`,
    }
  });
}
```

**Expected Improvement:**
- Eliminates timeout confusion
- Consistent behavior across environments
- Better observability

#### Fix 2: Refactor SupplierRepository Batch Operations
**File:** `/mnt/k/00Project/MantisNXT/src/lib/suppliers/core/SupplierRepository.ts`
**Impact:** HIGH - 4-5x throughput improvement

**Specific changes:**
1. **createMany() - lines 311-319**
2. **updateMany() - lines 322-330**
3. **deleteMany() - lines 333-337**

**Implementation:**
```typescript
// Replace createMany
async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
  if (data.length === 0) return [];

  return await withTransaction(async (client) => {
    // Bulk insert suppliers
    const supplierValues = data.map((d, idx) => {
      const offset = idx * 16;
      return `($${offset+1}, $${offset+2}, $${offset+3}, /* ... */, NOW(), NOW())`;
    }).join(',');

    const supplierParams = data.flatMap(d => [
      d.name, d.code, d.legalName, d.website, d.industry,
      d.tier, d.status, d.category, d.subcategory, d.tags,
      d.taxId, d.registrationNumber, d.foundedYear, d.employeeCount,
      d.annualRevenue, d.currency
    ]);

    const supplierQuery = `
      INSERT INTO suppliers (name, code, legal_name, /* ... */, created_at, updated_at)
      VALUES ${supplierValues}
      RETURNING id
    `;

    const supplierResult = await client.query(supplierQuery, supplierParams);
    const supplierIds = supplierResult.rows.map(r => r.id);

    // Bulk insert contacts for all suppliers
    const allContacts = data.flatMap((d, idx) =>
      (d.contacts || []).map(c => ({ ...c, supplierId: supplierIds[idx] }))
    );

    if (allContacts.length > 0) {
      // Use unnest for bulk insert (shown in Section 2)
      await client.query(/* bulk contact insert */);
    }

    // Similar for addresses and performance records

    // Fetch all created suppliers with single query
    const created = await client.query(`
      SELECT s.*, /* json_agg ... */
      WHERE s.id = ANY($1)
      GROUP BY s.id
    `, [supplierIds]);

    return created.rows.map(row => this.mapRowToSupplier(row));
  });
}

// Similar optimizations for updateMany and deleteMany
```

**Expected Improvement:**
- 10 suppliers: 2-5s → 500ms-1s (4-5x faster)
- Single transaction vs 10 sequential
- Pool freed 4-5x faster

#### Fix 3: Optimize Contact/Address Insertion
**File:** `/mnt/k/00Project/MantisNXT/src/lib/suppliers/core/SupplierRepository.ts`
**Lines:** 124-156 (create), 230-266 (update)

**Implementation:** See Section 2, Pattern 2 & 3 for detailed code

**Expected Improvement:**
- 80-90% reduction in insertion time
- 50-70% reduction in update writes

### Short-Term Optimizations (Week 2-3) - P1 Priority

#### Optimization 1: Migrate SupplierAPI to Enterprise Manager
**File:** `/mnt/k/00Project/MantisNXT/src/lib/api/suppliers.ts`
**Impact:** MEDIUM - Consistency and reliability

**Actions:**
1. Replace all `pool.query()` with `query()` from enterprise manager
2. Replace all manual transaction management with `withTransaction()`
3. Combine multi-query operations (getDashboardMetrics)

**Expected Improvement:**
- Automatic retry on transient failures
- Circuit breaker protection
- 60-70% faster dashboard metrics (4 queries → 1)

#### Optimization 2: Add Missing Composite Indexes
**File:** New migration file
**Impact:** MEDIUM - Query performance

**Check if these indexes exist (may be in migrations already):**
```sql
-- Verify in migrations/0009_indexes_perf.sql or 0012_inventory_performance_indexes.sql
-- Add if missing:

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_supplier_contacts_supplier_active
ON supplier_contacts(supplier_id, is_active)
WHERE is_active = true;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_supplier_addresses_supplier_active
ON supplier_addresses(supplier_id, is_active)
WHERE is_active = true;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_supplier_performance_supplier
ON supplier_performance(supplier_id);

-- For suppliers table queries in api/suppliers.ts
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_suppliers_search_composite
ON suppliers(name, supplier_code, company_name)
WHERE status != 'deleted';  -- Partial index for active records
```

**Note:** Review existing 468 indexes to ensure these aren't duplicates

**Expected Improvement:**
- 20-40% faster findById queries
- 30-50% faster search queries

#### Optimization 3: Parallelize Analytics ML Processing
**File:** `/mnt/k/00Project/MantisNXT/src/lib/analytics/analytics-service.ts`
**Lines:** 105-138, 184-196

**Implementation:** See Section 2, Pattern 5

**Expected Improvement:**
- 40-60% reduction in analytics processing time
- No change in database load

### Medium-Term Improvements (Month 2) - P2 Priority

#### Improvement 1: Implement Read Replicas
**Impact:** HIGH for read-heavy workloads

**Strategy:**
```typescript
// Add read replica configuration
const READ_REPLICA_URL = process.env.DATABASE_READ_REPLICA_URL;

// Modify enterprise-connection-manager.ts
class DatabaseConnectionManager {
  private readPool: Pool | null = null;

  // Add read-only query method
  public async queryReadOnly<T = any>(text: string, params?: any[]) {
    const pool = this.readPool || this.pool;  // Fallback to primary
    // ... same as query() but uses read replica
  }
}

// Usage in repositories
async findMany(filters: SupplierFilters): Promise<SupplierSearchResult> {
  // Use read replica for read-only queries
  const result = await queryReadOnly<any>(queryText, params);
  // ...
}
```

**Benefits:**
- Offload read queries (90%+ of queries) from primary
- Primary focuses on writes only
- Better scalability

#### Improvement 2: Implement Query Result Caching
**Impact:** MEDIUM - Reduces database load

**Strategy:**
```typescript
import NodeCache from 'node-cache';

const queryCache = new NodeCache({
  stdTTL: 300,  // 5 minutes
  checkperiod: 60,
  useClones: false
});

// Add to query function
export const queryCached = async <T = any>(
  text: string,
  params?: any[],
  ttl: number = 300
) => {
  const cacheKey = `query:${hash(text + JSON.stringify(params))}`;

  const cached = queryCache.get<{ rows: T[]; rowCount: number }>(cacheKey);
  if (cached) {
    console.log(`🎯 Cache hit: ${cacheKey}`);
    return cached;
  }

  const result = await query<T>(text, params);
  queryCache.set(cacheKey, result, ttl);
  return result;
};

// Usage for frequently accessed, rarely changing data
const suppliers = await queryCached<Supplier>(
  'SELECT * FROM suppliers WHERE status = $1',
  ['active'],
  600  // 10 minutes
);
```

**Use Cases:**
- Dashboard metrics (updated every 5-10 minutes)
- Supplier lists (updated on create/update/delete)
- Category/tier filters (static data)

**Expected Improvement:**
- 50-80% reduction in repeated queries
- 90%+ faster response for cached data

#### Improvement 3: Add Connection Pool Monitoring
**Impact:** MEDIUM - Observability

**Implementation:**
```typescript
// Add to enterprise-connection-manager.ts
class DatabaseConnectionManager {
  private metrics = {
    queriesExecuted: 0,
    transactionsExecuted: 0,
    averageQueryTime: 0,
    slowQueries: [] as Array<{ query: string; duration: number; timestamp: Date }>,
    poolExhaustedCount: 0,
    circuitBreakerTrips: 0
  };

  // Enhanced monitoring in health check
  private startHealthMonitoring(): void {
    this.healthCheck = setInterval(async () => {
      const status = this.getPoolStatus();

      // Log detailed metrics
      console.log('📊 Database Metrics:', {
        pool: {
          utilization: `${status.active}/${status.total} (${(status.active/status.total*100).toFixed(1)}%)`,
          waiting: status.waiting,
          idle: status.idle
        },
        performance: {
          queriesExecuted: this.metrics.queriesExecuted,
          avgQueryTime: `${this.metrics.averageQueryTime.toFixed(2)}ms`,
          slowQueries: this.metrics.slowQueries.length
        },
        reliability: {
          circuitBreakerTrips: this.metrics.circuitBreakerTrips,
          poolExhausted: this.metrics.poolExhaustedCount
        }
      });

      // Alert on issues
      if (status.active >= status.total * 0.9) {
        console.error('🚨 ALERT: Pool near exhaustion');
        // Send alert to monitoring system
      }
    }, 30000);
  }
}
```

**Benefits:**
- Early detection of pool exhaustion
- Identify slow queries
- Track circuit breaker effectiveness

### Long-Term Enhancements (Quarter 2) - P3 Priority

#### Enhancement 1: Implement Connection Pooling at Load Balancer
**Impact:** HIGH for horizontal scaling

**Strategy:**
- Use PgBouncer or similar connection pooler
- Application pools connect to PgBouncer (100s of connections)
- PgBouncer maintains smaller pool to PostgreSQL (20-50 connections)
- Transaction-level pooling for better utilization

#### Enhancement 2: Database Partitioning for Large Tables
**Impact:** HIGH for tables >10M rows

**Current State:**
- Already implemented for time-series tables (ai_message, customer_interaction, etc.)
- Review `migrations/0009_indexes_perf.sql` for partition strategy

**Additional Candidates:**
- audit_log (if grows beyond 10M records)
- stock_movements (high-volume transaction table)
- notification (time-based partitioning)

#### Enhancement 3: Query Performance Baselines
**Impact:** MEDIUM - Ongoing optimization

**Strategy:**
1. Enable pg_stat_statements extension
2. Set up automated slow query logging
3. Monthly query performance reviews
4. Automated index recommendations

---

## 5. MONITORING RECOMMENDATIONS

### Key Metrics to Track

#### Pool Health Metrics
```typescript
// Add to /api/health/database endpoint
{
  poolStatus: {
    size: { current: 10, min: 2, max: 10 },
    utilization: { active: 3, idle: 7, waiting: 0 },
    utilizationPercent: 30,
    alerts: {
      highUtilization: false,  // >80%
      exhaustion: false,       // >95%
      waitQueue: false         // waiting > 2
    }
  },
  performance: {
    avgQueryTime: 45.2,  // ms
    p95QueryTime: 120.5, // ms
    p99QueryTime: 450.8, // ms
    slowQueries: 3,      // >1s in last hour
    queriesPerSecond: 42.5
  },
  reliability: {
    circuitBreakerStatus: 'closed',
    circuitBreakerTrips: 0,
    failedQueries: 0,
    retries: 5
  },
  connections: {
    totalAcquired: 1250,
    totalReleased: 1248,
    potentialLeaks: 2  // acquired - released
  }
}
```

#### Alert Thresholds
```yaml
critical_alerts:
  pool_exhaustion:
    condition: active >= total * 0.95
    action: Scale up pool size or investigate leaks

  wait_queue_buildup:
    condition: waiting > 5
    action: Investigate slow queries or connection leaks

  circuit_breaker_open:
    condition: circuit_breaker_open == true
    action: Database connectivity issue

warning_alerts:
  high_utilization:
    condition: active >= total * 0.8
    action: Monitor for scaling needs

  slow_queries:
    condition: query_time > 1000ms
    action: Review and optimize query

  connection_churn:
    condition: connections_per_second > 10
    action: Review connection pooling strategy
```

### Monitoring Dashboard Queries

#### Query 1: Pool Status Over Time
```sql
-- Add to system_metrics table
SELECT
  timestamp,
  metric_value->>'active' as active_connections,
  metric_value->>'waiting' as waiting_connections,
  metric_value->>'utilization_percent' as utilization
FROM system_metric
WHERE metric_name = 'database_pool_status'
AND timestamp > NOW() - INTERVAL '1 hour'
ORDER BY timestamp DESC;
```

#### Query 2: Slow Query Log
```sql
-- Enable pg_stat_statements
SELECT
  substring(query, 1, 100) as query_preview,
  calls,
  total_exec_time / 1000 as total_time_sec,
  mean_exec_time / 1000 as avg_time_ms,
  max_exec_time / 1000 as max_time_ms
FROM pg_stat_statements
WHERE mean_exec_time > 100  -- >100ms average
ORDER BY total_exec_time DESC
LIMIT 20;
```

#### Query 3: Connection Leak Detection
```sql
-- Monitor long-running queries
SELECT
  pid,
  usename,
  application_name,
  client_addr,
  state,
  query_start,
  NOW() - query_start as duration,
  wait_event_type,
  wait_event,
  substring(query, 1, 100) as query_preview
FROM pg_stat_activity
WHERE state != 'idle'
AND NOW() - query_start > INTERVAL '5 minutes'
ORDER BY query_start;
```

#### Query 4: Index Usage Analysis
```sql
-- Find unused indexes (potential cleanup candidates)
SELECT
  schemaname,
  tablename,
  indexname,
  idx_scan,
  pg_size_pretty(pg_relation_size(indexrelid)) as index_size
FROM pg_stat_user_indexes
WHERE schemaname = 'public'
AND idx_scan < 10  -- Less than 10 scans since stats reset
AND indexrelname NOT LIKE 'pg_%'  -- Exclude system indexes
ORDER BY pg_relation_size(indexrelid) DESC;
```

---

## 6. IMPLEMENTATION CHECKLIST

### Week 1 - Critical Fixes (P0)

- [ ] **Day 1-2: Environment Configuration**
  - [ ] Update .env.local with consistent timeout values
  - [ ] Add pool configuration logging
  - [ ] Test and verify configuration loading
  - [ ] Document final configuration values

- [ ] **Day 3-4: SupplierRepository Batch Operations**
  - [ ] Refactor createMany() to use single transaction + bulk insert
  - [ ] Refactor updateMany() to use single transaction + bulk update
  - [ ] Refactor deleteMany() to use single transaction + bulk delete
  - [ ] Add unit tests for batch operations
  - [ ] Performance test: measure before/after execution times

- [ ] **Day 5: Contact/Address Insertion Optimization**
  - [ ] Implement bulk insert for contacts using unnest
  - [ ] Implement bulk insert for addresses using unnest
  - [ ] Update create() method to use new bulk inserts
  - [ ] Update update() method to use upsert pattern
  - [ ] Test with 1, 5, 10, 50 contacts/addresses

### Week 2 - High Priority (P1)

- [ ] **SupplierAPI Migration**
  - [ ] Replace pool imports with enterprise manager imports
  - [ ] Refactor all getX() methods to use query()
  - [ ] Refactor all createX/updateX methods to use withTransaction()
  - [ ] Combine getDashboardMetrics() into single query with CTEs
  - [ ] Test all API endpoints

- [ ] **Index Verification**
  - [ ] Review existing indexes in migrations (0009, 0012)
  - [ ] Verify supplier_contacts and supplier_addresses composite indexes exist
  - [ ] Add missing indexes if needed (create new migration)
  - [ ] Run ANALYZE on affected tables
  - [ ] Measure query performance before/after

- [ ] **Analytics Optimization**
  - [ ] Parallelize ML processing in analyzeSupplierPerformance()
  - [ ] Parallelize ML processing in forecastInventoryDemand()
  - [ ] Test with 10, 50, 100 suppliers
  - [ ] Measure performance improvement

### Week 3 - Medium Priority (P2)

- [ ] **Monitoring Setup**
  - [ ] Add detailed metrics tracking to DatabaseConnectionManager
  - [ ] Create /api/health/database-detailed endpoint
  - [ ] Set up alert thresholds in monitoring system
  - [ ] Create Grafana dashboard for pool metrics
  - [ ] Enable pg_stat_statements extension

- [ ] **Query Caching**
  - [ ] Implement queryCached() function
  - [ ] Identify cacheable queries (dashboard, lists, static data)
  - [ ] Add cache invalidation on writes
  - [ ] Test cache hit rates
  - [ ] Monitor cache memory usage

### Month 2 - Long-Term (P3)

- [ ] **Read Replica Setup**
  - [ ] Provision read replica database
  - [ ] Add read pool to enterprise-connection-manager
  - [ ] Implement queryReadOnly() method
  - [ ] Migrate read-heavy queries to read replica
  - [ ] Monitor primary vs replica load distribution

- [ ] **Performance Baseline**
  - [ ] Set up pg_stat_statements monitoring
  - [ ] Create automated slow query reports
  - [ ] Establish performance SLAs
  - [ ] Schedule monthly performance reviews

---

## 7. SUCCESS METRICS

### Performance Targets

| Metric | Current | Target (Week 2) | Target (Month 2) |
|--------|---------|-----------------|------------------|
| Pool Utilization | Unknown (1/1 in reports) | <60% under normal load | <50% under normal load |
| Avg Query Time | Unknown | <50ms (reads) | <30ms (reads) |
| Batch Operation Time (10 items) | ~2-5s (estimated) | <1s | <500ms |
| Dashboard Metrics Query | 4 queries | 1 query | 1 query (cached) |
| Connection Acquisition Time | Unknown | <100ms | <50ms |
| Slow Queries (>1s) | Unknown | <5/hour | <2/hour |
| Pool Exhaustion Events | Unknown (frequent) | <1/day | <1/week |

### Reliability Targets

| Metric | Target |
|--------|--------|
| Connection Leak Rate | 0 leaks/day |
| Circuit Breaker Trips | <2/day |
| Query Retry Success Rate | >95% |
| Transaction Rollback Rate | <1% |
| Database Uptime | >99.9% |

### Code Quality Targets

| Metric | Current | Target |
|--------|---------|--------|
| Direct pool.connect() usage | 226 instances | <50 instances (migrate to enterprise manager) |
| N+1 Query Patterns | 3 identified | 0 |
| Files using old pool import | 111 files | <20 files |
| Query result caching | 0% | 40% of read queries |

---

## 8. RISK ASSESSMENT

### Migration Risks

| Risk | Severity | Mitigation |
|------|----------|------------|
| Breaking existing functionality during refactor | HIGH | Comprehensive unit tests before/after, gradual rollout |
| Performance regression from bulk operations | MEDIUM | Benchmark before/after, rollback plan ready |
| Connection pool exhaustion during migration | MEDIUM | Perform during low-traffic windows, monitor closely |
| Cache invalidation bugs | MEDIUM | Start with read-only caching, extensive testing |
| Read replica lag issues | LOW | Monitor replication lag, fallback to primary |

### Rollback Plans

#### For Each Major Change:
1. **Batch Operations Refactor**
   - Rollback: Keep old methods as `createManyLegacy()`, switch via feature flag
   - Test: Unit tests + performance benchmarks
   - Criteria: >20% performance improvement or rollback

2. **Pool Configuration Changes**
   - Rollback: Revert .env.local to previous values
   - Test: Monitor pool utilization for 24 hours
   - Criteria: <80% utilization or rollback

3. **Query Caching Implementation**
   - Rollback: Disable cache via feature flag
   - Test: Verify data freshness
   - Criteria: >90% cache accuracy or rollback

---

## 9. APPENDIX

### A. Configuration Reference

#### Optimal Pool Sizing Formula
```
Max Connections = (Number of CPU Cores × 2) + Number of Effective Spindles

For cloud environments:
Max Connections = Expected Concurrent Users × 0.5 to 1.0

Conservative Start:
Development: max = 10, min = 2
Production (small): max = 20, min = 5
Production (large): max = 40, min = 10
```

#### Timeout Configuration Guidelines
```
Connection Timeout:
  - Development: 15-30s
  - Production: 30-60s

Acquire Timeout:
  - Development: 20-45s
  - Production: 45-60s

Idle Timeout:
  - Development: 60-180s (1-3 minutes)
  - Production: 300-600s (5-10 minutes)

Query Timeout:
  - Simple reads: 5-10s
  - Complex analytics: 30-120s
  - Background jobs: 300-600s
```

### B. Query Optimization Patterns

#### Pattern 1: Bulk Insert with unnest
```sql
INSERT INTO table_name (col1, col2, col3)
SELECT * FROM unnest(
  $1::type1[],
  $2::type2[],
  $3::type3[]
)
```

#### Pattern 2: Upsert
```sql
INSERT INTO table_name (id, col1, col2)
VALUES (unnest($1::uuid[]), unnest($2::text[]), unnest($3::int[]))
ON CONFLICT (id) DO UPDATE SET
  col1 = EXCLUDED.col1,
  col2 = EXCLUDED.col2,
  updated_at = NOW()
```

#### Pattern 3: CTE for Complex Queries
```sql
WITH data_source AS (
  SELECT ...
),
aggregated AS (
  SELECT ... FROM data_source ...
)
SELECT * FROM aggregated
```

### C. Monitoring Queries

See Section 5 for complete monitoring query set.

### D. Index Strategy

Current state: 468 indexes across database schema
- Review existing indexes in `/migrations/0009_indexes_perf.sql`
- Additional indexes in `/migrations/0012_inventory_performance_indexes.sql`
- Consider index usage monitoring to identify unused indexes for cleanup

**Index Maintenance:**
```sql
-- Run quarterly
SELECT * FROM check_unused_indexes();

-- Remove indexes with <10 scans and significant size
-- Verify no production queries depend on them first

-- Rebuild fragmented indexes (>30% bloat)
REINDEX INDEX CONCURRENTLY index_name;

-- Update statistics monthly
SELECT analyze_inventory_tables();
```

---

## CONCLUSION

The MantisNXT database connection pool and query performance issues stem from several interconnected problems:

1. **Configuration Inconsistencies:** Environment variables may not be loading correctly, causing timeout mismatches
2. **Architecture Patterns:** Heavy use of direct pool access (226 instances) bypasses enterprise manager protections
3. **N+1 Query Patterns:** Batch operations execute sequentially, consuming connections 4-5x longer than necessary
4. **Missing Optimizations:** Several opportunities for query combining and bulk operations

**Immediate Priority:** Focus on P0 items (Week 1) to resolve the critical connection pool bottleneck:
- Fix environment configuration
- Refactor batch operations in SupplierRepository
- Optimize insert patterns

**Expected Overall Improvement:**
- 60-70% reduction in connection hold time
- 4-5x improvement in bulk operation throughput
- 50-80% reduction in repeated query load (with caching)
- Elimination of pool exhaustion under normal load

**Timeline:** 3-4 weeks for P0-P1 items, 2 months for complete optimization roadmap

**Next Steps:**
1. Review and approve this analysis
2. Prioritize fixes based on business impact
3. Begin Week 1 implementation
4. Set up monitoring to track improvements
5. Schedule performance review after Week 2

---

**Report Generated:** 2025-09-30
**Analysis Tool:** Claude Code Performance Engineer
**Database Version:** PostgreSQL (version TBD - check via `SELECT version()`)
**Application:** MantisNXT Supply Chain Management Platform