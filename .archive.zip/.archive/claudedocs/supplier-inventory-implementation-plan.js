const { Pool } = require('pg');

const dbConfig = {
  user: "nxtdb_admin",
  password: "P@33w0rd-1",
  host: "62.169.20.53",
  port: 6600,
  database: "nxtprod-db_001",
  ssl: false
};

const pool = new Pool(dbConfig);

async function createSupplierInventoryViews() {
  console.log('🚀 CREATING SUPPLIER INVENTORY MANAGEMENT VIEWS\n');

  const views = [
    {
      name: 'supplier_inventory_summary',
      description: 'Aggregated supplier inventory metrics',
      sql: `
        CREATE OR REPLACE VIEW supplier_inventory_summary AS
        SELECT
          s.id as supplier_id,
          s.name as supplier_name,
          s.supplier_code,
          s.status as supplier_status,
          s.performance_tier,
          COUNT(ii.id) as item_count,
          SUM(COALESCE(ii.stock_qty, 0)) as total_stock_qty,
          SUM(COALESCE(ii.available_qty, 0)) as total_available_qty,
          SUM(COALESCE(ii.stock_qty, 0) * COALESCE(ii.cost_price, 0)) as total_inventory_value,
          AVG(COALESCE(ii.stock_qty, 0)) as avg_stock_per_item,
          MIN(ii.created_at) as first_item_date,
          MAX(ii.updated_at) as last_inventory_update,
          COUNT(CASE WHEN COALESCE(ii.stock_qty, 0) = 0 THEN 1 END) as out_of_stock_items,
          COUNT(CASE WHEN COALESCE(ii.stock_qty, 0) <= COALESCE(ii.reorder_point, 0) THEN 1 END) as low_stock_items
        FROM suppliers s
        LEFT JOIN inventory_items ii ON s.id = ii.supplier_id
        WHERE s.status = 'active'
        GROUP BY s.id, s.name, s.supplier_code, s.status, s.performance_tier
        ORDER BY total_inventory_value DESC NULLS LAST;
      `
    },
    {
      name: 'in_stock_inventory_master',
      description: 'Master view of all in-stock inventory with supplier details',
      sql: `
        CREATE OR REPLACE VIEW in_stock_inventory_master AS
        SELECT
          ii.id as inventory_id,
          ii.sku,
          ii.name as product_name,
          ii.description,
          ii.category,
          ii.brand,
          ii.stock_qty,
          ii.available_qty,
          ii.reserved_qty,
          ii.reorder_point,
          ii.max_stock,
          ii.cost_price,
          ii.sale_price,
          ii.currency,
          ii.unit,
          ii.location,
          ii.status as inventory_status,
          ii.updated_at as last_stock_update,
          s.id as supplier_id,
          s.name as supplier_name,
          s.supplier_code,
          s.status as supplier_status,
          s.performance_tier,
          s.contact_person,
          s.email as supplier_email,
          s.phone as supplier_phone,
          (ii.stock_qty * ii.cost_price) as total_item_value,
          CASE
            WHEN ii.stock_qty > ii.reorder_point THEN 'adequate'
            WHEN ii.stock_qty > 0 AND ii.stock_qty <= ii.reorder_point THEN 'low_stock'
            WHEN ii.stock_qty = 0 THEN 'out_of_stock'
            ELSE 'unknown'
          END as stock_status_category,
          COALESCE(ii.tags, ARRAY[]::text[]) as tags
        FROM inventory_items ii
        JOIN suppliers s ON ii.supplier_id = s.id
        WHERE ii.status = 'active' AND s.status = 'active'
          AND COALESCE(ii.stock_qty, 0) > 0
        ORDER BY total_item_value DESC, ii.name;
      `
    },
    {
      name: 'supplier_inventory_performance',
      description: 'Supplier performance metrics focused on inventory management',
      sql: `
        CREATE OR REPLACE VIEW supplier_inventory_performance AS
        SELECT
          s.id as supplier_id,
          s.name as supplier_name,
          s.supplier_code,
          s.performance_tier,
          s.rating as overall_rating,
          COUNT(ii.id) as total_items,
          SUM(COALESCE(ii.stock_qty, 0) * COALESCE(ii.cost_price, 0)) as total_inventory_value,
          AVG(COALESCE(ii.cost_price, 0)) as avg_item_cost,
          COUNT(CASE WHEN COALESCE(ii.stock_qty, 0) = 0 THEN 1 END) as stockout_items,
          COUNT(CASE WHEN COALESCE(ii.stock_qty, 0) <= COALESCE(ii.reorder_point, 0) AND COALESCE(ii.stock_qty, 0) > 0 THEN 1 END) as low_stock_items,
          CASE
            WHEN COUNT(ii.id) = 0 THEN 0
            ELSE ROUND(
              (COUNT(ii.id) - COUNT(CASE WHEN COALESCE(ii.stock_qty, 0) = 0 THEN 1 END)) * 100.0 / COUNT(ii.id),
              2
            )
          END as stock_availability_percent,
          EXTRACT(DAYS FROM (CURRENT_TIMESTAMP - MAX(ii.updated_at))) as days_since_last_update,
          COUNT(DISTINCT ii.category) as category_diversity,
          s.spend_last_12_months,
          s.created_at as supplier_since
        FROM suppliers s
        LEFT JOIN inventory_items ii ON s.id = ii.supplier_id AND ii.status = 'active'
        WHERE s.status = 'active'
        GROUP BY s.id, s.name, s.supplier_code, s.performance_tier, s.rating, s.spend_last_12_months, s.created_at
        ORDER BY total_inventory_value DESC NULLS LAST;
      `
    },
    {
      name: 'inventory_supplier_detail',
      description: 'Detailed inventory information with full supplier context',
      sql: `
        CREATE OR REPLACE VIEW inventory_supplier_detail AS
        SELECT
          ii.id as inventory_id,
          ii.sku,
          ii.supplier_sku,
          ii.name as product_name,
          ii.description,
          ii.category,
          ii.brand,
          ii.stock_qty,
          ii.available_qty,
          ii.reserved_qty,
          ii.reorder_point,
          ii.max_stock,
          ii.cost_price,
          ii.sale_price,
          ii.currency,
          ii.unit,
          ii.weight,
          ii.dimensions,
          ii.barcode,
          ii.location,
          ii.tags,
          ii.images,
          ii.status as inventory_status,
          ii.notes as inventory_notes,
          ii.created_at as inventory_created,
          ii.updated_at as inventory_updated,
          s.id as supplier_id,
          s.name as supplier_name,
          s.supplier_code,
          s.email as supplier_email,
          s.phone as supplier_phone,
          s.address as supplier_address,
          s.contact_person,
          s.website as supplier_website,
          s.tax_id as supplier_tax_id,
          s.payment_terms,
          s.primary_category as supplier_category,
          s.performance_tier,
          s.rating as supplier_rating,
          s.status as supplier_status,
          s.spend_last_12_months,
          s.notes as supplier_notes,
          (ii.stock_qty * ii.cost_price) as total_item_value,
          CASE
            WHEN ii.stock_qty > ii.max_stock * 0.8 THEN 'overstocked'
            WHEN ii.stock_qty > ii.reorder_point THEN 'adequate'
            WHEN ii.stock_qty > 0 AND ii.stock_qty <= ii.reorder_point THEN 'low_stock'
            WHEN ii.stock_qty = 0 THEN 'out_of_stock'
            ELSE 'unknown'
          END as stock_status,
          CASE
            WHEN ii.reorder_point > 0 THEN
              ROUND((ii.stock_qty::numeric / ii.reorder_point) * 100, 1)
            ELSE NULL
          END as reorder_point_percentage
        FROM inventory_items ii
        JOIN suppliers s ON ii.supplier_id = s.id
        WHERE ii.status = 'active' AND s.status = 'active'
        ORDER BY total_item_value DESC;
      `
    }
  ];

  try {
    for (const view of views) {
      console.log(`Creating view: ${view.name}...`);
      await pool.query(view.sql);
      console.log(`✅ ${view.name} - ${view.description}`);

      // Test the view with sample query
      const sample = await pool.query(`SELECT * FROM ${view.name} LIMIT 3`);
      console.log(`   Sample records: ${sample.rows.length}\n`);
    }

    console.log('🎉 ALL VIEWS CREATED SUCCESSFULLY!\n');

    // Test queries that will be used in the UI components
    await testComponentQueries();

  } catch (error) {
    console.error('❌ Error creating views:', error.message);
  } finally {
    await pool.end();
  }
}

async function testComponentQueries() {
  console.log('=== TESTING UI COMPONENT QUERIES ===\n');

  const queries = [
    {
      name: 'Supplier Inventory Dashboard - Summary Data',
      sql: `
        SELECT
          supplier_name,
          supplier_code,
          item_count,
          total_inventory_value,
          total_stock_qty,
          out_of_stock_items,
          low_stock_items
        FROM supplier_inventory_summary
        WHERE item_count > 0
        ORDER BY total_inventory_value DESC
        LIMIT 5;
      `
    },
    {
      name: 'In Stock Inventory Master - Available Items',
      sql: `
        SELECT
          sku,
          product_name,
          supplier_name,
          stock_qty,
          available_qty,
          stock_status_category,
          total_item_value
        FROM in_stock_inventory_master
        WHERE stock_status_category IN ('adequate', 'low_stock')
        ORDER BY total_item_value DESC
        LIMIT 5;
      `
    },
    {
      name: 'Supplier Performance - Inventory Focus',
      sql: `
        SELECT
          supplier_name,
          total_items,
          stock_availability_percent,
          stockout_items,
          low_stock_items,
          total_inventory_value,
          performance_tier
        FROM supplier_inventory_performance
        WHERE total_items > 0
        ORDER BY stock_availability_percent DESC, total_inventory_value DESC
        LIMIT 5;
      `
    },
    {
      name: 'Detailed Inventory with Supplier Context',
      sql: `
        SELECT
          product_name,
          sku,
          supplier_name,
          stock_status,
          stock_qty,
          reorder_point,
          total_item_value,
          supplier_rating
        FROM inventory_supplier_detail
        WHERE stock_status != 'out_of_stock'
        ORDER BY total_item_value DESC
        LIMIT 5;
      `
    }
  ];

  for (const query of queries) {
    console.log(`--- ${query.name} ---`);
    try {
      const result = await pool.query(query.sql);
      console.log(`✅ Query executed successfully - ${result.rows.length} rows returned`);
      if (result.rows.length > 0) {
        console.log('Sample result:', JSON.stringify(result.rows[0], null, 2));
      }
    } catch (error) {
      console.log(`❌ Query failed: ${error.message}`);
    }
    console.log();
  }
}

// Run the setup
createSupplierInventoryViews().catch(console.error);