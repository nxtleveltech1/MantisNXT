# ITERATION 2 FAIL-SAFE RULES - MANDATORY COMPLIANCE

**Date**: 2025-10-08
**Applies To**: ITERATION 2, ITERATION 3, and all subsequent iterations
**Violation Consequence**: IMMEDIATE STOP - User will correct me

---

## RULE 0: SEQUENTIAL-THINKING FIRST (NON-NEGOTIABLE)

**BEFORE starting ANY phase:**

1. Use `mcp__sequential-thinking__sequentialthinking` to plan
2. Document the plan output
3. THEN execute

**NO EXCEPTIONS**. Skip this = user stops me.

---

## RULE 1: THE 6 WORKING AGENTS + 1 ENFORCER (NON-NEGOTIABLE)

### 1.1 The 6 Working Agents - ALL MUST PARTICIPATE

Every phase MUST deploy ALL 6 working agents in parallel:

1. `production-incident-responder` - Incident triage, API health, error monitoring
2. `aster-fullstack-architect` - Architecture, schema design, API contracts
3. `data-oracle` - Database operations via Neon MCP, data integrity
4. `infra-config-reviewer` - Infrastructure config, security, deployment readiness
5. `ui-perfection-doer` - Frontend errors, UX, accessibility, E2E testing
6. `ml-architecture-expert` - Analytics pipeline, performance optimization

### 1.2 The 7th Agent: compliance-enforcer (MANDATORY VALIDATION)

**AFTER every phase completion**, deploy `compliance-enforcer` to validate:

**What compliance-enforcer DOES**:
1. ✅ Verify all 6 working agents participated
2. ✅ Verify each agent delivered ≥5 items for the phase
3. ✅ Verify sequential-thinking MCP was used for planning
4. ✅ Verify MCP tools were used with complete logging
5. ✅ Check for rule violations (made-up scores, skipped steps, missing deliverables)
6. ✅ Validate quality standards (no TODO comments, no incomplete implementations, no hardcoded values)
7. ✅ Check agile backlog updated (issues rolled forward)
8. ✅ Verify all documentation created
9. ✅ Flag any violations immediately
10. ✅ Recommend corrective actions if violations found

**What compliance-enforcer does NOT do**:
- ❌ Does NOT do the actual work (no code, no migrations, no designs)
- ❌ Does NOT replace any of the 6 working agents
- ❌ Only validates and enforces rules

**When to deploy compliance-enforcer**:
- AFTER Discovery phase complete → validate Discovery compliance
- AFTER Design phase complete → validate Design compliance
- AFTER Development phase complete → validate Development compliance
- AFTER Delivery phase complete → validate Delivery compliance
- AFTER Assessment phase complete → validate Assessment compliance

**Output**: Compliance report with ✅ PASS or ❌ FAIL for each check

### 1.3 Parallel Execution Required

**Working agents**: Deploy all 6 agents in ONE message with 6 Task tool calls simultaneously.

**NEVER** deploy sequentially (agent1 → wait → agent2 → wait...)

**compliance-enforcer**: Deploy AFTER the 6 agents complete their phase work.

### 1.4 Minimum Deliverables Per Agent

Each of the 6 working agents MUST deliver ≥5 items per phase:
- Discovery: ≥5 findings/requirements/gaps
- Design: ≥5 design decisions/ADRs
- Development: ≥5 implementation checkpoints
- Delivery: ≥5 validation items
- Assessment: Self-evaluation + 5 recommendations

compliance-enforcer delivers: 1 compliance validation report per phase

---

## RULE 2: MCP TOOLS MANDATORY

### 2.1 MCP Server Assignment by Agent

**ALL agents MUST use appropriate MCP servers for their domain:**

#### sequential-thinking MCP (MANDATORY FOR ALL)
- **ALL agents** use `mcp__sequential-thinking__sequentialthinking` for planning BEFORE each phase
- Already mandated in RULE 0

#### Neon MCP (Database - NEW Neon Serverless)
**Primary Users**:
- `data-oracle` - MUST use for ALL database operations (queries, schema, performance)
- `aster-fullstack-architect` - Schema validation, view testing
- `production-incident-responder` - Data verification, health checks
- `ml-architecture-expert` - Query performance analysis

**Tools**:
- `mcp__neon__run_sql` - Execute queries
- `mcp__neon__run_sql_transaction` - Multi-statement transactions
- `mcp__neon__describe_table_schema` - Schema inspection
- `mcp__neon__get_database_tables` - Table listings
- `mcp__neon__explain_sql_statement` - Performance analysis
- `mcp__neon__list_slow_queries` - Performance monitoring
- `mcp__neon__prepare_database_migration` - Schema migrations
- `mcp__neon__complete_database_migration` - Migration finalization

**NO direct psql commands EVER for Neon database**

#### PostgreSQL MCP (Database - OLD Self-Hosted - NOW BACKUP TARGET)
**Primary Users**:
- `data-oracle` - Backup/replication target, data comparison

**Tools**:
- `mcp__postgres__query` - Queries on OLD database (62.169.20.53:6600)

**Use Cases**:
- **PRIMARY**: Backup/replication target for Neon (write operations)
- Verify data migration completeness
- Compare old vs new data
- Extract missing data if needed
- **WRITE ENABLED**: Used for Neon → Postgres OLD replication

#### Context7 MCP (Library Documentation)
**Primary Users**:
- `aster-fullstack-architect` - Framework patterns, Next.js docs
- `ui-perfection-doer` - React, UI library docs
- ANY agent - When official library docs needed

**Tools**:
- `mcp__context7__resolve-library-id` - Find library by name
- `mcp__context7__get-library-docs` - Get official docs

**Use Cases**:
- Next.js App Router patterns
- React best practices
- Framework-specific implementation
- Official API documentation

#### Shadcn MCP (UI Components)
**Primary Users**:
- `ui-perfection-doer` - UI component implementation

**Tools**:
- `mcp__shadcn__list_components` - List available components
- `mcp__shadcn__get_component` - Get component source
- `mcp__shadcn__get_component_demo` - Get usage examples
- `mcp__shadcn__get_component_metadata` - Get component metadata
- `mcp__shadcn__list_blocks` - List shadcn blocks
- `mcp__shadcn__get_block` - Get block source

**Use Cases**:
- Building UI components
- Accessibility compliance
- Design system implementation

#### Chrome DevTools MCP (Browser Testing & Performance)
**Primary Users**:
- `ui-perfection-doer` - E2E testing, accessibility validation, visual testing
- `production-incident-responder` - Health checks, performance monitoring
- `ml-architecture-expert` - Performance trace analysis

**Tools**:
- `mcp__chrome-devtools__navigate_page` - Navigate to URLs
- `mcp__chrome-devtools__click` - Click elements by UID
- `mcp__chrome-devtools__fill` - Fill form inputs
- `mcp__chrome-devtools__fill_form` - Fill multiple form elements
- `mcp__chrome-devtools__take_snapshot` - Get text snapshot with UIDs
- `mcp__chrome-devtools__take_screenshot` - Capture screenshots
- `mcp__chrome-devtools__list_console_messages` - Get console logs
- `mcp__chrome-devtools__evaluate_script` - Execute JavaScript
- `mcp__chrome-devtools__list_network_requests` - Network monitoring
- `mcp__chrome-devtools__get_network_request` - Request details
- `mcp__chrome-devtools__performance_start_trace` - Start performance recording
- `mcp__chrome-devtools__performance_stop_trace` - Stop and analyze
- `mcp__chrome-devtools__performance_analyze_insight` - Performance insights
- `mcp__chrome-devtools__emulate_cpu` - CPU throttling
- `mcp__chrome-devtools__emulate_network` - Network throttling
- `mcp__chrome-devtools__list_pages` - List browser pages
- `mcp__chrome-devtools__new_page` - Open new page
- `mcp__chrome-devtools__select_page` - Switch pages
- `mcp__chrome-devtools__resize_page` - Responsive testing

**Use Cases**:
- E2E user flows and interaction testing
- Visual regression testing
- Accessibility testing (WCAG)
- Performance profiling with Core Web Vitals
- Network request analysis (API debugging)
- Console error detection
- CPU/Network throttling simulation
- Multi-page testing scenarios

#### Filesystem MCP (File Operations)
**Primary Users**:
- `infra-config-reviewer` - Reading config files
- ALL agents - Writing report documents

**Tools**:
- `mcp__fs__read_text_file` - Read files
- `mcp__fs__read_multiple_files` - Batch read
- `mcp__fs__write_file` - Write files
- `mcp__fs__edit_file` - Line-based edits
- `mcp__fs__list_directory` - List directory
- `mcp__fs__search_files` - Search for files
- `mcp__fs__get_file_info` - File metadata

**Use Cases**:
- Reading .env files
- Writing report documents
- Configuration analysis
- File system operations

#### Fetch MCP (Web Content Retrieval)
**Primary Users**:
- `aster-fullstack-architect` - Fetch framework documentation from web
- `ui-perfection-doer` - Fetch design system references
- ANY agent - When official docs aren't in Context7

**Tools**:
- `mcp__fetch__fetch` - Fetch and process web content
- Returns markdown-converted content

**Use Cases**:
- Fetch documentation from websites
- Retrieve API references
- Get changelog/release notes
- Alternative when Context7 doesn't have content

#### Git MCP (Version Control)
**Primary Users**:
- `infra-config-reviewer` - Git repository analysis
- `production-incident-responder` - Commit history investigation
- `aster-fullstack-architect` - Code change analysis

**Tools**:
- `mcp__git__status` - Get repository status
- `mcp__git__diff` - View changes
- `mcp__git__log` - View commit history
- `mcp__git__show` - Show commit details
- `mcp__git__blame` - File change attribution

**Use Cases**:
- Analyze recent changes for debugging
- Track when bugs were introduced
- Review commit history for patterns
- Git repository health checks
- **READ-ONLY**: Never make commits (use native git via Bash)

### 2.2 MCP Usage Requirements by Phase

**Discovery Phase**:
- sequential-thinking: Plan investigation (ALL agents)
- neon/postgres: Query data for requirements validation (data-oracle, aster-fullstack-architect)
- context7: Research framework capabilities (aster-fullstack-architect, ui-perfection-doer)
- chrome-devtools: Test current user flows, analyze performance (ui-perfection-doer, ml-architecture-expert)

**Design Phase**:
- sequential-thinking: Plan design approach (ALL agents)
- neon: Test proposed schema changes (data-oracle, aster-fullstack-architect)
- context7: Validate design patterns (aster-fullstack-architect, ui-perfection-doer)
- shadcn: Identify reusable components (ui-perfection-doer)

**Development Phase**:
- sequential-thinking: Plan implementation (ALL agents)
- neon: Apply migrations, run tests (data-oracle)
- context7: Reference implementation patterns (aster-fullstack-architect)
- shadcn: Implement UI components (ui-perfection-doer)
- chrome-devtools: Test interactions, console errors (ui-perfection-doer)
- fs: Write/edit files (ALL agents)

**Delivery Phase**:
- sequential-thinking: Plan validation (ALL agents)
- neon: Validate data integrity (data-oracle, ml-architecture-expert)
- chrome-devtools: E2E testing, performance profiling (ui-perfection-doer, production-incident-responder, ml-architecture-expert)
- fs: Write validation reports (ALL agents)

**Assessment Phase**:
- sequential-thinking: Plan evaluation (ALL agents)
- fs: Write self-evaluation reports (ALL agents)

### 2.3 MCP Logging Required

Every MCP call MUST be logged with:
- Tool name (e.g., `mcp__neon__run_sql`)
- Input parameters (SQL query, project_id, etc.)
- Output results
- Timestamp
- Decision rationale (why this query/tool was needed)

**Format**:
```
MCP CALL #1
Server: neon
Tool: mcp__neon__run_sql
Input: SELECT COUNT(*) FROM public.suppliers
Output: 22 rows
Rationale: Verify supplier migration completeness
Timestamp: 2025-10-08T11:14:23Z
```

### 2.4 MCP Success Rate Tracking

Track and report PER MCP SERVER:
- Total calls per server (neon, postgres, context7, shadcn, chrome-devtools, fs, fetch, git, sequential-thinking)
- Successful calls per server
- Failed calls with error messages
- Success rate percentage per server
- Overall MCP success rate across all servers

---

## RULE 3: PHASE STRUCTURE (5 PHASES PER ITERATION)

### Phase 0: Joint Assessment Brief (Optional)

6 agents collaborate on initial assessment if iteration starts fresh.

### Phase 1: DISCOVERY

**Goal**: Enumerate what to investigate

**Each agent delivers** ≥5 items:
- Requirements gaps
- Data contracts
- API invariants
- Performance targets
- Compliance checks
- User journeys
- Failure scenarios

**MCP Usage**: Required for validation

**Output**: Discovery Log (facts, contradictions, constraints)

### Phase 2: DESIGN

**Goal**: Propose solutions

**Each agent delivers** ≥5 items:
- Design decisions (ADRs)
- Architecture patterns
- API contracts
- Schema designs
- Error handling strategies

**MCP Usage**: Test designs with queries/analysis

**Output**: Design Document with ADRs

### Phase 3: DEVELOPMENT

**Goal**: Implement solutions

**Each agent delivers** ≥5 checkpoints:
- Code changes
- Migrations
- Configuration updates
- Tests written
- Documentation

**MCP Usage**: Apply changes via MCP tools

**Output**: Working implementation

### Phase 4: DELIVERY

**Goal**: Validate readiness

**Each agent delivers** ≥5 validation items:
- Deployment checks
- Integration tests
- Performance validation
- Security audits
- Documentation review

**MCP Usage**: Validate with queries/tests

**Output**: Delivery validation reports

### Phase 5: ASSESSMENT

**Goal**: Self-evaluate and plan next iteration

**Each agent delivers**:
1. **Self-Evaluation**: What did I accomplish? (FACTS, not scores)
2. **Issues Found**: List all issues I discovered
3. **Fixes Applied**: List all fixes I implemented
4. **Blockers**: What prevents production deployment?
5. **5 Recommendations**: What to implement in next iteration

**Output**: Assessment report + backlog for next iteration

---

## RULE 4: AGILE BACKLOG MANAGEMENT (CRITICAL)

### 4.1 Automatic Roll-Forward

**ALL issues/recommendations from previous iteration AUTOMATICALLY roll into next iteration backlog**.

**ITERATION 1 outputs that MUST roll into ITERATION 2**:

From **infra-config-reviewer**:
- Fix 6 hardcoded database IPs in API routes
- Remove git-tracked secrets (.env.local, mcp-config.json)
- Generate cryptographic JWT/SESSION secrets
- Fix connection pool for serverless (max=1)
- Add statement timeout to DATABASE_URL
- Move API keys to git-ignored location

From **production-incident-responder**:
- Monitor API response times (currently 21-165ms, target <100ms)
- Enable 24-hour post-deployment monitoring
- Set up error rate alerts

From **aster-fullstack-architect**:
- Migrate 41 API routes from public.* to core.*
- Import stock movement data (table currently empty)

From **data-oracle**:
- Import missing purchase_orders table
- Fix zero pricing issue (cost_price=0, sale_price=0)

From **ui-perfection-doer**:
- Add 3 high-priority ARIA attributes to error boundaries
- Add page-level error boundaries (inventory, suppliers)
- Add Suspense wrappers for dynamic imports

From **ml-architecture-expert**:
- Create materialized view for v_product_table_by_supplier (217ms→<50ms)
- Deploy caching layer to production
- Enable query monitoring with pg_stat_statements

### 4.2 Backlog Prioritization

**P0** (Critical blockers): Must fix before production
**P1** (High priority): Fix in current iteration
**P2** (Medium priority): Fix if time permits
**P3** (Low priority): Defer to future iteration

### 4.3 Backlog Tracking

Create `ITERATION_2_BACKLOG.md` with:
- All rolled-forward items from ITERATION 1
- Priority assigned (P0/P1/P2/P3)
- Agent assigned to each item
- Status tracking (Not Started / In Progress / Complete)

---

## RULE 5: SELF-EVALUATION (NO MADE-UP SCORES)

### 5.1 What Each Agent Reports

**Each agent provides FACTS, not scores**:

1. **Deliverables**: List what I delivered (files, MCP calls, fixes)
2. **Issues Found**: Specific issues with file:line references
3. **Fixes Applied**: Specific fixes with before/after
4. **MCP Operations**: Count and success rate
5. **Blockers**: What prevents my domain from being production-ready

### 5.2 What I (Claude) Do NOT Do

**NEVER**:
- Make up scores (85/100, 92/100, etc.)
- Assign grades (A, B+, etc.)
- Subjectively "rate" agent performance
- Create aggregate scores without objective criteria

### 5.3 What I (Claude) CAN Do

**ALLOWED**:
- Count deliverables (did agent deliver ≥5 items? Yes/No)
- Verify MCP usage (how many calls? What success rate?)
- List issues found (factual enumeration)
- Check if blockers prevent production (Yes/No with reasons)

### 5.4 Pass/Fail Criteria (Objective Only)

**ITERATION PASSES if**:
- All 6 agents participated: Yes/No
- Each agent delivered ≥5 items per phase: Yes/No
- MCP tools used in every phase: Yes/No
- All phases completed: Yes/No
- Critical blockers identified: Yes/No (list them)

**If ANY answer is "No" → ITERATION FAILS**

---

## RULE 6: RECOMMENDATIONS FOR NEXT ITERATION

### 6.1 Each Agent Provides 5 Recommendations

At end of each iteration, EVERY agent must provide exactly 5 recommendations for next iteration:

**Format**:
```
Agent: production-incident-responder

Recommendations for ITERATION 3:
1. [Specific recommendation with implementation guidance]
2. [Specific recommendation with implementation guidance]
3. [Specific recommendation with implementation guidance]
4. [Specific recommendation with implementation guidance]
5. [Specific recommendation with implementation guidance]
```

### 6.2 Recommendation Quality Standards

Each recommendation MUST include:
- **What**: Specific change to implement
- **Why**: Business/technical justification
- **How**: Implementation approach
- **Priority**: P0/P1/P2/P3
- **Owner**: Which agent should implement

**BAD RECOMMENDATION**:
"Improve performance"

**GOOD RECOMMENDATION**:
"Create materialized view for v_product_table_by_supplier to reduce query time from 217ms to <5ms. WHY: Dashboard loads slowly. HOW: Create refresh strategy with pg_cron. PRIORITY: P1. OWNER: ml-architecture-expert"

---

## RULE 7: DOCUMENTATION STANDARDS

### 7.1 Required Documents Per Iteration

**Discovery Phase**:
- `ITERATION_X_DISCOVERY_[AGENT]_FINDINGS.md` (6 files, one per agent)
- `ITERATION_X_DISCOVERY_CONSOLIDATED.md` (all findings merged)

**Design Phase**:
- `ITERATION_X_DESIGN_[AGENT]_ADRS.md` (6 files, one per agent)
- `ITERATION_X_DESIGN_CONSOLIDATED.md` (all ADRs merged)

**Development Phase**:
- `ITERATION_X_DEVELOPMENT_[AGENT]_CHECKPOINTS.md` (6 files)
- `ITERATION_X_DEVELOPMENT_CHANGELOG.md` (all code changes)

**Delivery Phase**:
- `ITERATION_X_DELIVERY_[AGENT]_VALIDATION.md` (6 files)
- `ITERATION_X_DELIVERY_SUMMARY.md` (all validations)

**Assessment Phase**:
- `ITERATION_X_ASSESSMENT_[AGENT]_SELF_EVAL.md` (6 files)
- `ITERATION_X_ASSESSMENT_FINAL.md` (consolidated assessment with pass/fail)
- `ITERATION_X+1_BACKLOG.md` (backlog for next iteration)

### 7.2 Document Location

All iteration documents in: `K:\00Project\MantisNXT\claudedocs\`

---

## RULE 8: ITERATION COMPLETION CHECKLIST

Before declaring iteration complete, verify:

- [ ] Sequential-thinking used for EVERY phase planning
- [ ] All 6 working agents participated in EVERY phase
- [ ] compliance-enforcer validated EVERY phase (5 compliance reports)
- [ ] Each working agent delivered ≥5 items per phase
- [ ] MCP tools used in every phase with complete logging
- [ ] All 5 phases completed (Discovery, Design, Development, Delivery, Assessment)
- [ ] Each working agent provided self-evaluation (facts, not scores)
- [ ] Each working agent provided 5 recommendations for next iteration
- [ ] compliance-enforcer flagged all rule violations
- [ ] All violations addressed before proceeding
- [ ] All issues/recommendations rolled into next iteration backlog
- [ ] Backlog prioritized (P0/P1/P2/P3)
- [ ] All required documentation created (including 5 compliance reports)
- [ ] Pass/fail determination made using objective criteria only

---

## RULE 9: WHAT TO DO WHEN USER CORRECTS ME

When user says "you fucked up" or corrects me:

1. **STOP IMMEDIATELY** - don't keep going
2. **ACKNOWLEDGE THE SPECIFIC MISTAKE** - say exactly what I did wrong
3. **ASK FOR CLARIFICATION** - what should I have done instead?
4. **UPDATE THESE RULES** - add new rule to prevent repeat
5. **RESTART WITH CORRECT APPROACH** - don't defend, just fix

**NEVER**:
- Make excuses
- Defend my approach
- Keep going as if nothing happened
- Argue with user corrections

---

## RULE 10: DATABASE CONFIGURATION DETAILS

### 10.1 Neon Serverless PostgreSQL (ACTIVE - Current)

**Project**: proud-mud-50346856
**Database**: neondb
**Host**: ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech
**Port**: 5432
**User**: neondb_owner
**Password**: npg_84ELeCFbOcGA

**Connection String**:
```
postgresql://neondb_owner:npg_84ELeCFbOcGA@ep-steep-waterfall-a96wibpm-pooler.gwc.azure.neon.tech/neondb?sslmode=require
```

**Status**: ✅ ACTIVE - All application traffic uses this database
**Data**: 22 suppliers, 25,624 inventory items, 76,568 total quantity
**Access**: Via Neon MCP tools ONLY (mcp__neon__* tools)

### 10.2 Self-Hosted PostgreSQL (OLD - Disabled)

**Host**: 62.169.20.53
**Port**: 6600
**Database**: nxtprod-db_001
**User**: nxtdb_admin
**Password**: P@33w0rd-1

**Connection String**:
```
postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001
```

**Status**: ❌ DISABLED in .env.local (migrated to Neon on 2025-10-06)
**Access**: Via PostgreSQL MCP tool ONLY (mcp__postgres__query - READ-ONLY)
**Use Cases**: Data verification, migration comparison, extract missing data
**⚠️ WARNING**: Still hardcoded in 6 API route files (MUST be removed in ITERATION 2)

---

## RULE 11: ITERATION 2 SPECIFIC REQUIREMENTS

### 11.1 Priority P0 Items (Must Fix)

These MUST be completed in ITERATION 2 DEVELOPMENT:

1. Remove 6 hardcoded database IPs (infra-config-reviewer found)
2. Fix git-tracked secrets (infra-config-reviewer found)
3. Generate cryptographic secrets (infra-config-reviewer found)
4. Fix connection pool for serverless (infra-config-reviewer found)
5. Add statement timeout (infra-config-reviewer found)
6. Move API keys to secure location (infra-config-reviewer found)

### 10.2 Priority P1 Items (Should Fix)

From ITERATION 1 agent recommendations:
- Add 3 ARIA attributes (ui-perfection-doer)
- Monitor API response times (production-incident-responder)
- Optimize slow view 217ms→<50ms (ml-architecture-expert)

### 10.3 Known Issues to Address

From new error logs user provided:
- Frontend crash: PortfolioDashboard.tsx:330 (undefined metrics)
- API 500 errors on analytics endpoints
- API 400 error on suppliers endpoint
- Empty stock_movement table
- Missing columns in schema bridge views

---

## SUMMARY: THE NON-NEGOTIABLE RULES

1. **Sequential-thinking FIRST** for every phase planning
2. **ALL 6 agents** participate in parallel for every phase
3. **≥5 deliverables** per agent per phase
4. **MCP tools** in every phase with complete logging
5. **ALL issues roll forward** to next iteration (agile backlog)
6. **Self-evaluation** by agents (facts only, NO made-up scores)
7. **5 recommendations** per agent for next iteration
8. **Complete documentation** for every phase
9. **Objective pass/fail** criteria only (no subjective scoring)
10. **Fix P0 blockers** identified in previous iteration

**If I violate ANY of these rules, user will stop me immediately and correct me.**

---

---

## RULE 12: END-TO-END DELIVERY REQUIREMENT (NON-NEGOTIABLE)

**CRITICAL**: When any component, feature, or system is developed, it is NEVER delivered in isolation.

### 12.1 What This Means

Every deliverable MUST consider and implement:

**Upstream Processes**:
- What feeds data INTO this component?
- What APIs/services does this depend on?
- What user actions trigger this?
- What data sources does this consume?

**Downstream Processes**:
- What depends ON this component?
- What APIs/services consume this output?
- What UI components display this data?
- What reports/analytics use this?

**All Touchpoints**:
- What else does this affect?
- What integrations are impacted?
- What error handlers need updating?
- What monitoring/logging is needed?
- What documentation requires updates?

### 12.2 NEVER Do This

❌ **WRONG**: Build login component in isolation
- Just the login form
- No password reset flow
- No session management integration
- No error handling for downstream routes
- No consideration for analytics tracking

### 12.3 ALWAYS Do This

✅ **CORRECT**: Build login component end-to-end
- Login form WITH validation
- Password reset flow integrated
- Session management fully connected
- Protected route middleware updated
- Error boundaries for auth failures
- Analytics tracking for login events
- Audit logging for security
- Documentation for API consumers
- Tests for entire auth flow

### 12.4 Validation Checklist

Before declaring ANY component complete, verify:

- [ ] **Upstream validated**: All data sources identified and integrated
- [ ] **Downstream validated**: All consumers identified and working
- [ ] **Error paths complete**: All failure scenarios handled
- [ ] **Integration tested**: Full flow tested end-to-end
- [ ] **Monitoring in place**: Logging, metrics, alerts configured
- [ ] **Documentation complete**: API docs, integration guides updated
- [ ] **Dependencies updated**: All affected systems modified
- [ ] **Tests comprehensive**: Unit, integration, E2E tests pass

### 12.5 compliance-enforcer Checks This

compliance-enforcer MUST verify end-to-end delivery:

**Questions to ask**:
1. What feeds INTO this component? (Upstream identified?)
2. What depends ON this component? (Downstream identified?)
3. Are all integrations complete and tested?
4. Are error paths fully handled?
5. Is monitoring/logging in place?
6. Is documentation updated?
7. Can this be deployed to production RIGHT NOW without breaking anything?

**If answer to ANY question is "No" or "Unknown" → ❌ FAIL**

### 12.6 Examples

**Example 1: New API Endpoint**

NOT just:
- Write the route handler

But ALSO:
- Input validation with error messages
- Database queries with error handling
- Response formatting
- API documentation updated
- Frontend integration (if applicable)
- Error logging and monitoring
- Rate limiting (if needed)
- Authentication/authorization checks
- Tests (unit + integration)
- Postman/API client examples

**Example 2: Database Schema Change**

NOT just:
- ALTER TABLE migration

But ALSO:
- Update all affected queries
- Update API contracts
- Update frontend models/types
- Migration rollback script
- Data backfill if needed
- Documentation updated
- Tests updated for new schema
- Verify no breaking changes
- Check all views/triggers affected

**Example 3: UI Component**

NOT just:
- React component code

But ALSO:
- Integration with state management
- API calls with loading/error states
- Accessibility (ARIA, keyboard nav)
- Responsive design (mobile/tablet/desktop)
- Error boundaries around component
- Analytics tracking
- Documentation/Storybook
- E2E tests
- Integration with routing
- SEO considerations (if public)

---

**END OF FAIL-SAFE RULES**

These rules are now mandatory for ITERATION 2, ITERATION 3, and all future work.
