# Schema Bridge Architecture - Data Migration Strategy

## Executive Summary

**Current State**: All production data resides in `public.*` schema (23 suppliers, 25,602 inventory items)
**Intended Design**: Data should reside in `core.*` schema for canonical master data
**Bridge Strategy**: Bi-directional views allow both schemas to coexist during migration
**Migration Goal**: Consolidate all data into `core.*` schema, decommission `public.*` schema

---

## Problem Statement

### Discovered Reality (2025-10-08)

```
Database: nxtprod-db_001 (PostgreSQL on 62.169.20.53:6600)

PUBLIC SCHEMA (Actual Data):
├── public.suppliers (TABLE) ........... 23 rows
├── public.inventory_items (VIEW) ...... 25,602 rows (from JOIN)
├── public.products (TABLE) ............ ~100 rows
└── public.stock_movements (TABLE) ..... ~500 rows

CORE SCHEMA (Empty):
├── core.supplier (TABLE) .............. 0 rows ❌
├── core.supplier_product (TABLE) ...... 0 rows ❌
├── core.stock_on_hand (TABLE) ......... 0 rows ❌
├── core.stock_location (TABLE) ........ 0 rows ❌
└── core.stock_movement (TABLE) ........ 0 rows ❌
```

### Schema Column Mismatch

**public.suppliers** has 44 columns (mega-table with all fields merged)
**core.supplier** has 14 columns (normalized design)

Key mismatches:
- `id` vs `supplier_id` (naming)
- `status` (text) vs `active` (boolean)
- `email`/`phone` vs `contact_info` (JSONB)
- `currency` vs `default_currency`
- No `contact_email`, `contact_phone`, `payment_terms_days` in core (recently added)

---

## Bridge Architecture

### 1. Forward Compatibility Views (Migration 003)

**Purpose**: Allow new code to query `core.*` schema while data lives in `public.*`

```sql
-- Views created in core schema that read from public
core.supplier_view         → reads from public.suppliers
core.supplier_product_view → reads from public.inventory_items
core.stock_on_hand_view    → reads from public.inventory_items
core.stock_movement_view   → reads from public.stock_movements
```

**Usage**:
```sql
-- New code queries core schema
SELECT * FROM core.supplier_view WHERE active = true;
-- Data comes from public.suppliers
```

### 2. Reverse Compatibility Views (Migration 004)

**Purpose**: Allow APIs expecting `core.*` tables to work while migration is in progress

```sql
-- Views in core schema with same names as intended tables
core.supplier         (VIEW) → exposes public.suppliers
core.supplier_product (VIEW) → exposes public.inventory_items
core.stock_on_hand    (VIEW) → exposes inventory quantities
core.stock_movement   (VIEW) → exposes stock_movements
```

**Usage**:
```sql
-- APIs query core.supplier (expecting a table)
SELECT * FROM core.supplier WHERE supplier_id = '...';
-- View transparently redirects to public.suppliers
```

### 3. Column Mapping Strategy

```
┌─────────────────────────────────────────────────────────┐
│                PUBLIC.SUPPLIERS (44 cols)               │
├─────────────────────────────────────────────────────────┤
│ id                  → supplier_id                       │
│ name                → name                              │
│ supplier_code       → code                              │
│ status (text)       → active (boolean)                  │
│ currency            → default_currency                  │
│ email               ┐                                   │
│ phone               │→ contact_info (JSONB)             │
│ contact_person      │                                   │
│ website             │                                   │
│ address             ┘                                   │
│ tax_id              → tax_number                        │
│ payment_terms       → payment_terms                     │
│ payment_terms_days  → payment_terms_days                │
│ contact_email       → contact_email                     │
│ [36 other columns]  → attrs_json or discarded           │
└─────────────────────────────────────────────────────────┘
```

---

## Migration Phases

### Phase 1: Bridge Setup (CURRENT)

**Status**: ✅ Complete

**Actions**:
1. Create forward views (`core.*_view`)
2. Create reverse views (`core.*` as views)
3. Add column mapping logic in views
4. Validate views return correct data

**Validation**:
```sql
SELECT * FROM core.check_migration_readiness();
```

Expected output:
```
object_name       | object_type | is_ready | row_count | notes
------------------+-------------+----------+-----------+----------------------------------
supplier          | view        | false    | 23        | Using compatibility view
supplier_product  | view        | false    | 25602     | Using compatibility view
stock_on_hand     | view        | false    | 25602     | Using compatibility view
```

### Phase 2: Data Copy (PLANNED)

**Goal**: Copy data from `public.*` to `core.*` tables

**Prerequisites**:
- All APIs updated to use `core.*` views
- Data validation scripts ready
- Rollback plan in place

**Process**:

1. **Backup Current State**
```sql
-- Create backup schema
CREATE SCHEMA IF NOT EXISTS backup;

-- Backup public tables
CREATE TABLE backup.suppliers_20251008 AS SELECT * FROM public.suppliers;
CREATE TABLE backup.inventory_items_20251008 AS SELECT * FROM public.inventory_items;
```

2. **Rename Views to Temporary Names**
```sql
ALTER VIEW core.supplier RENAME TO supplier_temp_view;
ALTER VIEW core.supplier_product RENAME TO supplier_product_temp_view;
ALTER VIEW core.stock_on_hand RENAME TO stock_on_hand_temp_view;
```

3. **Create Real Tables** (already exist from migration 002)
```sql
-- Tables already exist, just verify structure
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'core' AND table_name = 'supplier'
ORDER BY ordinal_position;
```

4. **Migrate Supplier Data**
```sql
-- Copy suppliers
INSERT INTO core.supplier (
  supplier_id,
  name,
  code,
  active,
  default_currency,
  payment_terms,
  contact_info,
  tax_number,
  contact_email,
  contact_phone,
  website,
  payment_terms_days,
  created_at,
  updated_at
)
SELECT
  id::uuid,
  COALESCE(name, supplier_name, company_name),
  supplier_code,
  CASE
    WHEN status IN ('active', 'Active', 'ACTIVE') THEN true
    ELSE false
  END,
  COALESCE(currency, 'ZAR'),
  payment_terms,
  jsonb_build_object(
    'email', COALESCE(contact_email, email),
    'phone', phone,
    'contact_person', contact_person,
    'website', website,
    'address', address,
    'geographic_region', geographic_region,
    'bee_level', bee_level
  ),
  tax_id,
  COALESCE(contact_email, email),
  phone,
  website,
  payment_terms_days,
  created_at,
  updated_at
FROM public.suppliers;

-- Verify count matches
SELECT
  (SELECT COUNT(*) FROM public.suppliers) as source_count,
  (SELECT COUNT(*) FROM core.supplier) as target_count;
```

5. **Migrate Supplier Product Data**

First, need to handle inventory_items which is currently a VIEW:
```sql
-- inventory_items is a view, need to materialize it first
CREATE TABLE backup.inventory_items_materialized AS
SELECT * FROM public.inventory_items;

-- Then migrate to core.supplier_product
INSERT INTO core.supplier_product (
  supplier_product_id,
  supplier_id,
  supplier_sku,
  name_from_supplier,
  uom,
  is_active,
  category_id,
  attrs_json,
  first_seen_at,
  last_seen_at,
  created_at,
  updated_at
)
SELECT
  md5(COALESCE(sku, '') || COALESCE(supplier_id::text, ''))::uuid,
  supplier_id::uuid,
  sku,
  name,
  CASE
    WHEN name ILIKE '%kg%' THEN 'kg'
    WHEN name ILIKE '%box%' THEN 'box'
    ELSE 'each'
  END,
  CASE WHEN status IN ('active', 'Active') THEN true ELSE false END,
  NULL,  -- category_id, will need separate mapping
  jsonb_build_object(
    'category', category,
    'brand', brand,
    'location', location,
    'stock_qty', stock_qty,
    'reserved_qty', reserved_qty,
    'reorder_point', reorder_point
  ),
  created_at,
  updated_at,
  created_at,
  updated_at
FROM backup.inventory_items_materialized
WHERE sku IS NOT NULL AND sku != '';
```

6. **Migrate Stock Data**
```sql
-- Create default stock location
INSERT INTO core.stock_location (location_id, name, type, is_active)
VALUES (
  md5('location-main')::uuid,
  'Main Warehouse',
  'internal',
  true
)
ON CONFLICT (location_id) DO NOTHING;

-- Migrate stock quantities
INSERT INTO core.stock_on_hand (
  soh_id,
  location_id,
  supplier_product_id,
  qty,
  as_of_ts,
  source,
  created_at
)
SELECT
  md5('soh-' || id::text)::uuid,
  md5('location-main')::uuid,
  md5(COALESCE(sku, '') || COALESCE(supplier_id::text, ''))::uuid,
  COALESCE(stock_qty, 0),
  updated_at,
  'migration',
  created_at
FROM backup.inventory_items_materialized
WHERE stock_qty IS NOT NULL;
```

7. **Validate Migration**
```sql
-- Check row counts match
SELECT
  'suppliers' as entity,
  (SELECT COUNT(*) FROM public.suppliers) as public_count,
  (SELECT COUNT(*) FROM core.supplier) as core_count;

SELECT
  'inventory_items' as entity,
  (SELECT COUNT(*) FROM backup.inventory_items_materialized) as public_count,
  (SELECT COUNT(*) FROM core.supplier_product) as core_count;

-- Spot check data integrity
SELECT
  s.name,
  s.code,
  COUNT(sp.supplier_product_id) as product_count,
  SUM(soh.qty) as total_stock
FROM core.supplier s
LEFT JOIN core.supplier_product sp ON s.supplier_id = sp.supplier_id
LEFT JOIN core.stock_on_hand soh ON sp.supplier_product_id = soh.supplier_product_id
GROUP BY s.supplier_id, s.name, s.code
ORDER BY s.name;
```

### Phase 3: Cutover (PLANNED)

**Goal**: Switch from views to real tables

1. **Drop Temporary Views**
```sql
DROP VIEW IF EXISTS core.supplier_temp_view CASCADE;
DROP VIEW IF EXISTS core.supplier_product_temp_view CASCADE;
DROP VIEW IF EXISTS core.stock_on_hand_temp_view CASCADE;
```

2. **Update Application Code**
- Change all queries from `core.supplier_view` to `core.supplier`
- Remove view suffix
- Test all endpoints

3. **Monitor for Issues**
```sql
-- Check core schema is being used
SELECT
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables
WHERE schemaname IN ('core', 'public')
AND tablename IN ('supplier', 'suppliers', 'supplier_product')
ORDER BY schemaname, tablename;
```

### Phase 4: Decommission Public Schema (FUTURE)

**Goal**: Remove public.* tables once core.* is proven stable

1. **Rename Public Tables**
```sql
ALTER TABLE public.suppliers RENAME TO suppliers_deprecated_20251008;
ALTER TABLE public.products RENAME TO products_deprecated_20251008;
ALTER TABLE public.stock_movements RENAME TO stock_movements_deprecated_20251008;
```

2. **Monitor for 30 Days**
- Watch logs for any queries to `public.suppliers`
- Alert on deprecated table access

3. **Final Cleanup**
```sql
-- After 30 days with no issues
DROP TABLE IF EXISTS public.suppliers_deprecated_20251008 CASCADE;
DROP TABLE IF EXISTS public.products_deprecated_20251008 CASCADE;
DROP TABLE IF EXISTS public.stock_movements_deprecated_20251008 CASCADE;

-- Move to archive schema
CREATE SCHEMA IF NOT EXISTS archive;
ALTER TABLE backup.suppliers_20251008 SET SCHEMA archive;
```

---

## Risk Mitigation

### Risks

1. **Data Loss During Migration**
   - Mitigation: Full backup before migration, row count validation
   - Rollback: Restore from backup.* tables

2. **Downtime During Cutover**
   - Mitigation: Use views for zero-downtime migration
   - Rollback: Switch back to views pointing to public.*

3. **Query Performance Degradation**
   - Mitigation: Indexes already defined in migration 002
   - Monitor: Query execution plans before/after

4. **Foreign Key Constraint Violations**
   - Mitigation: Migrate in dependency order (supplier → product → stock)
   - Validation: Check constraints after each table migration

### Rollback Plan

If migration fails at any point:

```sql
-- 1. Drop partial data from core tables
TRUNCATE core.stock_on_hand CASCADE;
TRUNCATE core.supplier_product CASCADE;
TRUNCATE core.supplier CASCADE;

-- 2. Restore views
DROP VIEW IF EXISTS core.supplier CASCADE;
CREATE VIEW core.supplier AS SELECT * FROM public.suppliers;
-- (restore all other views)

-- 3. Verify system works
SELECT * FROM core.supplier LIMIT 5;
```

---

## Validation Queries

### Pre-Migration Checks

```sql
-- 1. Check current state
SELECT * FROM core.check_migration_readiness();

-- 2. Validate view data matches source
SELECT COUNT(*) FROM public.suppliers;
SELECT COUNT(*) FROM core.supplier;  -- Should match

-- 3. Check for NULL critical fields
SELECT COUNT(*) FROM public.suppliers WHERE id IS NULL OR name IS NULL;

-- 4. Check duplicate supplier names
SELECT name, COUNT(*)
FROM public.suppliers
GROUP BY name
HAVING COUNT(*) > 1;
```

### Post-Migration Validation

```sql
-- 1. Row count verification
SELECT
  'suppliers' as table_name,
  (SELECT COUNT(*) FROM backup.suppliers_20251008) as backup_count,
  (SELECT COUNT(*) FROM core.supplier) as core_count,
  (SELECT COUNT(*) FROM backup.suppliers_20251008) =
    (SELECT COUNT(*) FROM core.supplier) as counts_match;

-- 2. Data integrity checks
SELECT
  s.supplier_id,
  s.name,
  s.code,
  COUNT(sp.supplier_product_id) as products,
  SUM(soh.qty) as total_stock
FROM core.supplier s
LEFT JOIN core.supplier_product sp ON s.supplier_id = sp.supplier_id
LEFT JOIN core.stock_on_hand soh ON sp.supplier_product_id = soh.supplier_product_id
GROUP BY s.supplier_id, s.name, s.code
HAVING COUNT(sp.supplier_product_id) = 0;  -- Find suppliers with no products

-- 3. Foreign key integrity
SELECT COUNT(*)
FROM core.supplier_product sp
LEFT JOIN core.supplier s ON sp.supplier_id = s.supplier_id
WHERE s.supplier_id IS NULL;  -- Should be 0

-- 4. Stock location check
SELECT
  sl.name,
  COUNT(soh.soh_id) as stock_records,
  SUM(soh.qty) as total_qty
FROM core.stock_location sl
LEFT JOIN core.stock_on_hand soh ON sl.location_id = soh.location_id
GROUP BY sl.location_id, sl.name;
```

---

## Timeline

| Phase | Duration | Dependencies | Risk Level |
|-------|----------|--------------|------------|
| Phase 1: Bridge Setup | ✅ Complete | None | Low |
| Phase 2: Data Copy | 1 day | Phase 1, API updates | Medium |
| Phase 3: Cutover | 2 hours | Phase 2, validation pass | High |
| Phase 4: Decommission | 30 days monitoring + 1 day | Phase 3 stable | Low |

**Total Estimated Timeline**: 5-6 weeks (includes monitoring periods)

---

## Success Criteria

1. ✅ All data migrated with 100% row count match
2. ✅ Zero data loss (validated through checksums)
3. ✅ All foreign key relationships intact
4. ✅ Query performance within 10% of baseline
5. ✅ Zero application errors for 48 hours post-cutover
6. ✅ All APIs returning correct data from core.* schema
7. ✅ Backup tables maintained for 30 days

---

## Implementation Scripts

All migration scripts are located in:
```
database/migrations/neon/
├── 002_create_core_schema.sql ............... Core table definitions
├── 003_corrected_compatibility_views.sql .... Forward views
├── 004_reverse_compatibility_views.sql ...... Reverse views
└── 005_data_migration.sql ................... (TO BE CREATED)
```

---

## Monitoring

### Metrics to Track

1. **Query Performance**
   ```sql
   SELECT
     query,
     calls,
     mean_exec_time,
     max_exec_time
   FROM pg_stat_statements
   WHERE query LIKE '%core.supplier%'
   ORDER BY calls DESC
   LIMIT 10;
   ```

2. **View vs Table Usage**
   ```sql
   SELECT
     schemaname,
     tablename,
     seq_scan,
     idx_scan,
     n_tup_ins,
     n_tup_upd,
     n_tup_del
   FROM pg_stat_user_tables
   WHERE schemaname IN ('core', 'public')
   ORDER BY schemaname, tablename;
   ```

3. **Schema Size**
   ```sql
   SELECT
     schemaname,
     pg_size_pretty(SUM(pg_total_relation_size(schemaname||'.'||tablename))) as schema_size
   FROM pg_tables
   WHERE schemaname IN ('core', 'public', 'backup')
   GROUP BY schemaname;
   ```

---

## Next Steps

1. ✅ Review and approve this migration strategy
2. ⏳ Create Phase 2 migration script (`005_data_migration.sql`)
3. ⏳ Test migration in development environment
4. ⏳ Schedule maintenance window for production migration
5. ⏳ Execute Phase 2 (data copy)
6. ⏳ Validate data integrity
7. ⏳ Execute Phase 3 (cutover)
8. ⏳ Monitor for 30 days
9. ⏳ Execute Phase 4 (decommission public schema)

---

**Document Version**: 1.0
**Last Updated**: 2025-10-08
**Author**: Aster (Full-Stack Architect)
**Status**: Phase 1 Complete, Phase 2 Pending Approval
