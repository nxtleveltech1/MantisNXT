/**
 * Database Analysis Script for MantisNXT Connection Pool Issues
 * Checks current database state and identifies connection pool problems
 */

const { Client } = require('pg');

const client = new Client({
  host: '62.169.20.53',
  port: 6600,
  database: 'nxtprod-db_001',
  user: 'nxtdb_admin',
  password: 'P@33w0rd-1',
});

async function analyzeDatabaseState() {
  try {
    await client.connect();
    console.log('🔗 Connected to database for analysis');

    // 1. Check current connections
    console.log('\n=== DATABASE CONNECTION ANALYSIS ===');
    const connections = await client.query(`
      SELECT
        application_name,
        state,
        COUNT(*) as connection_count,
        MAX(backend_start) as latest_connection
      FROM pg_stat_activity
      WHERE datname = current_database()
      GROUP BY application_name, state
      ORDER BY connection_count DESC
    `);

    console.log('Current database connections:');
    connections.rows.forEach(row => {
      console.log(`  ${row.application_name || 'Unknown'}: ${row.connection_count} (${row.state})`);
    });

    // 2. Check supplier data status
    console.log('\n=== SUPPLIER DATA STATUS ===');
    const supplierCount = await client.query('SELECT COUNT(*) as count FROM suppliers');
    console.log(`Total suppliers: ${supplierCount.rows[0].count}`);

    // 3. Check inventory items
    const inventoryCount = await client.query('SELECT COUNT(*) as count FROM inventory_items');
    console.log(`Total inventory items: ${inventoryCount.rows[0].count}`);

    // 4. Check pricelist data
    const pricelistCount = await client.query('SELECT COUNT(*) as count FROM "Pricelist"');
    const pricelistItemCount = await client.query('SELECT COUNT(*) as count FROM "PricelistItem"');
    console.log(`Total pricelists: ${pricelistCount.rows[0].count}`);
    console.log(`Total pricelist items: ${pricelistItemCount.rows[0].count}`);

    // 5. Check recent supplier additions
    const recentSuppliers = await client.query(`
      SELECT name, created_at
      FROM suppliers
      WHERE created_at >= NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC
      LIMIT 10
    `);

    console.log('\n=== RECENT SUPPLIER ADDITIONS (Last 7 days) ===');
    if (recentSuppliers.rows.length === 0) {
      console.log('No suppliers added in the last 7 days');
    } else {
      recentSuppliers.rows.forEach(supplier => {
        console.log(`  ${supplier.name} - ${supplier.created_at}`);
      });
    }

    // 6. Check pricelist processing status
    const pricelistsBySupplier = await client.query(`
      SELECT
        s.name as supplier_name,
        COUNT(pl.id) as pricelist_count,
        COUNT(pli.id) as total_items
      FROM suppliers s
      LEFT JOIN "Pricelist" pl ON s.id::text = pl."supplierId"::text
      LEFT JOIN "PricelistItem" pli ON pl.id::text = pli."pricelistId"::text
      GROUP BY s.id, s.name
      HAVING COUNT(pl.id) > 0
      ORDER BY total_items DESC
    `);

    console.log('\n=== SUPPLIERS WITH PROCESSED PRICELISTS ===');
    if (pricelistsBySupplier.rows.length === 0) {
      console.log('No suppliers have processed pricelists yet');
    } else {
      pricelistsBySupplier.rows.forEach(supplier => {
        console.log(`  ${supplier.supplier_name}: ${supplier.pricelist_count} pricelists, ${supplier.total_items} items`);
      });
    }

    // 7. Check for any "mock" or test data
    console.log('\n=== MOCK DATA DETECTION ===');
    const mockSuppliers = await client.query(`
      SELECT name, supplier_code
      FROM suppliers
      WHERE name ILIKE '%test%' OR name ILIKE '%mock%' OR name ILIKE '%sample%'
    `);

    if (mockSuppliers.rows.length === 0) {
      console.log('✅ No obvious mock suppliers found');
    } else {
      console.log('⚠️  Found potential mock suppliers:');
      mockSuppliers.rows.forEach(supplier => {
        console.log(`  ${supplier.name} (${supplier.supplier_code})`);
      });
    }

    // 8. Check database performance stats
    console.log('\n=== DATABASE PERFORMANCE STATS ===');
    const dbStats = await client.query(`
      SELECT
        numbackends,
        xact_commit,
        xact_rollback,
        blks_read,
        blks_hit,
        tup_returned,
        tup_fetched,
        tup_inserted,
        tup_updated,
        tup_deleted,
        deadlocks
      FROM pg_stat_database
      WHERE datname = current_database()
    `);

    const stats = dbStats.rows[0];
    console.log(`Active backends: ${stats.numbackends}`);
    console.log(`Committed transactions: ${stats.xact_commit}`);
    console.log(`Rolled back transactions: ${stats.xact_rollback}`);
    console.log(`Cache hit ratio: ${((stats.blks_hit / (stats.blks_hit + stats.blks_read)) * 100).toFixed(2)}%`);
    console.log(`Deadlocks: ${stats.deadlocks}`);

    console.log('\n✅ Database analysis complete');

  } catch (error) {
    console.error('❌ Error analyzing database:', error.message);
  } finally {
    await client.end();
  }
}

analyzeDatabaseState();