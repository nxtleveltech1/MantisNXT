# IMMEDIATE RECOVERY ACTIONS - MantisNXT

## 🚨 EXECUTE IMMEDIATELY

### Phase 1: Emergency Database Connection Unification (15 minutes)

#### 1.1 Remove Competing Connection Systems
The system has three competing database connection systems causing pool exhaustion:

1. **Legacy Pool** (`lib/database/connection.ts`) - ✅ KEEP THIS ONE
2. **Enterprise Manager** (`lib/database/enterprise-connection-manager.ts`) - ❌ REMOVE USAGE
3. **Mixed Database Layer** (`lib/database.ts`) - ❌ STANDARDIZE

#### 1.2 Standardize All API Routes
**CRITICAL**: All API routes must use the same connection pattern:

```typescript
// ✅ CORRECT PATTERN (use everywhere)
import { pool } from '@/lib/database/connection'

// ❌ REMOVE THESE PATTERNS
import { enterpriseDb } from '@/lib/database/enterprise-connection-manager'
import { db } from '@/lib/database'
```

### Phase 2: Fix Build-Breaking Issues (10 minutes)

#### 2.1 Clear Build Cache
```bash
cd K:/00Project/MantisNXT
rm -rf .next
rm -rf tsconfig.tsbuildinfo
```

#### 2.2 Fix Next.js 15 Async Parameters
All dynamic routes with `[id]` need this pattern:

```typescript
// ❌ OLD (Next.js 14)
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const { id } = params;
}

// ✅ NEW (Next.js 15)
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
}
```

### Phase 3: Database Health Recovery (5 minutes)

#### 3.1 Test Database Connection
Execute this command to verify database health:
```bash
cd K:/00Project/MantisNXT
node -e "
const { pool } = require('./lib/database/connection.ts');
pool.query('SELECT NOW(), COUNT(*) FROM suppliers')
  .then(result => console.log('✅ DB OK:', result.rows))
  .catch(err => console.error('❌ DB ERROR:', err));
"
```

## 🔧 FILES REQUIRING IMMEDIATE FIXES

### Priority 1: Database Connection Conflicts

1. **src/lib/database.ts**
   - Remove enterprise connection manager imports
   - Use simple fallback to `pool` from connection.ts

2. **src/app/api/analytics/anomalies/route.ts**
3. **src/app/api/analytics/predictions/route.ts**
4. **src/app/api/analytics/recommendations/route.ts**
   - Replace `enterpriseDb` imports with `pool`

### Priority 2: Next.js 15 Compliance

1. **src/app/api/suppliers/[id]/route.ts**
2. **src/app/api/inventory/products/[id]/route.ts**
   - Update async parameter handling

### Priority 3: Build System
1. **Clear all caches**
2. **Restart development server**
3. **Test build process**

## ⚡ RECOVERY VALIDATION

After implementing fixes, validate with these commands:

```bash
# Test 1: Build should complete
npm run build

# Test 2: Database health
curl http://localhost:3000/api/health/database

# Test 3: Core APIs
curl http://localhost:3000/api/suppliers
curl http://localhost:3000/api/inventory/items

# Test 4: TypeScript compilation
npm run type-check
```

## 🎯 SUCCESS CRITERIA

- [ ] Build completes without timeout
- [ ] Database health endpoint returns 100% success
- [ ] All API endpoints return 200 status
- [ ] No more "enterprise connection manager" errors
- [ ] Pool utilization under 80%

## 📞 ESCALATION

If recovery actions fail:
1. **Revert to last known stable commit**
2. **Use fallback simple database connection**
3. **Disable enterprise features temporarily**

Time allocation: **30 minutes maximum** for complete recovery