# ITERATION 2 PHASE 0: Analytics Pipeline Assessment

**Date**: 2025-10-08
**Assessor**: ML Architecture Expert
**Target**: Data pipeline and aggregation failures in analytics APIs

---

## Executive Summary

**Status**: 🔴 **CRITICAL FAILURES IDENTIFIED**

Three analytics endpoints are returning 500 errors due to fundamental schema mismatches between API code and Neon database structure. The failures stem from:

1. Column name mismatches (API uses `movement_type`, DB has `type`)
2. Missing cost pricing data (all `cost_price` values are 0)
3. No caching layer integration
4. Empty stock movement history (no data for trends)

**Impact**: All analytics dashboards are non-functional.

---

## 1. PIPELINE ANALYSIS

### 1.1 Analytics Queries Status

#### `/api/analytics/dashboard` - Dashboard KPIs
**Status**: ✅ **QUERIES EXECUTE** | ⚠️ **DATA QUALITY ISSUES**

```sql
-- Test Results:
SELECT COUNT(*) FROM suppliers WHERE status = 'active'
→ 22 suppliers ✅

SELECT COUNT(*), SUM(stock_qty * cost_price) FROM inventory_items
→ 25,624 items, $0.00 total value ❌

-- ISSUE: All cost_price values are 0
-- All 25,624 items show low_stock alert (stock_qty <= reorder_point)
```

**Root Cause**:
- `inventory_items` view pulls from `core.stock_on_hand` which lacks cost pricing
- Default `reorder_point = 10` causes false low-stock alerts
- View returns data but calculations produce meaningless results

#### `/api/inventory/analytics` - Inventory Metrics
**Status**: ✅ **QUERIES EXECUTE** | ⚠️ **DATA QUALITY ISSUES**

```sql
-- Aggregation queries work but:
- cost_price = 0 → total_value = $0
- All items flagged as low_stock
- excess_value, dead_value calculations invalid
```

**Root Cause**: Same as dashboard - missing cost data from source tables.

#### `/api/inventory/trends` - Time Series Analysis
**Status**: ❌ **QUERY FAILS** | 🔴 **SCHEMA MISMATCH**

```sql
-- API Query:
SELECT LOWER(m.movement_type) FROM stock_movements...

-- Error: column m.movement_type does not exist
-- Actual column name: "type"
```

**Root Cause**:
- API code expects `movement_type` column
- Neon DB `stock_movements` view uses `type` column
- Column name mismatch causes immediate query failure
- No stock movement data in last 30 days (table has 0 rows with recent dates)

---

## 2. DATA PROCESSING COMPATIBILITY

### 2.1 Schema Bridge Analysis

**Incompatibility Matrix**:

| API Expectation | Neon Reality | Status |
|----------------|--------------|--------|
| `movement_type` | `type` | ❌ MISMATCH |
| `cost_price` populated | `cost_price = 0` | ⚠️ EMPTY |
| `reorder_point` varied | `reorder_point = 10` | ⚠️ STATIC |
| `max_stock_level` | Does not exist | ❌ MISSING |
| Stock movements data | Empty table | ❌ NO DATA |

### 2.2 View Structure Issues

**`inventory_items` View**:
```sql
-- Schema:
- All columns nullable (including critical metrics)
- No indexes (0 bytes index size)
- Pulls from core.stock_on_hand joined with suppliers
- Missing cost_price population logic
```

**`stock_movements` View**:
```sql
-- Schema:
- Column: "type" (not "movement_type")
- Columns: id, sku, product_name, type, quantity, supplier_id, location_id
- 0 rows with created_at in last 30 days
- No historical movement data for trends
```

### 2.3 Data Transformation Issues

**Current State**:
- ✅ Views exist and are queryable
- ✅ Join logic works (suppliers, inventory)
- ❌ No cost price calculation from source tables
- ❌ Column naming convention mismatch
- ❌ No movement history for analytics

**Neon Compatibility**:
- ✅ PostgreSQL 17 supports all aggregation functions
- ✅ Window functions, CTEs work correctly
- ✅ Date series generation performs well (0.1ms execution)
- ❌ View definitions don't match API expectations

---

## 3. PERFORMANCE ANALYSIS

### 3.1 Query Execution Times

**Tested on Neon (proud-mud-50346856)**:

| Query Type | Execution Time | Status |
|-----------|----------------|--------|
| Simple COUNT | < 5ms | ✅ FAST |
| SUM aggregation (25K rows) | < 10ms | ✅ FAST |
| Time series with CTE | 0.1ms | ✅ EXCELLENT |
| Multi-table joins | < 15ms | ✅ FAST |

**Query Plan Analysis** (Trends query):
```
Planning Time: 0.269ms
Execution Time: 0.1ms
Total Cost: 176.83 (low)
Rows Processed: 31 (date series)

Bottleneck: NOT performance - empty data returns immediately
```

### 3.2 Database Performance Metrics

**Neon Project Stats**:
- Active Time: 37,568 seconds
- CPU Used: 13,723 seconds
- Storage: 132.7 MB
- Autoscaling: 0.25 - 2 CU
- Table Size: 40 kB (stock_movement)

**Performance Assessment**:
- ✅ Query execution is fast
- ✅ Neon autoscaling handles load well
- ❌ Data availability is the blocker, not performance

### 3.3 No Timeout Issues

**Conclusion**: Queries complete in milliseconds. There are NO performance-based failures.

---

## 4. CACHING STRATEGY REVIEW

### 4.1 Cache Implementation Status

**Cache Layer Exists**: ✅ YES
- Location: `src/lib/cache/query-cache.ts`
- Implementation: LRU cache with configurable TTL
- Pre-configured instances:
  - `hotCache`: 2 min TTL, 500 entries
  - `dashboardCache`: 5 min TTL, 200 entries
  - `analyticsCache`: 15 min TTL, 100 entries
  - `realtimeCache`: 30 sec TTL, 1000 entries

**Cache Integration Status**: ❌ **NOT INTEGRATED**

```typescript
// Analytics endpoints DO NOT use caching:
// ❌ /api/analytics/dashboard/route.ts
// ❌ /api/inventory/analytics/route.ts
// ❌ /api/inventory/trends/route.ts

// Only health/pipeline endpoint references CacheManager
```

### 4.2 Cache Design Quality

**Architecture**: ✅ PRODUCTION-GRADE
- Proper LRU eviction policy
- Metrics tracking (hits, misses, evictions)
- Invalidation by pattern/tag
- Query-specific TTL support
- Hit rate calculation

**Missing Implementation**:
```typescript
// Expected pattern (NOT implemented):
import { CacheManager, cachedQuery, CacheKeys } from '@/lib/cache/query-cache';

const kpis = await cachedQuery(
  CacheManager.analyticsCache,
  CacheKeys.dashboardKPIs(),
  async () => {
    const { rows } = await query('SELECT ...');
    return rows[0];
  }
);
```

### 4.3 Cache Integration Gap

**Impact of Missing Cache**:
- Every dashboard refresh hits database
- Redundant aggregations on same data
- No query result reuse across users
- Potential for thundering herd on dashboard loads

**Estimated Load Without Cache**:
- 10 concurrent users × 3 analytics endpoints × 1 req/5sec = 6 QPS
- All queries hit Neon directly (no buffering)

---

## 5. MONITORING GAPS

### 5.1 Current Monitoring Capabilities

**Available**:
- ✅ Basic console.log in endpoints
- ✅ Error details in 500 responses
- ✅ Neon platform metrics (CPU, storage)
- ✅ Cache stats API (unused)

**Missing**:
- ❌ Query performance tracking
- ❌ Slow query logging
- ❌ Cache hit/miss rates
- ❌ Aggregation failure alerts
- ❌ Data quality monitoring (null checks)
- ❌ Schema drift detection

### 5.2 Observability Needs

**Required Instrumentation**:
1. Query execution time logging
2. Cache performance metrics endpoint
3. Data quality assertions (cost_price validation)
4. Schema compatibility checks on startup
5. Aggregation result validation

**Recommended Tools**:
- Enable `pg_stat_statements` for query analysis
- Add APM tracing for API routes
- Implement health checks for data quality
- Create monitoring dashboard for cache stats

---

## 6. ROOT CAUSE ANALYSIS

### 6.1 Primary Failures

**1. Schema Mismatch** 🔴 CRITICAL
```
API Code → expects: movement_type
Neon DB  → provides: type

Result: Query fails with "column does not exist"
```

**2. Missing Cost Data** 🔴 CRITICAL
```
API Code → calculates: SUM(stock_qty * cost_price)
Neon DB  → all cost_price = 0

Result: Total inventory value = $0 (invalid)
```

**3. No Movement History** 🔴 CRITICAL
```
API Code → queries: last 30 days of movements
Neon DB  → 0 rows in date range

Result: Empty trend data, no analytics insights
```

### 6.2 Secondary Issues

**4. No Cache Integration** ⚠️ IMPORTANT
```
Cache code exists but not used in analytics endpoints
Result: Unnecessary database load, slower response times
```

**5. Data Quality** ⚠️ IMPORTANT
```
- All reorder_point = 10 (causes false alerts)
- No max_stock_level (can't detect overstocking)
- 25,624 items flagged as low stock (obviously wrong)
```

### 6.3 Aggregation Failure Causes

**Why Aggregations Fail**:

1. **Column Name Mismatch**
   - Code was written for different schema
   - No schema validation on deployment
   - Views use different naming than expected

2. **Data Availability**
   - Source tables lack required data
   - No data population for cost pricing
   - No stock movement transaction history

3. **View Design**
   - Views don't include all required columns
   - Missing computed fields (total_value)
   - No materialized views for performance

---

## 7. RECOMMENDATIONS

### 7.1 Immediate Fixes (P0 - Hours)

**Fix 1: Column Name Alignment**
```typescript
// Update API queries:
// src/app/api/inventory/trends/route.ts
// src/app/api/inventory/analytics/route.ts

- movement_type → type (align with Neon schema)
```

**Fix 2: Add Missing Columns to Views**
```sql
-- Update inventory_items view to include:
CREATE OR REPLACE VIEW inventory_items AS
SELECT
  ...,
  COALESCE(sp.cost, 0) as cost_price,  -- Pull from supplier_product
  ...
FROM core.stock_on_hand soh
LEFT JOIN core.supplier_product sp ON soh.supplier_product_id = sp.id
```

**Fix 3: Populate Test Data**
```sql
-- Add sample stock movements for trends:
INSERT INTO core.stock_movement (movement_type, qty, created_at, ...)
-- Generate 30 days of test data
```

### 7.2 Short-term Improvements (P1 - Days)

**Improve 1: Integrate Caching**
```typescript
// Wrap all analytics queries with cachedQuery:
const result = await cachedQuery(
  CacheManager.analyticsCache,
  CacheKeys.stockMovements(days),
  async () => executeQuery()
);
```

**Improve 2: Add Data Quality Checks**
```typescript
// Before returning results:
if (totalInventoryValue === 0 && itemCount > 0) {
  console.warn('⚠️ Cost price data missing');
  // Log to monitoring system
}
```

**Improve 3: Create Materialized Views**
```sql
-- For expensive aggregations:
CREATE MATERIALIZED VIEW mv_inventory_kpis AS
SELECT
  COUNT(*) as total_items,
  SUM(cost_price * stock_qty) as total_value,
  ...
FROM inventory_items;

-- Refresh hourly via cron
```

### 7.3 Long-term Enhancements (P2 - Weeks)

**Enhance 1: Schema Validation Layer**
```typescript
// Add runtime schema checks:
async function validateSchema() {
  const columns = await query(`
    SELECT column_name FROM information_schema.columns
    WHERE table_name = 'stock_movements'
  `);
  assert(columns.includes('type'), 'Missing type column');
}
```

**Enhance 2: Query Performance Monitoring**
```typescript
// Instrument all analytics queries:
const startTime = performance.now();
const result = await query(sql);
const duration = performance.now() - startTime;

logMetric('query.duration', duration, { endpoint, query });
```

**Enhance 3: Automated Data Pipelines**
- ETL jobs to populate cost pricing from supplier catalogs
- Scheduled movement data generation from orders
- Automated reorder point calculations based on velocity

---

## 8. MIGRATION STRATEGY

### Phase 1: Schema Alignment (1-2 days)
1. Update view definitions to match API expectations
2. Add missing columns (cost_price, max_stock_level)
3. Rename `type` to `movement_type` in views
4. Test all analytics queries against updated views

### Phase 2: Data Population (2-3 days)
1. Backfill cost_price from supplier_product table
2. Generate historical stock_movement data
3. Calculate realistic reorder_point values
4. Validate data quality with assertions

### Phase 3: Cache Integration (1 day)
1. Wrap analytics queries with cachedQuery
2. Configure appropriate TTLs per endpoint
3. Add cache invalidation on data updates
4. Monitor cache hit rates

### Phase 4: Monitoring Setup (1-2 days)
1. Enable pg_stat_statements extension
2. Add query performance logging
3. Create data quality health checks
4. Set up alerting for failures

---

## 9. SUCCESS METRICS

### 9.1 Functional Metrics

**Before Fix**:
- ❌ 3/3 analytics endpoints fail (100% failure rate)
- ❌ $0 total inventory value reported
- ❌ 25,624 false low-stock alerts
- ❌ 0 trend data points

**After Fix** (Target):
- ✅ 3/3 analytics endpoints succeed (0% failure rate)
- ✅ Accurate inventory valuation (> $0)
- ✅ < 5% items flagged low-stock (realistic)
- ✅ 30 days of trend data available

### 9.2 Performance Metrics

**Targets**:
- Query execution time: < 100ms (p95)
- Cache hit rate: > 80%
- Dashboard load time: < 500ms
- API error rate: < 0.1%

### 9.3 Data Quality Metrics

**Validation Rules**:
- `cost_price > 0` for 90%+ items
- `reorder_point` varies by item (not all = 10)
- Stock movements recorded daily
- Trend calculations produce non-zero values

---

## 10. CONCLUSION

### Current State Summary

**Analytics Pipeline**: 🔴 **BROKEN**
- Schema mismatches block query execution
- Data quality issues render results meaningless
- No caching causes unnecessary load
- Missing monitoring hides failures

**Neon Performance**: ✅ **EXCELLENT**
- Queries execute in milliseconds
- No timeout or scalability issues
- Database structure is sound

**Recovery Path**: ✅ **CLEAR**
- Issues are well-defined and fixable
- No architectural redesign needed
- Estimated fix time: 4-7 days

### Key Findings

1. **The database works** - Neon performance is excellent
2. **The schema doesn't match** - API expects different column names
3. **The data is missing** - Cost pricing and movements not populated
4. **The cache isn't used** - Integration layer not implemented
5. **Monitoring is blind** - No observability into failures

### Next Steps

**Immediate Actions**:
1. ✅ Assessment complete (this document)
2. ⏭️ Fix column name mismatches in API code
3. ⏭️ Update view definitions for cost_price
4. ⏭️ Populate test data for stock movements
5. ⏭️ Integrate caching layer

**Deliverable**: This assessment provides clear diagnosis and actionable remediation plan for analytics pipeline restoration.

---

**MCP Calls Log**:
- `list_projects`: Identified Neon project (proud-mud-50346856)
- `get_database_tables`: Enumerated schema (27 tables/views)
- `describe_table_schema`: Analyzed inventory_items, stock_movements structures
- `run_sql` (8 calls): Tested aggregations, validated data quality
- `explain_sql_statement`: Analyzed query performance (0.1ms execution)

**Assessment Status**: ✅ COMPLETE
