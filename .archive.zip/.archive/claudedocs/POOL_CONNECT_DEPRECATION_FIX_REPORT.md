# Pool.connect() Deprecation Fix Report

**Date**: 2025-09-30
**Issue**: Direct `pool.connect()` usage deprecated in favor of `query()` and `withTransaction()` from unified-connection
**Error**: `Error: Direct pool.connect() access deprecated. Use query() or withTransaction() instead.`

---

## Root Cause Analysis

The unified-connection module now throws an error when `pool.connect()` is called directly to enforce proper connection management patterns:

```typescript
// lib/database/unified-connection.ts:36-39
connect: async (): Promise<PoolClient> => {
  throw new Error('Direct pool.connect() access deprecated. Use query() or withTransaction() instead.');
}
```

### Architecture Overview

```
API Routes
  ↓
unified-connection.ts (façade layer)
  ↓
enterprise-connection-manager.ts (implementation)
  ↓
PostgreSQL Database Pool
```

---

## Proper Patterns

### Pattern 1: Read-Only Queries
**Use**: `query()` from unified-connection

```typescript
// BEFORE (Deprecated)
const client = await pool.connect()
try {
  const result = await client.query('SELECT * FROM users WHERE id = $1', [id])
  return result.rows[0]
} finally {
  client.release()
}

// AFTER (Correct)
import { query } from '@/lib/database/unified-connection'
const result = await query('SELECT * FROM users WHERE id = $1', [id])
return result.rows[0]
```

### Pattern 2: Transactional Operations
**Use**: `withTransaction()` from unified-connection

```typescript
// BEFORE (Deprecated)
const client = await pool.connect()
try {
  await client.query('BEGIN')
  const result1 = await client.query('INSERT INTO orders...', [...])
  const result2 = await client.query('UPDATE inventory...', [...])
  await client.query('COMMIT')
  return result1.rows[0]
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}

// AFTER (Correct)
import { withTransaction } from '@/lib/database/unified-connection'
const result = await withTransaction(async (client) => {
  const result1 = await client.query('INSERT INTO orders...', [...])
  const result2 = await client.query('UPDATE inventory...', [...])
  return result1.rows[0]
})
```

---

## Files Fixed (Primary Routes)

### ✅ 1. /src/app/api/inventory/[id]/route.ts
**Lines Fixed**: 49, 149, 291
**Changes**:
- **GET**: Replaced client acquisition with `query()` for read operations
- **PUT**: Wrapped update logic in `withTransaction()`
- **DELETE**: Wrapped delete logic in `withTransaction()`

**Before/After**:
```typescript
// BEFORE - GET (Line 49)
const client = await pool.connect()
try {
  const result = await client.query(query, [id])
  // ... more queries
} finally {
  client.release()
}

// AFTER - GET
const result = await query(itemQuery, [id])
const movementsResult = await query(movementsQuery, [id])
```

```typescript
// BEFORE - PUT (Line 149)
const client = await pool.connect()
try {
  await client.query('BEGIN')
  // ... update logic
  await client.query('COMMIT')
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}

// AFTER - PUT
const result = await withTransaction(async (client) => {
  // ... update logic
  return updateResult.rows[0]
})
```

**Error Handling**: Custom error messages now throw within transaction and are caught in outer try-catch

---

### ✅ 2. /src/app/api/inventory/route.ts
**Lines Fixed**: 493, 606
**Changes**:
- **PATCH** (batch update): Wrapped in `withTransaction()`
- **DELETE** (batch delete): Wrapped in `withTransaction()`

**Before/After**:
```typescript
// BEFORE - PATCH (Line 493)
const client = await pool.connect()
try {
  await client.query('BEGIN')
  for (const updateData of items) {
    // ... update each item
  }
  await client.query('COMMIT')
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}

// AFTER - PATCH
await withTransaction(async (client) => {
  for (const updateData of items) {
    // ... update each item
  }
})
```

**Benefits**:
- Automatic rollback on any error
- Connection properly managed
- Cleaner error handling

---

### ✅ 3. /src/lib/api/suppliers.ts
**Lines Fixed**: 121, 172, 237, 266
**Changes**:
- **createSupplier**: Wrapped in `withTransaction()`
- **updateSupplier**: Wrapped in `withTransaction()`
- **deleteSupplier**: Wrapped in `withTransaction()`
- **getDashboardMetrics**: Changed `pool.query()` to `query()`

**Before/After**:
```typescript
// BEFORE - createSupplier (Line 121)
const client = await pool.connect()
try {
  await client.query('BEGIN')
  const supplierResult = await client.query('INSERT INTO suppliers...', [...])
  await client.query('COMMIT')
  return supplierId
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}

// AFTER - createSupplier
const supplierId = await withTransaction(async (client) => {
  const supplierResult = await client.query('INSERT INTO suppliers...', [...])
  return supplierResult.rows[0].id
})
```

```typescript
// BEFORE - getDashboardMetrics (Line 266)
const result = await pool.query(`WITH metrics AS...`)

// AFTER - getDashboardMetrics
const result = await query(`WITH metrics AS...`)
```

---

### ✅ 4. /src/services/ai/SupplierIntelligenceService.ts
**Lines Fixed**: 107
**Changes**:
- **analyzeSupplier**: Wrapped analysis operations in `withTransaction()`

**Before/After**:
```typescript
// BEFORE (Line 107)
async analyzeSupplier(supplierId: string): Promise<SupplierAnalysis> {
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    // ... analysis operations
    await client.query('COMMIT')
    return analysis
  } catch (error) {
    await client.query('ROLLBACK')
    throw error
  } finally {
    client.release()
  }
}

// AFTER
async analyzeSupplier(supplierId: string): Promise<SupplierAnalysis> {
  return withTransaction(async (client) => {
    // ... analysis operations
    return analysis
  })
}
```

---

### ⚠️ 5. /src/lib/database/transaction-helper.ts
**Lines Fixed**: 41, 73, 106
**Changes**:
- Updated imports to use `enterpriseWithTransaction` from unified-connection
- **withTransaction**: Now delegates to enterprise connection manager
- **withClient**: Currently delegates to withTransaction (⚠️ needs refinement)

**Status**: Partially fixed - withClient should NOT wrap in transaction

**Recommendation**:
```typescript
// withClient should use enterprise query with connection pooling but NO transaction
// This requires exposing a new method in enterprise-connection-manager.ts
static async withClient<T>(callback: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await this.pool!.connect()
  try {
    return await callback(client)
  } finally {
    client.release()
  }
}
```

---

## Files Requiring Fixes (Remaining)

### Priority 1: Active Routes
1. ❌ `/src/app/api/inventory/detailed/[itemId]/route.ts` (Lines: 82, 441)
2. ❌ `/src/app/api/suppliers/[id]/inventory/route.ts` (Lines: 53, 417)
3. ❌ `/src/app/api/suppliers/pricelists/route.ts` (Lines: 137, 494, 686)
4. ❌ `/src/app/api/suppliers/pricelists/upload/live-route.ts` (Line: 357)
5. ❌ `/src/app/api/suppliers/pricelists/promote/route.ts` (Line: 156)

### Priority 2: Optional/Backup Files
6. ⏸️ `/src/app/api/alerts/route.ts.backup` (Line: 76) - Backup file, low priority
7. ⏸️ `/src/app/api/suppliers/route.optimized.ts` (Line: 293) - Alternative implementation

---

## Testing Checklist

### ✅ Completed
- [x] Inventory GET by ID endpoint
- [x] Inventory PUT (update) endpoint
- [x] Inventory DELETE endpoint
- [x] Inventory batch PATCH endpoint
- [x] Inventory batch DELETE endpoint
- [x] Supplier create/update/delete operations
- [x] Supplier dashboard metrics
- [x] AI supplier analysis

### ❌ Remaining
- [ ] Detailed inventory item routes
- [ ] Supplier inventory association routes
- [ ] Pricelist management routes
- [ ] Pricelist upload routes
- [ ] Pricelist promotion routes

---

## Performance Impact

### Benefits of New Pattern

1. **Connection Management**
   - Automatic pool exhaustion prevention
   - Circuit breaker for overload protection
   - Health monitoring and leak detection

2. **Retry Logic**
   - Automatic retry with exponential backoff (3 attempts default)
   - Smart retry skip for syntax/permission errors
   - Configurable timeout per operation

3. **Observability**
   - Query performance logging
   - Connection pool status tracking
   - Transaction lifecycle monitoring

### Benchmarks (from enterprise-connection-manager)
- Max connections: 20 (configurable via DB_POOL_MAX)
- Connection timeout: 30s
- Query timeout: 2 minutes (for complex analytics)
- Statement timeout: 90s
- Health check interval: 30s

---

## Migration Guide for Remaining Files

### Step 1: Update Imports
```typescript
// Old
import { pool } from '@/lib/database'

// New
import { query, withTransaction } from '@/lib/database/unified-connection'
```

### Step 2: Replace Read-Only Operations
```typescript
// Pattern: Single query without transaction
const result = await query('SELECT...', [params])

// Pattern: Multiple independent read queries
const result1 = await query('SELECT...', [params1])
const result2 = await query('SELECT...', [params2])
```

### Step 3: Replace Transactional Operations
```typescript
// Pattern: BEGIN/COMMIT/ROLLBACK
await withTransaction(async (client) => {
  const result1 = await client.query('INSERT...', [...])
  const result2 = await client.query('UPDATE...', [...])
  return result1.rows[0]
})
```

### Step 4: Error Handling
```typescript
// Throw custom errors inside transaction - they will be caught outside
await withTransaction(async (client) => {
  const check = await client.query('SELECT...', [id])
  if (check.rows.length === 0) {
    throw new Error('Record not found') // Will trigger ROLLBACK
  }
  // ... continue transaction
})
```

---

## Security Improvements

1. **Connection Leak Prevention**: Automatic release via finally blocks
2. **Pool Exhaustion Protection**: Circuit breaker pattern
3. **Timeout Enforcement**: Statement and connection timeouts
4. **Transaction Isolation**: Guaranteed single-connection transactions

---

## Rollback Plan

If issues arise, temporary fix:
```typescript
// In unified-connection.ts, temporarily allow pool.connect()
connect: async (): Promise<PoolClient> => {
  console.warn('⚠️ Using deprecated pool.connect() - update to query() or withTransaction()')
  return dbManager.pool!.connect()
}
```

**Note**: This defeats the purpose of the architecture improvement and should only be used as emergency rollback.

---

## Next Steps

1. **Immediate**: Fix remaining Priority 1 routes (detailed inventory, pricelists)
2. **Short-term**: Refine transaction-helper.ts withClient implementation
3. **Medium-term**: Add integration tests for all fixed routes
4. **Long-term**: Add TypeScript lint rule to prevent pool.connect() usage

---

## Contact

For questions or issues with this migration:
- Check: `/mnt/k/00Project/MantisNXT/claudedocs/transaction-helper-quick-reference.md`
- Review: `/mnt/k/00Project/MantisNXT/lib/database/enterprise-connection-manager.ts`