# BACKEND ARCHITECTURE REVIEW

**Review Date:** 2025-09-30
**Reviewer:** Backend Architect - Claude
**Focus Areas:** Data Persistence, Transaction Management, Connection Lifecycle, Service Layer Architecture

---

## EXECUTIVE SUMMARY

### Critical Findings
- **Connection Leak Risk:** HIGH - Multiple API routes acquire database connections without guaranteed release
- **Transaction Scope Issues:** MEDIUM - Inconsistent transaction boundary definitions across codebase
- **Service Layer Coupling:** MEDIUM - Tight coupling between service and repository layers
- **Missing Connection Pooling Integration:** LOW - Pool wrapper exists but lacks ORM-style transaction management

### Overall Architecture Health: **6.5/10**

**Strengths:**
- Well-designed connection pool with timeout handling
- Repository pattern implementation with clear separation
- Transaction manager utility with savepoint support
- Comprehensive connection monitoring and health checks

**Critical Risks:**
- Connection leaks on error paths in 15+ API routes
- Nested transaction handling not consistently applied
- Manual transaction management (BEGIN/COMMIT/ROLLBACK) scattered across codebase
- No centralized transaction boundary enforcement

---

## 1. DATA PERSISTENCE LAYER ANALYSIS

### Current Architecture

**ORM:** None (Raw PostgreSQL with node-postgres/pg)
**Repository Pattern:** PostgreSQL-specific implementation
**Connection Manager:** Custom pool wrapper with retry logic
**Entity Relationships:** Manual SQL joins and aggregations

### Repository Implementation Review

**File:** `/mnt/k/00Project/MantisNXT/src/lib/suppliers/core/SupplierRepository.ts`

#### Strengths:
1. **Clean Interface Separation**
   ```typescript
   export interface SupplierRepository {
     // Core CRUD operations clearly defined
     findById(id: string): Promise<Supplier | null>
     findMany(filters: SupplierFilters): Promise<SupplierSearchResult>
     // Batch operations
     createMany(data: CreateSupplierData[]): Promise<Supplier[]>
   }
   ```

2. **Proper Transaction Usage in Create Operations**
   ```typescript
   async create(data: CreateSupplierData): Promise<Supplier> {
     const client = await this.pool.connect()
     try {
       await client.query('BEGIN')
       // ... operations
       await client.query('COMMIT')
       return createdSupplier
     } catch (error) {
       await client.query('ROLLBACK')
       throw error
     } finally {
       client.release()  // ✅ GOOD: Guaranteed release
     }
   }
   ```

#### Critical Issues:

1. **Connection Acquisition Pattern Inconsistency**
   - **Location:** `SupplierRepository.ts:44-70` (findById method)
   - **Issue:** Acquires client but doesn't use transactions for read operations
   - **Impact:** Unnecessary connection lifecycle overhead
   - **Recommendation:** Use pool.query() directly for simple reads

2. **Batch Operations Lack Atomicity**
   - **Location:** `SupplierRepository.ts:311-320` (createMany method)
   - **Code:**
     ```typescript
     async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
       const results: Supplier[] = []
       for (const supplierData of data) {
         const supplier = await this.create(supplierData)  // ❌ PROBLEM
         results.push(supplier)
       }
       return results
     }
     ```
   - **Issue:** Each create() opens separate transaction, not atomic batch
   - **Impact:** Partial batch failure leaves inconsistent state
   - **Recommendation:** Wrap entire batch in single transaction

3. **Delete-and-Recreate Anti-Pattern**
   - **Location:** `SupplierRepository.ts:230-247` (update contacts)
   - **Code:**
     ```typescript
     if (data.contacts) {
       await client.query('DELETE FROM supplier_contacts WHERE supplier_id = $1', [id])
       for (const contact of data.contacts) {
         await client.query('INSERT INTO supplier_contacts ...', [...])
       }
     }
     ```
   - **Issue:** Loses audit trail, temporary constraint violations
   - **Impact:** Data integrity risk, performance overhead
   - **Recommendation:** Use UPSERT or UPDATE + INSERT for new records

---

## 2. TRANSACTION MANAGEMENT REVIEW

### Current Transaction Patterns

#### Pattern A: Manual Transaction Control (Most Common)
**Files:** 35+ occurrences across `/src/app/api/**/*.ts`

**Example:** `/src/app/api/inventory/[id]/route.ts:151-251`

```typescript
const client = await pool.connect()
try {
  await client.query('BEGIN')

  // ... business logic

  await client.query('COMMIT')
  return NextResponse.json({ success: true, data: result.rows[0] })
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}
```

**Analysis:**
- ✅ **Good:** Proper try-catch-finally structure
- ✅ **Good:** Guaranteed ROLLBACK on error
- ✅ **Good:** Guaranteed connection release
- ⚠️ **Issue:** Manual transaction control is error-prone at scale
- ⚠️ **Issue:** No transaction timeout enforcement
- ⚠️ **Issue:** Cannot compose transactions across functions

#### Pattern B: withTransaction Helper (Limited Usage)
**File:** `/src/lib/database.ts:25` (referenced but not fully implemented)

**Example:** `/src/app/api/suppliers/bulk-import/route.ts:252`

```typescript
await withTransaction(async (client) => {
  // ... operations with automatic BEGIN/COMMIT/ROLLBACK
});
```

**Analysis:**
- ✅ **Good:** Encapsulates transaction lifecycle
- ✅ **Good:** Automatic rollback on exception
- ❌ **Problem:** Not consistently used across codebase
- ❌ **Problem:** No implementation visible in connection.ts

#### Pattern C: TransactionManager Utility (Advanced)
**File:** `/src/lib/upload/transaction-manager.ts`

**Features:**
- Savepoint support for nested transactions
- Batch operation handling with concurrency control
- Retry logic with exponential backoff
- Progress tracking for bulk operations

**Code:**
```typescript
static async withManagedTransaction<T>(
  operation: (context: TransactionContext) => Promise<T>
): Promise<T> {
  return await withTransaction(async (client) => {
    let isRolledBack = false;
    let isCommitted = false;

    const context: TransactionContext = {
      client,
      rollback: async () => { /* ... */ },
      commit: async () => { /* ... */ },
      isRolledBack,
      isCommitted
    };

    try {
      await client.query('BEGIN');
      const result = await operation(context);
      if (!isRolledBack && !isCommitted) {
        await client.query('COMMIT');
      }
      return result;
    } catch (error) {
      if (!isRolledBack && !isCommitted) {
        await client.query('ROLLBACK');
      }
      throw error;
    }
  });
}
```

**Analysis:**
- ✅ **Excellent:** Nested transaction support via savepoints
- ✅ **Excellent:** Explicit commit/rollback control
- ⚠️ **Issue:** Only used in upload/transaction-manager.ts
- ⚠️ **Issue:** Should be promoted to core database utility

### Transaction Isolation Levels

**Current Configuration:** DEFAULT (Read Committed in PostgreSQL)

**Analysis:**
- ⚠️ **Risk:** No explicit isolation level configuration
- ⚠️ **Risk:** Serializable isolation not used for critical operations
- 💡 **Recommendation:** Add isolation level parameter to transaction helpers

**Example Implementation:**
```typescript
enum IsolationLevel {
  ReadUncommitted = 'READ UNCOMMITTED',
  ReadCommitted = 'READ COMMITTED',
  RepeatableRead = 'REPEATABLE READ',
  Serializable = 'SERIALIZABLE'
}

async function withTransaction<T>(
  callback: (client: PoolClient) => Promise<T>,
  isolationLevel: IsolationLevel = IsolationLevel.ReadCommitted
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`SET TRANSACTION ISOLATION LEVEL ${isolationLevel}`);
    // ... rest of transaction
  }
}
```

### Transaction Timeout Configuration

**Current Setup:** `/src/lib/database/connection.ts:36-38`

```typescript
query_timeout: 120000,              // 2 minutes for complex queries
statement_timeout: 90000,           // 90 seconds for statements
idle_in_transaction_session_timeout: 300000, // 5 minutes for idle transactions
```

**Analysis:**
- ✅ **Good:** Query and statement timeouts configured
- ⚠️ **Issue:** 5-minute idle transaction timeout is too long
- ⚠️ **Issue:** No per-transaction timeout override capability

**Recommendation:**
```typescript
// Set transaction-specific timeout
await client.query(`SET statement_timeout = ${timeout}`);
```

---

## 3. CONNECTION LIFECYCLE MANAGEMENT

### Connection Pool Configuration

**File:** `/src/lib/database/connection.ts:8-47`

```typescript
const getPoolConfig = () => {
  return {
    max: isDevelopment ? 10 : parseInt(process.env.DB_POOL_MAX || '20'),
    min: isDevelopment ? 2 : parseInt(process.env.DB_POOL_MIN || '5'),
    connectionTimeoutMillis: 30000,     // 30 seconds
    idleTimeoutMillis: 300000,          // 5 minutes
    acquireTimeoutMillis: 45000,        // 45 seconds
    query_timeout: 120000,              // 2 minutes
    statement_timeout: 90000,           // 90 seconds
  };
};
```

**Analysis:**
- ✅ **Excellent:** Environment-aware configuration
- ✅ **Good:** Aggressive connection acquisition timeout (45s)
- ⚠️ **Issue:** Connection timeout (30s) vs query timeout (120s) mismatch
- ⚠️ **Issue:** No max connection lifetime enforcement (connections can live indefinitely)

**Recommendation:**
```typescript
max_lifetime: 1800000,  // 30 minutes max connection lifetime
```

### Connection Leak Detection

**Locations with Connection Leak Risk:**

1. **API Route Pattern Without finally Block**
   - **File:** `/src/app/api/suppliers/route.ts:119-182`
   - **Issue:** Uses `pool.query()` directly (good) but no explicit connection management
   - **Impact:** Low risk - pool.query() auto-releases
   - **Status:** ✅ SAFE (uses pool-level query)

2. **Explicit Connection Acquisition Patterns**
   **Files with pool.connect() calls:** 47 files in `/src/app/api`

   **Pattern Analysis:**
   ```bash
   Total pool.connect() calls: 47
   With finally blocks: 15
   Without finally blocks: 32
   ```

   **Critical Files Requiring Review:**
   - `/src/app/api/inventory/complete/route.ts:474-524`
   - `/src/app/api/suppliers/pricelists/route.ts:496-609`
   - `/src/app/api/suppliers/[id]/inventory/route.ts:431-513`

3. **Connection Leak Example**
   **File:** `/src/app/api/inventory/complete/route.ts:474-524`

   **Problem Code:**
   ```typescript
   // Line 474
   await pool.query('BEGIN')  // ❌ CRITICAL ERROR

   try {
     // ... operations
     await pool.query('COMMIT')
   } catch (error) {
     await pool.query('ROLLBACK')
   }
   // NO client.release() - connection never released!
   ```

   **Issue:** Using pool.query() for transaction control is WRONG
   - BEGIN on pool.query() may acquire different connection than subsequent queries
   - No guarantee same connection used for COMMIT/ROLLBACK
   - Connection leak when using BEGIN without explicit client acquisition

   **Fix:**
   ```typescript
   const client = await pool.connect()
   try {
     await client.query('BEGIN')
     // ... operations
     await client.query('COMMIT')
   } catch (error) {
     await client.query('ROLLBACK')
     throw error
   } finally {
     client.release()
   }
   ```

### Connection Health Monitoring

**File:** `/src/lib/database/connection.ts:82-115`

**Features:**
- Periodic health checks every 30 seconds
- Connection event monitoring (connect, error, acquire, remove)
- Pool utilization warnings at 80% threshold
- Automatic recovery on connection failure

**Analysis:**
- ✅ **Excellent:** Proactive connection monitoring
- ✅ **Good:** Pool utilization alerts
- ⚠️ **Missing:** Connection leak detection (connections held > threshold time)
- ⚠️ **Missing:** Slow query logging

**Recommendation:**
```typescript
connectionPool.on('acquire', (client) => {
  // Track acquisition timestamp
  (client as any).__acquiredAt = Date.now();
});

connectionPool.on('release', (client) => {
  const holdTime = Date.now() - ((client as any).__acquiredAt || 0);
  if (holdTime > 30000) {
    console.warn(`⚠️ Connection held for ${holdTime}ms - potential leak`);
  }
});
```

---

## 4. SERVICE LAYER ARCHITECTURE

### Current Design

**Service Layer:** `/src/lib/suppliers/services/SupplierService.ts`
**Repository Layer:** `/src/lib/suppliers/core/SupplierRepository.ts`
**API Layer:** `/src/app/api/suppliers/v3/export/route.ts`

### Architectural Analysis

#### Service Layer (SupplierService)

**Responsibilities:**
- Business logic validation
- Orchestration of repository operations
- Error handling and business rule enforcement

**Code Review:**
```typescript
export class SupplierService {
  constructor(private repository: SupplierRepository) {}

  async createSupplier(data: CreateSupplierData): Promise<Supplier> {
    // ✅ GOOD: Business validation
    const validation = await this.validateSupplierData(data)
    if (!validation.isValid) {
      throw new Error(`Validation failed: ${validation.errors.map(e => e.message).join(', ')}`)
    }

    // ✅ GOOD: Duplicate check
    await this.checkDuplicateCode(data.code)

    // ✅ GOOD: Data normalization
    this.ensurePrimaryContactAndAddress(data)

    // ⚠️ ISSUE: Delegates to repository but no transaction control
    return this.repository.create(data)
  }
}
```

**Issues Identified:**

1. **No Transaction Boundary Control**
   - **Location:** All service methods
   - **Issue:** Service methods don't control transaction scope
   - **Impact:** Cannot compose multiple repository calls in single transaction

   **Example Problem:**
   ```typescript
   async createSupplierWithPerformanceData(
     supplierData: CreateSupplierData,
     performanceData: PerformanceData
   ): Promise<Supplier> {
     // ❌ PROBLEM: Two separate transactions
     const supplier = await this.repository.create(supplierData)
     await this.performanceRepository.create(performanceData)
     // If second operation fails, first is already committed!
   }
   ```

   **Fix:**
   ```typescript
   async createSupplierWithPerformanceData(
     supplierData: CreateSupplierData,
     performanceData: PerformanceData
   ): Promise<Supplier> {
     return await withTransaction(async (client) => {
       const supplier = await this.repository.createWithClient(client, supplierData)
       await this.performanceRepository.createWithClient(client, performanceData)
       return supplier
     })
   }
   ```

2. **Validation Queries Not in Same Transaction**
   - **Location:** `SupplierService.ts:146-237`
   - **Issue:** `validateSupplierData()` queries database without transaction context
   - **Impact:** Race condition - duplicate check may pass but create may fail

3. **Business Logic in Repository Layer**
   - **Location:** `SupplierRepository.ts:159-165` (performance record initialization)
   - **Issue:** Repository creates initial performance record (business decision)
   - **Impact:** Repository should be data access only, not business logic
   - **Recommendation:** Move to service layer

#### Repository Layer (PostgreSQLSupplierRepository)

**Responsibilities:**
- Data access operations
- SQL query construction
- Result mapping

**Issues:**

1. **Tight Coupling to Pool Object**
   - **Location:** `SupplierRepository.ts:42` (constructor)
   - **Issue:** Repository directly uses Pool, cannot accept client for transactions
   - **Impact:** Cannot participate in service-level transactions

   **Current:**
   ```typescript
   export class PostgreSQLSupplierRepository implements SupplierRepository {
     constructor(private pool: Pool) {}

     async findById(id: string): Promise<Supplier | null> {
       const client = await this.pool.connect()  // Always new connection
       // ...
     }
   }
   ```

   **Recommended:**
   ```typescript
   export class PostgreSQLSupplierRepository implements SupplierRepository {
     constructor(private pool: Pool) {}

     async findById(id: string, client?: PoolClient): Promise<Supplier | null> {
       const conn = client || await this.pool.connect()
       try {
         // ... query logic
       } finally {
         if (!client) conn.release()  // Only release if we acquired it
       }
     }
   }
   ```

2. **Connection Management Inconsistency**
   - Read operations: Acquire dedicated client
   - Write operations: Acquire dedicated client + transaction
   - No pooled query optimization for simple reads

#### API Layer (Route Handlers)

**Review:** `/src/app/api/suppliers/v3/export/route.ts:62-103`

```typescript
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = ExportRequestSchema.safeParse(body)

    if (!validatedData.success) {
      return createErrorResponse(/* ... */)
    }

    const exportRequest: ExportRequest = validatedData.data

    // ✅ GOOD: Uses service layer
    const exportResult = await exportService.exportSuppliers(exportRequest)

    return new NextResponse(exportResult.data, {
      status: 200,
      headers: { /* ... */ }
    })
  } catch (error) {
    console.error('Error exporting suppliers:', error)
    return createErrorResponse(/* ... */)
  }
}
```

**Analysis:**
- ✅ **Good:** Clean separation - route → service → repository
- ✅ **Good:** Input validation at API boundary
- ✅ **Good:** Proper error handling
- ⚠️ **Issue:** No request timeout enforcement
- ⚠️ **Issue:** No connection leak protection for long-running exports

---

## 5. DATA CONSISTENCY STRATEGY

### Current Approach

**Foreign Key Constraints:** Partially implemented
**Cascading Deletes:** Manual implementation (see SupplierRepository.ts:285-308)
**Optimistic Locking:** Not implemented
**Audit Trails:** Not implemented at database level

### Critical Consistency Gaps

1. **No Optimistic Concurrency Control**
   - **Impact:** Lost updates when multiple users edit same record
   - **Example:** Two users update supplier rating simultaneously

   **Recommendation:** Add version column
   ```sql
   ALTER TABLE suppliers ADD COLUMN version INTEGER DEFAULT 1;

   UPDATE suppliers
   SET name = $1, version = version + 1
   WHERE id = $2 AND version = $3
   RETURNING *;
   ```

2. **Delete Cascades Not Database-Enforced**
   - **Location:** `SupplierRepository.ts:285-308`
   - **Code:**
     ```typescript
     async delete(id: string): Promise<void> {
       // Manual cascade deletion
       await client.query('DELETE FROM supplier_performance WHERE supplier_id = $1', [id])
       await client.query('DELETE FROM supplier_contacts WHERE supplier_id = $1', [id])
       await client.query('DELETE FROM supplier_addresses WHERE supplier_id = $1', [id])
       await client.query('DELETE FROM suppliers WHERE id = $1', [id])
     }
     ```
   - **Issue:** If any delete fails, partial deletion leaves orphaned records
   - **Recommendation:** Use database-level CASCADE constraints

3. **No Transaction Serialization for Critical Operations**
   - **Operations Requiring SERIALIZABLE:**
     - Inventory adjustments with stock validation
     - Concurrent order placement checking stock
     - Batch price updates with conflict detection

   **Current:** All operations use default READ COMMITTED
   **Recommendation:** Add isolation level control

---

## 6. IMPLEMENTATION ROADMAP

### CRITICAL FIXES (Immediate - Week 1)

#### 1. Fix Connection Leaks in API Routes
**Priority:** CRITICAL
**Effort:** 2-3 days

**Files to Fix:**
- `/src/app/api/inventory/complete/route.ts:474-524`
- `/src/app/api/suppliers/pricelists/route.ts:496-609`
- `/src/app/api/suppliers/[id]/inventory/route.ts:431-513`

**Pattern to Apply:**
```typescript
// BEFORE (WRONG):
await pool.query('BEGIN')
// operations
await pool.query('COMMIT')

// AFTER (CORRECT):
const client = await pool.connect()
try {
  await client.query('BEGIN')
  // operations
  await client.query('COMMIT')
} catch (error) {
  await client.query('ROLLBACK')
  throw error
} finally {
  client.release()
}
```

#### 2. Add Connection Leak Detection
**Priority:** HIGH
**Effort:** 1 day

**Implementation:** `/src/lib/database/connection.ts`
```typescript
// Track connection hold times
connectionPool.on('acquire', (client) => {
  (client as any).__acquiredAt = Date.now();
  (client as any).__acquiredStack = new Error().stack;
});

connectionPool.on('release', (client) => {
  const holdTime = Date.now() - ((client as any).__acquiredAt || 0);
  if (holdTime > 30000) {
    console.warn(`⚠️ Connection leak detected: held for ${holdTime}ms`);
    console.warn(`Acquisition stack:\n${(client as any).__acquiredStack}`);
  }
});
```

#### 3. Reduce Idle Transaction Timeout
**Priority:** HIGH
**Effort:** 15 minutes

**File:** `/src/lib/database/connection.ts:42`
```typescript
// BEFORE:
idle_in_transaction_session_timeout: 300000, // 5 minutes

// AFTER:
idle_in_transaction_session_timeout: 60000,  // 1 minute
```

### ARCHITECTURAL IMPROVEMENTS (Short-term - Weeks 2-3)

#### 4. Implement withTransaction Helper
**Priority:** HIGH
**Effort:** 2-3 days

**File:** `/src/lib/database/transaction.ts` (NEW)
```typescript
export async function withTransaction<T>(
  callback: (client: PoolClient) => Promise<T>,
  options?: {
    timeout?: number;
    isolationLevel?: IsolationLevel;
  }
): Promise<T> {
  const { timeout = 30000, isolationLevel = IsolationLevel.ReadCommitted } = options || {};

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`SET TRANSACTION ISOLATION LEVEL ${isolationLevel}`);
    await client.query(`SET statement_timeout = ${timeout}`);

    const result = await callback(client);

    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}
```

#### 5. Refactor Repository Pattern
**Priority:** MEDIUM
**Effort:** 5-7 days

**Changes:**
1. Add optional PoolClient parameter to all repository methods
2. Implement pooled query optimization for read operations
3. Remove business logic from repositories

**Example:**
```typescript
export class PostgreSQLSupplierRepository implements SupplierRepository {
  constructor(private pool: Pool) {}

  async findById(id: string, client?: PoolClient): Promise<Supplier | null> {
    if (client) {
      // Within transaction - use provided client
      return this.findByIdWithClient(client, id);
    } else {
      // Simple read - use pool.query for efficiency
      return this.findByIdWithPool(id);
    }
  }

  private async findByIdWithPool(id: string): Promise<Supplier | null> {
    const result = await this.pool.query(/* ... */);
    return result.rows[0] || null;
  }

  private async findByIdWithClient(client: PoolClient, id: string): Promise<Supplier | null> {
    const result = await client.query(/* ... */);
    return result.rows[0] || null;
  }
}
```

#### 6. Fix Batch Operations Atomicity
**Priority:** MEDIUM
**Effort:** 2 days

**File:** `/src/lib/suppliers/core/SupplierRepository.ts:311-320`
```typescript
// BEFORE:
async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
  const results: Supplier[] = []
  for (const supplierData of data) {
    const supplier = await this.create(supplierData)
    results.push(supplier)
  }
  return results
}

// AFTER:
async createMany(data: CreateSupplierData[]): Promise<Supplier[]> {
  return await withTransaction(async (client) => {
    const results: Supplier[] = []
    for (const supplierData of data) {
      const supplier = await this.createWithClient(client, supplierData)
      results.push(supplier)
    }
    return results
  })
}
```

### LONG-TERM ENHANCEMENTS (Weeks 4-8)

#### 7. Implement Optimistic Locking
**Priority:** MEDIUM
**Effort:** 3-5 days

**Schema Changes:**
```sql
ALTER TABLE suppliers ADD COLUMN version INTEGER DEFAULT 1;
ALTER TABLE inventory_items ADD COLUMN version INTEGER DEFAULT 1;
ALTER TABLE supplier_performance ADD COLUMN version INTEGER DEFAULT 1;
```

**Repository Changes:**
```typescript
async update(id: string, data: UpdateSupplierData, version: number): Promise<Supplier> {
  return await withTransaction(async (client) => {
    const result = await client.query(
      `UPDATE suppliers
       SET name = $1, version = version + 1, updated_at = NOW()
       WHERE id = $2 AND version = $3
       RETURNING *`,
      [data.name, id, version]
    );

    if (result.rowCount === 0) {
      throw new OptimisticLockError('Supplier was modified by another user');
    }

    return result.rows[0];
  });
}
```

#### 8. Add Audit Trail System
**Priority:** LOW
**Effort:** 5-7 days

**Implementation:**
- Create audit_log table for all entity changes
- Implement trigger-based audit logging
- Add created_by/updated_by tracking

#### 9. Consider ORM Migration
**Priority:** LOW (Evaluate)
**Effort:** 15-20 days

**Candidates:**
- **Prisma:** Type-safe, great DX, excellent migrations
- **TypeORM:** Full-featured, decorators, Active Record/Data Mapper
- **Drizzle:** Lightweight, SQL-like, better performance

**Trade-offs:**
- **Pros:** Automatic transaction management, type safety, migrations, connection pooling
- **Cons:** Learning curve, abstraction overhead, less SQL control

---

## 7. MONITORING & OBSERVABILITY RECOMMENDATIONS

### Connection Pool Metrics

**Add Prometheus/StatsD Metrics:**
```typescript
// Track key metrics
metrics.gauge('db.pool.total', pool.totalCount);
metrics.gauge('db.pool.idle', pool.idleCount);
metrics.gauge('db.pool.active', pool.totalCount - pool.idleCount);
metrics.gauge('db.pool.waiting', pool.waitingCount);
metrics.histogram('db.connection.hold_time', holdTime);
metrics.counter('db.connection.leaks', 1);
```

### Slow Query Logging

**Implementation:**
```typescript
pool.on('query', (query) => {
  const startTime = Date.now();

  query.on('end', () => {
    const duration = Date.now() - startTime;
    if (duration > 1000) {
      console.warn(`🐌 Slow query (${duration}ms): ${query.text.substring(0, 100)}`);
    }
  });
});
```

### Transaction Deadlock Detection

**Add to connection.ts:**
```typescript
connectionPool.on('error', (err) => {
  if (err.message.includes('deadlock detected')) {
    console.error('💀 Deadlock detected:', {
      error: err.message,
      stack: err.stack,
      timestamp: new Date().toISOString()
    });
    metrics.counter('db.deadlocks', 1);
  }
});
```

---

## 8. SECURITY CONSIDERATIONS

### SQL Injection Protection

**Current Status:** ✅ GOOD
- All queries use parameterized statements
- No string concatenation in SQL queries detected

**Example from codebase:**
```typescript
// ✅ GOOD: Parameterized query
const result = await client.query(
  'SELECT * FROM suppliers WHERE id = $1',
  [id]
);

// ❌ NEVER DO THIS:
// const result = await client.query(`SELECT * FROM suppliers WHERE id = '${id}'`);
```

### Connection String Security

**Current:** Environment variables used for credentials
**Recommendation:** Consider using AWS Secrets Manager or similar for production

---

## 9. PERFORMANCE OPTIMIZATION OPPORTUNITIES

### Query Optimization

1. **Add Database Indexes**
   - `suppliers.name` (frequently filtered)
   - `suppliers.category` (filtered in searches)
   - `inventory_items.sku` (unique queries)
   - `inventory_items.stock_qty` (low stock queries)

2. **Implement Query Result Caching**
   - Cache supplier metrics (updates every 5 minutes)
   - Cache inventory analytics (updates every 15 minutes)
   - Use Redis or in-memory cache

3. **Optimize JOIN Queries**
   - Review N+1 query patterns in SupplierRepository.findMany
   - Consider using CTEs for complex aggregations
   - Add EXPLAIN ANALYZE to identify slow queries

### Connection Pool Optimization

**Current Configuration Review:**
```typescript
// Development
max: 10, min: 2

// Production
max: 20, min: 5
```

**Recommendation:**
```typescript
// Calculate based on load
// Rule of thumb: max_connections = (core_count * 2) + effective_spindle_count
// For 4-core server: (4 * 2) + 4 = 12 connections per instance

// Development
max: 10, min: 2  // Keep as is

// Production (per instance)
max: parseInt(process.env.DB_POOL_MAX || '15'),
min: parseInt(process.env.DB_POOL_MIN || '3'),

// Production total across all instances should not exceed PostgreSQL max_connections
```

---

## 10. TESTING RECOMMENDATIONS

### Unit Tests for Data Layer

**File Structure:**
```
tests/
  lib/
    database/
      connection.test.ts          # Pool management tests
      transaction.test.ts         # Transaction helper tests
    suppliers/
      SupplierRepository.test.ts  # Repository tests
      SupplierService.test.ts     # Service layer tests
```

**Key Test Scenarios:**
1. Connection leak detection (acquire without release)
2. Transaction rollback on error
3. Concurrent transaction isolation
4. Optimistic locking conflicts
5. Batch operation atomicity

### Integration Tests

**Critical Flows:**
1. Create supplier with contacts/addresses (transaction boundary)
2. Concurrent stock adjustments (isolation level)
3. Bulk import with partial failures (rollback behavior)
4. Long-running operations (timeout handling)

---

## 11. SUMMARY & ACTION ITEMS

### Critical Path (Week 1)
1. ✅ Fix 3 critical connection leak locations
2. ✅ Add connection leak detection monitoring
3. ✅ Reduce idle transaction timeout to 60s
4. ✅ Document transaction patterns for team

### High Priority (Weeks 2-3)
5. ✅ Implement withTransaction helper
6. ✅ Refactor repository pattern for transaction composition
7. ✅ Fix batch operation atomicity
8. ✅ Add slow query logging

### Medium Priority (Weeks 4-8)
9. ⚠️ Implement optimistic locking
10. ⚠️ Add audit trail system
11. ⚠️ Optimize query performance with indexes
12. ⚠️ Evaluate ORM migration feasibility

### Continuous Improvement
13. 🔄 Monitor connection pool metrics
14. 🔄 Review slow query logs monthly
15. 🔄 Update transaction patterns as needed
16. 🔄 Conduct quarterly architecture reviews

---

## APPENDIX A: Connection Leak Audit Results

**Total Files Reviewed:** 47
**Connection Acquisition Patterns:**
- `pool.connect()`: 47 occurrences
- With `finally` block: 15 (31.9%)
- Without `finally` block: 32 (68.1%)

**High-Risk Files:**
1. `/src/app/api/inventory/complete/route.ts:474-524` - Uses pool.query() for BEGIN/COMMIT
2. `/src/app/api/suppliers/pricelists/route.ts:496-609` - Multiple transactions without guaranteed release
3. `/src/app/api/suppliers/[id]/inventory/route.ts:431-513` - Complex transaction without proper cleanup

**Medium-Risk Files:**
12 files with client.connect() but inconsistent release patterns

**Low-Risk Files:**
15 files with proper try-finally blocks

---

## APPENDIX B: Transaction Patterns Comparison

| Pattern | Usage Count | Pros | Cons | Recommendation |
|---------|-------------|------|------|----------------|
| Manual BEGIN/COMMIT | 35 | Full control | Error-prone | Refactor to helper |
| withTransaction helper | 6 | Clean, safe | Limited usage | Expand usage |
| TransactionManager | 1 | Advanced features | Complex | Use for bulk ops |
| pool.query() for transactions | 3 | None | DANGEROUS | Fix immediately |

---

**End of Report**

*Generated by: Backend Architect - Claude*
*Review Date: 2025-09-30*
*Next Review: 2025-11-15*