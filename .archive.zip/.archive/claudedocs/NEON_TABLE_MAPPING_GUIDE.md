# Neon Database Table Mapping Guide
**Critical Reference for API Query Fixes**

---

## The Problem

API code expects tables in `public` schema (legacy):
```sql
SELECT * FROM suppliers          -- ❌ Table doesn't exist
SELECT * FROM inventory_items    -- ❌ Table doesn't exist
SELECT * FROM products           -- ❌ Wrong table name
```

Actual Neon schema has everything in `core` schema with different names:
```sql
SELECT * FROM core.supplier           -- ✅ Correct (singular!)
SELECT * FROM core.stock_on_hand      -- ✅ Correct (renamed!)
SELECT * FROM core.product            -- ✅ Correct (singular!)
```

---

## Complete Table Mapping

| Legacy (API Code) | Neon (Actual) | Notes |
|-------------------|---------------|-------|
| `suppliers` | `core.supplier` | **Singular**, in core schema |
| `inventory_items` | `core.stock_on_hand` | **Completely renamed** |
| `products` | `core.product` | **Singular**, in core schema |
| `stock_movements` | `core.stock_movement` | **Singular**, in core schema |
| N/A | `core.supplier_product` | New junction table |
| N/A | `core.price_history` | New pricing table |
| N/A | `core.stock_location` | New location table |

---

## Critical Schema Differences

### 1. stock_on_hand (formerly inventory_items)

**Missing Columns** (need calculation or join):
- `cost_price` → Must join to `supplier_product` → `price_history`
- `total_value` → Calculate as `qty * price`
- `sku` → Available in `supplier_product.supplier_sku`
- `name` → Available in `supplier_product.name_from_supplier`
- `supplier_id` → Must join through `supplier_product`

**New Column Names**:
- `id` → `soh_id`
- `stock_qty` → `qty`
- `reorder_point` → Not in this table (business logic)
- `warehouse` → `location_id` (foreign key to core.stock_location)

**Correct Query Pattern**:
```sql
-- OLD (BROKEN)
SELECT * FROM inventory_items WHERE stock_qty > 0

-- NEW (CORRECT)
SELECT
  soh.soh_id,
  soh.qty,
  soh.location_id,
  sp.supplier_sku as sku,
  sp.name_from_supplier as name,
  sp.supplier_id,
  s.name as supplier_name,
  p.product_name,
  ph.unit_price as cost_price,
  (soh.qty * ph.unit_price) as total_value
FROM core.stock_on_hand soh
JOIN core.supplier_product sp ON soh.supplier_product_id = sp.supplier_product_id
JOIN core.supplier s ON sp.supplier_id = s.supplier_id
LEFT JOIN core.product p ON sp.product_id = p.product_id
LEFT JOIN LATERAL (
  SELECT unit_price
  FROM core.price_history
  WHERE supplier_product_id = sp.supplier_product_id
  ORDER BY effective_date DESC
  LIMIT 1
) ph ON true
WHERE soh.qty > 0
```

### 2. supplier (formerly suppliers)

**Column Mapping**:
- `id` → `supplier_id` (BIGINT, not UUID!)
- `name` → `name`
- `status` → `active` (boolean, not enum!)
- `email` → `contact_email`
- `phone` → `contact_phone`

**Correct Query Pattern**:
```sql
-- OLD (BROKEN)
SELECT * FROM suppliers WHERE status = 'active'

-- NEW (CORRECT)
SELECT
  supplier_id as id,
  name,
  active,
  contact_email,
  contact_phone,
  payment_terms_days,
  default_currency
FROM core.supplier
WHERE active = true
```

### 3. product (formerly products)

**Column Mapping**:
- `id` → `product_id` (BIGINT)
- Schema exists but structure unknown (need to verify columns)

**Correct Query Pattern**:
```sql
-- OLD (BROKEN)
SELECT * FROM products WHERE status = 'active'

-- NEW (CORRECT - need to verify exact columns)
SELECT
  product_id as id,
  product_name as name,
  sku,
  category_id,
  is_active as status
FROM core.product
WHERE is_active = true
```

### 4. stock_movement (formerly stock_movements)

**Table exists!** Just needs schema prefix.

```sql
-- OLD (BROKEN)
SELECT * FROM stock_movements

-- NEW (CORRECT)
SELECT * FROM core.stock_movement
```

---

## API Query Conversion Examples

### Example 1: Get Active Suppliers

**Before** (fails with "relation does not exist"):
```typescript
const result = await pool.query(`
  SELECT * FROM suppliers WHERE status = 'active'
`);
```

**After** (works):
```typescript
const result = await pool.query(`
  SELECT
    supplier_id,
    name,
    active,
    contact_email,
    contact_phone
  FROM core.supplier
  WHERE active = true
`);
```

### Example 2: Get Inventory with Values

**Before** (fails - multiple issues):
```typescript
const result = await pool.query(`
  SELECT
    i.id,
    i.sku,
    i.name,
    i.stock_qty,
    i.cost_price,
    i.stock_qty * i.cost_price as total_value,
    s.name as supplier_name
  FROM inventory_items i
  LEFT JOIN suppliers s ON i.supplier_id = s.id
  WHERE i.stock_qty > 0
`);
```

**After** (works):
```typescript
const result = await pool.query(`
  SELECT
    soh.soh_id as id,
    sp.supplier_sku as sku,
    sp.name_from_supplier as name,
    soh.qty as stock_qty,
    s.name as supplier_name,
    soh.location_id
  FROM core.stock_on_hand soh
  JOIN core.supplier_product sp
    ON soh.supplier_product_id = sp.supplier_product_id
  JOIN core.supplier s
    ON sp.supplier_id = s.supplier_id
  WHERE soh.qty > 0
`);
```

### Example 3: Analytics Dashboard

**Before** (fails):
```typescript
const [suppliers, items, alerts] = await Promise.all([
  pool.query('SELECT COUNT(*) FROM suppliers WHERE status = $1', ['active']),
  pool.query('SELECT COUNT(*) FROM inventory_items WHERE stock_qty <= reorder_point'),
  pool.query('SELECT COUNT(*) FROM inventory_items WHERE stock_qty = 0')
]);
```

**After** (works):
```typescript
const [suppliers, items, alerts] = await Promise.all([
  pool.query('SELECT COUNT(*) FROM core.supplier WHERE active = true'),
  pool.query('SELECT COUNT(*) FROM core.stock_on_hand WHERE qty < 10'), // Hardcoded reorder point
  pool.query('SELECT COUNT(*) FROM core.stock_on_hand WHERE qty = 0')
]);
```

---

## Migration Strategy

### Phase 1: Create Database Views (Compatibility Layer)

Create views in `public` schema that map to `core` tables:

```sql
-- File: database/migrations/neon/002_create_compatibility_views.sql

-- View: public.suppliers → core.supplier
CREATE OR REPLACE VIEW public.suppliers AS
SELECT
  supplier_id::text as id,  -- Cast to text for UUID compatibility
  name,
  active as status,
  contact_email as email,
  contact_phone as phone,
  payment_terms_days,
  default_currency as currency,
  created_at,
  updated_at
FROM core.supplier;

-- View: public.inventory_items → core.stock_on_hand (with joins)
CREATE OR REPLACE VIEW public.inventory_items AS
SELECT
  soh.soh_id::text as id,
  sp.supplier_sku as sku,
  sp.name_from_supplier as name,
  'Electronics' as category,  -- Default category
  soh.qty as stock_qty,
  0 as reserved_qty,
  10 as reorder_point,  -- Default reorder point
  'active' as status,
  soh.location_id,
  sp.supplier_id::text as supplier_id,
  soh.created_at,
  soh.created_at as updated_at
FROM core.stock_on_hand soh
JOIN core.supplier_product sp ON soh.supplier_product_id = sp.supplier_product_id;

-- View: public.products → core.product
CREATE OR REPLACE VIEW public.products AS
SELECT
  product_id::text as id,
  product_name as name,
  sku,
  category_id,
  is_active as status,
  created_at,
  updated_at
FROM core.product;
```

### Phase 2: Update API Code (Permanent Fix)

1. **Search & Replace** across all API files:
   ```bash
   FROM suppliers    → FROM core.supplier
   JOIN suppliers    → JOIN core.supplier
   INTO suppliers    → INTO core.supplier
   ```

2. **Update Column Names**:
   ```typescript
   // OLD
   row.id           → row.supplier_id
   row.status       → row.active
   row.stock_qty    → row.qty

   // NEW mapping object
   const mapRow = (row) => ({
     id: row.supplier_id?.toString(),
     name: row.name,
     status: row.active ? 'active' : 'inactive',
     email: row.contact_email,
     phone: row.contact_phone
   });
   ```

3. **Fix Type Conversions**:
   ```typescript
   // BIGINT to string for UUID compatibility
   supplier_id::text as id
   product_id::text as id
   ```

---

## Testing Checklist

- [ ] Suppliers API returns data
- [ ] Inventory API returns data
- [ ] Products API returns data
- [ ] Analytics aggregations work
- [ ] Stock movements queries work
- [ ] All foreign key relationships intact
- [ ] No N+1 query patterns introduced
- [ ] Performance within acceptable limits (<500ms)

---

## Files Requiring Updates

Based on grep results, these files need fixing:

### Critical Priority (API Endpoints)
- `src/app/api/inventory/route.ts`
- `src/app/api/inventory/[id]/route.ts`
- `src/app/api/inventory/products/route.ts`
- `src/app/api/suppliers/route.ts`
- `src/app/api/suppliers/enhanced/route.ts`
- `src/app/api/analytics/dashboard/route.ts`
- `src/app/api/alerts/route.ts`

### Medium Priority (Support Files)
- `src/lib/database/transaction-helper.ts`
- `src/lib/integrations/**`
- `src/lib/services/**`

### Low Priority (Test Files)
- `scripts/test_*.js`
- `scripts/verify_*.js`

---

## Performance Considerations

### Index Requirements

Given the new join patterns, these indexes are CRITICAL:

```sql
-- Already have these (confirmed)
core.stock_on_hand(supplier_product_id)
core.supplier_product(supplier_id)
core.supplier_product(product_id)

-- Missing (need to create)
core.product(product_id)          -- PRIMARY KEY
core.product(category_id)         -- Foreign key
core.stock_location(location_id)  -- PRIMARY KEY
core.price_history(supplier_product_id, effective_date DESC)
```

### Query Performance Tips

1. **Use covering indexes** for frequently accessed columns
2. **LIMIT early** - don't fetch all 25K records
3. **Use materialized views** for complex aggregations
4. **Add query timeouts** (10s max)
5. **Use connection pooling** (already configured)

---

*Generated: 2025-10-08*
*Project: proud-mud-50346856 (NXT-SPP)*
