# AI-POWERED SUPPLIER MANAGEMENT API DOCUMENTATION

## Overview

This comprehensive API documentation covers all AI-powered endpoints for intelligent supplier management, predictive analytics, and automated insights generation.

---

## AUTHENTICATION & AUTHORIZATION

### AI-Specific Permissions
```javascript
// Permission levels for AI endpoints
AI_SUPPLIER_DISCOVER     // Supplier discovery and matching
AI_ANALYTICS_VIEW        // View predictive analytics
AI_INSIGHTS_GENERATE     // Generate insights and recommendations
AI_RECOMMENDATIONS_ACCESS // Access recommendation engine
AI_JOBS_CREATE           // Create background AI jobs
AI_JOBS_MONITOR          // Monitor AI job status
AI_ADMIN                 // Full AI system administration
```

### Rate Limiting
- **Discovery**: 10 requests per 15 minutes
- **Analytics**: 20 requests per 5 minutes
- **Insights**: 15 requests per 10 minutes
- **Jobs**: 5 requests per hour

---

## AI SUPPLIER DISCOVERY API

### POST /api/ai/suppliers/discover
Intelligent supplier discovery using natural language processing and multi-criteria matching.

**Request Body:**
```json
{
  "query": "Find reliable electronics suppliers in North America",
  "requirements": {
    "category": ["Electronics", "Components"],
    "location": ["North America", "USA", "Canada"],
    "certifications": ["ISO9001", "RoHS"],
    "capacity": {
      "min": 1000,
      "max": 50000
    },
    "priceRange": {
      "min": 100,
      "max": 5000
    }
  },
  "filters": {
    "existingSuppliers": false,
    "verified": true,
    "riskLevel": "low"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "suppliers": [
      {
        "id": "supplier_001",
        "name": "TechCorp Electronics",
        "matchScore": 0.92,
        "category": "Electronics",
        "location": "North America",
        "capabilities": ["Premium Service", "High Quality", "Flexible Payment"],
        "riskScore": 0.15,
        "estimatedPricing": {
          "min": 2500,
          "max": 4200,
          "currency": "USD"
        },
        "aiInsights": {
          "strengths": [
            "Excellent performance rating",
            "Established relationship",
            "Favorable payment terms"
          ],
          "concerns": [],
          "recommendations": [
            "Consider expanding relationship"
          ]
        }
      }
    ],
    "searchMetadata": {
      "queryProcessed": "Find reliable electronics suppliers in North America",
      "totalResults": 5,
      "searchTime": 850,
      "confidence": 0.88
    },
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

### GET /api/ai/suppliers/discover?supplierId={id}
Find suppliers similar to an existing supplier using AI similarity algorithms.

**Response:**
```json
{
  "success": true,
  "data": {
    "supplierId": "supplier_001",
    "similarSuppliers": [
      {
        "id": "supplier_002",
        "name": "ElectroComponents Ltd",
        "matchScore": 0.85,
        "similarityFactors": [
          "Category match: Electronics",
          "Geographic proximity",
          "Similar capacity range",
          "Comparable performance rating"
        ]
      }
    ],
    "count": 3,
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

---

## AI PREDICTIVE ANALYTICS API

### POST /api/ai/analytics/predictive
Generate predictive analytics for multiple metrics using machine learning models.

**Request Body:**
```json
{
  "supplierId": "supplier_001",
  "category": "Electronics",
  "timeHorizon": "6months",
  "metrics": ["cost", "performance", "risk"]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "predictions": [
      {
        "metric": "cost",
        "currentValue": 45000,
        "predictedValues": [
          {
            "date": "2025-10-26T00:00:00Z",
            "value": 46200,
            "confidence": 0.92,
            "factors": [
              "Historical trend",
              "Seasonal adjustment",
              "Market conditions"
            ]
          },
          {
            "date": "2025-11-26T00:00:00Z",
            "value": 47100,
            "confidence": 0.88,
            "factors": [
              "Historical trend",
              "Market volatility",
              "Supply chain factors"
            ]
          }
        ],
        "trends": {
          "direction": "increasing",
          "strength": "moderate",
          "volatility": 0.12
        },
        "recommendations": [
          "Consider cost optimization strategies",
          "Monitor market trends closely"
        ]
      }
    ],
    "modelInfo": {
      "accuracy": 0.85,
      "lastTraining": "2025-09-26T08:00:00Z",
      "dataPoints": 180
    },
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

### GET /api/ai/analytics/predictive?supplierId={id}&months={n}
Generate supplier performance forecast for specified time period.

**Response:**
```json
{
  "success": true,
  "data": {
    "supplierId": "supplier_001",
    "forecastPeriod": 6,
    "performanceForecast": [
      {
        "month": "2025-10",
        "predictedRating": 4.2,
        "confidence": 0.90,
        "factors": [
          "Historical trend",
          "Seasonal factors",
          "Market conditions"
        ]
      }
    ],
    "riskTrend": {
      "current": 0.25,
      "projected": 0.20,
      "trend": "improving"
    },
    "recommendations": [
      "Maintain current partnership",
      "Monitor seasonal performance dips"
    ],
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

---

## AI ANOMALY DETECTION API

### POST /api/ai/analytics/anomalies
Real-time anomaly detection across multiple metrics and entity types.

**Request Body:**
```json
{
  "entityType": "supplier",
  "entityId": "supplier_001",
  "timeRange": {
    "start": "2025-08-26T00:00:00Z",
    "end": "2025-09-26T00:00:00Z"
  },
  "sensitivity": "medium",
  "metrics": ["cost", "performance", "delivery_time"]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "anomalies": [
      {
        "id": "anomaly_cost_1727337600000",
        "type": "cost_anomaly",
        "severity": "high",
        "description": "Unusual cost value detected",
        "affectedMetric": "cost",
        "detectedAt": "2025-09-26T10:00:00Z",
        "actualValue": 125000,
        "expectedValue": 85000,
        "deviation": 40000,
        "confidence": 0.94,
        "possibleCauses": [
          "Price spike",
          "Volume increase",
          "Emergency purchase"
        ],
        "recommendedActions": [
          "Investigate root cause",
          "Review purchase orders",
          "Contact supplier for clarification"
        ],
        "context": {
          "entityType": "supplier",
          "entityId": "supplier_001",
          "relatedEntities": [
            {
              "type": "purchase_order",
              "id": "po_001",
              "name": "Emergency Electronics Order"
            }
          ]
        }
      }
    ],
    "summary": {
      "totalAnomalies": 3,
      "criticalCount": 0,
      "newAnomalies": 1,
      "resolvedAnomalies": 0
    },
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

### GET /api/ai/analytics/anomalies?supplierId={id}
Monitor supplier risk in real-time with AI-powered analysis.

**Response:**
```json
{
  "success": true,
  "data": {
    "supplierId": "supplier_001",
    "currentRisk": 0.35,
    "riskTrend": "stable",
    "alerts": [
      {
        "type": "payment_risk",
        "severity": "medium",
        "message": "Payment delays increasing over past 30 days",
        "detectedAt": "2025-09-26T10:00:00Z"
      }
    ],
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

### PUT /api/ai/analytics/anomalies
Manage anomaly lifecycle (acknowledge, resolve, dismiss).

**Request Body:**
```json
{
  "anomalyId": "anomaly_cost_1727337600000",
  "action": "resolve",
  "userId": "user_001",
  "resolution": "Confirmed emergency purchase - price justified by urgency"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "anomalyId": "anomaly_cost_1727337600000",
    "action": "resolve",
    "result": {
      "status": "resolved",
      "resolvedBy": "user_001",
      "resolvedAt": "2025-09-26T10:05:00Z",
      "resolution": "Confirmed emergency purchase - price justified by urgency"
    },
    "timestamp": "2025-09-26T10:05:00Z"
  }
}
```

---

## AI INSIGHTS GENERATION API

### POST /api/ai/insights/generate
Generate contextual insights using advanced AI analysis.

**Request Body:**
```json
{
  "context": {
    "type": "supplier",
    "id": "supplier_001"
  },
  "focusAreas": ["cost", "risk", "performance"],
  "timeFrame": {
    "start": "2025-06-26T00:00:00Z",
    "end": "2025-09-26T00:00:00Z"
  },
  "includeActions": true
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "insights": [
      {
        "id": "perf_opportunity_supplier_001",
        "type": "opportunity",
        "title": "High-Performing Supplier Expansion",
        "description": "Supplier shows excellent performance (85% score). Consider expanding partnership.",
        "impact": {
          "score": 8,
          "type": "efficiency_gain",
          "estimatedValue": {
            "amount": 25000,
            "currency": "USD",
            "timeframe": "annually"
          }
        },
        "confidence": 0.85,
        "evidence": [
          "Performance score: 85%",
          "Consistent delivery track record",
          "High quality ratings"
        ],
        "relatedEntities": [
          {
            "type": "supplier",
            "id": "supplier_001",
            "name": "TechCorp Electronics"
          }
        ],
        "actionItems": [
          {
            "action": "Schedule strategic partnership discussion",
            "priority": "high",
            "effort": "medium",
            "timeframe": "2 weeks"
          }
        ]
      }
    ],
    "summary": {
      "totalInsights": 5,
      "opportunityCount": 3,
      "riskCount": 1,
      "potentialSavings": 75000
    },
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

### GET /api/ai/insights/generate?category={name}
Generate market intelligence for specific product categories.

**Response:**
```json
{
  "success": true,
  "data": {
    "category": "Electronics",
    "marketTrends": {
      "priceDirection": "increasing",
      "volatility": 0.15,
      "marketGrowth": 0.05
    },
    "competitiveAnalysis": {
      "averagePrice": 1000,
      "priceRange": {
        "min": 800,
        "max": 1200
      },
      "topSuppliers": [
        {
          "name": "TechCorp Electronics",
          "marketShare": 0.25,
          "competitiveness": 0.88
        }
      ]
    },
    "recommendations": [
      "Monitor market trends closely",
      "Consider long-term contracts to lock in prices",
      "Diversify supplier portfolio"
    ],
    "timestamp": "2025-09-26T10:00:00Z"
  }
}
```

---

## ERROR HANDLING

### Standard Error Response
```json
{
  "success": false,
  "error": "Error description",
  "details": "Detailed error message",
  "code": "ERROR_CODE",
  "timestamp": "2025-09-26T10:00:00Z"
}
```

### Error Codes
- `VALIDATION_ERROR` (400): Invalid request parameters
- `UNAUTHORIZED` (401): Authentication required
- `FORBIDDEN` (403): Insufficient permissions
- `AI_SERVICE_ERROR` (500): AI service failure
- `MODEL_ERROR` (503): AI model temporarily unavailable
- `RATE_LIMIT_EXCEEDED` (429): Too many requests

### Validation Errors
```json
{
  "success": false,
  "error": "Validation failed",
  "details": "Query must be at least 3 characters long",
  "field": "query",
  "code": "VALIDATION_ERROR"
}
```

---

## USAGE EXAMPLES

### JavaScript/TypeScript
```javascript
// Supplier Discovery
const response = await fetch('/api/ai/suppliers/discover', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer your-jwt-token'
  },
  body: JSON.stringify({
    query: "Find sustainable packaging suppliers",
    requirements: {
      category: ["Packaging", "Sustainable"]
    },
    filters: {
      verified: true,
      riskLevel: "low"
    }
  })
});

const data = await response.json();

if (data.success) {
  console.log(`Found ${data.data.suppliers.length} suppliers`);
  data.data.suppliers.forEach(supplier => {
    console.log(`${supplier.name}: ${supplier.matchScore} match score`);
  });
}
```

### cURL Examples
```bash
# Anomaly Detection
curl -X POST "https://api.mantisnxt.com/api/ai/analytics/anomalies" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-jwt-token" \
  -d '{
    "entityType": "supplier",
    "timeRange": {
      "start": "2025-08-01T00:00:00Z",
      "end": "2025-09-26T00:00:00Z"
    },
    "sensitivity": "high",
    "metrics": ["cost", "performance", "delivery"]
  }'

# Insights Generation
curl -X POST "https://api.mantisnxt.com/api/ai/insights/generate" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-jwt-token" \
  -d '{
    "context": {
      "type": "portfolio"
    },
    "focusAreas": ["cost", "risk"],
    "timeFrame": {
      "start": "2025-06-01T00:00:00Z",
      "end": "2025-09-26T00:00:00Z"
    },
    "includeActions": true
  }'
```

---

## PERFORMANCE CONSIDERATIONS

### Response Times
- **Supplier Discovery**: 500-2000ms (depending on query complexity)
- **Predictive Analytics**: 1000-3000ms (depending on time horizon)
- **Anomaly Detection**: 300-1500ms (depending on data volume)
- **Insights Generation**: 800-2500ms (depending on context scope)

### Caching
- Insights cached for 1 hour
- Market intelligence cached for 4 hours
- Supplier similarity scores cached for 2 hours
- Anomaly detection results cached for 15 minutes

### Rate Limiting Headers
```
X-RateLimit-Limit: 20
X-RateLimit-Remaining: 15
X-RateLimit-Reset: 1727340000
Retry-After: 300
```

---

## WEBHOOK NOTIFICATIONS

AI events can trigger webhooks for real-time notifications:

### Supported Events
- `insight_generated`: New insights available
- `anomaly_detected`: Critical anomaly found
- `recommendation_ready`: New recommendations generated
- `analysis_complete`: Background analysis finished

### Webhook Payload
```json
{
  "event": "anomaly_detected",
  "timestamp": "2025-09-26T10:00:00Z",
  "data": {
    "anomalyId": "anomaly_001",
    "severity": "critical",
    "entityType": "supplier",
    "entityId": "supplier_001"
  },
  "confidence": 0.95
}
```

---

This comprehensive API documentation provides everything needed to integrate with the AI-powered supplier management system. All endpoints include proper authentication, validation, error handling, and performance optimization.