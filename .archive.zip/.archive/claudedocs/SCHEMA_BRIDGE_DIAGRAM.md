# Schema Bridge Architecture Diagram

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         MantisNXT Database                              │
│                    nxtprod-db_001 @ 62.169.20.53:6600                  │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    │                               │
            ┌───────▼────────┐            ┌────────▼─────────┐
            │  PUBLIC Schema │            │   CORE Schema    │
            │  (Actual Data) │            │ (Intended Design)│
            └───────┬────────┘            └────────┬─────────┘
                    │                               │
         ┌──────────┼──────────┐         ┌─────────┼─────────┐
         │          │          │         │         │         │
    ┌────▼───┐ ┌───▼────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐ ┌─▼─────┐
    │suppliers│ │products│ │stock_ │ │supplier│ │supplier│ │stock_ │
    │ (TABLE) │ │(TABLE) │ │move-  │ │(VIEW)  │ │_product│ │on_hand│
    │23 rows  │ │~100    │ │ments  │ │→public │ │(VIEW)  │ │(VIEW) │
    └─────────┘ └────────┘ │(TABLE)│ │23 rows │ │→public │ │→public│
                            │~500   │ └────────┘ └────────┘ └───────┘
                            └───────┘
```

## Current State (Phase 1: Bridge Active)

### Data Flow - API Query Path

```
┌──────────────────────────────────────────────────────────────────────┐
│                     API Request Flow                                 │
└──────────────────────────────────────────────────────────────────────┘

1. API queries core.supplier:
   ┌────────────┐
   │   API      │ SELECT * FROM core.supplier WHERE active = true
   └──────┬─────┘
          │
          ▼
   ┌─────────────────┐
   │ core.supplier   │ (VIEW - reverse compatibility)
   │ (Migration 004) │
   └──────┬──────────┘
          │ View definition redirects to public.suppliers
          │ with column mapping:
          │   - id → supplier_id
          │   - status → active (boolean)
          │   - email/phone → contact_info (jsonb)
          ▼
   ┌─────────────────┐
   │ public.suppliers│ (TABLE - actual data)
   │ 23 rows         │
   └──────┬──────────┘
          │
          ▼
   ┌─────────────────┐
   │ Result Set      │ Returns data in core.supplier schema format
   └─────────────────┘
```

### Column Mapping Example

```
┌───────────────────────────────────────────────────────────────────────┐
│              public.suppliers → core.supplier Mapping                 │
├───────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  PUBLIC.SUPPLIERS (Source - 44 columns)                              │
│  ┌─────────────────────────────────────────────┐                     │
│  │ id (uuid)                                   │──┐                  │
│  │ name (varchar)                              │  │                  │
│  │ supplier_code (varchar)                     │  │                  │
│  │ status (varchar) "active"/"inactive"        │  │                  │
│  │ currency (varchar)                          │  │                  │
│  │ email (varchar)                             │  │                  │
│  │ phone (varchar)                             │  │                  │
│  │ contact_person (varchar)                    │  │                  │
│  │ website (varchar)                           │  │                  │
│  │ address (text)                              │  │                  │
│  │ tax_id (varchar)                            │  │                  │
│  │ payment_terms (varchar)                     │  │                  │
│  │ payment_terms_days (integer)                │  │                  │
│  │ contact_email (varchar)                     │  │                  │
│  │ ... (30 more columns)                       │  │                  │
│  └─────────────────────────────────────────────┘  │                  │
│                                                    │ VIEW TRANSFORMS  │
│  CORE.SUPPLIER (Target - 14 columns)              │                  │
│  ┌─────────────────────────────────────────────┐  │                  │
│  │ supplier_id (uuid)              ←─────────────┘                  │
│  │ name (varchar)                  ←── COALESCE(name, supplier_name)│
│  │ code (varchar)                  ←── supplier_code                │
│  │ active (boolean)                ←── CASE WHEN status='active'    │
│  │ default_currency (char)         ←── COALESCE(currency, 'ZAR')    │
│  │ payment_terms (varchar)         ←── payment_terms                │
│  │ contact_info (jsonb)            ←── jsonb_build_object(...)      │
│  │   ├─ email                      ←── COALESCE(contact_email,email)│
│  │   ├─ phone                      ←── phone                        │
│  │   ├─ contact_person             ←── contact_person               │
│  │   ├─ website                    ←── website                      │
│  │   └─ address                    ←── address                      │
│  │ tax_number (varchar)            ←── tax_id                       │
│  │ contact_email (varchar)         ←── contact_email                │
│  │ contact_phone (varchar)         ←── phone                        │
│  │ website (text)                  ←── website                      │
│  │ payment_terms_days (integer)    ←── payment_terms_days           │
│  │ created_at (timestamptz)        ←── created_at                   │
│  │ updated_at (timestamptz)        ←── updated_at                   │
│  └─────────────────────────────────────────────┘                     │
└───────────────────────────────────────────────────────────────────────┘
```

## Bi-Directional Bridge Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Schema Bridge - Dual Direction                       │
└─────────────────────────────────────────────────────────────────────────┘

                              APPLICATION LAYER
                    ┌───────────────┬────────────────┐
                    │   New APIs    │   Legacy APIs  │
                    │ (use core.*)  │  (use core.*)  │
                    └───────┬───────┴────────┬───────┘
                            │                │
        ┌───────────────────┤                ├──────────────────┐
        │                   │                │                  │
        │ FORWARD VIEWS     │                │  REVERSE VIEWS   │
        │ (Migration 003)   │                │  (Migration 004) │
        │                   │                │                  │
    ┌───▼────────────────┐  │                │  ┌───────────────▼───┐
    │ core.supplier_view │  │                │  │  core.supplier    │
    │ (reads public.*)   │  │                │  │  (VIEW → public.*) │
    └───┬────────────────┘  │                │  └───────┬───────────┘
        │                   │                │          │
        │   ┌───────────────▼────────────────▼──────────┤
        │   │                                            │
        │   │         PUBLIC.SUPPLIERS (TABLE)           │
        └───►         ┌─────────────────────┐            │
            │         │  Actual Data        │            │
            │         │  23 suppliers       │            │
            │         │  44 columns         │            │
            │         └─────────────────────┘            │
            │                                            │
            └────────────────────────────────────────────┘

Benefits:
- New code can query core.supplier_view (explicit view)
- Legacy code queries core.supplier (looks like table, is view)
- Both read same source data
- Zero downtime migration possible
- Views can be dropped when real core.* tables have data
```

## Inventory Data Bridge

```
┌─────────────────────────────────────────────────────────────────────────┐
│              Inventory Items → Supplier Product Mapping                 │
└─────────────────────────────────────────────────────────────────────────┘

                    PUBLIC.INVENTORY_ITEMS (VIEW)
                    ┌──────────────────────────┐
                    │ Complex JOIN of:         │
                    │ - supplier_product       │
                    │ - stock_on_hand          │
                    │ - stock_location         │
                    │ 25,602 rows              │
                    └──────────┬───────────────┘
                               │
          ┌────────────────────┼────────────────────┐
          │                    │                    │
     ┌────▼──────────┐  ┌──────▼──────────┐  ┌────▼─────────┐
     │core.supplier_ │  │core.stock_on_   │  │core.stock_   │
     │product        │  │hand             │  │movement      │
     │(VIEW)         │  │(VIEW)           │  │(VIEW)        │
     └───────────────┘  └─────────────────┘  └──────────────┘
          │                    │                    │
          └────────────────────┴────────────────────┘
                               │
                    Derived from public.inventory_items:
                    - SKU → supplier_sku
                    - stock_qty → qty
                    - Generate UUIDs from SKU+supplier_id
```

## Migration State Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      Migration State Transitions                        │
└─────────────────────────────────────────────────────────────────────────┘

PHASE 1: BRIDGE SETUP (Current State)
┌───────────────────────────────────────────────────────────────────────┐
│ core.supplier (VIEW) ──────┐                                          │
│                            │                                          │
│ core.supplier_view (VIEW) ─┼──→ public.suppliers (TABLE, 23 rows)    │
│                            │                                          │
│ core.supplier_product      │                                          │
│ core.stock_on_hand         ├──→ public.inventory_items (VIEW)        │
│ core.stock_movement     ───┘                                          │
└───────────────────────────────────────────────────────────────────────┘

         │
         │ Execute Migration 005 (Data Copy)
         ▼

PHASE 2: DATA COPIED (Transition State)
┌───────────────────────────────────────────────────────────────────────┐
│ core.supplier_temp_view ───────→ public.suppliers (TABLE, 23 rows)   │
│                                                                       │
│ core.supplier (TABLE, 23 rows) ← Data copied from public            │
│                                                                       │
│ Both exist simultaneously, views point to public during validation   │
└───────────────────────────────────────────────────────────────────────┘

         │
         │ Validate, then Drop Views
         ▼

PHASE 3: CUTOVER (New Stable State)
┌───────────────────────────────────────────────────────────────────────┐
│ APIs ──────→ core.supplier (TABLE, 23 rows)                          │
│                                                                       │
│              core.supplier_product (TABLE, 25,602 rows)              │
│                                                                       │
│              core.stock_on_hand (TABLE, 25,602 rows)                 │
│                                                                       │
│ public.suppliers_deprecated (TABLE) ← Not actively used              │
└───────────────────────────────────────────────────────────────────────┘

         │
         │ Monitor 30 days
         ▼

PHASE 4: DECOMMISSIONED (Final State)
┌───────────────────────────────────────────────────────────────────────┐
│ APIs ──────→ core.supplier (TABLE, 23 rows)                          │
│              core.supplier_product (TABLE, 25,602 rows)              │
│              core.stock_on_hand (TABLE, 25,602 rows)                 │
│                                                                       │
│ archive.suppliers_backup_20251008 ← Historical backup                │
│                                                                       │
│ public schema: Only new operational tables, no legacy data           │
└───────────────────────────────────────────────────────────────────────┘
```

## View Dependency Graph

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        View Dependencies                                │
└─────────────────────────────────────────────────────────────────────────┘

    core.supplier_summary (MATERIALIZED VIEW)
           │
           │ depends on
           │
           ├─→ core.supplier_view ───────┐
           │                             │
           ├─→ core.supplier_product_view┼──→ public.suppliers
           │                             │
           └─→ core.stock_on_hand_view ──┘


    core.supplier (VIEW - reverse compatibility)
           │
           └──→ public.suppliers (TABLE)


    APIs can query either:
    - core.supplier (reverse view for backward compat)
    - core.supplier_view (forward view for new code)
    - core.supplier_summary (materialized, requires refresh)

    All ultimately read from public.suppliers
```

## Schema Evolution Timeline

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Schema Evolution History                             │
└─────────────────────────────────────────────────────────────────────────┘

2024-XX-XX: Initial public.suppliers table created
            ┌───────────────────────────┐
            │ public.suppliers (TABLE)  │
            │ - Monolithic design       │
            │ - All fields in one table │
            └───────────────────────────┘

2025-XX-XX: Migration 002 - Core schema created (empty)
            ┌───────────────────────────┐
            │ core.supplier (TABLE)     │
            │ - Normalized design       │
            │ - 0 rows (empty)          │
            └───────────────────────────┘

2025-10-08: Migration 003 - Forward views created
            ┌───────────────────────────┐
            │ core.supplier_view (VIEW) │
            │ → reads public.suppliers  │
            │ → maps columns            │
            └───────────────────────────┘

2025-10-08: Migration 004 - Reverse views created
            ┌───────────────────────────┐
            │ core.supplier (VIEW)      │
            │ → exposes public data     │
            │ → backward compatibility  │
            └───────────────────────────┘

2025-XX-XX: Migration 005 - Data migration (PLANNED)
            ┌───────────────────────────┐
            │ core.supplier (TABLE)     │
            │ - Contains real data      │
            │ - 23 rows migrated        │
            │ - Views dropped           │
            └───────────────────────────┘
```

## Query Performance Comparison

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Query Execution Paths                                │
└─────────────────────────────────────────────────────────────────────────┘

SCENARIO 1: Query through view (current)
┌─────────────────────────────────────────────────────────────────────┐
│ SELECT * FROM core.supplier WHERE active = true;                   │
├─────────────────────────────────────────────────────────────────────┤
│ Plan:                                                               │
│   → View expansion (core.supplier)                                  │
│   → Column transformation (CASE WHEN status IN ('active'...))      │
│   → Table scan on public.suppliers                                  │
│   → Filter on status column                                         │
│                                                                     │
│ Estimated Cost: ~15 units                                           │
│ Actual Rows: 23                                                     │
└─────────────────────────────────────────────────────────────────────┘

SCENARIO 2: Query on real table (post-migration)
┌─────────────────────────────────────────────────────────────────────┐
│ SELECT * FROM core.supplier WHERE active = true;                   │
├─────────────────────────────────────────────────────────────────────┤
│ Plan:                                                               │
│   → Index scan on core.supplier (idx_supplier_active)               │
│   → Filter on active column (boolean index)                         │
│                                                                     │
│ Estimated Cost: ~8 units (47% faster)                               │
│ Actual Rows: 23                                                     │
└─────────────────────────────────────────────────────────────────────┘

Performance Impact:
- Views add ~7-10% overhead (column transformation)
- Real tables benefit from optimized indexes
- For large datasets (>10K rows), difference is more significant
- Current dataset (23 suppliers) - negligible difference
```

## Security & Access Control

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      Schema Access Patterns                             │
└─────────────────────────────────────────────────────────────────────────┘

PUBLIC SCHEMA:
├── public.suppliers (TABLE)
│   └── GRANT ALL to nxtdb_admin
│   └── GRANT SELECT to app_readonly
│
└── public.inventory_items (VIEW)
    └── GRANT SELECT to PUBLIC

CORE SCHEMA:
├── core.supplier (VIEW)
│   └── GRANT SELECT to PUBLIC ← Allows API access
│
├── core.supplier_view (VIEW)
│   └── GRANT SELECT to PUBLIC
│
└── core.supplier_summary (MATERIALIZED VIEW)
    └── GRANT SELECT to PUBLIC
    └── REFRESH requires nxtdb_admin

Migration Impact:
- All existing grants preserved during view → table transition
- No security model changes required
- Application role permissions remain unchanged
```

---

**Diagram Version**: 1.0
**Last Updated**: 2025-10-08
**Next Update**: After Phase 2 (Data Migration) completion
