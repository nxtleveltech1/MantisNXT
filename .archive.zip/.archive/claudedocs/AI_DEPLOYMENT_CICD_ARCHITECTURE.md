# MantisNXT AI Deployment & CI/CD Architecture

## Executive Summary

**Mission**: Establish enterprise-grade deployment pipeline and CI/CD architecture for AI-powered supplier management system with automated testing, security validation, and production readiness.

**Focus**: Container orchestration, AI model deployment, automated testing, security integration, and production monitoring.

---

## 1. Container Architecture

### 1.1 Docker Container Strategy

```dockerfile
# AI Service Base Image
FROM nvidia/cuda:12.1-devel-ubuntu20.04 as ai-base

# Install system dependencies
RUN apt-get update && apt-get install -y \
    python3.9 \
    python3-pip \
    nodejs \
    npm \
    curl \
    git \
    && rm -rf /var/lib/apt/lists/*

# Install Python AI dependencies
COPY requirements.ai.txt /tmp/
RUN pip3 install --no-cache-dir -r /tmp/requirements.ai.txt

# Install Node.js dependencies
COPY package.json package-lock.json /app/
WORKDIR /app
RUN npm ci --only=production

# AI Supplier Intelligence Service
FROM ai-base as supplier-intelligence

COPY src/services/ai/supplier-intelligence/ /app/src/
COPY src/lib/ai/ /app/lib/ai/
COPY src/types/ /app/types/

# Set up environment
ENV NODE_ENV=production
ENV AI_SERVICE_TYPE=supplier_intelligence
ENV MODEL_CACHE_DIR=/app/models
ENV METRICS_PORT=9090

# Create non-root user
RUN useradd -m -u 1001 aiuser && \
    chown -R aiuser:aiuser /app
USER aiuser

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1

EXPOSE 8080 9090
CMD ["node", "src/index.js"]

# Next.js Application
FROM node:18-alpine as nextjs-app

WORKDIR /app

# Copy dependency files
COPY package.json package-lock.json ./
RUN npm ci --only=production && npm cache clean --force

# Copy application code
COPY . .
COPY .env.production .env.local

# Build application
RUN npm run build

# Create non-root user
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nextjs -u 1001

# Set ownership
RUN chown -R nextjs:nodejs /app
USER nextjs

EXPOSE 3000
CMD ["npm", "start"]

# Database Migration Service
FROM postgres:16-alpine as db-migrator

# Install migration tools
RUN apk add --no-cache nodejs npm

COPY database/migrations/ /migrations/
COPY scripts/database-migration.js /scripts/
COPY package.json /

RUN npm install --only=production

# Migration execution script
COPY docker/migration-entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

ENTRYPOINT ["/entrypoint.sh"]
```

### 1.2 Multi-Stage Build Strategy

```yaml
# Docker Compose for Development
version: '3.8'

services:
  # Next.js Application
  webapp:
    build:
      context: .
      dockerfile: Dockerfile
      target: nextjs-app
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://user:password@postgres:5432/mantisnxt
      - REDIS_URL=redis://redis:6379
    depends_on:
      - postgres
      - redis
      - supplier-intelligence
    volumes:
      - ./src:/app/src
      - ./public:/app/public
    networks:
      - mantisnxt-network

  # AI Supplier Intelligence Service
  supplier-intelligence:
    build:
      context: .
      dockerfile: Dockerfile
      target: supplier-intelligence
    ports:
      - "8080:8080"
      - "9090:9090"  # Metrics port
    environment:
      - AI_SERVICE_TYPE=supplier_intelligence
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - DATABASE_URL=postgresql://user:password@postgres:5432/mantisnxt
      - REDIS_URL=redis://redis:6379
    volumes:
      - ai-models:/app/models
      - ai-cache:/app/cache
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
    networks:
      - mantisnxt-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Database
  postgres:
    image: postgres:16-alpine
    environment:
      - POSTGRES_DB=mantisnxt
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres-data:/var/lib/postgresql/data
      - ./database/init:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    networks:
      - mantisnxt-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U user -d mantisnxt"]
      interval: 30s
      timeout: 5s
      retries: 5

  # Redis Cache
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    networks:
      - mantisnxt-network
    command: redis-server --appendonly yes --maxmemory 512mb --maxmemory-policy allkeys-lru

  # Vector Database (Qdrant)
  vectordb:
    image: qdrant/qdrant:v1.7.0
    ports:
      - "6333:6333"
      - "6334:6334"
    volumes:
      - vectordb-data:/qdrant/storage
    networks:
      - mantisnxt-network
    environment:
      - QDRANT__SERVICE__HTTP_PORT=6333
      - QDRANT__SERVICE__GRPC_PORT=6334

  # Monitoring Stack
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus-data:/prometheus
    networks:
      - mantisnxt-network
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources
    networks:
      - mantisnxt-network

volumes:
  postgres-data:
  redis-data:
  vectordb-data:
  prometheus-data:
  grafana-data:
  ai-models:
  ai-cache:

networks:
  mantisnxt-network:
    driver: bridge
```

---

## 2. Kubernetes Deployment Architecture

### 2.1 Kubernetes Manifests

```yaml
# Namespace
apiVersion: v1
kind: Namespace
metadata:
  name: mantisnxt
  labels:
    app: mantisnxt
    environment: production

---
# ConfigMap for Application Configuration
apiVersion: v1
kind: ConfigMap
metadata:
  name: mantisnxt-config
  namespace: mantisnxt
data:
  NODE_ENV: "production"
  DATABASE_HOST: "postgres-service"
  DATABASE_PORT: "5432"
  DATABASE_NAME: "mantisnxt"
  REDIS_HOST: "redis-service"
  REDIS_PORT: "6379"
  AI_SERVICE_HOST: "supplier-intelligence-service"
  AI_SERVICE_PORT: "8080"
  VECTOR_DB_HOST: "vectordb-service"
  VECTOR_DB_PORT: "6333"

---
# Secrets
apiVersion: v1
kind: Secret
metadata:
  name: mantisnxt-secrets
  namespace: mantisnxt
type: Opaque
data:
  DATABASE_PASSWORD: <base64-encoded-password>
  OPENAI_API_KEY: <base64-encoded-api-key>
  ANTHROPIC_API_KEY: <base64-encoded-api-key>
  JWT_SECRET: <base64-encoded-jwt-secret>

---
# PostgreSQL Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: postgres
  namespace: mantisnxt
  labels:
    app: postgres
spec:
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:16-alpine
        ports:
        - containerPort: 5432
        env:
        - name: POSTGRES_DB
          valueFrom:
            configMapKeyRef:
              name: mantisnxt-config
              key: DATABASE_NAME
        - name: POSTGRES_USER
          value: "mantisnxt_user"
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: DATABASE_PASSWORD
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          exec:
            command:
            - sh
            - -c
            - pg_isready -U mantisnxt_user -d mantisnxt
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          exec:
            command:
            - sh
            - -c
            - pg_isready -U mantisnxt_user -d mantisnxt
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: postgres-storage
        persistentVolumeClaim:
          claimName: postgres-pvc

---
# PostgreSQL Service
apiVersion: v1
kind: Service
metadata:
  name: postgres-service
  namespace: mantisnxt
spec:
  selector:
    app: postgres
  ports:
  - port: 5432
    targetPort: 5432
  type: ClusterIP

---
# PostgreSQL PVC
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: postgres-pvc
  namespace: mantisnxt
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 50Gi
  storageClassName: fast-ssd

---
# Redis Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: mantisnxt
  labels:
    app: redis
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
        command: ["redis-server"]
        args: ["--maxmemory", "1gb", "--maxmemory-policy", "allkeys-lru", "--appendonly", "yes"]
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        volumeMounts:
        - name: redis-storage
          mountPath: /data
        livenessProbe:
          tcpSocket:
            port: 6379
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          exec:
            command:
            - redis-cli
            - ping
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: redis-storage
        persistentVolumeClaim:
          claimName: redis-pvc

---
# Redis Service
apiVersion: v1
kind: Service
metadata:
  name: redis-service
  namespace: mantisnxt
spec:
  selector:
    app: redis
  ports:
  - port: 6379
    targetPort: 6379
  type: ClusterIP

---
# AI Supplier Intelligence Service Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: supplier-intelligence
  namespace: mantisnxt
  labels:
    app: supplier-intelligence
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1
      maxSurge: 2
  selector:
    matchLabels:
      app: supplier-intelligence
  template:
    metadata:
      labels:
        app: supplier-intelligence
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "9090"
        prometheus.io/path: "/metrics"
    spec:
      containers:
      - name: supplier-intelligence
        image: mantisnxt/supplier-intelligence:latest
        ports:
        - containerPort: 8080
          name: http
        - containerPort: 9090
          name: metrics
        env:
        - name: DATABASE_URL
          value: "postgresql://mantisnxt_user:$(DATABASE_PASSWORD)@postgres-service:5432/mantisnxt"
        - name: DATABASE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: DATABASE_PASSWORD
        - name: REDIS_URL
          value: "redis://redis-service:6379"
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: OPENAI_API_KEY
        - name: ANTHROPIC_API_KEY
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: ANTHROPIC_API_KEY
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        volumeMounts:
        - name: model-cache
          mountPath: /app/models
        - name: ai-cache
          mountPath: /app/cache
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
          timeoutSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
        startupProbe:
          httpGet:
            path: /startup
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 12
      volumes:
      - name: model-cache
        emptyDir:
          sizeLimit: 10Gi
      - name: ai-cache
        emptyDir:
          sizeLimit: 5Gi

---
# AI Service HPA
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: supplier-intelligence-hpa
  namespace: mantisnxt
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: supplier-intelligence
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 100
        periodSeconds: 15
      - type: Pods
        value: 5
        periodSeconds: 60
      selectPolicy: Max
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60

---
# Next.js Application Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: webapp
  namespace: mantisnxt
  labels:
    app: webapp
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1
      maxSurge: 2
  selector:
    matchLabels:
      app: webapp
  template:
    metadata:
      labels:
        app: webapp
    spec:
      containers:
      - name: webapp
        image: mantisnxt/webapp:latest
        ports:
        - containerPort: 3000
        env:
        - name: DATABASE_URL
          value: "postgresql://mantisnxt_user:$(DATABASE_PASSWORD)@postgres-service:5432/mantisnxt"
        - name: DATABASE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: DATABASE_PASSWORD
        - name: REDIS_URL
          value: "redis://redis-service:6379"
        - name: AI_SERVICE_URL
          value: "http://supplier-intelligence-service:8080"
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: mantisnxt-secrets
              key: JWT_SECRET
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /api/ready
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 10

---
# Application Service
apiVersion: v1
kind: Service
metadata:
  name: webapp-service
  namespace: mantisnxt
spec:
  selector:
    app: webapp
  ports:
  - port: 80
    targetPort: 3000
  type: ClusterIP

---
# AI Service
apiVersion: v1
kind: Service
metadata:
  name: supplier-intelligence-service
  namespace: mantisnxt
  labels:
    app: supplier-intelligence
spec:
  selector:
    app: supplier-intelligence
  ports:
  - name: http
    port: 8080
    targetPort: 8080
  - name: metrics
    port: 9090
    targetPort: 9090
  type: ClusterIP

---
# Ingress
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: mantisnxt-ingress
  namespace: mantisnxt
  annotations:
    kubernetes.io/ingress.class: "nginx"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/use-regex: "true"
    nginx.ingress.kubernetes.io/rate-limit: "100"
    nginx.ingress.kubernetes.io/rate-limit-window: "1m"
spec:
  tls:
  - hosts:
    - app.mantisnxt.com
    - api.mantisnxt.com
    secretName: mantisnxt-tls
  rules:
  - host: app.mantisnxt.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: webapp-service
            port:
              number: 80
  - host: api.mantisnxt.com
    http:
      paths:
      - path: /ai
        pathType: Prefix
        backend:
          service:
            name: supplier-intelligence-service
            port:
              number: 8080
      - path: /
        pathType: Prefix
        backend:
          service:
            name: webapp-service
            port:
              number: 80
```

---

## 3. CI/CD Pipeline Architecture

### 3.1 GitHub Actions Workflow

```yaml
# .github/workflows/ci-cd-pipeline.yml
name: MantisNXT AI Supplier Management CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  release:
    types: [published]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  # Code Quality and Security
  code-quality:
    name: Code Quality & Security Analysis
    runs-on: ubuntu-latest
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
      with:
        fetch-depth: 0

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'

    - name: Install dependencies
      run: npm ci

    - name: Run ESLint
      run: npm run lint

    - name: Run TypeScript check
      run: npm run type-check

    - name: Run Prettier check
      run: npm run format:check

    - name: SonarCloud Scan
      uses: SonarSource/sonarcloud-github-action@master
      env:
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}

    - name: Security audit
      run: npm audit --audit-level moderate

    - name: Dependency vulnerability scan
      uses: anchore/syft-action@v1
      with:
        image: node:18-alpine
        output-format: spdx-json
        output-file: sbom.spdx.json

    - name: Upload SBOM
      uses: actions/upload-artifact@v4
      with:
        name: sbom
        path: sbom.spdx.json

  # Unit and Integration Tests
  test:
    name: Unit & Integration Tests
    runs-on: ubuntu-latest
    needs: code-quality

    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: mantisnxt_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
        - 5432:5432

      redis:
        image: redis:7-alpine
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
        - 6379:6379

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'

    - name: Install dependencies
      run: npm ci

    - name: Run database migrations
      run: npm run db:migrate:test
      env:
        DATABASE_URL: postgresql://postgres:postgres@localhost:5432/mantisnxt_test

    - name: Run unit tests
      run: npm run test:unit
      env:
        NODE_ENV: test
        DATABASE_URL: postgresql://postgres:postgres@localhost:5432/mantisnxt_test
        REDIS_URL: redis://localhost:6379

    - name: Run integration tests
      run: npm run test:integration
      env:
        NODE_ENV: test
        DATABASE_URL: postgresql://postgres:postgres@localhost:5432/mantisnxt_test
        REDIS_URL: redis://localhost:6379

    - name: Generate coverage report
      run: npm run test:coverage

    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage/lcov.info
        flags: unittests
        name: codecov-umbrella

  # AI Model Tests
  ai-model-tests:
    name: AI Model Tests
    runs-on: ubuntu-latest
    needs: code-quality

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
        cache: 'pip'

    - name: Install Python dependencies
      run: |
        pip install -r requirements.ai.txt
        pip install pytest pytest-cov

    - name: Run AI model unit tests
      run: pytest tests/ai/ -v --cov=src/lib/ai --cov-report=xml

    - name: Validate model performance
      run: python scripts/validate-model-performance.py
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY_TEST }}

    - name: Test model bias detection
      run: python tests/ai/test_bias_detection.py

    - name: Upload AI test coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
        flags: ai-models
        name: ai-model-coverage

  # End-to-End Tests
  e2e-tests:
    name: End-to-End Tests
    runs-on: ubuntu-latest
    needs: [test, ai-model-tests]

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'

    - name: Install dependencies
      run: npm ci

    - name: Install Playwright
      run: npx playwright install --with-deps

    - name: Start test environment
      run: docker-compose -f docker-compose.test.yml up -d

    - name: Wait for services
      run: |
        ./scripts/wait-for-services.sh
        sleep 30

    - name: Run E2E tests
      run: npm run test:e2e
      env:
        BASE_URL: http://localhost:3000

    - name: Upload E2E test results
      uses: actions/upload-artifact@v4
      if: always()
      with:
        name: playwright-report
        path: playwright-report/

    - name: Cleanup test environment
      if: always()
      run: docker-compose -f docker-compose.test.yml down

  # Security Testing
  security-tests:
    name: Security Testing
    runs-on: ubuntu-latest
    needs: code-quality

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Run Trivy vulnerability scanner
      uses: aquasecurity/trivy-action@master
      with:
        scan-type: 'fs'
        format: 'sarif'
        output: 'trivy-results.sarif'

    - name: Upload Trivy scan results to GitHub Security tab
      uses: github/codeql-action/upload-sarif@v2
      with:
        sarif_file: 'trivy-results.sarif'

    - name: OWASP ZAP Scan
      uses: zaproxy/action-full-scan@v0.7.0
      with:
        target: 'http://localhost:3000'
        rules_file_name: '.zap/rules.tsv'
        cmd_options: '-a'

  # Build and Push Images
  build:
    name: Build & Push Images
    runs-on: ubuntu-latest
    needs: [test, ai-model-tests, e2e-tests, security-tests]
    if: github.event_name != 'pull_request'

    strategy:
      matrix:
        service: [webapp, supplier-intelligence, db-migrator]

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Set up Docker Buildx
      uses: docker/setup-buildx-action@v3

    - name: Log in to Container Registry
      uses: docker/login-action@v3
      with:
        registry: ${{ env.REGISTRY }}
        username: ${{ github.actor }}
        password: ${{ secrets.GITHUB_TOKEN }}

    - name: Extract metadata
      id: meta
      uses: docker/metadata-action@v5
      with:
        images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}/${{ matrix.service }}
        tags: |
          type=ref,event=branch
          type=ref,event=pr
          type=semver,pattern={{version}}
          type=semver,pattern={{major}}.{{minor}}
          type=sha

    - name: Build and push image
      uses: docker/build-push-action@v5
      with:
        context: .
        file: Dockerfile
        target: ${{ matrix.service }}
        push: true
        tags: ${{ steps.meta.outputs.tags }}
        labels: ${{ steps.meta.outputs.labels }}
        cache-from: type=gha
        cache-to: type=gha,mode=max
        platforms: linux/amd64,linux/arm64

    - name: Sign container image
      uses: sigstore/cosign-installer@v3
      with:
        cosign-release: 'v2.2.1'

    - name: Sign the published Docker image
      env:
        COSIGN_EXPERIMENTAL: 1
      run: |
        echo "${{ steps.meta.outputs.tags }}" | xargs -I {} cosign sign --yes {}@${{ steps.build.outputs.digest }}

  # Deploy to Staging
  deploy-staging:
    name: Deploy to Staging
    runs-on: ubuntu-latest
    needs: build
    if: github.ref == 'refs/heads/develop'
    environment: staging

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup kubectl
      uses: azure/setup-kubectl@v3
      with:
        version: 'v1.28.0'

    - name: Configure kubectl
      run: |
        echo "${{ secrets.KUBE_CONFIG_STAGING }}" | base64 -d > kubeconfig
        export KUBECONFIG=kubeconfig

    - name: Deploy to staging
      run: |
        export KUBECONFIG=kubeconfig
        envsubst < k8s/staging/kustomization.yaml | kubectl apply -f -
        kubectl set image deployment/webapp webapp=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}/webapp:${{ github.sha }} -n mantisnxt-staging
        kubectl set image deployment/supplier-intelligence supplier-intelligence=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}/supplier-intelligence:${{ github.sha }} -n mantisnxt-staging
        kubectl rollout status deployment/webapp -n mantisnxt-staging
        kubectl rollout status deployment/supplier-intelligence -n mantisnxt-staging

    - name: Run smoke tests
      run: |
        export KUBECONFIG=kubeconfig
        ./scripts/smoke-tests-staging.sh

    - name: Notify deployment status
      uses: 8398a7/action-slack@v3
      with:
        status: ${{ job.status }}
        channel: '#deployments'
        webhook_url: ${{ secrets.SLACK_WEBHOOK }}

  # Deploy to Production
  deploy-production:
    name: Deploy to Production
    runs-on: ubuntu-latest
    needs: build
    if: github.event_name == 'release'
    environment: production

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup kubectl
      uses: azure/setup-kubectl@v3
      with:
        version: 'v1.28.0'

    - name: Configure kubectl
      run: |
        echo "${{ secrets.KUBE_CONFIG_PRODUCTION }}" | base64 -d > kubeconfig
        export KUBECONFIG=kubeconfig

    - name: Database migration
      run: |
        export KUBECONFIG=kubeconfig
        kubectl create job --from=cronjob/db-migration db-migration-$(date +%Y%m%d%H%M%S) -n mantisnxt
        kubectl wait --for=condition=complete --timeout=600s job -l job-name=db-migration -n mantisnxt

    - name: Deploy to production (Blue-Green)
      run: |
        export KUBECONFIG=kubeconfig
        ./scripts/blue-green-deploy.sh
      env:
        IMAGE_TAG: ${{ github.event.release.tag_name }}

    - name: Run production health checks
      run: |
        export KUBECONFIG=kubeconfig
        ./scripts/production-health-check.sh

    - name: Cleanup old deployments
      run: |
        export KUBECONFIG=kubeconfig
        ./scripts/cleanup-old-deployments.sh

    - name: Notify production deployment
      uses: 8398a7/action-slack@v3
      with:
        status: ${{ job.status }}
        channel: '#production'
        webhook_url: ${{ secrets.SLACK_WEBHOOK }}
        text: |
          Production deployment completed successfully!
          Version: ${{ github.event.release.tag_name }}
          Commit: ${{ github.sha }}

  # Performance Tests
  performance-tests:
    name: Performance Testing
    runs-on: ubuntu-latest
    needs: deploy-staging
    if: github.ref == 'refs/heads/develop'

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup K6
      run: |
        sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
        echo "deb https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
        sudo apt-get update
        sudo apt-get install k6

    - name: Run AI performance tests
      run: k6 run tests/performance/ai-endpoints.js
      env:
        BASE_URL: https://staging.mantisnxt.com

    - name: Run load tests
      run: k6 run tests/performance/load-test.js
      env:
        BASE_URL: https://staging.mantisnxt.com

    - name: Generate performance report
      run: |
        k6 run --out json=performance-results.json tests/performance/comprehensive-test.js
        node scripts/generate-performance-report.js

    - name: Upload performance results
      uses: actions/upload-artifact@v4
      with:
        name: performance-results
        path: |
          performance-results.json
          performance-report.html

    - name: Performance regression check
      run: node scripts/check-performance-regression.js
      env:
        BASELINE_RESULTS_URL: ${{ secrets.BASELINE_RESULTS_URL }}
```

### 3.2 GitLab CI/CD Alternative

```yaml
# .gitlab-ci.yml
stages:
  - validate
  - test
  - security
  - build
  - deploy-staging
  - performance
  - deploy-production

variables:
  DOCKER_DRIVER: overlay2
  DOCKER_TLS_CERTDIR: "/certs"
  REGISTRY: $CI_REGISTRY
  IMAGE_TAG: $CI_COMMIT_SHA

# Code Validation
validate:
  stage: validate
  image: node:18-alpine
  cache:
    paths:
      - node_modules/
  script:
    - npm ci
    - npm run lint
    - npm run type-check
    - npm run format:check
  artifacts:
    reports:
      junit: junit.xml
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_BRANCH == "main"
    - if: $CI_COMMIT_BRANCH == "develop"

# Unit Tests
test:unit:
  stage: test
  image: node:18-alpine
  services:
    - name: postgres:16-alpine
      alias: postgres
      variables:
        POSTGRES_DB: mantisnxt_test
        POSTGRES_USER: test
        POSTGRES_PASSWORD: test
    - name: redis:7-alpine
      alias: redis
  variables:
    DATABASE_URL: "postgresql://test:test@postgres:5432/mantisnxt_test"
    REDIS_URL: "redis://redis:6379"
  cache:
    paths:
      - node_modules/
  script:
    - npm ci
    - npm run db:migrate:test
    - npm run test:unit
    - npm run test:coverage
  coverage: '/Lines\s*:\s*(\d+\.\d+)%/'
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage/cobertura-coverage.xml
      junit: junit.xml
    paths:
      - coverage/

# AI Model Tests
test:ai:
  stage: test
  image: python:3.9-slim
  script:
    - pip install -r requirements.ai.txt
    - pip install pytest pytest-cov
    - pytest tests/ai/ -v --cov=src/lib/ai --cov-report=xml --cov-report=term
    - python scripts/validate-model-performance.py
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage.xml
    paths:
      - coverage.xml
  variables:
    OPENAI_API_KEY: $OPENAI_API_KEY_TEST

# Security Scanning
security:sast:
  stage: security
  include:
    - template: Security/SAST.gitlab-ci.yml

security:dependency:
  stage: security
  include:
    - template: Security/Dependency-Scanning.gitlab-ci.yml

security:secret:
  stage: security
  include:
    - template: Security/Secret-Detection.gitlab-ci.yml

security:container:
  stage: security
  include:
    - template: Security/Container-Scanning.gitlab-ci.yml

# Build Images
build:webapp:
  stage: build
  image: docker:24.0.5
  services:
    - docker:24.0.5-dind
  script:
    - echo $CI_REGISTRY_PASSWORD | docker login -u $CI_REGISTRY_USER --password-stdin $CI_REGISTRY
    - docker buildx create --use
    - docker buildx build
        --target webapp
        --platform linux/amd64,linux/arm64
        --tag $CI_REGISTRY_IMAGE/webapp:$CI_COMMIT_SHA
        --tag $CI_REGISTRY_IMAGE/webapp:latest
        --push .
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
    - if: $CI_COMMIT_BRANCH == "develop"
    - if: $CI_COMMIT_TAG

build:ai-service:
  stage: build
  image: docker:24.0.5
  services:
    - docker:24.0.5-dind
  script:
    - echo $CI_REGISTRY_PASSWORD | docker login -u $CI_REGISTRY_USER --password-stdin $CI_REGISTRY
    - docker buildx create --use
    - docker buildx build
        --target supplier-intelligence
        --platform linux/amd64,linux/arm64
        --tag $CI_REGISTRY_IMAGE/supplier-intelligence:$CI_COMMIT_SHA
        --tag $CI_REGISTRY_IMAGE/supplier-intelligence:latest
        --push .
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
    - if: $CI_COMMIT_BRANCH == "develop"
    - if: $CI_COMMIT_TAG

# Deploy to Staging
deploy:staging:
  stage: deploy-staging
  image: bitnami/kubectl:latest
  environment:
    name: staging
    url: https://staging.mantisnxt.com
  script:
    - echo $KUBE_CONFIG_STAGING | base64 -d > kubeconfig
    - export KUBECONFIG=kubeconfig
    - kubectl set image deployment/webapp webapp=$CI_REGISTRY_IMAGE/webapp:$CI_COMMIT_SHA -n mantisnxt-staging
    - kubectl set image deployment/supplier-intelligence supplier-intelligence=$CI_REGISTRY_IMAGE/supplier-intelligence:$CI_COMMIT_SHA -n mantisnxt-staging
    - kubectl rollout status deployment/webapp -n mantisnxt-staging --timeout=600s
    - kubectl rollout status deployment/supplier-intelligence -n mantisnxt-staging --timeout=600s
    - ./scripts/smoke-tests-staging.sh
  rules:
    - if: $CI_COMMIT_BRANCH == "develop"

# Performance Testing
performance:tests:
  stage: performance
  image: loadimpact/k6:latest
  script:
    - k6 run --out json=performance-results.json tests/performance/ai-endpoints.js
    - k6 run --out json=load-results.json tests/performance/load-test.js
  artifacts:
    reports:
      performance: performance-results.json
    paths:
      - performance-results.json
      - load-results.json
  rules:
    - if: $CI_COMMIT_BRANCH == "develop"

# Deploy to Production
deploy:production:
  stage: deploy-production
  image: bitnami/kubectl:latest
  environment:
    name: production
    url: https://app.mantisnxt.com
  script:
    - echo $KUBE_CONFIG_PRODUCTION | base64 -d > kubeconfig
    - export KUBECONFIG=kubeconfig
    - kubectl create job --from=cronjob/db-migration db-migration-$(date +%Y%m%d%H%M%S) -n mantisnxt
    - kubectl wait --for=condition=complete --timeout=600s job -l job-name=db-migration -n mantisnxt
    - ./scripts/blue-green-deploy.sh
    - ./scripts/production-health-check.sh
    - ./scripts/cleanup-old-deployments.sh
  rules:
    - if: $CI_COMMIT_TAG
  when: manual
  allow_failure: false
```

---

## 4. Infrastructure as Code

### 4.1 Terraform Configuration

```hcl
# terraform/main.tf
terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.23"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.11"
    }
  }

  backend "s3" {
    bucket = "mantisnxt-terraform-state"
    key    = "infrastructure/terraform.tfstate"
    region = "us-west-2"

    dynamodb_table = "mantisnxt-terraform-locks"
    encrypt        = true
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "MantisNXT"
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  }
}

# VPC Configuration
module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${var.project_name}-${var.environment}"
  cidr = var.vpc_cidr

  azs             = var.availability_zones
  private_subnets = var.private_subnet_cidrs
  public_subnets  = var.public_subnet_cidrs

  enable_nat_gateway     = true
  single_nat_gateway     = var.environment != "production"
  enable_vpn_gateway     = false
  enable_dns_hostnames   = true
  enable_dns_support     = true

  # Enable VPC Flow Logs
  enable_flow_log                      = true
  create_flow_log_cloudwatch_iam_role  = true
  create_flow_log_cloudwatch_log_group = true

  tags = {
    Name = "${var.project_name}-${var.environment}-vpc"
  }
}

# EKS Cluster
module "eks" {
  source = "terraform-aws-modules/eks/aws"
  version = "~> 19.0"

  cluster_name                   = "${var.project_name}-${var.environment}"
  cluster_version               = var.kubernetes_version
  cluster_endpoint_public_access = true

  vpc_id                         = module.vpc.vpc_id
  subnet_ids                     = module.vpc.private_subnets
  control_plane_subnet_ids       = module.vpc.private_subnets

  # EKS Managed Node Groups
  eks_managed_node_groups = {
    general = {
      name = "${var.project_name}-${var.environment}-general"

      instance_types = var.node_instance_types
      capacity_type  = "ON_DEMAND"

      min_size     = var.node_group_min_size
      max_size     = var.node_group_max_size
      desired_size = var.node_group_desired_size

      ami_type = "AL2_x86_64"

      k8s_labels = {
        Environment = var.environment
        NodeType    = "general"
      }

      tags = {
        Name = "${var.project_name}-${var.environment}-general-nodes"
      }
    }

    ai_workloads = {
      name = "${var.project_name}-${var.environment}-ai"

      instance_types = ["g4dn.xlarge", "g4dn.2xlarge"]
      capacity_type  = "ON_DEMAND"

      min_size     = 0
      max_size     = 10
      desired_size = 1

      ami_type = "AL2_x86_64_GPU"

      k8s_labels = {
        Environment = var.environment
        NodeType    = "ai-gpu"
        workload    = "ai-inference"
      }

      taints = {
        ai-workload = {
          key    = "ai-workload"
          value  = "true"
          effect = "NO_SCHEDULE"
        }
      }

      tags = {
        Name = "${var.project_name}-${var.environment}-ai-nodes"
      }
    }
  }

  # AWS Load Balancer Controller
  enable_irsa = true

  tags = {
    Name = "${var.project_name}-${var.environment}-eks"
  }
}

# RDS Database
resource "aws_db_subnet_group" "main" {
  name       = "${var.project_name}-${var.environment}-db-subnet-group"
  subnet_ids = module.vpc.private_subnets

  tags = {
    Name = "${var.project_name}-${var.environment}-db-subnet-group"
  }
}

resource "aws_security_group" "rds" {
  name_prefix = "${var.project_name}-${var.environment}-rds"
  vpc_id      = module.vpc.vpc_id

  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project_name}-${var.environment}-rds-sg"
  }
}

resource "aws_db_instance" "main" {
  identifier = "${var.project_name}-${var.environment}"

  engine         = "postgres"
  engine_version = var.postgres_version
  instance_class = var.db_instance_class

  allocated_storage     = var.db_allocated_storage
  max_allocated_storage = var.db_max_allocated_storage
  storage_type          = "gp3"
  storage_encrypted     = true

  db_name  = var.database_name
  username = var.database_username
  password = var.database_password

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.main.name

  backup_retention_period = var.environment == "production" ? 30 : 7
  backup_window          = "03:00-04:00"
  maintenance_window     = "sun:04:00-sun:05:00"

  skip_final_snapshot       = var.environment != "production"
  final_snapshot_identifier = "${var.project_name}-${var.environment}-final-snapshot"

  performance_insights_enabled = var.environment == "production"
  monitoring_interval         = var.environment == "production" ? 60 : 0

  tags = {
    Name = "${var.project_name}-${var.environment}-database"
  }
}

# ElastiCache Redis
resource "aws_elasticache_subnet_group" "main" {
  name       = "${var.project_name}-${var.environment}-cache-subnet"
  subnet_ids = module.vpc.private_subnets
}

resource "aws_security_group" "redis" {
  name_prefix = "${var.project_name}-${var.environment}-redis"
  vpc_id      = module.vpc.vpc_id

  ingress {
    from_port   = 6379
    to_port     = 6379
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project_name}-${var.environment}-redis-sg"
  }
}

resource "aws_elasticache_replication_group" "main" {
  replication_group_id       = "${var.project_name}-${var.environment}"
  description               = "Redis cluster for ${var.project_name} ${var.environment}"

  node_type                 = var.redis_node_type
  port                      = 6379
  parameter_group_name      = "default.redis7"

  num_cache_clusters        = var.redis_num_cache_nodes
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true

  subnet_group_name         = aws_elasticache_subnet_group.main.name
  security_group_ids        = [aws_security_group.redis.id]

  tags = {
    Name = "${var.project_name}-${var.environment}-redis"
  }
}

# S3 Buckets
resource "aws_s3_bucket" "ai_models" {
  bucket = "${var.project_name}-${var.environment}-ai-models"

  tags = {
    Name = "${var.project_name}-${var.environment}-ai-models"
    Type = "ai-storage"
  }
}

resource "aws_s3_bucket_versioning" "ai_models" {
  bucket = aws_s3_bucket.ai_models.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_encryption" "ai_models" {
  bucket = aws_s3_bucket.ai_models.id

  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default {
        sse_algorithm = "AES256"
      }
    }
  }
}

# CloudWatch Log Groups
resource "aws_cloudwatch_log_group" "application" {
  name              = "/aws/eks/${var.project_name}-${var.environment}/application"
  retention_in_days = var.environment == "production" ? 30 : 7

  tags = {
    Name = "${var.project_name}-${var.environment}-application-logs"
  }
}

resource "aws_cloudwatch_log_group" "ai_services" {
  name              = "/aws/eks/${var.project_name}-${var.environment}/ai-services"
  retention_in_days = var.environment == "production" ? 30 : 7

  tags = {
    Name = "${var.project_name}-${var.environment}-ai-logs"
  }
}

# IAM Roles for Services
resource "aws_iam_role" "ai_service" {
  name = "${var.project_name}-${var.environment}-ai-service"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRoleWithWebIdentity"
        Effect = "Allow"
        Principal = {
          Federated = module.eks.oidc_provider_arn
        }
        Condition = {
          StringEquals = {
            "${module.eks.oidc_provider}:sub" = "system:serviceaccount:mantisnxt:ai-service"
            "${module.eks.oidc_provider}:aud" = "sts.amazonaws.com"
          }
        }
      }
    ]
  })

  tags = {
    Name = "${var.project_name}-${var.environment}-ai-service-role"
  }
}

resource "aws_iam_policy" "ai_service" {
  name = "${var.project_name}-${var.environment}-ai-service-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject"
        ]
        Resource = "${aws_s3_bucket.ai_models.arn}/*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:ListBucket"
        ]
        Resource = aws_s3_bucket.ai_models.arn
      },
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = [
          aws_cloudwatch_log_group.application.arn,
          aws_cloudwatch_log_group.ai_services.arn
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "ai_service" {
  policy_arn = aws_iam_policy.ai_service.arn
  role       = aws_iam_role.ai_service.name
}
```

### 4.2 Helm Charts

```yaml
# helm/mantisnxt/Chart.yaml
apiVersion: v2
name: mantisnxt
description: AI-Powered Supplier Management System
type: application
version: 0.1.0
appVersion: "1.0.0"

dependencies:
  - name: postgresql
    version: 12.1.2
    repository: https://charts.bitnami.com/bitnami
    condition: postgresql.enabled

  - name: redis
    version: 17.4.3
    repository: https://charts.bitnami.com/bitnami
    condition: redis.enabled

  - name: prometheus
    version: 15.18.0
    repository: https://prometheus-community.github.io/helm-charts
    condition: monitoring.prometheus.enabled

  - name: grafana
    version: 6.50.7
    repository: https://grafana.github.io/helm-charts
    condition: monitoring.grafana.enabled

---
# helm/mantisnxt/values.yaml
# Global configuration
global:
  imageRegistry: ""
  imagePullSecrets: []

# Application configuration
app:
  name: mantisnxt
  version: "1.0.0"

# Web application
webapp:
  enabled: true
  replicaCount: 3

  image:
    repository: mantisnxt/webapp
    pullPolicy: IfNotPresent
    tag: ""

  service:
    type: ClusterIP
    port: 80
    targetPort: 3000

  ingress:
    enabled: true
    className: "nginx"
    annotations:
      nginx.ingress.kubernetes.io/ssl-redirect: "true"
      cert-manager.io/cluster-issuer: "letsencrypt-prod"
    hosts:
      - host: app.mantisnxt.com
        paths:
          - path: /
            pathType: Prefix
    tls:
      - secretName: webapp-tls
        hosts:
          - app.mantisnxt.com

  resources:
    limits:
      cpu: 1000m
      memory: 2Gi
    requests:
      cpu: 250m
      memory: 512Mi

  autoscaling:
    enabled: true
    minReplicas: 3
    maxReplicas: 20
    targetCPUUtilizationPercentage: 70
    targetMemoryUtilizationPercentage: 80

  env:
    NODE_ENV: "production"
    DATABASE_HOST: "postgresql"
    DATABASE_PORT: "5432"
    REDIS_HOST: "redis-master"
    REDIS_PORT: "6379"

# AI Supplier Intelligence Service
aiService:
  enabled: true
  replicaCount: 3

  image:
    repository: mantisnxt/supplier-intelligence
    pullPolicy: IfNotPresent
    tag: ""

  service:
    type: ClusterIP
    port: 8080
    targetPort: 8080
    metricsPort: 9090

  resources:
    limits:
      cpu: 2000m
      memory: 4Gi
      nvidia.com/gpu: 1  # GPU resources for AI workloads
    requests:
      cpu: 500m
      memory: 1Gi

  tolerations:
    - key: "ai-workload"
      operator: "Equal"
      value: "true"
      effect: "NoSchedule"

  nodeSelector:
    workload: "ai-inference"

  autoscaling:
    enabled: true
    minReplicas: 3
    maxReplicas: 10
    targetCPUUtilizationPercentage: 70

  env:
    AI_SERVICE_TYPE: "supplier_intelligence"
    MODEL_CACHE_SIZE: "2Gi"
    INFERENCE_BATCH_SIZE: "16"

# Database configuration
postgresql:
  enabled: false  # Use external RDS instance

# External database configuration
externalDatabase:
  host: "rds-host"
  port: 5432
  database: "mantisnxt"
  username: "mantisnxt_user"
  existingSecret: "database-secret"
  existingSecretPasswordKey: "password"

# Redis configuration
redis:
  enabled: false  # Use external ElastiCache

externalRedis:
  host: "elasticache-host"
  port: 6379
  existingSecret: "redis-secret"
  existingSecretPasswordKey: "password"

# Monitoring configuration
monitoring:
  prometheus:
    enabled: true

  grafana:
    enabled: true
    adminPassword: "admin123"

  serviceMonitor:
    enabled: true
    interval: 30s
    scrapeTimeout: 10s

# Security configuration
security:
  networkPolicies:
    enabled: true

  podSecurityPolicy:
    enabled: true

  rbac:
    create: true

# ConfigMaps and Secrets
configMaps:
  application:
    data:
      NODE_ENV: "production"
      LOG_LEVEL: "info"

secrets:
  database:
    type: Opaque
    data:
      password: ""  # Base64 encoded

  aiProviders:
    type: Opaque
    data:
      openai-api-key: ""
      anthropic-api-key: ""
```

---

## Conclusion

This comprehensive AI Deployment & CI/CD Architecture provides:

### Deployment Benefits:
1. **Container Orchestration**: Production-ready Kubernetes deployment with auto-scaling
2. **Infrastructure as Code**: Terraform-managed AWS infrastructure with proper security
3. **Multi-Environment Support**: Staging and production environments with proper isolation
4. **High Availability**: Load balancing, redundancy, and disaster recovery capabilities

### CI/CD Benefits:
1. **Automated Testing**: Comprehensive test suite including AI model validation
2. **Security Integration**: SAST, dependency scanning, and container security
3. **Quality Gates**: Code quality, performance, and security checks at each stage
4. **Blue-Green Deployments**: Zero-downtime production deployments

### Operational Benefits:
1. **Monitoring Integration**: Built-in observability with Prometheus and Grafana
2. **Scalability**: Automatic scaling based on resource utilization and demand
3. **Cost Optimization**: Efficient resource allocation with spot instances where appropriate
4. **Compliance**: Security scanning, audit trails, and regulatory compliance features

### AI-Specific Features:
1. **GPU Support**: Dedicated AI workload nodes with GPU resources
2. **Model Management**: S3-based model storage with versioning and caching
3. **Performance Optimization**: Resource allocation and scaling tailored for AI workloads
4. **Security**: AI-specific security scanning and validation in the pipeline

The architecture ensures reliable, scalable, and secure deployment of the AI-powered supplier management system with enterprise-grade DevOps practices.