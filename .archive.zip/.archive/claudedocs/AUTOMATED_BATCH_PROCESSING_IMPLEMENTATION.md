# Automated Batch Processing Implementation Guide

## Overview

This document provides detailed implementation guidance for processing all 28 supplier price list files in the MantisNXT upload directory. The system will automatically detect, process, and integrate supplier data while maintaining data quality and consistency.

## 1. Batch Processing Engine Architecture

### 1.1 Core Processing Components

```typescript
// src/lib/batch-processing/BatchProcessingEngine.ts
interface BatchProcessingConfig {
  // File processing settings
  maxConcurrentFiles: number; // 3-5 files simultaneously
  fileProcessingTimeout: number; // 30 minutes per file
  retryAttempts: number; // 3 retries per file

  // Data validation settings
  qualityThreshold: number; // 0.95 (95% data quality required)
  requiredFields: string[]; // ['sku', 'name', 'price', 'category']

  // Supplier detection settings
  supplierDetectionMethods: ('filename' | 'content' | 'pattern')[];
  confidenceThreshold: number; // 0.8 (80% confidence required)
}

export class BatchProcessingEngine {
  private config: BatchProcessingConfig;
  private processingQueue: ProcessingQueue;
  private supplierDetector: SupplierDetectionEngine;
  private dataValidator: DataValidationEngine;
  private progressTracker: ProgressTracker;

  constructor(config: BatchProcessingConfig) {
    this.config = config;
    this.processingQueue = new ProcessingQueue(config.maxConcurrentFiles);
    this.supplierDetector = new SupplierDetectionEngine();
    this.dataValidator = new DataValidationEngine();
    this.progressTracker = new ProgressTracker();
  }

  async processBatch(uploadDirectory: string): Promise<BatchProcessingResult> {
    const batchSession = await this.createBatchSession();

    try {
      // 1. Discover all files in directory
      const files = await this.discoverFiles(uploadDirectory);
      console.log(`Discovered ${files.length} files for processing`);

      // 2. Initialize batch session
      await this.initializeBatchSession(batchSession.id, files);

      // 3. Process files in parallel with queue management
      const results = await this.processFilesInParallel(batchSession.id, files);

      // 4. Generate batch summary and analytics
      const batchSummary = await this.generateBatchSummary(batchSession.id, results);

      return batchSummary;
    } catch (error) {
      await this.handleBatchError(batchSession.id, error);
      throw error;
    }
  }

  private async processFilesInParallel(
    batchSessionId: string,
    files: FileInfo[]
  ): Promise<FileProcessingResult[]> {
    const results: FileProcessingResult[] = [];

    // Process files with controlled concurrency
    const promises = files.map(file =>
      this.processingQueue.add(() => this.processSingleFile(batchSessionId, file))
    );

    const settledResults = await Promise.allSettled(promises);

    // Handle results and errors
    settledResults.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        results.push(result.value);
      } else {
        console.error(`File ${files[index].filename} processing failed:`, result.reason);
        results.push({
          filename: files[index].filename,
          status: 'failed',
          error: result.reason.message
        });
      }
    });

    return results;
  }
}
```

### 1.2 Supplier Detection Engine

```typescript
// src/lib/batch-processing/SupplierDetectionEngine.ts
export class SupplierDetectionEngine {
  private supplierPatterns: Map<string, SupplierPattern>;

  constructor() {
    this.supplierPatterns = this.loadSupplierPatterns();
  }

  async detectSupplier(
    filename: string,
    headers: string[],
    sampleData: any[][]
  ): Promise<SupplierDetectionResult> {
    const detectionMethods = [
      this.detectByFilename(filename),
      this.detectByHeaders(headers),
      this.detectByDataPatterns(sampleData),
      this.detectByProductCodes(sampleData)
    ];

    const results = await Promise.all(detectionMethods);
    return this.consolidateResults(results);
  }

  private loadSupplierPatterns(): Map<string, SupplierPattern> {
    // Based on the 28 supplier files in the upload directory
    return new Map([
      ['ApexPro Distribution', {
        filenamePatterns: ['apex', 'apexpro', 'distribution'],
        headerPatterns: ['item code', 'product name', 'wholesale price'],
        dataPatterns: ['APX-', 'APEX-'],
        priceColumns: ['wholesale price', 'dealer price', 'cost'],
        categoryPatterns: ['audio', 'equipment', 'gear']
      }],

      ['Alpha Technologies', {
        filenamePatterns: ['alpha', 'alpha-tech', 'technologies'],
        headerPatterns: ['part number', 'description', 'list price'],
        dataPatterns: ['ALPHA-', 'AT-'],
        priceColumns: ['list price', 'dealer price', 'wholesale'],
        categoryPatterns: ['power', 'battery', 'backup']
      }],

      ['Active Music Distribution', {
        filenamePatterns: ['active', 'music', 'distribution'],
        headerPatterns: ['sku', 'product', 'retail price'],
        dataPatterns: ['AMD-', 'MUSIC-'],
        priceColumns: ['retail price', 'cost price', 'wholesale'],
        categoryPatterns: ['instruments', 'music', 'audio']
      }],

      ['Audiosure', {
        filenamePatterns: ['audiosure', 'audio'],
        headerPatterns: ['stock code', 'description', 'price'],
        dataPatterns: ['AS-', 'AUDIO-'],
        priceColumns: ['price', 'cost', 'wholesale'],
        categoryPatterns: ['audio', 'sound', 'equipment']
      }],

      ['Global Music', {
        filenamePatterns: ['global', 'music'],
        headerPatterns: ['sku list', 'product name', 'advertised price'],
        dataPatterns: ['GM-', 'GLOBAL-'],
        priceColumns: ['advertised price', 'suggested price', 'online price'],
        categoryPatterns: ['musical', 'instruments', 'accessories']
      }],

      ['Rolling Thunder', {
        filenamePatterns: ['rolling', 'thunder'],
        headerPatterns: ['item', 'description', 'price'],
        dataPatterns: ['RT-', 'THUNDER-'],
        priceColumns: ['price', 'cost', 'wholesale'],
        categoryPatterns: ['drums', 'percussion', 'accessories']
      }],

      ['Stage Audio Works', {
        filenamePatterns: ['stage', 'audio', 'works'],
        headerPatterns: ['soh', 'info', 'stock'],
        dataPatterns: ['SAW-', 'STAGE-'],
        priceColumns: ['price', 'cost', 'wholesale'],
        categoryPatterns: ['stage', 'audio', 'lighting']
      }],

      ['Yamaha', {
        filenamePatterns: ['yamaha', 'retail'],
        headerPatterns: ['model', 'description', 'retail price'],
        dataPatterns: ['YAS-', 'YAM-', 'YAMAHA'],
        priceColumns: ['retail price', 'dealer price', 'cost'],
        categoryPatterns: ['piano', 'keyboard', 'audio', 'instruments']
      }],

      ['Sennheiser', {
        filenamePatterns: ['sennheiser'],
        headerPatterns: ['article', 'description', 'price'],
        dataPatterns: ['SENN-', 'HD', 'ME'],
        priceColumns: ['price', 'cost', 'wholesale'],
        categoryPatterns: ['headphones', 'microphones', 'audio']
      }]

      // Continue for all 28 suppliers...
    ]);
  }

  private detectByFilename(filename: string): SupplierMatch {
    const normalizedFilename = filename.toLowerCase();
    let bestMatch: SupplierMatch = { supplierId: null, confidence: 0, method: 'filename' };

    for (const [supplierName, pattern] of this.supplierPatterns) {
      const confidence = this.calculateFilenameMatch(normalizedFilename, pattern.filenamePatterns);

      if (confidence > bestMatch.confidence) {
        // Look up supplier ID from database
        const supplierId = this.getSupplierIdByName(supplierName);
        if (supplierId) {
          bestMatch = { supplierId, confidence, method: 'filename', supplierName };
        }
      }
    }

    return bestMatch;
  }

  private calculateFilenameMatch(filename: string, patterns: string[]): number {
    let maxScore = 0;

    for (const pattern of patterns) {
      if (filename.includes(pattern)) {
        // Higher score for more specific matches
        const score = pattern.length / filename.length;
        maxScore = Math.max(maxScore, score);
      }
    }

    return Math.min(maxScore * 1.5, 1.0); // Boost filename matches but cap at 1.0
  }
}
```

### 1.3 Data Processing Pipeline

```typescript
// src/lib/batch-processing/DataProcessor.ts
export class DataProcessor {
  async processSupplierFile(
    fileInfo: FileInfo,
    supplierInfo: SupplierDetectionResult,
    batchSessionId: string
  ): Promise<FileProcessingResult> {

    const processingStartTime = Date.now();
    const fileProcessor = new FileProcessingTracker(fileInfo.filename, batchSessionId);

    try {
      // Step 1: Extract and validate file data
      const extractedData = await this.extractFileData(fileInfo);
      await fileProcessor.updateStatus('extracted', { rowCount: extractedData.data.length });

      // Step 2: Apply supplier-specific transformations
      const transformedData = await this.applySupplierTransformations(
        extractedData,
        supplierInfo
      );
      await fileProcessor.updateStatus('transformed', { validRows: transformedData.validRows });

      // Step 3: Validate data quality
      const qualityReport = await this.validateDataQuality(transformedData);
      await fileProcessor.updateStatus('validated', { qualityScore: qualityReport.overallScore });

      // Step 4: Check for conflicts and duplicates
      const conflictAnalysis = await this.analyzeConflicts(transformedData, supplierInfo.supplierId);
      await fileProcessor.updateStatus('conflict_analyzed', { conflicts: conflictAnalysis.totalConflicts });

      // Step 5: Import to database with transaction safety
      const importResult = await this.importToDatabase(
        transformedData,
        supplierInfo,
        conflictAnalysis,
        batchSessionId
      );
      await fileProcessor.updateStatus('imported', importResult);

      // Step 6: Update analytics and caches
      await this.updateSystemAnalytics(supplierInfo.supplierId, importResult);

      const processingTime = Date.now() - processingStartTime;

      return {
        filename: fileInfo.filename,
        supplierId: supplierInfo.supplierId,
        supplierName: supplierInfo.supplierName,
        status: 'completed',
        processingTime,
        recordsProcessed: importResult.totalRecords,
        recordsCreated: importResult.created,
        recordsUpdated: importResult.updated,
        recordsSkipped: importResult.skipped,
        qualityScore: qualityReport.overallScore,
        dataMetrics: {
          totalValue: importResult.totalValue,
          categoriesFound: importResult.categoriesFound,
          brandsCounted: importResult.brandsCounted,
          avgItemCost: importResult.avgItemCost
        }
      };

    } catch (error) {
      await fileProcessor.updateStatus('failed', { error: error.message });

      return {
        filename: fileInfo.filename,
        status: 'failed',
        error: error.message,
        processingTime: Date.now() - processingStartTime
      };
    }
  }

  private async importToDatabase(
    transformedData: TransformedData,
    supplierInfo: SupplierDetectionResult,
    conflictAnalysis: ConflictAnalysis,
    batchSessionId: string
  ): Promise<ImportResult> {
    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Create backup of existing data that will be modified
      const backupId = await this.createDataBackup(client, conflictAnalysis.affectedItems);

      let created = 0, updated = 0, skipped = 0;
      let totalValue = 0;
      const categoriesFound = new Set<string>();
      const brandsCounted = new Set<string>();

      // Process each validated row
      for (const row of transformedData.validRows) {
        try {
          const existingItem = conflictAnalysis.existingItems.get(row.sku);

          if (existingItem) {
            // Update existing item
            const updateResult = await this.updateInventoryItem(client, row, existingItem, supplierInfo);
            if (updateResult.success) {
              updated++;
              totalValue += row.cost_price * row.stock_qty;
            } else {
              skipped++;
            }
          } else {
            // Create new item
            const createResult = await this.createInventoryItem(client, row, supplierInfo);
            if (createResult.success) {
              created++;
              totalValue += row.cost_price * row.stock_qty;

              // Record stock movement
              await this.recordStockMovement(client, createResult.itemId, {
                type: 'initial_stock',
                quantity: row.stock_qty,
                cost: row.cost_price,
                reference: `Batch import: ${batchSessionId}`,
                reason: 'Initial stock from supplier price list'
              });
            } else {
              skipped++;
            }
          }

          // Track categories and brands
          if (row.category) categoriesFound.add(row.category);
          if (row.brand) brandsCounted.add(row.brand);

        } catch (rowError) {
          console.error(`Error processing row ${row.sku}:`, rowError);
          skipped++;
        }
      }

      // Update batch session statistics
      await this.updateBatchSessionStats(client, batchSessionId, {
        recordsCreated: created,
        recordsUpdated: updated,
        recordsSkipped: skipped
      });

      await client.query('COMMIT');

      return {
        totalRecords: transformedData.validRows.length,
        created,
        updated,
        skipped,
        backupId,
        totalValue,
        categoriesFound: categoriesFound.size,
        brandsCounted: brandsCounted.size,
        avgItemCost: totalValue / Math.max(created + updated, 1)
      };

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
```

## 2. Implementation Scripts

### 2.1 Batch Processing Initialization Script

```typescript
// scripts/initialize-batch-processing.ts
import { BatchProcessingEngine } from '@/lib/batch-processing/BatchProcessingEngine';
import { pool } from '@/lib/database/connection';

async function main() {
  const config = {
    maxConcurrentFiles: 4,
    fileProcessingTimeout: 30 * 60 * 1000, // 30 minutes
    retryAttempts: 3,
    qualityThreshold: 0.90, // 90% quality threshold
    requiredFields: ['sku', 'name', 'cost_price', 'category'],
    supplierDetectionMethods: ['filename', 'content', 'pattern'] as const,
    confidenceThreshold: 0.75
  };

  const batchEngine = new BatchProcessingEngine(config);
  const uploadDirectory = 'database/Uploads/drive-download-20250904T012253Z-1-001';

  console.log('🚀 Starting batch processing for all supplier files...');
  console.log(`📂 Processing directory: ${uploadDirectory}`);

  try {
    const result = await batchEngine.processBatch(uploadDirectory);

    console.log('✅ Batch processing completed successfully!');
    console.log('📊 Processing Summary:');
    console.log(`   • Total files: ${result.totalFiles}`);
    console.log(`   • Successfully processed: ${result.successfulFiles}`);
    console.log(`   • Failed files: ${result.failedFiles}`);
    console.log(`   • Total records processed: ${result.totalRecords}`);
    console.log(`   • Records created: ${result.recordsCreated}`);
    console.log(`   • Records updated: ${result.recordsUpdated}`);
    console.log(`   • Processing time: ${result.totalProcessingTime}ms`);
    console.log(`   • Average quality score: ${result.averageQualityScore}%`);

    // Display per-supplier results
    console.log('\n📋 Per-Supplier Results:');
    result.supplierResults.forEach(supplier => {
      console.log(`   ${supplier.supplierName}:`);
      console.log(`     - Files: ${supplier.filesProcessed}`);
      console.log(`     - Products: ${supplier.productsImported}`);
      console.log(`     - Value: R${supplier.totalValue.toLocaleString()}`);
      console.log(`     - Quality: ${supplier.qualityScore}%`);
    });

    // Display any issues found
    if (result.issues.length > 0) {
      console.log('\n⚠️  Issues that require attention:');
      result.issues.forEach(issue => {
        console.log(`   • ${issue.type}: ${issue.description}`);
        if (issue.recommendations.length > 0) {
          console.log(`     Recommendations: ${issue.recommendations.join(', ')}`);
        }
      });
    }

  } catch (error) {
    console.error('❌ Batch processing failed:', error);
    process.exit(1);
  }
}

// Run the batch processing
main().catch(console.error);
```

### 2.2 Database Schema Setup

```sql
-- Execute this SQL to set up batch processing tables
-- scripts/setup-batch-processing-schema.sql

-- Batch processing session tracking
CREATE TABLE IF NOT EXISTS batch_upload_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_name VARCHAR(255) NOT NULL,
    upload_directory TEXT NOT NULL,
    total_files INTEGER DEFAULT 0,
    processed_files INTEGER DEFAULT 0,
    successful_files INTEGER DEFAULT 0,
    failed_files INTEGER DEFAULT 0,

    -- Processing metrics
    total_records_processed INTEGER DEFAULT 0,
    records_created INTEGER DEFAULT 0,
    records_updated INTEGER DEFAULT 0,
    records_skipped INTEGER DEFAULT 0,

    -- Quality metrics
    average_quality_score DECIMAL(5,2) DEFAULT 0,
    validation_errors INTEGER DEFAULT 0,

    -- Performance tracking
    processing_start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processing_end_time TIMESTAMP WITH TIME ZONE,
    total_processing_time_ms BIGINT,

    -- Status and configuration
    status VARCHAR(50) DEFAULT 'initializing', -- initializing, processing, completed, failed, cancelled
    configuration JSONB,

    -- Error and issue tracking
    error_summary JSONB,
    issues_found JSONB,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- File-level processing tracking
CREATE TABLE IF NOT EXISTS file_processing_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_session_id UUID NOT NULL REFERENCES batch_upload_sessions(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT,
    file_hash VARCHAR(64),

    -- Supplier detection results
    detected_supplier_id UUID REFERENCES suppliers(id),
    supplier_detection_confidence DECIMAL(5,2),
    supplier_detection_method VARCHAR(50),
    supplier_name VARCHAR(255),

    -- Processing status and metrics
    status VARCHAR(50) DEFAULT 'pending', -- pending, processing, completed, failed, skipped
    processing_attempts INTEGER DEFAULT 0,
    processing_start_time TIMESTAMP WITH TIME ZONE,
    processing_end_time TIMESTAMP WITH TIME ZONE,
    processing_time_ms BIGINT,

    -- Data metrics
    total_rows_found INTEGER DEFAULT 0,
    header_row_detected INTEGER,
    valid_data_rows INTEGER DEFAULT 0,
    records_created INTEGER DEFAULT 0,
    records_updated INTEGER DEFAULT 0,
    records_skipped INTEGER DEFAULT 0,

    -- Quality and validation
    data_quality_score DECIMAL(5,2) DEFAULT 0,
    validation_issues JSONB,
    transformation_applied JSONB,
    auto_fixes_count INTEGER DEFAULT 0,

    -- Financial metrics
    total_value_processed DECIMAL(15,2) DEFAULT 0,
    categories_found INTEGER DEFAULT 0,
    brands_found INTEGER DEFAULT 0,
    average_item_cost DECIMAL(15,2) DEFAULT 0,

    -- Error handling
    last_error TEXT,
    error_details JSONB,
    retry_scheduled_for TIMESTAMP WITH TIME ZONE,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Data backup tracking for rollback capability
CREATE TABLE IF NOT EXISTS batch_processing_backups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_session_id UUID NOT NULL REFERENCES batch_upload_sessions(id),
    backup_type VARCHAR(50) NOT NULL, -- full_backup, incremental, affected_records

    -- Backup scope
    affected_tables TEXT[] NOT NULL,
    affected_supplier_ids UUID[],
    affected_record_count INTEGER DEFAULT 0,

    -- Backup data
    backup_data JSONB NOT NULL,
    backup_metadata JSONB,

    -- Backup management
    backup_size_bytes BIGINT,
    compression_used BOOLEAN DEFAULT false,
    retention_until TIMESTAMP WITH TIME ZONE,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Supplier-specific processing configurations
CREATE TABLE IF NOT EXISTS supplier_processing_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_id UUID NOT NULL REFERENCES suppliers(id),

    -- Detection patterns
    filename_patterns TEXT[] DEFAULT '{}',
    header_patterns TEXT[] DEFAULT '{}',
    data_patterns TEXT[] DEFAULT '{}',
    price_column_patterns TEXT[] DEFAULT '{}',
    category_patterns TEXT[] DEFAULT '{}',

    -- Processing rules
    field_mappings JSONB NOT NULL DEFAULT '{}',
    transformation_rules JSONB DEFAULT '{}',
    validation_rules JSONB DEFAULT '{}',
    default_values JSONB DEFAULT '{}',

    -- Conflict resolution
    conflict_resolution_strategy VARCHAR(50) DEFAULT 'merge', -- skip, update, merge, create_variant
    update_fields TEXT[] DEFAULT '{}',
    preserve_fields TEXT[] DEFAULT '{}',

    -- Quality settings
    minimum_quality_threshold DECIMAL(5,2) DEFAULT 0.90,
    required_fields TEXT[] DEFAULT '{}',
    optional_fields TEXT[] DEFAULT '{}',

    -- Performance settings
    batch_size INTEGER DEFAULT 1000,
    processing_priority INTEGER DEFAULT 5, -- 1-10 scale

    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(supplier_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_batch_sessions_status ON batch_upload_sessions(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_file_processing_batch ON file_processing_status(batch_session_id, status);
CREATE INDEX IF NOT EXISTS idx_file_processing_supplier ON file_processing_status(detected_supplier_id, status);
CREATE INDEX IF NOT EXISTS idx_batch_backups_session ON batch_processing_backups(batch_session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_supplier_configs_active ON supplier_processing_configs(supplier_id) WHERE active = true;
```

### 2.3 Quality Assurance Script

```typescript
// scripts/validate-batch-results.ts
import { pool } from '@/lib/database/connection';

interface ValidationResult {
  passed: boolean;
  issues: ValidationIssue[];
  metrics: ValidationMetrics;
}

interface ValidationIssue {
  severity: 'error' | 'warning' | 'info';
  category: string;
  description: string;
  affectedRecords: number;
  recommendations: string[];
}

class BatchResultValidator {
  async validateBatchProcessing(batchSessionId: string): Promise<ValidationResult> {
    console.log('🔍 Starting batch processing validation...');

    const validations = [
      this.validateDataIntegrity(batchSessionId),
      this.validateSupplierRelationships(batchSessionId),
      this.validatePriceConsistency(batchSessionId),
      this.validateInventoryConsistency(batchSessionId),
      this.validateDataCompleteness(batchSessionId),
      this.checkForDuplicates(batchSessionId),
      this.validateBusinessRules(batchSessionId)
    ];

    const results = await Promise.all(validations);
    const allIssues = results.flatMap(r => r.issues);
    const overallPassed = allIssues.filter(i => i.severity === 'error').length === 0;

    const metrics = await this.calculateValidationMetrics(batchSessionId);

    return {
      passed: overallPassed,
      issues: allIssues,
      metrics
    };
  }

  private async validateDataIntegrity(batchSessionId: string): Promise<{ issues: ValidationIssue[] }> {
    const issues: ValidationIssue[] = [];

    // Check for missing required fields
    const missingFieldsQuery = `
      SELECT
        COUNT(*) as count,
        supplier_id
      FROM inventory_items
      WHERE (sku IS NULL OR sku = '' OR
             name IS NULL OR name = '' OR
             cost_price IS NULL OR cost_price <= 0)
        AND updated_at > (
          SELECT processing_start_time
          FROM batch_upload_sessions
          WHERE id = $1
        )
      GROUP BY supplier_id
    `;

    const missingFieldsResult = await pool.query(missingFieldsQuery, [batchSessionId]);

    if (missingFieldsResult.rows.length > 0) {
      issues.push({
        severity: 'error',
        category: 'data_integrity',
        description: 'Required fields are missing or invalid',
        affectedRecords: missingFieldsResult.rows.reduce((sum, row) => sum + parseInt(row.count), 0),
        recommendations: [
          'Review data mapping for affected suppliers',
          'Implement stricter validation rules',
          'Check source data quality'
        ]
      });
    }

    return { issues };
  }

  private async validateSupplierRelationships(batchSessionId: string): Promise<{ issues: ValidationIssue[] }> {
    const issues: ValidationIssue[] = [];

    // Check for orphaned inventory items (invalid supplier references)
    const orphanedItemsQuery = `
      SELECT COUNT(*) as count
      FROM inventory_items ii
      LEFT JOIN suppliers s ON ii.supplier_id = s.id
      WHERE s.id IS NULL
        AND ii.updated_at > (
          SELECT processing_start_time
          FROM batch_upload_sessions
          WHERE id = $1
        )
    `;

    const orphanedResult = await pool.query(orphanedItemsQuery, [batchSessionId]);
    const orphanedCount = parseInt(orphanedResult.rows[0].count);

    if (orphanedCount > 0) {
      issues.push({
        severity: 'error',
        category: 'referential_integrity',
        description: `Found ${orphanedCount} inventory items with invalid supplier references`,
        affectedRecords: orphanedCount,
        recommendations: [
          'Verify supplier detection accuracy',
          'Review supplier ID assignment logic',
          'Check supplier database consistency'
        ]
      });
    }

    return { issues };
  }
}

// Usage script
async function validateBatchResults(batchSessionId: string) {
  const validator = new BatchResultValidator();

  try {
    const result = await validator.validateBatchProcessing(batchSessionId);

    if (result.passed) {
      console.log('✅ Batch processing validation PASSED');
    } else {
      console.log('❌ Batch processing validation FAILED');
    }

    console.log('\n📊 Validation Metrics:');
    console.log(`   Total Records Validated: ${result.metrics.totalRecordsValidated}`);
    console.log(`   Data Integrity Score: ${result.metrics.dataIntegrityScore}%`);
    console.log(`   Supplier Relationship Accuracy: ${result.metrics.supplierAccuracy}%`);
    console.log(`   Price Data Consistency: ${result.metrics.priceConsistency}%`);

    if (result.issues.length > 0) {
      console.log('\n⚠️  Issues Found:');
      result.issues.forEach((issue, index) => {
        console.log(`\n${index + 1}. ${issue.category.toUpperCase()} - ${issue.severity.toUpperCase()}`);
        console.log(`   Description: ${issue.description}`);
        console.log(`   Affected Records: ${issue.affectedRecords}`);
        console.log(`   Recommendations:`);
        issue.recommendations.forEach(rec => console.log(`     • ${rec}`));
      });
    }

  } catch (error) {
    console.error('❌ Validation failed:', error);
  }
}
```

## 3. Monitoring and Alerting

### 3.1 Real-time Processing Monitor

```typescript
// src/components/admin/BatchProcessingMonitor.tsx
export function BatchProcessingMonitor() {
  const [batchSessions, setBatchSessions] = useState<BatchSession[]>([]);
  const [currentSession, setCurrentSession] = useState<BatchSession | null>(null);
  const [realTimeStats, setRealTimeStats] = useState<ProcessingStats>({});

  useEffect(() => {
    // Set up WebSocket connection for real-time updates
    const ws = new WebSocket(`ws://localhost:3000/api/batch-processing/monitor`);

    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);

      switch (update.type) {
        case 'session_update':
          setBatchSessions(prev =>
            prev.map(session =>
              session.id === update.sessionId
                ? { ...session, ...update.data }
                : session
            )
          );
          break;

        case 'file_update':
          setRealTimeStats(prev => ({
            ...prev,
            [update.sessionId]: {
              ...prev[update.sessionId],
              filesProcessed: update.filesProcessed,
              currentFile: update.currentFile,
              progress: update.progress
            }
          }));
          break;
      }
    };

    return () => ws.close();
  }, []);

  return (
    <div className="batch-processing-monitor">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-time Overview */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Processing Overview</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Active Sessions:</span>
              <span className="font-mono">{batchSessions.filter(s => s.status === 'processing').length}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Files:</span>
              <span className="font-mono">{batchSessions.reduce((sum, s) => sum + s.totalFiles, 0)}</span>
            </div>
            <div className="flex justify-between">
              <span>Completed:</span>
              <span className="font-mono text-green-600">
                {batchSessions.reduce((sum, s) => sum + s.processedFiles, 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Failed:</span>
              <span className="font-mono text-red-600">
                {batchSessions.reduce((sum, s) => sum + s.failedFiles, 0)}
              </span>
            </div>
          </div>
        </div>

        {/* Current Processing Status */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Current Processing</h3>
          {currentSession ? (
            <div className="space-y-3">
              <div className="text-sm text-gray-600">
                Session: {currentSession.sessionName}
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(currentSession.processedFiles / currentSession.totalFiles) * 100}%` }}
                />
              </div>
              <div className="text-sm">
                {currentSession.processedFiles} / {currentSession.totalFiles} files
              </div>
              {realTimeStats[currentSession.id]?.currentFile && (
                <div className="text-xs text-gray-500">
                  Processing: {realTimeStats[currentSession.id].currentFile}
                </div>
              )}
            </div>
          ) : (
            <div className="text-gray-500">No active processing sessions</div>
          )}
        </div>

        {/* Quality Metrics */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Quality Metrics</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Avg Quality Score:</span>
              <span className="font-mono">
                {batchSessions.length > 0
                  ? (batchSessions.reduce((sum, s) => sum + (s.averageQualityScore || 0), 0) / batchSessions.length).toFixed(1)
                  : '0.0'
                }%
              </span>
            </div>
            <div className="flex justify-between">
              <span>Records Created:</span>
              <span className="font-mono text-green-600">
                {batchSessions.reduce((sum, s) => sum + s.recordsCreated, 0).toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Records Updated:</span>
              <span className="font-mono text-blue-600">
                {batchSessions.reduce((sum, s) => sum + s.recordsUpdated, 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Session History */}
      <div className="mt-8 bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold">Processing Sessions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Session
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Progress
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Quality
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Duration
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {batchSessions.map((session) => (
                <tr key={session.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {session.sessionName}
                    </div>
                    <div className="text-sm text-gray-500">
                      {session.totalFiles} files
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusBadge status={session.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{
                            width: `${(session.processedFiles / session.totalFiles) * 100}%`
                          }}
                        />
                      </div>
                      <span className="text-sm text-gray-600">
                        {Math.round((session.processedFiles / session.totalFiles) * 100)}%
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {session.averageQualityScore?.toFixed(1) || 'N/A'}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {session.totalProcessingTimeMs
                      ? `${Math.round(session.totalProcessingTimeMs / 1000)}s`
                      : 'In progress'
                    }
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => setCurrentSession(session)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
```

This implementation provides a comprehensive automated batch processing system that can handle all 28 supplier price list files efficiently, with robust error handling, quality assurance, and real-time monitoring capabilities. The system ensures data consistency and provides detailed feedback on the processing results.