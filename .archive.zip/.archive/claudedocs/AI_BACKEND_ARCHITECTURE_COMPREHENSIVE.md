# AI SUPPLIER BACKEND ARCHITECTURE - COMPREHENSIVE DESIGN

## Executive Summary

This document outlines the comprehensive backend architecture for AI-powered supplier management APIs and services. The architecture emphasizes reliability, data integrity, and intelligent automation while maintaining strict security and performance standards.

---

## IMMEDIATE FIXES COMPLETED ✅

### Database Schema Issues
- **FIXED**: Added missing `currency` column to suppliers table
- **VALIDATED**: All critical columns for analytics APIs are present
- **TESTED**: Recommendations API now working correctly

### API Status Check
- ✅ Dashboard API - Working
- ✅ Anomalies API - Working
- ✅ Predictions API - Working
- ✅ Recommendations API - **NOW WORKING** (currency column added)

---

## CORE BACKEND ARCHITECTURE

### 1. Service Layer Architecture

```typescript
// Service Layer Structure
src/
├── services/
│   ├── ai/
│   │   ├── SupplierIntelligenceService.ts
│   │   ├── PredictiveAnalyticsService.ts
│   │   ├── RecommendationEngine.ts
│   │   ├── AnomalyDetectionService.ts
│   │   └── NLPProcessingService.ts
│   ├── analytics/
│   │   ├── PerformanceAnalyticsService.ts
│   │   ├── RiskAssessmentService.ts
│   │   ├── SpendAnalyticsService.ts
│   │   └── MarketIntelligenceService.ts
│   ├── data/
│   │   ├── SupplierDataService.ts
│   │   ├── InventoryDataService.ts
│   │   ├── ContractDataService.ts
│   │   └── TransactionDataService.ts
│   └── integration/
│       ├── ExternalAIService.ts
│       ├── WebhookService.ts
│       └── QueueService.ts
```

### 2. Repository Pattern Implementation

```typescript
// Base Repository Interface
interface BaseRepository<T> {
  findById(id: string): Promise<T | null>;
  findMany(filters: Record<string, any>): Promise<T[]>;
  create(data: Partial<T>): Promise<T>;
  update(id: string, data: Partial<T>): Promise<T>;
  delete(id: string): Promise<boolean>;
  count(filters?: Record<string, any>): Promise<number>;
}

// AI-Specific Repository Methods
interface AISupplierRepository extends BaseRepository<Supplier> {
  findSimilarSuppliers(criteria: SupplierCriteria): Promise<Supplier[]>;
  getPerformanceMetrics(supplierId: string, period: DateRange): Promise<PerformanceMetrics>;
  getRiskIndicators(supplierId: string): Promise<RiskIndicator[]>;
  getAIInsights(supplierId: string): Promise<AIInsight[]>;
}
```

### 3. Database Integration Layer

```typescript
// Enhanced Database Connection with AI Optimizations
export class DatabaseService {
  private pool: Pool;
  private vectorStore: VectorDatabase; // For AI similarity searches
  private cache: RedisCache; // For AI insights caching

  // AI-optimized queries with connection pooling
  async executeAIQuery<T>(
    query: string,
    params: any[],
    options: {
      useCache?: boolean;
      cacheKey?: string;
      cacheTTL?: number;
      vectorSearch?: boolean;
    }
  ): Promise<T> {
    // Implementation with connection pooling and caching
  }

  // Transaction support for AI batch processing
  async withAITransaction<T>(
    callback: (client: PoolClient) => Promise<T>
  ): Promise<T> {
    // Enhanced transaction handling for AI operations
  }
}
```

---

## AI-POWERED API ENDPOINTS

### 1. AI Supplier Discovery API

```typescript
// POST /api/ai/suppliers/discover
interface SupplierDiscoveryRequest {
  query: string; // Natural language query
  requirements: {
    category: string[];
    location?: string[];
    certifications?: string[];
    capacity?: {
      min: number;
      max: number;
    };
    priceRange?: {
      min: number;
      max: number;
    };
  };
  filters?: {
    existingSuppliers?: boolean;
    verified?: boolean;
    riskLevel?: 'low' | 'medium' | 'high';
  };
}

interface SupplierDiscoveryResponse {
  suppliers: Array<{
    id: string;
    name: string;
    matchScore: number; // 0-1
    category: string;
    location: string;
    capabilities: string[];
    riskScore: number;
    estimatedPricing: {
      min: number;
      max: number;
      currency: string;
    };
    aiInsights: {
      strengths: string[];
      concerns: string[];
      recommendations: string[];
    };
  }>;
  searchMetadata: {
    queryProcessed: string;
    totalResults: number;
    searchTime: number;
    confidence: number;
  };
}
```

### 2. Advanced Analytics API Layer

```typescript
// GET /api/ai/analytics/predictive
interface PredictiveAnalyticsRequest {
  supplierId?: string;
  category?: string;
  timeHorizon: '3months' | '6months' | '1year' | '2years';
  metrics: Array<'cost' | 'performance' | 'risk' | 'demand' | 'availability'>;
}

interface PredictiveAnalyticsResponse {
  predictions: Array<{
    metric: string;
    currentValue: number;
    predictedValues: Array<{
      date: string;
      value: number;
      confidence: number;
      factors: string[];
    }>;
    trends: {
      direction: 'increasing' | 'decreasing' | 'stable';
      strength: 'weak' | 'moderate' | 'strong';
      volatility: number;
    };
    recommendations: string[];
  }>;
  modelInfo: {
    accuracy: number;
    lastTraining: string;
    dataPoints: number;
  };
}

// POST /api/ai/analytics/anomalies/detect
interface AnomalyDetectionRequest {
  entityType: 'supplier' | 'order' | 'payment' | 'performance';
  entityId?: string;
  timeRange: {
    start: string;
    end: string;
  };
  sensitivity: 'low' | 'medium' | 'high';
  metrics: string[];
}

interface AnomalyDetectionResponse {
  anomalies: Array<{
    id: string;
    type: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    affectedMetric: string;
    detectedAt: string;
    actualValue: number;
    expectedValue: number;
    deviation: number;
    confidence: number;
    possibleCauses: string[];
    recommendedActions: string[];
    context: {
      entityType: string;
      entityId: string;
      relatedEntities: Array<{
        type: string;
        id: string;
        name: string;
      }>;
    };
  }>;
  summary: {
    totalAnomalies: number;
    criticalCount: number;
    newAnomalies: number;
    resolvedAnomalies: number;
  };
}
```

### 3. AI Insights and Recommendations API

```typescript
// POST /api/ai/insights/generate
interface InsightsGenerationRequest {
  context: {
    type: 'supplier' | 'category' | 'portfolio' | 'contract';
    id?: string;
  };
  focusAreas: Array<'cost' | 'risk' | 'performance' | 'sustainability' | 'innovation'>;
  timeFrame: {
    start: string;
    end: string;
  };
  includeActions: boolean;
}

interface InsightsGenerationResponse {
  insights: Array<{
    id: string;
    type: 'opportunity' | 'risk' | 'trend' | 'benchmark' | 'prediction';
    title: string;
    description: string;
    impact: {
      score: number; // 0-10
      type: 'cost_savings' | 'risk_reduction' | 'efficiency_gain' | 'quality_improvement';
      estimatedValue?: {
        amount: number;
        currency: string;
        timeframe: string;
      };
    };
    confidence: number;
    evidence: string[];
    relatedEntities: Array<{
      type: string;
      id: string;
      name: string;
    }>;
    actionItems?: Array<{
      action: string;
      priority: 'low' | 'medium' | 'high';
      effort: 'low' | 'medium' | 'high';
      timeframe: string;
    }>;
  }>;
  summary: {
    totalInsights: number;
    opportunityCount: number;
    riskCount: number;
    potentialSavings: number;
  };
}

// POST /api/ai/recommendations/contextual
interface ContextualRecommendationRequest {
  query: string; // Natural language query
  context: {
    userId: string;
    currentPage?: string;
    filters?: Record<string, any>;
    recentActions?: Array<{
      type: string;
      entityId: string;
      timestamp: string;
    }>;
  };
  maxResults?: number;
}

interface ContextualRecommendationResponse {
  recommendations: Array<{
    id: string;
    type: 'action' | 'supplier' | 'contract' | 'optimization' | 'alert';
    title: string;
    description: string;
    reasoning: string;
    relevanceScore: number;
    urgency: 'low' | 'medium' | 'high';
    category: string;
    actionUrl?: string;
    parameters?: Record<string, any>;
  }>;
  queryUnderstanding: {
    intent: string;
    entities: Array<{
      type: string;
      value: string;
      confidence: number;
    }>;
    clarification?: string;
  };
}
```

### 4. AI Processing Pipeline APIs

```typescript
// POST /api/ai/jobs/create
interface AIJobRequest {
  type: 'supplier_analysis' | 'market_research' | 'risk_assessment' | 'optimization' | 'forecasting';
  parameters: {
    entityIds?: string[];
    filters?: Record<string, any>;
    options?: Record<string, any>;
  };
  priority: 'low' | 'medium' | 'high';
  schedule?: {
    executeAt?: string;
    recurring?: {
      frequency: 'daily' | 'weekly' | 'monthly';
      interval: number;
    };
  };
}

interface AIJobResponse {
  jobId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  estimatedDuration: number;
  progress?: {
    current: number;
    total: number;
    stage: string;
  };
}

// GET /api/ai/jobs/{jobId}/status
interface AIJobStatus {
  id: string;
  type: string;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';
  progress: {
    current: number;
    total: number;
    stage: string;
    message?: string;
  };
  result?: {
    data: any;
    insights: any[];
    recommendations: any[];
  };
  error?: {
    message: string;
    code: string;
    details?: any;
  };
  timing: {
    createdAt: string;
    startedAt?: string;
    completedAt?: string;
    duration?: number;
  };
}

// WebSocket: /api/ai/jobs/subscribe
interface AIJobWebSocketMessage {
  type: 'job_started' | 'job_progress' | 'job_completed' | 'job_failed';
  jobId: string;
  payload: {
    progress?: number;
    stage?: string;
    result?: any;
    error?: any;
  };
}
```

---

## ERROR HANDLING AND VALIDATION FRAMEWORKS

### 1. Comprehensive Error Handling

```typescript
// Custom Error Classes for AI Operations
export class AIServiceError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500,
    public context?: Record<string, any>
  ) {
    super(message);
    this.name = 'AIServiceError';
  }
}

export class ValidationError extends AIServiceError {
  constructor(message: string, public field?: string, public value?: any) {
    super(message, 'VALIDATION_ERROR', 400, { field, value });
    this.name = 'ValidationError';
  }
}

export class ModelError extends AIServiceError {
  constructor(message: string, public modelId?: string) {
    super(message, 'MODEL_ERROR', 503, { modelId });
    this.name = 'ModelError';
  }
}

// Global Error Handler Middleware
export function errorHandler(error: Error, req: Request, res: Response, next: NextFunction) {
  console.error('API Error:', {
    error: error.message,
    stack: error.stack,
    path: req.path,
    method: req.method,
    timestamp: new Date().toISOString()
  });

  if (error instanceof ValidationError) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      message: error.message,
      field: error.field,
      code: error.code
    });
  }

  if (error instanceof ModelError) {
    return res.status(503).json({
      success: false,
      error: 'AI service temporarily unavailable',
      message: error.message,
      code: error.code,
      retryAfter: 60
    });
  }

  if (error instanceof AIServiceError) {
    return res.status(error.statusCode).json({
      success: false,
      error: error.message,
      code: error.code,
      context: error.context
    });
  }

  // Fallback for unknown errors
  return res.status(500).json({
    success: false,
    error: 'Internal server error',
    code: 'INTERNAL_ERROR'
  });
}
```

### 2. Request Validation Framework

```typescript
// AI-Specific Validation Schemas
export const validationSchemas = {
  supplierDiscovery: {
    query: {
      required: true,
      type: 'string',
      minLength: 3,
      maxLength: 500
    },
    requirements: {
      required: true,
      type: 'object',
      properties: {
        category: {
          type: 'array',
          items: { type: 'string' },
          minItems: 1
        },
        location: {
          type: 'array',
          items: { type: 'string' }
        },
        capacity: {
          type: 'object',
          properties: {
            min: { type: 'number', minimum: 0 },
            max: { type: 'number', minimum: 0 }
          }
        }
      }
    }
  },

  predictiveAnalytics: {
    timeHorizon: {
      required: true,
      type: 'string',
      enum: ['3months', '6months', '1year', '2years']
    },
    metrics: {
      required: true,
      type: 'array',
      items: {
        type: 'string',
        enum: ['cost', 'performance', 'risk', 'demand', 'availability']
      },
      minItems: 1
    }
  }
};

// Validation Middleware
export function validateRequest(schema: any) {
  return (req: Request, res: Response, next: NextFunction) => {
    const errors = validateAgainstSchema(req.body, schema);

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errors
      });
    }

    next();
  };
}
```

---

## AUTHENTICATION AND AUTHORIZATION

### 1. AI Endpoint Security

```typescript
// AI-Specific Permission System
export enum AIPermission {
  AI_SUPPLIER_DISCOVER = 'ai:supplier:discover',
  AI_ANALYTICS_VIEW = 'ai:analytics:view',
  AI_INSIGHTS_GENERATE = 'ai:insights:generate',
  AI_RECOMMENDATIONS_ACCESS = 'ai:recommendations:access',
  AI_JOBS_CREATE = 'ai:jobs:create',
  AI_JOBS_MONITOR = 'ai:jobs:monitor',
  AI_ADMIN = 'ai:admin'
}

// Role-Based Access Control for AI Features
export const aiRolePermissions = {
  ai_analyst: [
    AIPermission.AI_SUPPLIER_DISCOVER,
    AIPermission.AI_ANALYTICS_VIEW,
    AIPermission.AI_INSIGHTS_GENERATE,
    AIPermission.AI_RECOMMENDATIONS_ACCESS
  ],
  ai_manager: [
    ...aiRolePermissions.ai_analyst,
    AIPermission.AI_JOBS_CREATE,
    AIPermission.AI_JOBS_MONITOR
  ],
  ai_admin: Object.values(AIPermission)
};

// Authentication Middleware for AI Endpoints
export function requireAIPermission(permission: AIPermission) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const user = req.user;

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
        code: 'UNAUTHORIZED'
      });
    }

    const hasPermission = await checkUserPermission(user.id, permission);

    if (!hasPermission) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions for AI operation',
        code: 'FORBIDDEN',
        requiredPermission: permission
      });
    }

    next();
  };
}
```

### 2. Rate Limiting for AI Endpoints

```typescript
// AI-Specific Rate Limiting
export const aiRateLimits = {
  discovery: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // 10 requests per window
    message: 'Too many supplier discovery requests'
  },
  analytics: {
    windowMs: 5 * 60 * 1000, // 5 minutes
    max: 20, // 20 requests per window
    message: 'Too many analytics requests'
  },
  insights: {
    windowMs: 10 * 60 * 1000, // 10 minutes
    max: 15, // 15 requests per window
    message: 'Too many insight generation requests'
  },
  jobs: {
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 5, // 5 job creation requests per hour
    message: 'Too many AI job creation requests'
  }
};
```

---

## PERFORMANCE OPTIMIZATION STRATEGIES

### 1. Caching Layer for AI Operations

```typescript
// AI Insights Caching Strategy
export class AICacheService {
  private redis: Redis;

  async cacheInsight(key: string, data: any, ttl: number = 3600): Promise<void> {
    await this.redis.setex(key, ttl, JSON.stringify(data));
  }

  async getCachedInsight<T>(key: string): Promise<T | null> {
    const cached = await this.redis.get(key);
    return cached ? JSON.parse(cached) : null;
  }

  // Smart cache invalidation for AI results
  async invalidateRelatedCache(entityType: string, entityId: string): Promise<void> {
    const pattern = `ai:*:${entityType}:${entityId}*`;
    const keys = await this.redis.keys(pattern);
    if (keys.length > 0) {
      await this.redis.del(...keys);
    }
  }
}
```

### 2. Database Query Optimization

```typescript
// Optimized Queries for AI Operations
export class AIQueryOptimizer {
  // Vector similarity search optimization
  static buildSimilarityQuery(entityType: string, criteria: any): string {
    return `
      WITH similarity_scores AS (
        SELECT
          id,
          name,
          (embedding <-> $1::vector) as distance,
          1 - (embedding <-> $1::vector) as similarity_score
        FROM ${entityType}_embeddings
        WHERE similarity_score > $2
      )
      SELECT
        s.*,
        ss.similarity_score
      FROM ${entityType}s s
      JOIN similarity_scores ss ON s.id = ss.id
      ORDER BY ss.similarity_score DESC
      LIMIT $3
    `;
  }

  // Performance analytics optimization with window functions
  static buildPerformanceQuery(supplierId: string, metrics: string[]): string {
    const metricColumns = metrics.map(metric =>
      `AVG(${metric}) OVER (ORDER BY date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) as ${metric}_ma30`
    ).join(', ');

    return `
      WITH daily_metrics AS (
        SELECT
          date,
          supplier_id,
          ${metrics.join(', ')},
          ${metricColumns}
        FROM supplier_performance_daily
        WHERE supplier_id = $1
          AND date >= CURRENT_DATE - INTERVAL '90 days'
      )
      SELECT * FROM daily_metrics
      ORDER BY date DESC
    `;
  }
}
```

### 3. Connection Pool Optimization

```typescript
// AI-Optimized Database Pool Configuration
export const aiDatabaseConfig = {
  ...dbConfig,
  // Increased pool size for AI operations
  max: 25,
  min: 5,

  // Longer timeouts for complex AI queries
  acquireTimeoutMillis: 30000,
  query_timeout: 60000,

  // Prepared statement cache for repeated AI queries
  prepared_statement_cache: true,
  max_prepared_statements: 100,

  // Connection optimization for vector operations
  application_name: "MantisNXT_AI",
  statement_timeout: 60000
};
```

---

## MONITORING AND OBSERVABILITY

### 1. AI Operations Monitoring

```typescript
// AI Metrics Collection
export interface AIMetrics {
  requests: {
    total: number;
    successful: number;
    failed: number;
    avgResponseTime: number;
  };
  models: {
    [modelId: string]: {
      accuracy: number;
      lastUpdate: Date;
      usage: number;
    };
  };
  jobs: {
    queued: number;
    processing: number;
    completed: number;
    failed: number;
  };
  cache: {
    hitRate: number;
    missRate: number;
    evictions: number;
  };
}

// Monitoring Middleware
export function aiMetricsMiddleware(req: Request, res: Response, next: NextFunction) {
  const startTime = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const endpoint = req.path;

    // Record metrics
    metricsCollector.recordAPICall(endpoint, res.statusCode, duration);
  });

  next();
}
```

### 2. Health Check Endpoints

```typescript
// GET /api/health/ai
export async function aiHealthCheck(): Promise<HealthStatus> {
  const checks = await Promise.allSettled([
    checkDatabaseConnection(),
    checkAIModelAvailability(),
    checkCacheConnection(),
    checkQueueHealth()
  ]);

  const status = checks.every(check => check.status === 'fulfilled') ? 'healthy' : 'degraded';

  return {
    status,
    timestamp: new Date().toISOString(),
    services: {
      database: checks[0].status === 'fulfilled',
      aiModels: checks[1].status === 'fulfilled',
      cache: checks[2].status === 'fulfilled',
      queue: checks[3].status === 'fulfilled'
    },
    metrics: await getAIMetrics()
  };
}
```

---

## DEPLOYMENT AND SCALING STRATEGY

### 1. Microservices Architecture

```
AI Backend Services:
├── ai-gateway-service (API Gateway & Auth)
├── supplier-intelligence-service (Core AI Logic)
├── analytics-service (Predictive Analytics)
├── recommendation-engine-service (ML Recommendations)
├── nlp-processing-service (Natural Language Processing)
├── job-processor-service (Background AI Jobs)
└── monitoring-service (Metrics & Health)
```

### 2. Container Configuration

```dockerfile
# Dockerfile.ai-service
FROM node:18-alpine

# AI-specific dependencies
RUN apk add --no-cache python3 py3-pip
RUN pip3 install numpy pandas scikit-learn

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .

# Health check for AI services
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
  CMD curl -f http://localhost:3000/health/ai || exit 1

EXPOSE 3000
CMD ["npm", "run", "start:ai"]
```

---

## INTEGRATION POINTS

### 1. External AI Services Integration

```typescript
// External AI Service Adapter Pattern
export interface ExternalAIProvider {
  name: string;
  generateEmbeddings(text: string): Promise<number[]>;
  analyzeText(text: string): Promise<TextAnalysis>;
  predictValues(data: number[][]): Promise<PredictionResult>;
}

export class OpenAIProvider implements ExternalAIProvider {
  name = 'OpenAI';

  async generateEmbeddings(text: string): Promise<number[]> {
    // OpenAI embeddings implementation
  }

  async analyzeText(text: string): Promise<TextAnalysis> {
    // OpenAI text analysis implementation
  }
}

export class AWSBedrockProvider implements ExternalAIProvider {
  name = 'AWS Bedrock';
  // AWS Bedrock implementation
}
```

### 2. Webhook Integration

```typescript
// AI Event Webhooks
export interface AIWebhookEvent {
  type: 'insight_generated' | 'anomaly_detected' | 'recommendation_ready' | 'analysis_complete';
  data: any;
  timestamp: string;
  confidence?: number;
}

export class WebhookService {
  async sendAIEvent(event: AIWebhookEvent, endpoints: string[]): Promise<void> {
    const promises = endpoints.map(endpoint =>
      this.sendWebhook(endpoint, event)
    );

    await Promise.allSettled(promises);
  }
}
```

---

## CONCLUSION

This comprehensive AI backend architecture provides:

1. **Immediate Stability**: Fixed database schema issues for analytics APIs
2. **Scalable AI Services**: Microservices architecture for AI operations
3. **Robust Error Handling**: Comprehensive error management and validation
4. **Security First**: RBAC and rate limiting for AI endpoints
5. **Performance Optimized**: Caching, connection pooling, and query optimization
6. **Observable**: Full monitoring and health check capabilities
7. **Extensible**: Plugin architecture for external AI services

The architecture supports both current operational needs and future AI feature expansion while maintaining enterprise-grade reliability and security standards.