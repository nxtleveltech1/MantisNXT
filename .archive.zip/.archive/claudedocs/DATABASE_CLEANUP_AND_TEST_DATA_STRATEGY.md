# DATABASE CLEANUP & 22-SUPPLIER TEST DATASET STRATEGY
## Complete Database Cleansing and Test Data Generation Plan

**Generated:** 2025-09-30
**Purpose:** Remove duplicate suppliers, clean slate database, create 22 complete end-to-end test datasets
**Status:** Ready for Execution (Review Required)

---

## EXECUTIVE SUMMARY

### Current State Analysis
- **Total Suppliers**: Unknown (duplicates exist)
- **Database Schema**: PostgreSQL-based with comprehensive relationships
- **Critical Tables**: supplier, inventory_item, purchase_order, purchase_order_item, invoices (extended schemas)
- **Foreign Key Dependencies**: Multi-level cascading relationships
- **Existing Scripts**: Partial cleanup and generation scripts available

### Strategy Overview
1. **Phase 1**: Comprehensive schema analysis and dependency mapping
2. **Phase 2**: Safe duplicate supplier detection and resolution
3. **Phase 3**: Complete data cleanup with backup strategy
4. **Phase 4**: 22 end-to-end test datasets generation
5. **Phase 5**: Validation and integrity verification

### Success Criteria
- ✅ Zero duplicate suppliers
- ✅ Complete clean slate (all test data removed)
- ✅ 22 suppliers with complete transactional history
- ✅ 100% referential integrity maintained
- ✅ Inventory visible at all locations
- ✅ All business workflows represented

---

## 1. DATABASE SCHEMA ANALYSIS

### Core Tables Identified

#### Primary Entities
```sql
-- Organization (Root entity)
CREATE TABLE organization (
    id uuid PRIMARY KEY,
    name text NOT NULL,
    slug text UNIQUE NOT NULL,
    plan_type organization_plan,
    ...
);

-- Supplier (Target for cleanup)
CREATE TABLE supplier (
    id uuid PRIMARY KEY,
    org_id uuid REFERENCES organization(id) ON DELETE CASCADE,
    name text NOT NULL,
    contact_email text,
    contact_phone text,
    address jsonb,
    risk_score integer DEFAULT 50,
    status supplier_status DEFAULT 'pending_approval',
    payment_terms text,
    lead_time_days integer DEFAULT 0,
    certifications text[],
    notes text,
    created_at timestamptz,
    updated_at timestamptz
);

-- Inventory Item (Direct FK to supplier)
CREATE TABLE inventory_item (
    id uuid PRIMARY KEY,
    org_id uuid REFERENCES organization(id) ON DELETE CASCADE,
    sku text NOT NULL,
    name text NOT NULL,
    category inventory_category NOT NULL,
    unit_price numeric(10,2),
    quantity_on_hand integer DEFAULT 0,
    quantity_reserved integer DEFAULT 0,
    supplier_id uuid REFERENCES supplier(id) ON DELETE SET NULL,
    barcode text,
    location text,
    ...
);

-- Purchase Order (Direct FK to supplier)
CREATE TABLE purchase_order (
    id uuid PRIMARY KEY,
    org_id uuid REFERENCES organization(id) ON DELETE CASCADE,
    supplier_id uuid REFERENCES supplier(id) ON DELETE RESTRICT,
    po_number text NOT NULL,
    status po_status DEFAULT 'draft',
    total_amount numeric(12,2),
    order_date date,
    expected_delivery_date date,
    ...
);

-- Purchase Order Item (Indirect dependency through PO and inventory)
CREATE TABLE purchase_order_item (
    id uuid PRIMARY KEY,
    purchase_order_id uuid REFERENCES purchase_order(id) ON DELETE CASCADE,
    inventory_item_id uuid REFERENCES inventory_item(id) ON DELETE RESTRICT,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    ...
);
```

#### Extended Schemas (From existing scripts)
Based on analysis of `/scripts/insert_22_realistic_purchase_orders.sql`:

```sql
-- Extended Purchase Orders (Enhanced schema)
purchase_orders_enhanced (
    id, org_id, supplier_id, po_number, title, description,
    category, priority, requested_by, department, budget_code,
    subtotal, tax_amount, shipping_amount, discount_amount,
    total_amount, currency, order_date, requested_delivery_date,
    confirmed_delivery_date, actual_delivery_date, delivery_location,
    payment_terms, status, workflow_status, approved_by, approved_at,
    sent_at, acknowledged_at, tracking_number, carrier, risk_score,
    three_way_match_status, notes, internal_notes, created_by, created_at
)

-- Purchase Order Items (Enhanced)
purchase_order_items_enhanced (
    id, purchase_order_id, line_number, product_code, product_name,
    description, specifications, category, quantity, unit, unit_price,
    total_price, discount_percentage, tax_percentage, requested_date,
    status, quality_requirements, inspection_required, warranty_period, notes
)

-- Purchase Order Receipts
purchase_order_receipts (
    id, purchase_order_id, receipt_number, receipt_type, received_date,
    received_by, receiving_location, inspection_status, inspector_name,
    inspection_date, overall_quality_score, certificate_number,
    documentation_complete, invoice_received, invoice_amount, status
)

-- Purchase Order Approvals
purchase_order_approvals (
    id, purchase_order_id, step_number, step_name, approver_role,
    approver_name, approver_email, approval_threshold, required,
    status, approved_at
)

-- Supplier Contracts
supplier_contracts (
    id, supplier_id, contract_number, contract_type, title, description,
    start_date, end_date, auto_renewal, renewal_period,
    total_contract_value, minimum_spend, maximum_spend,
    payment_terms, delivery_sla_days, quality_sla_percentage,
    quality_requirements, performance_metrics, penalties,
    status, approved_by, approved_at, signed_date
)

-- Invoices
invoices (
    id, org_id, supplier_id, purchase_order_id, invoice_number,
    supplier_invoice_number, invoice_date, due_date, received_date,
    processed_date, paid_date, currency, subtotal, tax_amount,
    discount_amount, shipping_amount, other_charges, total_amount,
    paid_amount, payment_terms, status, approval_status,
    payment_status, three_way_match_status, ...
)

-- Invoice Line Items
invoice_line_items (
    id, invoice_id, line_number, product_code, product_name,
    description, quantity, unit_price, total_price, ...
)

-- Accounts Payable
accounts_payable (
    id, org_id, supplier_id, invoice_id, ap_account_code,
    debit_amount, credit_amount, balance, ...
)

-- General Ledger Entries
general_ledger_entries (
    id, org_id, entry_number, entry_date, description,
    total_debit, total_credit, ...
)

-- General Ledger Lines
general_ledger_lines (
    id, gl_entry_id, account_code, account_name,
    debit_amount, credit_amount, ...
)

-- Payments
payments (
    id, org_id, supplier_id, payment_number, payment_date,
    payment_method, amount, currency, status, ...
)

-- Three-Way Matching
three_way_matching (
    id, org_id, purchase_order_id, receipt_id, invoice_id,
    match_status, match_date, ...
)
```

### Dependency Map

```mermaid
graph TD
    ORG[organization]
    SUPP[supplier]
    INV[inventory_item]
    PO[purchase_order]
    POI[purchase_order_item]
    POR[purchase_order_receipts]
    POA[purchase_order_approvals]
    CONTRACT[supplier_contracts]
    INVOICE[invoices]
    INVLINE[invoice_line_items]
    AP[accounts_payable]
    GL[general_ledger_entries]
    GLLINE[general_ledger_lines]
    PAY[payments]
    MATCH[three_way_matching]

    ORG -->|CASCADE| SUPP
    SUPP -->|SET NULL| INV
    SUPP -->|RESTRICT| PO
    SUPP --> CONTRACT
    SUPP --> INVOICE
    PO -->|CASCADE| POI
    PO --> POR
    PO --> POA
    PO --> MATCH
    INV -->|RESTRICT| POI
    INVOICE --> INVLINE
    INVOICE --> AP
    INVOICE --> MATCH
    AP --> GL
    GL --> GLLINE
    INVOICE --> PAY
```

### Critical Relationships

1. **supplier → inventory_item**: `ON DELETE SET NULL` (safe)
2. **supplier → purchase_order**: `ON DELETE RESTRICT` (⚠️ must delete POs first)
3. **purchase_order → purchase_order_item**: `ON DELETE CASCADE` (automatic)
4. **inventory_item → purchase_order_item**: `ON DELETE RESTRICT` (⚠️ order matters)

### Deletion Order (Critical!)

```sql
-- PHASE 1: Transactional Data (Leaf nodes first)
1. general_ledger_lines
2. general_ledger_entries
3. payment_allocations
4. payments
5. matching_exceptions
6. three_way_matching
7. accounts_payable
8. invoice_line_items
9. invoices

-- PHASE 2: Purchase Order Related
10. purchase_order_receipt_items
11. purchase_order_receipts
12. purchase_order_items_enhanced
13. purchase_order_approvals
14. purchase_order_audit_trail
15. purchase_orders_enhanced (if extended schema exists)
16. purchase_order_item (core schema)
17. purchase_order (core schema)

-- PHASE 3: Contracts
18. contract_performance_metrics
19. contract_amendments
20. supplier_contracts

-- PHASE 4: Inventory
21. inventory_item

-- PHASE 5: Supplier (Final)
22. supplier
```

---

## 2. DUPLICATE SUPPLIER DETECTION

### Detection Strategy

```sql
-- Identify duplicates by normalized name
WITH duplicate_candidates AS (
    SELECT
        LOWER(TRIM(REGEXP_REPLACE(name, '\s+', ' ', 'g'))) as normalized_name,
        COUNT(*) as duplicate_count,
        ARRAY_AGG(id ORDER BY
            CASE status
                WHEN 'active' THEN 1
                WHEN 'inactive' THEN 2
                ELSE 3
            END,
            created_at ASC
        ) as supplier_ids,
        ARRAY_AGG(name ORDER BY created_at ASC) as original_names,
        ARRAY_AGG(status ORDER BY created_at ASC) as statuses,
        ARRAY_AGG(created_at ORDER BY created_at ASC) as created_dates
    FROM supplier
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
    GROUP BY normalized_name
    HAVING COUNT(*) > 1
)
SELECT
    normalized_name,
    duplicate_count,
    supplier_ids,
    original_names,
    statuses,
    created_dates,
    -- Recommended primary (first active, or oldest)
    supplier_ids[1] as recommended_primary_id
FROM duplicate_candidates
ORDER BY duplicate_count DESC, normalized_name;
```

### Resolution Strategy

**Option A: Merge (Recommended for data retention)**
```sql
-- Keep first active supplier, reassign all relationships
1. Identify primary supplier (active status, earliest creation, most references)
2. Update inventory_item SET supplier_id = primary WHERE supplier_id IN (duplicates)
3. Update purchase_order SET supplier_id = primary WHERE supplier_id IN (duplicates)
4. Soft delete duplicates (SET status = 'merged', merged_into = primary)
```

**Option B: Delete (Recommended for clean slate)**
```sql
-- Delete all duplicates after reassignment
1. Follow reassignment from Option A
2. DELETE FROM supplier WHERE id IN (duplicate_ids)
```

---

## 3. COMPLETE DATA CLEANUP PROCEDURE

### Pre-Cleanup Validation

```sql
-- Count current state
SELECT
    'PRE-CLEANUP STATE' as phase,
    (SELECT COUNT(*) FROM supplier WHERE org_id = '00000000-0000-0000-0000-000000000001') as suppliers,
    (SELECT COUNT(*) FROM inventory_item WHERE org_id = '00000000-0000-0000-0000-000000000001') as inventory_items,
    (SELECT COUNT(*) FROM purchase_order WHERE org_id = '00000000-0000-0000-0000-000000000001') as purchase_orders,
    (SELECT COUNT(*) FROM invoices WHERE org_id = '00000000-0000-0000-0000-000000000001') as invoices;
```

### Backup Strategy

```sql
-- Create backup tables before cleanup
CREATE TABLE supplier_backup_20250930 AS SELECT * FROM supplier WHERE org_id = '00000000-0000-0000-0000-000000000001';
CREATE TABLE inventory_item_backup_20250930 AS SELECT * FROM inventory_item WHERE org_id = '00000000-0000-0000-0000-000000000001';
CREATE TABLE purchase_order_backup_20250930 AS SELECT * FROM purchase_order WHERE org_id = '00000000-0000-0000-0000-000000000001';
CREATE TABLE invoices_backup_20250930 AS SELECT * FROM invoices WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Verify backups
SELECT
    'supplier_backup_20250930' as table_name, COUNT(*) as record_count FROM supplier_backup_20250930
UNION ALL
SELECT 'inventory_item_backup_20250930', COUNT(*) FROM inventory_item_backup_20250930
UNION ALL
SELECT 'purchase_order_backup_20250930', COUNT(*) FROM purchase_order_backup_20250930
UNION ALL
SELECT 'invoices_backup_20250930', COUNT(*) FROM invoices_backup_20250930;
```

### Complete Cleanup Procedure

See separate SQL file: `/scripts/data_cleanup/COMPLETE_DATABASE_CLEANUP.sql`

Key steps:
1. Backup all data
2. Delete in correct order (respecting FK constraints)
3. Reset sequences
4. Verify empty state
5. Maintain rollback capability

---

## 4. 22-SUPPLIER TEST DATASET GENERATION

### Dataset Design Principles

1. **Realistic Business Scenarios**
   - Mix of industries (technology, manufacturing, healthcare, etc.)
   - Various supplier statuses (active, pending, etc.)
   - Different risk profiles (10-50 risk scores)
   - Diverse payment terms (Net 7, Net 30, Net 45, Net 60)
   - Varied lead times (1-28 days)

2. **Complete Transaction Flows**
   - Each supplier → 1 primary product
   - Each product → 1 purchase order
   - Each PO → line items + approvals
   - Strategic suppliers → contracts
   - All POs → invoices
   - All invoices → payment records or pending status
   - Select POs → receipts (quality inspection)

3. **Inventory Visibility**
   - Products at multiple locations (Warehouse A, B, C, etc.)
   - Realistic stock levels (on-hand, reserved, reorder points)
   - Proper SKU/barcode assignment
   - Category-appropriate pricing

4. **Business Workflow States**
   - **Draft POs**: 2 orders (recently created, not yet approved)
   - **Approved POs**: 4 orders (approved, pending supplier acknowledgment)
   - **In Progress POs**: 6 orders (manufacturing, shipping, quality inspection)
   - **Completed POs**: 8 orders (received, inspected, matched with invoices)
   - **Cancelled POs**: 2 orders (business scenarios - scope change, supplier issue)

### Supplier Distribution

| Industry Category | Count | Risk Profile | Example Suppliers |
|------------------|-------|--------------|-------------------|
| Technology & Electronics | 3 | Low (15-25) | Alpha Tech, BK Electronics, Sonic Pro Audio |
| Manufacturing & Industrial | 2 | Medium (30-40) | Precision Mfg, Industrial Components |
| Construction & Building | 2 | Medium (35-45) | BuildMaster, Steelcraft |
| Automotive & Transport | 2 | Low (20-30) | AutoParts Direct, Fleet Solutions |
| Healthcare & Medical | 2 | Very Low (10-20) | MediSupply, PharmaLogistics |
| Food & Beverage | 2 | Medium (20-35) | FreshProduce, Beverage Solutions |
| Textiles & Apparel | 2 | High (40-50) | Textile Mills, Corp Uniforms |
| Energy & Utilities | 2 | Low (20-30) | Solar Power, Electrical Contractors |
| Office & Stationery | 1 | Very Low (15) | Office Depot SA |
| Chemical & Laboratory | 1 | High (40) | ChemLab Supplies |
| Agriculture & Farming | 1 | High (35) | AgriSupply Solutions |
| Packaging & Logistics | 2 | Low (25) | PackagePro Logistics |

### Product Distribution by Category

```sql
inventory_category:
- finished_goods: 10 products (equipment, monitors, generators, etc.)
- components: 5 products (bearings, housings, brake discs, etc.)
- raw_materials: 5 products (cement, steel, fabric, cable, etc.)
- consumables: 2 products (chemicals, fertilizers)
```

### Contract Coverage

Strategic contracts for high-value/strategic suppliers:
1. **Alpha Technologies** - IT Equipment Supply (R2.5M annual, strategic partnership)
2. **PowerTech Engineering** - Power Systems (R1.8M annual, strategic partnership)
3. **MediSupply Healthcare** - Medical Equipment (R1.2M annual, preferred supplier)
4. **Solar Power Solutions** - Renewable Energy (R800K annual, framework agreement)
5. **Precision Manufacturing** - Custom Manufacturing (R600K annual, preferred supplier)

### Invoice and Payment Scenarios

| Status | Count | Description | Example |
|--------|-------|-------------|---------|
| **Paid** | 8 | Completed transactions with payment records | Early payment discount utilized, matched invoices |
| **Approved (Pending Payment)** | 6 | Approved invoices awaiting payment date | Due date approaching, payment scheduled |
| **Under Review** | 4 | Pending approval or three-way matching | Quality inspection pending, matching in progress |
| **Disputed** | 2 | Invoice discrepancies identified | Quantity mismatch, pricing dispute |
| **Draft** | 2 | Invoices received but not yet processed | OCR processing, awaiting manual review |

### Financial Entry Integration

Complete GL and AP entries for all invoices:
- **Chart of Accounts**: Standard expense accounts (5xxx series)
- **AP Entries**: Proper debit/credit entries
- **GL Transactions**: Journal entries with proper account codes
- **Payment Allocations**: Link payments to invoices
- **Three-Way Matching**: PO + Receipt + Invoice reconciliation

---

## 5. DATA GENERATION EXECUTION PLAN

### Phase 1: Organization Setup
```sql
-- Ensure test organization exists
INSERT INTO organization (id, name, slug, plan_type, settings)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'MantisNXT Test Organization',
    'mantisnxt-test',
    'enterprise',
    '{"test_mode": true, "data_source": "ai_generated_2025_09_30"}'::jsonb
) ON CONFLICT (slug) DO UPDATE SET updated_at = NOW();
```

### Phase 2: 22 Suppliers
See script: `/scripts/test_data/01_generate_22_suppliers.sql`

Key attributes per supplier:
- Unique South African company names
- Complete contact information (email, phone, physical address)
- Industry-appropriate certifications
- Realistic risk scores
- Proper payment terms
- Business notes and context

### Phase 3: 22 Products (1 per supplier)
See script: `/scripts/test_data/02_generate_22_products.sql`

Key attributes per product:
- Unique SKU codes (supplier prefix + category + sequence)
- Realistic product names and descriptions
- Industry-appropriate specifications
- Market-appropriate pricing (R35 - R185,000)
- Proper stock levels (on-hand, reserved, reorder points)
- Multiple locations for visibility
- Barcodes (realistic South African format)

### Phase 4: 22 Purchase Orders
See script: `/scripts/test_data/03_generate_22_purchase_orders.sql`

Key components:
- **PO Headers**: Complete with all financial fields (subtotal, tax, shipping, discounts)
- **PO Line Items**: Detailed specifications, quality requirements, warranty info
- **Approval Workflows**: Multi-level approvals (Department → Director → Finance)
- **Status Progression**: Draft → Approved → Sent → Acknowledged → Manufacturing → Received
- **Tracking**: Carrier information, tracking numbers, delivery locations

### Phase 5: Contracts (5 strategic suppliers)
See script: `/scripts/test_data/04_generate_5_contracts.sql`

Key components:
- Contract types: Strategic Partnership, Preferred Supplier, Framework Agreement
- Financial terms: Annual values, minimum/maximum spends
- Performance metrics: On-time delivery %, quality acceptance %, SLA response times
- Penalties: Late delivery, quality issues, SLA misses
- Auto-renewal terms

### Phase 6: 22 Invoices
See script: `/scripts/test_data/05_generate_22_invoices.sql`

Key components:
- **Invoice Headers**: Supplier invoice numbers, dates, payment terms
- **Line Items**: Match PO line items with received quantities
- **Financial Entries**: Tax, discounts, shipping charges
- **Approval Status**: Various workflow states
- **Three-Way Matching**: Link to PO + Receipt
- **Payment Records**: For paid invoices

### Phase 7: Financial Entries
See script: `/scripts/test_data/06_generate_financial_entries.sql`

Key components:
- **Accounts Payable**: For each invoice, proper AP entries
- **General Ledger**: Journal entries with proper account codes
  - Debit: Expense accounts (5xxx series)
  - Credit: Accounts Payable (2100)
- **Payments**: Payment records for paid invoices
  - Payment methods: EFT, Check, Bank Transfer
  - Payment references and dates
- **Payment Allocations**: Link payments to invoices

### Phase 8: Inventory at All Locations
See script: `/scripts/test_data/07_generate_inventory_locations.sql`

Create inventory entries for each product at multiple locations:
- **Main Warehouse** (all 22 products)
- **Warehouse A - Technology** (tech products)
- **Warehouse B - Manufacturing** (components and raw materials)
- **Warehouse C - Healthcare** (medical products)
- **Warehouse D - General** (office, consumables)

---

## 6. VALIDATION AND VERIFICATION

### Comprehensive Validation Queries

```sql
-- 1. Supplier Count and Status
SELECT
    'SUPPLIER VALIDATION' as check_type,
    COUNT(*) as total_count,
    COUNT(*) FILTER (WHERE status = 'active') as active,
    COUNT(*) FILTER (WHERE status = 'pending_approval') as pending,
    COUNT(DISTINCT name) as unique_names,
    COUNT(*) - COUNT(DISTINCT name) as duplicate_count
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- 2. Product-Supplier Linkage
SELECT
    'PRODUCT-SUPPLIER LINKAGE' as check_type,
    COUNT(*) as total_products,
    COUNT(DISTINCT supplier_id) as linked_suppliers,
    COUNT(*) FILTER (WHERE supplier_id IS NULL) as orphaned_products
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- 3. Purchase Order Integrity
SELECT
    'PURCHASE ORDER INTEGRITY' as check_type,
    COUNT(DISTINCT po.id) as total_pos,
    COUNT(DISTINCT po.supplier_id) as suppliers_with_pos,
    COUNT(DISTINCT poi.id) as total_line_items,
    ROUND(AVG(line_item_count), 2) as avg_items_per_po,
    COUNT(*) FILTER (WHERE po.total_amount != COALESCE(item_total, 0)) as amount_mismatch_count
FROM purchase_order po
LEFT JOIN (
    SELECT purchase_order_id, COUNT(*) as line_item_count, SUM(total_price) as item_total
    FROM purchase_order_item
    GROUP BY purchase_order_id
) poi ON po.id = poi.purchase_order_id
WHERE po.org_id = '00000000-0000-0000-0000-000000000001';

-- 4. Invoice-PO Matching
SELECT
    'INVOICE-PO MATCHING' as check_type,
    COUNT(DISTINCT i.id) as total_invoices,
    COUNT(DISTINCT i.purchase_order_id) as pos_with_invoices,
    COUNT(*) FILTER (WHERE i.purchase_order_id IS NULL) as orphaned_invoices,
    COUNT(*) FILTER (WHERE i.three_way_match_status = 'matched') as matched_invoices,
    COUNT(*) FILTER (WHERE i.status = 'paid') as paid_invoices,
    ROUND(SUM(i.total_amount), 2) as total_invoice_value,
    ROUND(SUM(i.paid_amount), 2) as total_paid
FROM invoices i
WHERE i.org_id = '00000000-0000-0000-0000-000000000001';

-- 5. Contract Coverage
SELECT
    'CONTRACT COVERAGE' as check_type,
    COUNT(DISTINCT c.supplier_id) as suppliers_with_contracts,
    ROUND(SUM(c.total_contract_value), 2) as total_contract_value,
    ROUND(AVG(c.total_contract_value), 2) as avg_contract_value,
    COUNT(*) FILTER (WHERE c.status = 'active') as active_contracts
FROM supplier_contracts c
JOIN supplier s ON c.supplier_id = s.id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001';

-- 6. Financial Entry Completeness
SELECT
    'FINANCIAL ENTRY COMPLETENESS' as check_type,
    (SELECT COUNT(*) FROM invoices WHERE org_id = '00000000-0000-0000-0000-000000000001') as total_invoices,
    (SELECT COUNT(DISTINCT invoice_id) FROM accounts_payable WHERE org_id = '00000000-0000-0000-0000-000000000001') as invoices_with_ap,
    (SELECT COUNT(*) FROM payments WHERE org_id = '00000000-0000-0000-0000-000000000001') as total_payments,
    (SELECT COUNT(*) FROM general_ledger_entries WHERE org_id = '00000000-0000-0000-0000-000000000001') as gl_entries;

-- 7. Inventory Location Coverage
SELECT
    'INVENTORY LOCATION COVERAGE' as check_type,
    COUNT(DISTINCT location) as unique_locations,
    COUNT(*) as total_inventory_records,
    ROUND(COUNT(*) * 1.0 / COUNT(DISTINCT sku), 2) as avg_locations_per_product,
    SUM(quantity_on_hand) as total_stock_on_hand,
    SUM(quantity_reserved) as total_stock_reserved
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- 8. No Orphaned Records
SELECT
    'ORPHANED RECORDS CHECK' as check_type,
    (SELECT COUNT(*) FROM inventory_item WHERE supplier_id IS NOT NULL AND supplier_id NOT IN (SELECT id FROM supplier)) as orphaned_inventory,
    (SELECT COUNT(*) FROM purchase_order WHERE supplier_id NOT IN (SELECT id FROM supplier)) as orphaned_pos,
    (SELECT COUNT(*) FROM invoices WHERE supplier_id NOT IN (SELECT id FROM supplier)) as orphaned_invoices,
    (SELECT COUNT(*) FROM invoices WHERE purchase_order_id NOT IN (SELECT id FROM purchase_order)) as invoices_without_pos;

-- 9. Business Workflow States
SELECT
    'BUSINESS WORKFLOW STATES' as check_type,
    status,
    COUNT(*) as count,
    ROUND(SUM(total_amount), 2) as total_value
FROM purchase_order
WHERE org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY status
ORDER BY count DESC;

-- 10. Complete End-to-End Flow Check
WITH supplier_flow AS (
    SELECT
        s.id as supplier_id,
        s.name as supplier_name,
        COUNT(DISTINCT i.id) as product_count,
        COUNT(DISTINCT po.id) as po_count,
        COUNT(DISTINCT inv.id) as invoice_count,
        COUNT(DISTINCT c.id) as contract_count,
        CASE
            WHEN COUNT(DISTINCT i.id) > 0
                AND COUNT(DISTINCT po.id) > 0
                AND COUNT(DISTINCT inv.id) > 0
            THEN 'COMPLETE'
            ELSE 'INCOMPLETE'
        END as flow_status
    FROM supplier s
    LEFT JOIN inventory_item i ON s.id = i.supplier_id
    LEFT JOIN purchase_order po ON s.id = po.supplier_id
    LEFT JOIN invoices inv ON s.id = inv.supplier_id
    LEFT JOIN supplier_contracts c ON s.id = c.supplier_id
    WHERE s.org_id = '00000000-0000-0000-0000-000000000001'
    GROUP BY s.id, s.name
)
SELECT
    'END-TO-END FLOW VALIDATION' as check_type,
    COUNT(*) as total_suppliers,
    COUNT(*) FILTER (WHERE flow_status = 'COMPLETE') as complete_flows,
    COUNT(*) FILTER (WHERE flow_status = 'INCOMPLETE') as incomplete_flows,
    ROUND(COUNT(*) FILTER (WHERE flow_status = 'COMPLETE') * 100.0 / COUNT(*), 2) as completion_percentage
FROM supplier_flow;
```

### Expected Results
```
Total Suppliers: 22
Unique Supplier Names: 22 (zero duplicates)
Products: 22 (1 per supplier, all linked)
Purchase Orders: 22 (1 per supplier)
Invoices: 22 (1 per PO)
Contracts: 5 (strategic suppliers)
Inventory Locations: 88+ (22 products × 4 average locations)
Complete End-to-End Flows: 22/22 (100%)
Orphaned Records: 0
Referential Integrity: 100% maintained
```

---

## 7. EXECUTION CHECKLIST

### Pre-Execution Tasks
- [ ] **Database Backup**: Full PostgreSQL backup of entire database
- [ ] **Schema Validation**: Verify all required tables exist
- [ ] **Connection Test**: Confirm database connection and permissions
- [ ] **Dry Run Review**: Review all SQL scripts for syntax and logic
- [ ] **Rollback Plan**: Prepare rollback procedures if needed

### Execution Sequence

#### Step 1: Analysis Phase
- [ ] Run `/scripts/database_analysis.sql` to understand current state
- [ ] Run `/scripts/supplier_dependency_map.sql` to map relationships
- [ ] Execute duplicate detection queries
- [ ] Document findings and confirm cleanup scope

#### Step 2: Backup Phase
- [ ] Create backup tables for all major entities
- [ ] Export backup to external files (CSV/SQL dumps)
- [ ] Verify backup integrity and completeness
- [ ] Store backups in `/database/backups/backup_20250930/`

#### Step 3: Cleanup Phase
- [ ] Execute `/scripts/data_cleanup/COMPLETE_DATABASE_CLEANUP.sql`
- [ ] Monitor deletion progress (check row counts)
- [ ] Verify clean slate with validation queries
- [ ] Reset sequences and auto-increment fields

#### Step 4: Data Generation Phase
Execute in order:
- [ ] `/scripts/test_data/01_generate_22_suppliers.sql`
- [ ] `/scripts/test_data/02_generate_22_products.sql`
- [ ] `/scripts/test_data/03_generate_22_purchase_orders.sql`
- [ ] `/scripts/test_data/04_generate_5_contracts.sql`
- [ ] `/scripts/test_data/05_generate_22_invoices.sql`
- [ ] `/scripts/test_data/06_generate_financial_entries.sql`
- [ ] `/scripts/test_data/07_generate_inventory_locations.sql`

#### Step 5: Validation Phase
- [ ] Run all validation queries from Section 6
- [ ] Verify expected results match actual results
- [ ] Check UI visibility for all entities
- [ ] Test key application workflows

#### Step 6: Documentation Phase
- [ ] Document actual results vs. expected results
- [ ] Create data dictionary for test dataset
- [ ] Update application documentation
- [ ] Prepare handoff documentation

### Post-Execution Tasks
- [ ] **Performance Test**: Verify query performance with new dataset
- [ ] **UI Testing**: Test all CRUD operations in application
- [ ] **API Testing**: Verify API endpoints return correct data
- [ ] **Backup Cleanup**: Remove old backup tables if successful
- [ ] **Documentation**: Update system documentation with test data info

---

## 8. ROLLBACK PROCEDURES

### Emergency Rollback (If Issues Occur)

```sql
-- Option A: Restore from backup tables
BEGIN;

-- Restore suppliers
TRUNCATE supplier CASCADE;
INSERT INTO supplier SELECT * FROM supplier_backup_20250930;

-- Restore inventory
TRUNCATE inventory_item CASCADE;
INSERT INTO inventory_item SELECT * FROM inventory_item_backup_20250930;

-- Restore purchase orders
TRUNCATE purchase_order CASCADE;
INSERT INTO purchase_order SELECT * FROM purchase_order_backup_20250930;

-- Restore invoices
TRUNCATE invoices CASCADE;
INSERT INTO invoices SELECT * FROM invoices_backup_20250930;

-- Verify restoration
SELECT
    'ROLLBACK VERIFICATION' as check_type,
    (SELECT COUNT(*) FROM supplier) as restored_suppliers,
    (SELECT COUNT(*) FROM inventory_item) as restored_inventory,
    (SELECT COUNT(*) FROM purchase_order) as restored_pos,
    (SELECT COUNT(*) FROM invoices) as restored_invoices;

COMMIT;
```

```sql
-- Option B: Restore from external SQL dump
-- Run from command line:
psql -U postgres -d mantisnxt < /database/backups/backup_20250930/full_backup.sql
```

### Partial Rollback (Specific Tables)

```sql
-- Rollback only suppliers if generation failed
DELETE FROM supplier WHERE org_id = '00000000-0000-0000-0000-000000000001';
INSERT INTO supplier SELECT * FROM supplier_backup_20250930;
```

---

## 9. RISK ASSESSMENT

### High Risks (Mitigation Required)
1. **Data Loss**: ⚠️ Complete cleanup removes all existing test data
   - **Mitigation**: Comprehensive backup before execution
   - **Recovery**: Rollback procedures prepared and tested

2. **Foreign Key Violations**: ⚠️ Incorrect deletion order causes FK constraint errors
   - **Mitigation**: Carefully ordered deletion sequence (leaf → root)
   - **Recovery**: Transaction-based execution with rollback on error

3. **Orphaned Records**: ⚠️ Incomplete deletion leaves orphaned data
   - **Mitigation**: Cascade deletes and comprehensive cleanup queries
   - **Recovery**: Orphaned record detection and cleanup queries

### Medium Risks (Monitoring Required)
1. **Performance Impact**: Database lock during large delete operations
   - **Mitigation**: Execute during low-traffic periods
   - **Recovery**: Transaction timeout settings

2. **Sequence Reset**: Auto-increment sequences not properly reset
   - **Mitigation**: Explicit sequence reset commands
   - **Recovery**: Manual sequence adjustment

### Low Risks (Acceptable)
1. **Extended Tables**: Some extended schema tables may not exist yet
   - **Mitigation**: Conditional table existence checks
   - **Recovery**: Skip non-existent tables

---

## 10. SUCCESS METRICS

### Quantitative Metrics
- ✅ **Zero Duplicates**: No duplicate supplier names detected
- ✅ **22 Suppliers**: Exactly 22 unique, realistic suppliers created
- ✅ **100% Linkage**: All suppliers have products, POs, and invoices
- ✅ **100% Integrity**: No orphaned records, all FKs valid
- ✅ **Multi-Location Visibility**: Average 4+ locations per product
- ✅ **Complete Financial Chain**: All invoices have AP and GL entries
- ✅ **Contract Coverage**: 5 strategic suppliers with active contracts

### Qualitative Metrics
- ✅ **Realistic Data**: Suppliers, products, and transactions reflect real business scenarios
- ✅ **Business Workflows**: Multiple workflow states represented (draft, approved, completed, etc.)
- ✅ **UI Usability**: All entities visible and functional in application UI
- ✅ **Testing Readiness**: Dataset suitable for comprehensive application testing

---

## 11. NEXT STEPS

### Immediate Actions
1. ✅ **Review Strategy**: Stakeholder review and approval of this document
2. ⏳ **Generate SQL Scripts**: Create all 7 test data generation scripts
3. ⏳ **Prepare Cleanup Script**: Finalize comprehensive cleanup procedure
4. ⏳ **Test in Development**: Execute full procedure in dev environment first
5. ⏳ **Production Execution**: Execute in production after successful dev test

### Future Enhancements
1. **Automated Data Generation**: Create script to generate N suppliers on demand
2. **Data Refresh Procedure**: Scheduled cleanup and regeneration for test environments
3. **Data Seeding Library**: Package test data generation as reusable library
4. **Performance Benchmarking**: Establish baseline performance metrics with this dataset

---

## APPENDIX A: SQL Script Locations

### Cleanup Scripts
- `/scripts/data_cleanup/COMPLETE_DATABASE_CLEANUP.sql` - Master cleanup procedure
- `/scripts/data_cleanup/01_supplier_consolidation.sql` - Duplicate resolution
- `/scripts/data_cleanup/02_transactional_data_cleanup.sql` - Transaction data cleanup
- `/scripts/data_cleanup/03_sequence_reset.sql` - Sequence reset
- `/scripts/data_cleanup/04_rollback_procedures.sql` - Emergency rollback

### Test Data Generation Scripts
- `/scripts/test_data/01_generate_22_suppliers.sql` - 22 realistic suppliers
- `/scripts/test_data/02_generate_22_products.sql` - 22 products (1 per supplier)
- `/scripts/test_data/03_generate_22_purchase_orders.sql` - 22 complete POs
- `/scripts/test_data/04_generate_5_contracts.sql` - 5 strategic contracts
- `/scripts/test_data/05_generate_22_invoices.sql` - 22 invoices with line items
- `/scripts/test_data/06_generate_financial_entries.sql` - AP and GL entries
- `/scripts/test_data/07_generate_inventory_locations.sql` - Multi-location inventory

### Analysis Scripts
- `/scripts/database_analysis.sql` - Current state analysis
- `/scripts/supplier_dependency_map.sql` - Relationship mapping
- `/scripts/backup_database.sql` - Backup procedures

---

## APPENDIX B: South African Business Context

### Supplier Naming Conventions
- **(Pty) Ltd**: Private limited company (most common)
- **SA / South Africa**: Geographic identifier
- **Solutions**: Service-oriented businesses
- **Technologies / Tech**: Technology companies

### South African Addresses
- **Provinces**: Gauteng (Johannesburg), Western Cape (Cape Town), KwaZulu-Natal (Durban)
- **Postal Codes**: 4-digit format (e.g., 2000, 7441, 4052)
- **Phone Format**: +27 prefix, area code (11, 21, 31), local number

### Currency and Pricing
- **Currency**: ZAR (South African Rand)
- **VAT**: 15% standard rate
- **Pricing Range**: R35 (consumables) to R185,000 (heavy equipment)

### Certifications
- **ISO Standards**: ISO 9001 (quality), ISO 14001 (environmental), ISO 13485 (medical)
- **SABS**: South African Bureau of Standards
- **SAHPRA**: South African Health Products Regulatory Authority
- **B-BBEE**: Broad-Based Black Economic Empowerment levels

---

**Document Status**: ✅ Ready for Review and Execution
**Last Updated**: 2025-09-30
**Author**: Database Oracle (Claude Code - Data Specialist)
**Approval Required**: System Administrator, Database Administrator, Development Lead