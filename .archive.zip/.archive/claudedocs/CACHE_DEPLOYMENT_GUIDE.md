# Cache System Deployment Guide
**ITERATION 2 - ADR-6 & ADR-1 Implementation**

## Overview
This guide covers deployment of the event-driven cache invalidation system (ADR-6) and Phase 1 cache integration rollout (ADR-1) for MantisNXT inventory management system.

### Implementation Summary
- **ADR-6**: Event-driven cache invalidation with React Query integration
- **ADR-1**: Phase 1 cache rollout for 3 high-traffic endpoints
- **Target**: 70-90% response time reduction
- **Status**: Production-ready with rollback support

---

## System Architecture

### Components Implemented

#### 1. Event Bus System (`src/lib/cache/`)
- **event-bus.ts**: Central event coordination for cache invalidation
- **events.ts**: Event type definitions and creation utilities
- **patterns.ts**: Cache key pattern matching and query key factories
- **event-invalidation.ts**: React Query integration and invalidation logic

#### 2. Cache Hooks (`src/hooks/api/`)
- **useDashboardMetrics.ts**: Dashboard metrics cached query (2min stale time)
- **useInventoryList.ts**: Inventory list cached query (5min stale time)
- **useAnalyticsOverview.ts**: Analytics overview cached query (10min stale time)
- **useInvalidation.ts**: Invalidation trigger hooks for mutations

#### 3. Monitoring & Control (`src/lib/cache/`)
- **monitoring.ts**: Performance tracking and metrics collection
- **feature-flags.ts**: Gradual rollout and rollback controls

---

## Pre-Deployment Checklist

### Environment Verification
- [ ] Node.js 18+ installed
- [ ] Next.js 15.5.3+ configured
- [ ] React Query 5.90.2+ installed
- [ ] Development environment tested

### Database Requirements
- [ ] Database connection pool configured
- [ ] Existing cache implementation (query-cache.ts) reviewed
- [ ] No conflicts with server-side caching (Next.js revalidation)

### Dependencies Check
```bash
npm list @tanstack/react-query
npm list react
npm list next
```

Expected versions:
- @tanstack/react-query: ^5.90.2
- react: ^19.1.1
- next: ^15.5.3

---

## Deployment Steps

### Step 1: Code Deployment
```bash
# 1. Pull latest changes
git pull origin main

# 2. Install dependencies
npm install

# 3. Build application
npm run build

# 4. Verify build success
npm run lint
npm run type-check
```

### Step 2: Run Tests
```bash
# Unit tests
npm test -- tests/cache/event-bus.test.ts
npm test -- tests/cache/invalidation.test.ts
npm test -- tests/cache/patterns.test.ts

# Integration tests
npm test -- tests/cache/integration.test.ts

# All cache tests
npm test -- tests/cache/
```

Expected results:
- All tests passing
- No console errors
- Test coverage ≥80%

### Step 3: Performance Baseline
Before enabling cache, establish baseline metrics:

```bash
# Start development server
npm run dev

# In separate terminal, run benchmark
node scripts/cache-performance-benchmark.js
```

Record baseline metrics:
- Dashboard Metrics: ~500ms
- Inventory List: ~800ms
- Analytics Overview: ~1200ms

### Step 4: Enable Phase 1 Cache
Cache is enabled by default in the implementation. To verify:

```javascript
// Check feature flags in browser console
import { featureFlagManager } from '@/lib/cache/feature-flags';
console.log(featureFlagManager.getFlags());
```

Expected output:
```json
{
  "cacheEnabled": true,
  "dashboardMetricsCache": true,
  "inventoryListCache": true,
  "analyticsOverviewCache": true
}
```

### Step 5: Verify Cache Performance
```bash
# Run benchmark again with cache enabled
node scripts/cache-performance-benchmark.js

# Expected improvements:
# Dashboard Metrics: 500ms → 50-150ms (70-90% reduction)
# Inventory List: 800ms → 80-240ms (70-90% reduction)
# Analytics Overview: 1200ms → 120-360ms (70-90% reduction)
```

### Step 6: Monitor Cache Behavior

#### Browser Console Monitoring
```javascript
// Get performance stats
import { getPerformanceReport } from '@/lib/cache/monitoring';
const report = getPerformanceReport();
console.log(report.summary);
```

Expected output:
```
Cache Performance Summary:
- Total Queries: 100
- Cache Hit Rate: 65.0%
- Avg Response Time: 150ms
- Avg Cache Hit Time: 45ms
- Avg Cache Miss Time: 520ms
- Improvement Factor: 11.6x faster
```

#### Invalidation Monitoring
```javascript
// Check invalidation stats
import { getInvalidationManager } from '@/lib/cache/event-invalidation';
const manager = getInvalidationManager();
const stats = manager.getStats();
console.log(stats);
```

---

## Rollback Procedures

### Emergency Rollback (Immediate)
If critical issues occur, disable cache immediately:

```javascript
// In browser console or application code
import { rollbackPhase1Cache } from '@/lib/cache/feature-flags';
rollbackPhase1Cache();
```

This disables:
- Dashboard metrics cache
- Inventory list cache
- Analytics overview cache

### Selective Rollback
Disable specific endpoints:

```javascript
import { featureFlagManager } from '@/lib/cache/feature-flags';

// Disable only dashboard cache
featureFlagManager.setFlag('dashboardMetricsCache', false);

// Disable only inventory cache
featureFlagManager.setFlag('inventoryListCache', false);

// Disable only analytics cache
featureFlagManager.setFlag('analyticsOverviewCache', false);
```

### Full System Rollback
```bash
# 1. Disable cache globally
# In application code or browser console:
featureFlagManager.setFlag('cacheEnabled', false);

# 2. Clear all cached data
import { QueryClient } from '@tanstack/react-query';
const queryClient = new QueryClient();
queryClient.clear();

# 3. Restart application
npm run dev  # Development
npm run start  # Production
```

---

## Monitoring & Validation

### Key Metrics to Track

#### 1. Cache Hit Rate
**Target**: ≥60% after 1 week
```javascript
const report = getPerformanceReport();
console.log(`Hit Rate: ${(report.stats.hitRate * 100).toFixed(1)}%`);
```

#### 2. Response Time Improvement
**Target**: 70-90% reduction
```javascript
const stats = report.stats;
const improvement = ((stats.avgCacheMissTime - stats.avgCacheHitTime) / stats.avgCacheMissTime) * 100;
console.log(`Improvement: ${improvement.toFixed(1)}%`);
```

#### 3. Invalidation Effectiveness
**Target**: No stale data observed
```javascript
const manager = getInvalidationManager();
const invalidationStats = manager.getStats();
console.log(`Total Invalidations: ${invalidationStats.totalInvalidations}`);
console.log(`Queries Invalidated: ${invalidationStats.totalQueriesInvalidated}`);
```

### Health Checks

#### Daily Checks (Week 1-2)
- [ ] Cache hit rate trending upward
- [ ] No stale data reported by users
- [ ] Response times meeting targets
- [ ] No error spikes in logs

#### Weekly Validation
- [ ] Run performance benchmark
- [ ] Review invalidation logs
- [ ] Check feature flag status
- [ ] Validate consistency tests pass

### Alerting Thresholds
Set up monitoring alerts for:
- Cache hit rate <50% (warning)
- Cache hit rate <40% (critical)
- Response time >500ms for cached endpoints (warning)
- Invalidation errors >5% (critical)

---

## Troubleshooting Guide

### Issue: Low Cache Hit Rate (<40%)

**Symptoms**:
- Cache hit rate below expected 60%
- Performance not improving

**Diagnosis**:
```javascript
const report = getPerformanceReport();
console.log('Top Queries:', report.topQueries);
```

**Solutions**:
1. Check stale time configuration (may be too short)
2. Verify query keys are consistent
3. Check for unnecessary invalidations

### Issue: Stale Data Observed

**Symptoms**:
- Users see outdated inventory counts
- Dashboard metrics not reflecting recent changes

**Diagnosis**:
```javascript
const manager = getInvalidationManager();
const log = manager.getInvalidationLog();
console.log('Recent Invalidations:', log.slice(-10));
```

**Solutions**:
1. Verify invalidation events are firing
2. Check pattern matching logic
3. Review event bus statistics
4. Manual invalidation if needed:
```javascript
const { invalidateInventory } = useInvalidation();
invalidateInventory({});
```

### Issue: Cache Invalidation Not Working

**Symptoms**:
- Mutations not triggering invalidation
- Cache staying stale after updates

**Diagnosis**:
```javascript
import { cacheEventBus } from '@/lib/cache/event-bus';
const stats = cacheEventBus.getStats();
console.log('Event Bus Stats:', stats);
```

**Solutions**:
1. Verify event bus is initialized
2. Check event listeners are registered
3. Test event emission:
```javascript
import { triggerCacheInvalidation } from '@/lib/cache/event-invalidation';
await triggerCacheInvalidation('inventory.updated', { entityId: 'test' });
```

### Issue: Performance Not Improving

**Symptoms**:
- Response times still slow despite cache
- Improvement factor <5x

**Diagnosis**:
```bash
node scripts/cache-performance-benchmark.js --iterations=100
```

**Solutions**:
1. Verify cache is actually enabled
2. Check stale times are appropriate
3. Review network waterfall in DevTools
4. Ensure data fetching is optimized

---

## Testing in Production

### Gradual Rollout Strategy (Recommended)

#### Week 1: Monitor Only
- Cache enabled with logging
- Collect baseline metrics
- No user-facing changes

#### Week 2: Partial Rollout
- Enable cache for 50% of users
- Monitor hit rates and performance
- Gather user feedback

#### Week 3-4: Full Rollout
- Enable cache for all users
- Continue monitoring
- Optimize based on data

### Canary Deployment
```javascript
// Use feature flags for A/B testing
const isCanaryUser = userId % 10 < 5; // 50% of users

if (isCanaryUser) {
  featureFlagManager.updateFlags({
    dashboardMetricsCache: true,
    inventoryListCache: true,
    analyticsOverviewCache: true,
  });
} else {
  featureFlagManager.updateFlags({
    dashboardMetricsCache: false,
    inventoryListCache: false,
    analyticsOverviewCache: false,
  });
}
```

---

## Performance Benchmarks

### Expected Results (Phase 1)

| Endpoint | Baseline | Target | Actual |
|----------|----------|--------|--------|
| Dashboard Metrics | 500ms | 50-150ms | TBD |
| Inventory List | 800ms | 80-240ms | TBD |
| Analytics Overview | 1200ms | 120-360ms | TBD |

| Metric | Target | Status |
|--------|--------|--------|
| Cache Hit Rate | ≥60% | TBD |
| Improvement Factor | 5-10x | TBD |
| Response Time Reduction | 70-90% | TBD |
| Stale Data Incidents | 0 | TBD |

### Benchmark Commands

```bash
# Full benchmark
node scripts/cache-performance-benchmark.js

# Single endpoint
node scripts/cache-performance-benchmark.js --endpoint=dashboardMetrics

# High iteration count
node scripts/cache-performance-benchmark.js --iterations=200

# Continuous monitoring (run every hour)
while true; do
  node scripts/cache-performance-benchmark.js
  sleep 3600
done
```

---

## Future Phases

### Phase 2 (Week 3-4)
- Supplier list caching
- Supplier details caching
- Inventory details caching

### Phase 3 (Week 5-6)
- Stock movements caching
- Purchase orders caching
- Analytics reports caching

### Advanced Features
- Prefetching for predictive loading
- Background refetch optimization
- Optimistic updates for mutations

---

## Support & Escalation

### Documentation
- ADR-6: Event-Driven Cache Invalidation Strategy
- ADR-1: Cache Integration Rollout Plan
- React Query Docs: https://tanstack.com/query/latest

### Logs & Debugging
```javascript
// Enable verbose logging
localStorage.setItem('debug', 'cache:*');

// Check cache state
queryClient.getQueryCache().getAll();

// Export performance data
import { cachePerformanceMonitor } from '@/lib/cache/monitoring';
const metrics = cachePerformanceMonitor.exportMetrics();
console.table(metrics);
```

### Emergency Contacts
- System Owner: [TBD]
- On-Call Engineer: [TBD]
- Escalation Path: [TBD]

---

## Deployment Verification

### Post-Deployment Checklist
- [ ] All tests passing
- [ ] Cache hit rate ≥60%
- [ ] Response times meeting 70-90% reduction target
- [ ] No stale data incidents reported
- [ ] Invalidation events firing correctly
- [ ] Monitoring and alerts configured
- [ ] Rollback procedure tested and documented
- [ ] Team trained on cache system
- [ ] Performance benchmarks recorded

### Sign-Off
- [ ] Technical Lead Approval
- [ ] QA Verification
- [ ] Product Owner Acceptance
- [ ] Documentation Complete

**Deployment Date**: _______________
**Deployed By**: _______________
**Verified By**: _______________

---

## Appendix

### A. File Manifest
```
src/lib/cache/
├── event-bus.ts           # Event coordination
├── events.ts              # Event definitions
├── patterns.ts            # Pattern matching
├── event-invalidation.ts  # Invalidation logic
├── monitoring.ts          # Performance tracking
├── feature-flags.ts       # Rollout controls
└── query-cache.ts         # Existing cache (unchanged)

src/hooks/api/
├── useDashboardMetrics.ts
├── useInventoryList.ts
├── useAnalyticsOverview.ts
└── useInvalidation.ts

scripts/
└── cache-performance-benchmark.js

tests/cache/
├── event-bus.test.ts
├── invalidation.test.ts
├── patterns.test.ts
└── integration.test.ts
```

### B. Configuration Reference
```typescript
// Default cache policies
const CACHE_POLICIES = {
  dashboardMetrics: { staleTime: 2 * 60 * 1000 },  // 2 minutes
  inventoryList: { staleTime: 5 * 60 * 1000 },     // 5 minutes
  analyticsOverview: { staleTime: 10 * 60 * 1000 }, // 10 minutes
};
```

### C. Event Types
```typescript
type CacheInvalidationEventType =
  | 'inventory.created'
  | 'inventory.updated'
  | 'inventory.deleted'
  | 'inventory.bulk_updated'
  | 'inventory.stock_movement'
  | 'product.created'
  | 'product.updated'
  | 'product.deleted'
  | 'supplier.created'
  | 'supplier.updated'
  | 'supplier.deleted'
  | 'analytics.new'
  | 'dashboard.refresh'
  | 'cache.clear_all';
```

### D. Pattern Matching Examples
```typescript
// Inventory update invalidates:
'inventory.updated' => [
  'inventory-list.*',
  'inventory-item-.*',
  'inventory-analytics.*',
  'dashboard-metrics.*',
  'supplier-inventory-.*'
]

// Supplier update invalidates:
'supplier.updated' => [
  'suppliers-list.*',
  'supplier-.*',
  'supplier-metrics-.*',
  'supplier-inventory-.*'
]
```

---

**Document Version**: 1.0
**Last Updated**: 2025-10-09
**Status**: Production-Ready
