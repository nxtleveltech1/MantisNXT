# COMPREHENSIVE END-TO-END QUALITY VALIDATION REPORT
**Quality Engineer: Agent QA**
**Date: 2025-09-30**
**System: MantisNXT Production Database**
**Mission: 100% Data Integrity Validation**

## Executive Summary

This report provides a comprehensive quality assurance testing strategy for the MantisNXT system, focusing on achieving exactly 22 unique suppliers, 22 products (1 per supplier), 22 purchase orders, 22 invoices, complete inventory visibility, zero orphaned records, and validated system-wide integrity.

## SUCCESS CRITERIA CHECKLIST

- [ ] Exactly 22 unique suppliers (no duplicates, no more, no less)
- [ ] Exactly 22 products, each properly linked to 1 supplier
- [ ] Exactly 22 purchase orders with complete line items
- [ ] Exactly 22 invoices matching POs
- [ ] All 22 products visible in inventory at all locations
- [ ] Zero orphaned records anywhere in the system
- [ ] All relationships intact and validated
- [ ] System-wide visibility confirmed

---

## PHASE 1: PRE-CLEANUP VALIDATION

### 1.1 Current System State Documentation

#### Test 1.1.1: Current Supplier Count & Duplicates
```sql
-- Objective: Identify total suppliers and duplicates before cleanup
SELECT
    'Total Suppliers' as metric,
    COUNT(*) as count
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT
    'Unique Supplier Names' as metric,
    COUNT(DISTINCT LOWER(TRIM(name))) as count
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT
    'Duplicate Names' as metric,
    COUNT(*) as count
FROM (
    SELECT LOWER(TRIM(name)) as normalized_name
    FROM supplier
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
    GROUP BY LOWER(TRIM(name))
    HAVING COUNT(*) > 1
) duplicates;

-- Expected Result: Document current state for comparison
-- Pass Criteria: Results documented in baseline report
```

#### Test 1.1.2: Identify All Duplicate Suppliers
```sql
-- Objective: List all duplicate supplier groups with details
SELECT
    LOWER(TRIM(name)) as normalized_name,
    COUNT(*) as duplicate_count,
    ARRAY_AGG(id::text ORDER BY created_at) as supplier_ids,
    ARRAY_AGG(name ORDER BY created_at) as original_names,
    ARRAY_AGG(status::text ORDER BY created_at) as statuses,
    ARRAY_AGG(created_at ORDER BY created_at) as creation_dates
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY LOWER(TRIM(name))
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC, normalized_name;

-- Expected Result: Complete list of duplicate supplier groups
-- Pass Criteria: All duplicates identified with full metadata
```

#### Test 1.1.3: Current Entity Counts
```sql
-- Objective: Baseline count of all major entities
SELECT
    'Suppliers' as entity,
    COUNT(*) as total
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT 'Products', COUNT(*)
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT 'Purchase Orders', COUNT(*)
FROM purchase_order
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT 'PO Line Items', COUNT(*)
FROM purchase_order_item
WHERE purchase_order_id IN (
    SELECT id FROM purchase_order
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
)
UNION ALL
SELECT 'Invoices', COUNT(*)
FROM supplier_invoices
WHERE org_id = '00000000-0000-0000-0000-000000000001'
UNION ALL
SELECT 'Invoice Line Items', COUNT(*)
FROM invoice_line_items
WHERE invoice_id IN (
    SELECT id FROM supplier_invoices
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
)
UNION ALL
SELECT 'Contracts', COUNT(*)
FROM supplier_contracts sc
JOIN supplier s ON sc.supplier_id = s.id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001'
ORDER BY entity;

-- Expected Result: Baseline counts for all entities
-- Pass Criteria: All entity counts documented
```

#### Test 1.1.4: Dependency Analysis
```sql
-- Objective: Identify dependencies for each duplicate supplier
WITH duplicate_suppliers AS (
    SELECT
        LOWER(TRIM(name)) as normalized_name,
        id
    FROM supplier
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
    GROUP BY LOWER(TRIM(name)), id
    HAVING COUNT(*) > 0
)
SELECT
    s.id as supplier_id,
    s.name as supplier_name,
    COUNT(DISTINCT i.id) as product_count,
    COUNT(DISTINCT po.id) as purchase_order_count,
    COUNT(DISTINCT si.id) as invoice_count,
    COUNT(DISTINCT sc.id) as contract_count,
    COALESCE(SUM(po.total_amount), 0) as total_po_value,
    COALESCE(SUM(si.total_amount), 0) as total_invoice_value
FROM supplier s
LEFT JOIN inventory_item i ON s.id = i.supplier_id
LEFT JOIN purchase_order po ON s.id = po.supplier_id
LEFT JOIN supplier_invoices si ON s.id = si.supplier_id
LEFT JOIN supplier_contracts sc ON s.id = sc.supplier_id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY s.id, s.name
ORDER BY s.name;

-- Expected Result: Dependency count for each supplier
-- Pass Criteria: All supplier dependencies documented
```

### 1.2 Backup Validation

#### Test 1.2.1: Verify Backup Creation
```sql
-- Objective: Confirm backup schema exists and contains data
SELECT
    schemaname,
    tablename,
    n_tup_ins as rows_backed_up,
    last_vacuum,
    last_autovacuum
FROM pg_stat_user_tables
WHERE schemaname = 'backup_before_dedup'
ORDER BY tablename;

-- Expected Result: Backup schema with row counts
-- Pass Criteria: All critical tables backed up successfully
```

---

## PHASE 2: POST-CLEANUP VALIDATION

### 2.1 Clean Slate Verification

#### Test 2.1.1: Verify Zero Suppliers
```sql
-- Objective: Confirm complete supplier cleanup
SELECT
    COUNT(*) as remaining_suppliers,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 0 suppliers
-- Pass Criteria: COUNT(*) = 0
```

#### Test 2.1.2: Verify Zero Products
```sql
-- Objective: Confirm complete product cleanup
SELECT
    COUNT(*) as remaining_products,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 0 products
-- Pass Criteria: COUNT(*) = 0
```

#### Test 2.1.3: Verify Zero Purchase Orders
```sql
-- Objective: Confirm complete PO cleanup
SELECT
    COUNT(*) as remaining_pos,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌'
    END as test_status
FROM purchase_order
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 0 purchase orders
-- Pass Criteria: COUNT(*) = 0
```

#### Test 2.1.4: Verify Zero Invoices
```sql
-- Objective: Confirm complete invoice cleanup
SELECT
    COUNT(*) as remaining_invoices,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌'
    END as test_status
FROM supplier_invoices
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 0 invoices
-- Pass Criteria: COUNT(*) = 0
```

#### Test 2.1.5: Verify All Related Tables Empty
```sql
-- Objective: Confirm complete cleanup across all related tables
SELECT
    'PO Line Items' as table_name,
    COUNT(*) as row_count
FROM purchase_order_item
WHERE purchase_order_id NOT IN (SELECT id FROM purchase_order)
UNION ALL
SELECT 'Invoice Line Items', COUNT(*)
FROM invoice_line_items
WHERE invoice_id NOT IN (SELECT id FROM supplier_invoices)
UNION ALL
SELECT 'Contracts', COUNT(*)
FROM supplier_contracts
WHERE supplier_id NOT IN (SELECT id FROM supplier)
UNION ALL
SELECT 'Contract Amendments', COUNT(*)
FROM contract_amendments
WHERE contract_id NOT IN (SELECT id FROM supplier_contracts);

-- Expected Result: All counts = 0
-- Pass Criteria: All row_count = 0
```

#### Test 2.1.6: Verify Sequence Reset
```sql
-- Objective: Confirm auto-increment sequences reset (if applicable)
-- Note: PostgreSQL uses gen_random_uuid() for most tables, no sequences to reset
SELECT
    'Sequence Check' as test_name,
    'N/A - Using UUIDs' as status,
    'PASS ✅' as result;

-- Expected Result: N/A for UUID-based tables
-- Pass Criteria: Acknowledged UUID usage
```

---

## PHASE 3: TEST DATA CREATION VALIDATION

### 3.1 Supplier Creation Validation

#### Test 3.1.1: Verify Exact Count
```sql
-- Objective: Confirm exactly 22 suppliers created
SELECT
    COUNT(*) as supplier_count,
    CASE
        WHEN COUNT(*) = 22 THEN 'PASS ✅'
        WHEN COUNT(*) < 22 THEN 'FAIL ❌ - Insufficient suppliers'
        WHEN COUNT(*) > 22 THEN 'FAIL ❌ - Too many suppliers'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 suppliers
-- Pass Criteria: COUNT(*) = 22
```

#### Test 3.1.2: Verify All Unique Names
```sql
-- Objective: Confirm no duplicate supplier names
SELECT
    COUNT(*) as total_suppliers,
    COUNT(DISTINCT LOWER(TRIM(name))) as unique_names,
    CASE
        WHEN COUNT(*) = COUNT(DISTINCT LOWER(TRIM(name))) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Duplicate names detected'
    END as test_status,
    COUNT(*) - COUNT(DISTINCT LOWER(TRIM(name))) as duplicates
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 suppliers, 22 unique names, 0 duplicates
-- Pass Criteria: total_suppliers = unique_names AND duplicates = 0
```

#### Test 3.1.3: Verify All Suppliers Have Required Fields
```sql
-- Objective: Confirm all suppliers have complete data
SELECT
    COUNT(*) as total_suppliers,
    COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '') as with_name,
    COUNT(*) FILTER (WHERE contact_email IS NOT NULL AND contact_email != '') as with_email,
    COUNT(*) FILTER (WHERE contact_phone IS NOT NULL AND contact_phone != '') as with_phone,
    COUNT(*) FILTER (WHERE address IS NOT NULL) as with_address,
    COUNT(*) FILTER (WHERE status IS NOT NULL) as with_status,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            name IS NOT NULL AND name != '' AND
            contact_email IS NOT NULL AND contact_email != '' AND
            contact_phone IS NOT NULL AND contact_phone != '' AND
            address IS NOT NULL AND
            status IS NOT NULL
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Missing required fields'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 suppliers with complete data
-- Pass Criteria: All counts = 22
```

#### Test 3.1.4: Verify Supplier Data Quality
```sql
-- Objective: Validate supplier data formatting and ranges
SELECT
    COUNT(*) as total_suppliers,
    COUNT(*) FILTER (WHERE risk_score BETWEEN 0 AND 100) as valid_risk_scores,
    COUNT(*) FILTER (WHERE lead_time_days >= 0) as valid_lead_times,
    COUNT(*) FILTER (WHERE status IN ('active', 'inactive', 'suspended', 'pending_approval', 'blocked', 'under_review')) as valid_statuses,
    COUNT(*) FILTER (WHERE contact_email LIKE '%@%') as valid_emails,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            risk_score BETWEEN 0 AND 100 AND
            lead_time_days >= 0 AND
            status IN ('active', 'inactive', 'suspended', 'pending_approval', 'blocked', 'under_review') AND
            contact_email LIKE '%@%'
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Invalid data detected'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 suppliers with valid data
-- Pass Criteria: All validation counts = 22
```

### 3.2 Product Creation Validation

#### Test 3.2.1: Verify Exact Count
```sql
-- Objective: Confirm exactly 22 products created
SELECT
    COUNT(*) as product_count,
    CASE
        WHEN COUNT(*) = 22 THEN 'PASS ✅'
        WHEN COUNT(*) < 22 THEN 'FAIL ❌ - Insufficient products'
        WHEN COUNT(*) > 22 THEN 'FAIL ❌ - Too many products'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 products
-- Pass Criteria: COUNT(*) = 22
```

#### Test 3.2.2: Verify 1 Product Per Supplier
```sql
-- Objective: Confirm each supplier has exactly 1 product
SELECT
    supplier_id,
    COUNT(*) as product_count,
    CASE
        WHEN COUNT(*) = 1 THEN 'PASS ✅'
        WHEN COUNT(*) < 1 THEN 'FAIL ❌ - No products'
        WHEN COUNT(*) > 1 THEN 'FAIL ❌ - Multiple products'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY supplier_id
ORDER BY product_count DESC, supplier_id;

-- Expected Result: All suppliers with exactly 1 product
-- Pass Criteria: All product_count = 1
```

#### Test 3.2.3: Verify All Products Linked to Valid Suppliers
```sql
-- Objective: Confirm no orphaned products
SELECT
    COUNT(i.id) as total_products,
    COUNT(s.id) as products_with_valid_supplier,
    COUNT(i.id) - COUNT(s.id) as orphaned_products,
    CASE
        WHEN COUNT(i.id) = COUNT(s.id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned products detected'
    END as test_status
FROM inventory_item i
LEFT JOIN supplier s ON i.supplier_id = s.id AND s.org_id = i.org_id
WHERE i.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 products, all with valid suppliers, 0 orphans
-- Pass Criteria: orphaned_products = 0
```

#### Test 3.2.4: Verify Product Data Completeness
```sql
-- Objective: Confirm all products have required fields
SELECT
    COUNT(*) as total_products,
    COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '') as with_name,
    COUNT(*) FILTER (WHERE sku IS NOT NULL AND sku != '') as with_sku,
    COUNT(*) FILTER (WHERE unit_price > 0) as with_price,
    COUNT(*) FILTER (WHERE quantity_on_hand >= 0) as with_quantity,
    COUNT(*) FILTER (WHERE category IS NOT NULL) as with_category,
    COUNT(*) FILTER (WHERE supplier_id IS NOT NULL) as with_supplier,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            name IS NOT NULL AND name != '' AND
            sku IS NOT NULL AND sku != '' AND
            unit_price > 0 AND
            quantity_on_hand >= 0 AND
            category IS NOT NULL AND
            supplier_id IS NOT NULL
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Incomplete product data'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 products complete
-- Pass Criteria: All counts = 22
```

### 3.3 Purchase Order Creation Validation

#### Test 3.3.1: Verify Exact Count
```sql
-- Objective: Confirm exactly 22 purchase orders created
SELECT
    COUNT(*) as po_count,
    CASE
        WHEN COUNT(*) = 22 THEN 'PASS ✅'
        WHEN COUNT(*) < 22 THEN 'FAIL ❌ - Insufficient POs'
        WHEN COUNT(*) > 22 THEN 'FAIL ❌ - Too many POs'
    END as test_status
FROM purchase_order
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 purchase orders
-- Pass Criteria: COUNT(*) = 22
```

#### Test 3.3.2: Verify All POs Have Line Items
```sql
-- Objective: Confirm every PO has at least one line item
SELECT
    COUNT(DISTINCT po.id) as total_pos,
    COUNT(DISTINCT poi.purchase_order_id) as pos_with_items,
    COUNT(DISTINCT po.id) - COUNT(DISTINCT poi.purchase_order_id) as pos_without_items,
    CASE
        WHEN COUNT(DISTINCT po.id) = COUNT(DISTINCT poi.purchase_order_id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - POs without line items'
    END as test_status
FROM purchase_order po
LEFT JOIN purchase_order_item poi ON po.id = poi.purchase_order_id
WHERE po.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 POs, all with line items, 0 without
-- Pass Criteria: pos_without_items = 0
```

#### Test 3.3.3: Verify PO Line Items Link to Valid Products
```sql
-- Objective: Confirm all PO line items reference existing products
SELECT
    COUNT(poi.id) as total_line_items,
    COUNT(i.id) as items_with_valid_product,
    COUNT(poi.id) - COUNT(i.id) as orphaned_line_items,
    CASE
        WHEN COUNT(poi.id) = COUNT(i.id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned line items'
    END as test_status
FROM purchase_order_item poi
LEFT JOIN inventory_item i ON poi.inventory_item_id = i.id
WHERE poi.purchase_order_id IN (
    SELECT id FROM purchase_order
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: All line items valid, 0 orphans
-- Pass Criteria: orphaned_line_items = 0
```

#### Test 3.3.4: Verify PO Financial Calculations
```sql
-- Objective: Validate PO total amounts match line item totals
SELECT
    COUNT(*) as total_pos,
    COUNT(*) FILTER (WHERE
        ABS(po.total_amount - COALESCE(line_totals.calculated_total, 0)) < 0.01
    ) as pos_with_correct_totals,
    COUNT(*) - COUNT(*) FILTER (WHERE
        ABS(po.total_amount - COALESCE(line_totals.calculated_total, 0)) < 0.01
    ) as pos_with_incorrect_totals,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            ABS(po.total_amount - COALESCE(line_totals.calculated_total, 0)) < 0.01
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Calculation mismatches'
    END as test_status
FROM purchase_order po
LEFT JOIN (
    SELECT
        purchase_order_id,
        SUM(quantity * unit_price) as calculated_total
    FROM purchase_order_item
    GROUP BY purchase_order_id
) line_totals ON po.id = line_totals.purchase_order_id
WHERE po.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 POs with correct calculations
-- Pass Criteria: pos_with_incorrect_totals = 0
```

### 3.4 Contract Creation Validation

#### Test 3.4.1: Verify Contract Count
```sql
-- Objective: Confirm appropriate number of contracts created
SELECT
    COUNT(*) as contract_count,
    COUNT(DISTINCT sc.supplier_id) as suppliers_with_contracts,
    CASE
        WHEN COUNT(*) > 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - No contracts created'
    END as test_status
FROM supplier_contracts sc
JOIN supplier s ON sc.supplier_id = s.id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: Contracts present (count based on business rules)
-- Pass Criteria: contract_count > 0
```

#### Test 3.4.2: Verify Contract Supplier Linkage
```sql
-- Objective: Confirm all contracts link to valid suppliers
SELECT
    COUNT(sc.id) as total_contracts,
    COUNT(s.id) as contracts_with_valid_supplier,
    COUNT(sc.id) - COUNT(s.id) as orphaned_contracts,
    CASE
        WHEN COUNT(sc.id) = COUNT(s.id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned contracts'
    END as test_status
FROM supplier_contracts sc
LEFT JOIN supplier s ON sc.supplier_id = s.id AND s.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All contracts with valid suppliers, 0 orphans
-- Pass Criteria: orphaned_contracts = 0
```

### 3.5 Invoice Creation Validation

#### Test 3.5.1: Verify Exact Count
```sql
-- Objective: Confirm exactly 22 invoices created
SELECT
    COUNT(*) as invoice_count,
    CASE
        WHEN COUNT(*) = 22 THEN 'PASS ✅'
        WHEN COUNT(*) < 22 THEN 'FAIL ❌ - Insufficient invoices'
        WHEN COUNT(*) > 22 THEN 'FAIL ❌ - Too many invoices'
    END as test_status
FROM supplier_invoices
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 invoices
-- Pass Criteria: COUNT(*) = 22
```

#### Test 3.5.2: Verify All Invoices Match POs
```sql
-- Objective: Confirm every invoice references a valid PO
SELECT
    COUNT(si.id) as total_invoices,
    COUNT(po.id) as invoices_with_valid_po,
    COUNT(si.id) - COUNT(po.id) as invoices_without_po,
    CASE
        WHEN COUNT(si.id) = COUNT(po.id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Invoices without PO reference'
    END as test_status
FROM supplier_invoices si
LEFT JOIN purchase_order po ON si.purchase_order_id = po.id
WHERE si.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: 22 invoices, all with valid PO, 0 without
-- Pass Criteria: invoices_without_po = 0
```

#### Test 3.5.3: Verify Invoice Line Items
```sql
-- Objective: Confirm all invoices have line items
SELECT
    COUNT(DISTINCT si.id) as total_invoices,
    COUNT(DISTINCT ili.invoice_id) as invoices_with_items,
    COUNT(DISTINCT si.id) - COUNT(DISTINCT ili.invoice_id) as invoices_without_items,
    CASE
        WHEN COUNT(DISTINCT si.id) = COUNT(DISTINCT ili.invoice_id) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Invoices without line items'
    END as test_status
FROM supplier_invoices si
LEFT JOIN invoice_line_items ili ON si.id = ili.invoice_id
WHERE si.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 invoices with line items, 0 without
-- Pass Criteria: invoices_without_items = 0
```

#### Test 3.5.4: Verify Invoice Financial Calculations
```sql
-- Objective: Validate invoice amounts match subtotal + tax + shipping
SELECT
    COUNT(*) as total_invoices,
    COUNT(*) FILTER (WHERE
        ABS(total_amount - (subtotal + tax_amount + shipping_amount)) < 0.01
    ) as invoices_with_correct_math,
    COUNT(*) - COUNT(*) FILTER (WHERE
        ABS(total_amount - (subtotal + tax_amount + shipping_amount)) < 0.01
    ) as invoices_with_incorrect_math,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            ABS(total_amount - (subtotal + tax_amount + shipping_amount)) < 0.01
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Calculation errors'
    END as test_status
FROM supplier_invoices
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 invoices with correct math
-- Pass Criteria: invoices_with_incorrect_math = 0
```

#### Test 3.5.5: Verify Invoice-PO Amount Matching
```sql
-- Objective: Confirm invoice amounts reasonably match PO amounts
SELECT
    COUNT(*) as matched_pairs,
    COUNT(*) FILTER (WHERE
        ABS(si.total_amount - po.total_amount) < 0.01
    ) as exact_matches,
    COUNT(*) FILTER (WHERE
        si.total_amount BETWEEN po.total_amount * 0.95 AND po.total_amount * 1.05
    ) as within_5_percent,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE
            si.total_amount BETWEEN po.total_amount * 0.95 AND po.total_amount * 1.05
        ) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Invoice-PO amount mismatches'
    END as test_status
FROM supplier_invoices si
JOIN purchase_order po ON si.purchase_order_id = po.id
WHERE si.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All invoices within reasonable range of PO amounts
-- Pass Criteria: All within_5_percent = matched_pairs
```

### 3.6 Inventory Visibility Validation

#### Test 3.6.1: Verify All Products Visible in Inventory
```sql
-- Objective: Confirm all 22 products are in inventory tables
SELECT
    COUNT(DISTINCT i.id) as total_products,
    COUNT(DISTINCT ii.id) as products_in_inventory,
    COUNT(DISTINCT i.id) - COUNT(DISTINCT ii.id) as products_not_in_inventory,
    CASE
        WHEN COUNT(DISTINCT i.id) = 22 AND COUNT(DISTINCT ii.id) = 22 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Products missing from inventory'
    END as test_status
FROM inventory_item i
LEFT JOIN inventory_item ii ON i.id = ii.id
WHERE i.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 products visible
-- Pass Criteria: products_not_in_inventory = 0
```

#### Test 3.6.2: Verify Multi-Location Inventory (if applicable)
```sql
-- Objective: Confirm products visible at all configured locations
-- Note: Adjust based on actual location table structure
SELECT
    COUNT(DISTINCT product_id) as products_with_locations,
    COUNT(DISTINCT location_id) as unique_locations,
    COUNT(*) as total_inventory_records,
    CASE
        WHEN COUNT(DISTINCT product_id) = 22 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Products missing from locations'
    END as test_status
FROM inventory
WHERE product_id IN (
    SELECT id FROM inventory_item
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: All 22 products at all locations
-- Pass Criteria: products_with_locations = 22
```

---

## PHASE 4: REFERENTIAL INTEGRITY TESTING

### 4.1 Foreign Key Relationship Tests

#### Test 4.1.1: Supplier → Product Relationship
```sql
-- Objective: Verify all products have valid supplier references
SELECT
    'Supplier → Product' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE s.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE s.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE s.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM inventory_item i
LEFT JOIN supplier s ON i.supplier_id = s.id AND i.org_id = s.org_id
WHERE i.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 products with valid supplier references
-- Pass Criteria: broken_references = 0
```

#### Test 4.1.2: Supplier → Purchase Order Relationship
```sql
-- Objective: Verify all POs have valid supplier references
SELECT
    'Supplier → PO' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE s.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE s.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE s.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM purchase_order po
LEFT JOIN supplier s ON po.supplier_id = s.id AND po.org_id = s.org_id
WHERE po.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 POs with valid supplier references
-- Pass Criteria: broken_references = 0
```

#### Test 4.1.3: Purchase Order → PO Line Item Relationship
```sql
-- Objective: Verify all PO line items have valid PO references
SELECT
    'PO → Line Item' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE po.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE po.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE po.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM purchase_order_item poi
LEFT JOIN purchase_order po ON poi.purchase_order_id = po.id
WHERE poi.purchase_order_id IN (
    SELECT id FROM purchase_order
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: All line items with valid PO references
-- Pass Criteria: broken_references = 0
```

#### Test 4.1.4: Purchase Order → Invoice Relationship
```sql
-- Objective: Verify all invoices have valid PO references
SELECT
    'PO → Invoice' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE po.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE po.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE po.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM supplier_invoices si
LEFT JOIN purchase_order po ON si.purchase_order_id = po.id
WHERE si.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 invoices with valid PO references
-- Pass Criteria: broken_references = 0
```

#### Test 4.1.5: Invoice → Invoice Line Item Relationship
```sql
-- Objective: Verify all invoice line items have valid invoice references
SELECT
    'Invoice → Line Item' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE si.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE si.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE si.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM invoice_line_items ili
LEFT JOIN supplier_invoices si ON ili.invoice_id = si.id
WHERE ili.invoice_id IN (
    SELECT id FROM supplier_invoices
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: All line items with valid invoice references
-- Pass Criteria: broken_references = 0
```

#### Test 4.1.6: PO Line Item → Product Relationship
```sql
-- Objective: Verify all PO line items reference valid products
SELECT
    'PO Line Item → Product' as relationship,
    COUNT(*) as total_records,
    COUNT(*) FILTER (WHERE i.id IS NOT NULL) as valid_references,
    COUNT(*) FILTER (WHERE i.id IS NULL) as broken_references,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE i.id IS NOT NULL) THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Broken foreign keys'
    END as test_status
FROM purchase_order_item poi
LEFT JOIN inventory_item i ON poi.inventory_item_id = i.id
WHERE poi.purchase_order_id IN (
    SELECT id FROM purchase_order
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: All line items with valid product references
-- Pass Criteria: broken_references = 0
```

### 4.2 Orphaned Record Detection

#### Test 4.2.1: Orphaned Products
```sql
-- Objective: Detect products without valid suppliers
SELECT
    'Orphaned Products' as test_name,
    COUNT(*) as orphan_count,
    ARRAY_AGG(i.id::text) as orphan_ids,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned products found'
    END as test_status
FROM inventory_item i
LEFT JOIN supplier s ON i.supplier_id = s.id AND i.org_id = s.org_id
WHERE i.org_id = '00000000-0000-0000-0000-000000000001'
AND s.id IS NULL;

-- Expected Result: 0 orphaned products
-- Pass Criteria: orphan_count = 0
```

#### Test 4.2.2: Orphaned PO Line Items
```sql
-- Objective: Detect PO line items without valid POs
SELECT
    'Orphaned PO Line Items' as test_name,
    COUNT(*) as orphan_count,
    ARRAY_AGG(poi.id::text) as orphan_ids,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned line items found'
    END as test_status
FROM purchase_order_item poi
LEFT JOIN purchase_order po ON poi.purchase_order_id = po.id
WHERE po.id IS NULL
AND poi.purchase_order_id IN (
    SELECT id FROM purchase_order
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: 0 orphaned line items
-- Pass Criteria: orphan_count = 0
```

#### Test 4.2.3: Orphaned Invoice Line Items
```sql
-- Objective: Detect invoice line items without valid invoices
SELECT
    'Orphaned Invoice Line Items' as test_name,
    COUNT(*) as orphan_count,
    ARRAY_AGG(ili.id::text) as orphan_ids,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned line items found'
    END as test_status
FROM invoice_line_items ili
LEFT JOIN supplier_invoices si ON ili.invoice_id = si.id
WHERE si.id IS NULL
AND ili.invoice_id IN (
    SELECT id FROM supplier_invoices
    WHERE org_id = '00000000-0000-0000-0000-000000000001'
);

-- Expected Result: 0 orphaned line items
-- Pass Criteria: orphan_count = 0
```

#### Test 4.2.4: Orphaned Contracts
```sql
-- Objective: Detect contracts without valid suppliers
SELECT
    'Orphaned Contracts' as test_name,
    COUNT(*) as orphan_count,
    ARRAY_AGG(sc.id::text) as orphan_ids,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Orphaned contracts found'
    END as test_status
FROM supplier_contracts sc
LEFT JOIN supplier s ON sc.supplier_id = s.id
WHERE s.id IS NULL;

-- Expected Result: 0 orphaned contracts
-- Pass Criteria: orphan_count = 0
```

### 4.3 Cascade Behavior Validation

#### Test 4.3.1: Test Supplier Deletion Cascade (DRY RUN)
```sql
-- Objective: Verify cascade behavior without actual deletion
-- Note: This is a read-only simulation
SELECT
    'Cascade Simulation' as test_name,
    s.id as supplier_id,
    s.name as supplier_name,
    COUNT(DISTINCT i.id) as products_affected,
    COUNT(DISTINCT po.id) as pos_affected,
    COUNT(DISTINCT si.id) as invoices_affected,
    COUNT(DISTINCT sc.id) as contracts_affected,
    'SIMULATED - NO DELETION' as status
FROM supplier s
LEFT JOIN inventory_item i ON s.id = i.supplier_id
LEFT JOIN purchase_order po ON s.id = po.supplier_id
LEFT JOIN supplier_invoices si ON s.id = si.supplier_id
LEFT JOIN supplier_contracts sc ON s.id = sc.supplier_id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY s.id, s.name
ORDER BY s.name
LIMIT 1; -- Test with just one supplier

-- Expected Result: Cascade impact documented
-- Pass Criteria: Results documented, no actual deletion
```

---

## PHASE 5: SYSTEM-WIDE VISIBILITY TESTING

### 5.1 API Endpoint Validation

#### Test 5.1.1: Supplier List API Test
```javascript
// Test script for /api/suppliers endpoint
const testSupplierAPI = async () => {
    const response = await fetch('http://localhost:3000/api/suppliers', {
        headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();

    console.log('Test 5.1.1: Supplier List API');
    console.log(`Status: ${response.status}`);
    console.log(`Suppliers returned: ${data.length}`);
    console.log(`Expected: 22`);
    console.log(`Test Status: ${data.length === 22 ? 'PASS ✅' : 'FAIL ❌'}`);
};

// Expected Result: 22 suppliers returned
// Pass Criteria: data.length === 22 && response.status === 200
```

#### Test 5.1.2: Product List API Test
```javascript
// Test script for /api/products or /api/inventory endpoint
const testProductAPI = async () => {
    const response = await fetch('http://localhost:3000/api/inventory', {
        headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();

    console.log('Test 5.1.2: Product List API');
    console.log(`Status: ${response.status}`);
    console.log(`Products returned: ${data.length}`);
    console.log(`Expected: 22`);
    console.log(`Test Status: ${data.length === 22 ? 'PASS ✅' : 'FAIL ❌'}`);
};

// Expected Result: 22 products returned
// Pass Criteria: data.length === 22 && response.status === 200
```

#### Test 5.1.3: Purchase Order API Test
```javascript
// Test script for /api/purchase-orders endpoint
const testPOAPI = async () => {
    const response = await fetch('http://localhost:3000/api/purchase-orders', {
        headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();

    console.log('Test 5.1.3: Purchase Order API');
    console.log(`Status: ${response.status}`);
    console.log(`POs returned: ${data.length}`);
    console.log(`Expected: 22`);
    console.log(`Test Status: ${data.length === 22 ? 'PASS ✅' : 'FAIL ❌'}`);
};

// Expected Result: 22 POs returned
// Pass Criteria: data.length === 22 && response.status === 200
```

#### Test 5.1.4: Invoice API Test
```javascript
// Test script for /api/invoices endpoint
const testInvoiceAPI = async () => {
    const response = await fetch('http://localhost:3000/api/invoices', {
        headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();

    console.log('Test 5.1.4: Invoice API');
    console.log(`Status: ${response.status}`);
    console.log(`Invoices returned: ${data.length}`);
    console.log(`Expected: 22`);
    console.log(`Test Status: ${data.length === 22 ? 'PASS ✅' : 'FAIL ❌'}`);
};

// Expected Result: 22 invoices returned
// Pass Criteria: data.length === 22 && response.status === 200
```

### 5.2 UI Display Validation

#### Test 5.2.1: Supplier UI Display
```sql
-- Objective: Verify UI-ready supplier data
SELECT
    COUNT(*) as total_suppliers,
    COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '') as displayable_names,
    COUNT(*) FILTER (WHERE contact_email IS NOT NULL) as displayable_emails,
    COUNT(*) FILTER (WHERE status IS NOT NULL) as displayable_status,
    CASE
        WHEN COUNT(*) = 22 AND
             COUNT(*) = COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '')
        THEN 'PASS ✅'
        ELSE 'FAIL ❌ - UI display issues'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 suppliers UI-ready
-- Pass Criteria: All displayable counts = 22
```

#### Test 5.2.2: Product UI Display
```sql
-- Objective: Verify UI-ready product data
SELECT
    COUNT(*) as total_products,
    COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '') as displayable_names,
    COUNT(*) FILTER (WHERE unit_price > 0) as displayable_prices,
    COUNT(*) FILTER (WHERE sku IS NOT NULL) as displayable_skus,
    CASE
        WHEN COUNT(*) = 22 AND
             COUNT(*) = COUNT(*) FILTER (WHERE name IS NOT NULL AND name != '')
        THEN 'PASS ✅'
        ELSE 'FAIL ❌ - UI display issues'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 products UI-ready
-- Pass Criteria: All displayable counts = 22
```

### 5.3 Search Functionality Testing

#### Test 5.3.1: Supplier Search by Name
```sql
-- Objective: Verify search returns correct results
-- Test: Search for "Alpha"
SELECT
    COUNT(*) as search_results,
    ARRAY_AGG(name) as found_suppliers,
    CASE
        WHEN COUNT(*) > 0 THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Search not working'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
AND LOWER(name) LIKE '%alpha%';

-- Expected Result: At least 1 result (Alpha Technologies)
-- Pass Criteria: search_results >= 1
```

#### Test 5.3.2: Product Search by SKU
```sql
-- Objective: Verify product search functionality
SELECT
    COUNT(*) as total_searchable_products,
    COUNT(*) FILTER (WHERE sku IS NOT NULL AND sku != '') as products_with_sku,
    CASE
        WHEN COUNT(*) = COUNT(*) FILTER (WHERE sku IS NOT NULL AND sku != '')
        THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Missing SKUs'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: All 22 products searchable by SKU
-- Pass Criteria: products_with_sku = 22
```

### 5.4 Filter and Pagination Testing

#### Test 5.4.1: Supplier Status Filtering
```sql
-- Objective: Verify filtering by supplier status
SELECT
    status,
    COUNT(*) as count,
    CASE
        WHEN COUNT(*) > 0 THEN 'PASS ✅'
        ELSE 'INFO - No suppliers in this status'
    END as test_status
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY status
ORDER BY status;

-- Expected Result: All statuses with counts
-- Pass Criteria: At least one status group present
```

#### Test 5.4.2: Product Category Filtering
```sql
-- Objective: Verify filtering by product category
SELECT
    category,
    COUNT(*) as count,
    CASE
        WHEN COUNT(*) > 0 THEN 'PASS ✅'
        ELSE 'INFO - No products in this category'
    END as test_status
FROM inventory_item
WHERE org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY category
ORDER BY category;

-- Expected Result: All categories with counts
-- Pass Criteria: At least one category group present
```

#### Test 5.4.3: Pagination Test
```sql
-- Objective: Verify pagination returns correct records
-- Test: Get first 10 suppliers
SELECT
    id,
    name,
    status,
    created_at
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
ORDER BY name
LIMIT 10 OFFSET 0;

-- Test: Get next 10 suppliers
SELECT
    id,
    name,
    status,
    created_at
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
ORDER BY name
LIMIT 10 OFFSET 10;

-- Expected Result: 10 unique suppliers per page
-- Pass Criteria: No overlap between pages
```

### 5.5 Report Generation Testing

#### Test 5.5.1: Supplier Performance Report
```sql
-- Objective: Verify reporting data completeness
SELECT
    s.name as supplier_name,
    COUNT(DISTINCT i.id) as product_count,
    COUNT(DISTINCT po.id) as po_count,
    COALESCE(SUM(po.total_amount), 0) as total_spend,
    COALESCE(AVG(po.total_amount), 0) as avg_po_value,
    s.risk_score,
    s.lead_time_days,
    CASE
        WHEN COUNT(DISTINCT po.id) > 0 THEN 'PASS ✅'
        ELSE 'INFO - No activity'
    END as test_status
FROM supplier s
LEFT JOIN inventory_item i ON s.id = i.supplier_id
LEFT JOIN purchase_order po ON s.id = po.supplier_id
WHERE s.org_id = '00000000-0000-0000-0000-000000000001'
GROUP BY s.id, s.name, s.risk_score, s.lead_time_days
ORDER BY total_spend DESC;

-- Expected Result: Complete report for all 22 suppliers
-- Pass Criteria: 22 rows returned with all data
```

#### Test 5.5.2: Financial Summary Report
```sql
-- Objective: Verify financial reporting accuracy
SELECT
    COUNT(DISTINCT po.id) as total_pos,
    COALESCE(SUM(po.total_amount), 0) as total_po_value,
    COUNT(DISTINCT si.id) as total_invoices,
    COALESCE(SUM(si.total_amount), 0) as total_invoice_value,
    COALESCE(SUM(si.paid_amount), 0) as total_paid,
    COALESCE(SUM(si.total_amount) - SUM(si.paid_amount), 0) as outstanding,
    CASE
        WHEN COUNT(DISTINCT po.id) = 22 AND COUNT(DISTINCT si.id) = 22
        THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Incomplete financial data'
    END as test_status
FROM purchase_order po
FULL OUTER JOIN supplier_invoices si ON po.id = si.purchase_order_id
WHERE po.org_id = '00000000-0000-0000-0000-000000000001'
OR si.org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: Complete financial summary
-- Pass Criteria: All counts = 22
```

---

## PHASE 6: EDGE CASE TESTING

### 6.1 Concurrent Access Testing

#### Test 6.1.1: Simultaneous Read Test
```javascript
// Test script for concurrent supplier reads
const testConcurrentReads = async () => {
    const promises = Array(10).fill(null).map(() =>
        fetch('http://localhost:3000/api/suppliers')
    );

    const results = await Promise.all(promises);
    const allSuccess = results.every(r => r.status === 200);

    console.log('Test 6.1.1: Concurrent Reads');
    console.log(`All requests successful: ${allSuccess}`);
    console.log(`Test Status: ${allSuccess ? 'PASS ✅' : 'FAIL ❌'}`);
};

// Expected Result: All reads successful
// Pass Criteria: All status codes = 200
```

### 6.2 Data Consistency Under Load

#### Test 6.2.1: High-Volume Query Test
```sql
-- Objective: Verify data consistency under repeated queries
-- Run this query 100 times and verify consistent results
SELECT COUNT(*) as supplier_count
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: Always returns 22
-- Pass Criteria: All queries return identical count
```

### 6.3 Boundary Value Testing

#### Test 6.3.1: Empty Result Set Handling
```sql
-- Objective: Verify system handles empty searches gracefully
SELECT COUNT(*) as result_count
FROM supplier
WHERE org_id = '00000000-0000-0000-0000-000000000001'
AND name LIKE '%NONEXISTENT_SUPPLIER_XYZ%';

-- Expected Result: 0 results
-- Pass Criteria: Query executes without error, returns 0
```

#### Test 6.3.2: Maximum Value Handling
```sql
-- Objective: Verify system handles large values correctly
SELECT
    MAX(total_amount) as max_po_amount,
    MIN(total_amount) as min_po_amount,
    CASE
        WHEN MAX(total_amount) > 0 AND MIN(total_amount) > 0
        THEN 'PASS ✅'
        ELSE 'FAIL ❌ - Invalid amounts'
    END as test_status
FROM purchase_order
WHERE org_id = '00000000-0000-0000-0000-000000000001';

-- Expected Result: Valid min/max values
-- Pass Criteria: Both values > 0
```

---

## FINAL VALIDATION SUMMARY

### Success Criteria Verification

```sql
-- COMPREHENSIVE FINAL VALIDATION QUERY
WITH validation_metrics AS (
    SELECT
        -- Supplier metrics
        (SELECT COUNT(*) FROM supplier WHERE org_id = '00000000-0000-0000-0000-000000000001') as supplier_count,
        (SELECT COUNT(DISTINCT LOWER(TRIM(name))) FROM supplier WHERE org_id = '00000000-0000-0000-0000-000000000001') as unique_supplier_names,

        -- Product metrics
        (SELECT COUNT(*) FROM inventory_item WHERE org_id = '00000000-0000-0000-0000-000000000001') as product_count,
        (SELECT COUNT(DISTINCT supplier_id) FROM inventory_item WHERE org_id = '00000000-0000-0000-0000-000000000001') as suppliers_with_products,

        -- Purchase order metrics
        (SELECT COUNT(*) FROM purchase_order WHERE org_id = '00000000-0000-0000-0000-000000000001') as po_count,
        (SELECT COUNT(*) FROM purchase_order WHERE org_id = '00000000-0000-0000-0000-000000000001' AND id IN (SELECT DISTINCT purchase_order_id FROM purchase_order_item)) as pos_with_items,

        -- Invoice metrics
        (SELECT COUNT(*) FROM supplier_invoices WHERE org_id = '00000000-0000-0000-0000-000000000001') as invoice_count,
        (SELECT COUNT(*) FROM supplier_invoices WHERE org_id = '00000000-0000-0000-0000-000000000001' AND purchase_order_id IS NOT NULL) as invoices_with_po,

        -- Orphan checks
        (SELECT COUNT(*) FROM inventory_item i LEFT JOIN supplier s ON i.supplier_id = s.id AND i.org_id = s.org_id WHERE i.org_id = '00000000-0000-0000-0000-000000000001' AND s.id IS NULL) as orphaned_products,
        (SELECT COUNT(*) FROM purchase_order_item poi LEFT JOIN purchase_order po ON poi.purchase_order_id = po.id WHERE po.id IS NULL) as orphaned_po_items,
        (SELECT COUNT(*) FROM invoice_line_items ili LEFT JOIN supplier_invoices si ON ili.invoice_id = si.id WHERE si.id IS NULL) as orphaned_invoice_items
)
SELECT
    '✅ Exactly 22 unique suppliers' as criterion,
    supplier_count as actual,
    22 as expected,
    CASE WHEN supplier_count = 22 AND unique_supplier_names = 22 THEN 'PASS ✅' ELSE 'FAIL ❌' END as status
FROM validation_metrics
UNION ALL
SELECT
    '✅ Exactly 22 products (1 per supplier)',
    product_count,
    22,
    CASE WHEN product_count = 22 AND suppliers_with_products = 22 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics
UNION ALL
SELECT
    '✅ Exactly 22 purchase orders with line items',
    po_count,
    22,
    CASE WHEN po_count = 22 AND pos_with_items = 22 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics
UNION ALL
SELECT
    '✅ Exactly 22 invoices matching POs',
    invoice_count,
    22,
    CASE WHEN invoice_count = 22 AND invoices_with_po = 22 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics
UNION ALL
SELECT
    '✅ Zero orphaned products',
    orphaned_products,
    0,
    CASE WHEN orphaned_products = 0 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics
UNION ALL
SELECT
    '✅ Zero orphaned PO line items',
    orphaned_po_items,
    0,
    CASE WHEN orphaned_po_items = 0 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics
UNION ALL
SELECT
    '✅ Zero orphaned invoice line items',
    orphaned_invoice_items,
    0,
    CASE WHEN orphaned_invoice_items = 0 THEN 'PASS ✅' ELSE 'FAIL ❌' END
FROM validation_metrics;
```

---

## SYSTEM HEALTH METRICS

### Database Performance

```sql
-- Database connection health
SELECT
    'Database Connections' as metric,
    numbackends as current_connections,
    CASE WHEN numbackends < 20 THEN 'HEALTHY ✅' ELSE 'WARNING ⚠️' END as status
FROM pg_stat_database
WHERE datname = 'nxtprod-db_001';

-- Query performance
SELECT
    'Average Query Time' as metric,
    ROUND(AVG(total_exec_time), 2) as avg_time_ms,
    CASE WHEN AVG(total_exec_time) < 100 THEN 'HEALTHY ✅' ELSE 'WARNING ⚠️' END as status
FROM pg_stat_statements
WHERE query LIKE '%supplier%' OR query LIKE '%inventory%'
LIMIT 1;

-- Table sizes
SELECT
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as total_size,
    CASE WHEN pg_total_relation_size(schemaname||'.'||tablename) < 100000000 THEN 'HEALTHY ✅' ELSE 'INFO' END as status
FROM pg_tables
WHERE schemaname = 'public'
AND tablename IN ('supplier', 'inventory_item', 'purchase_order', 'supplier_invoices')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

---

## EXECUTION INSTRUCTIONS

### Running the Complete Test Suite

```bash
# 1. Set environment variables
export DB_HOST=62.169.20.53
export DB_PORT=6600
export DB_USER=nxtdb_admin
export DB_PASSWORD='P@33w0rd-1'
export DB_NAME=nxtprod-db_001

# 2. Create test execution script
cat > /mnt/k/00Project/MantisNXT/scripts/run_comprehensive_tests.js << 'EOF'
const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
    host: process.env.DB_HOST || '62.169.20.53',
    port: parseInt(process.env.DB_PORT || '6600'),
    user: process.env.DB_USER || 'nxtdb_admin',
    password: process.env.DB_PASSWORD || 'P@33w0rd-1',
    database: process.env.DB_NAME || 'nxtprod-db_001',
    ssl: false
});

async function runAllTests() {
    console.log('🧪 COMPREHENSIVE E2E QUALITY VALIDATION');
    console.log('========================================\\n');

    // Read test queries from report file
    // Execute each phase sequentially
    // Collect results
    // Generate pass/fail report

    console.log('✅ All tests complete');
}

runAllTests().finally(() => pool.end());
EOF

# 3. Run the test suite
node /mnt/k/00Project/MantisNXT/scripts/run_comprehensive_tests.js
```

---

## TEST REPORTING FORMAT

### Test Result Template

```
PHASE X: [PHASE NAME]
======================

Test X.X.X: [Test Name]
Objective: [What we're testing]
Expected: [Expected result]
Actual: [Actual result]
Status: [PASS ✅ | FAIL ❌ | WARNING ⚠️]
Notes: [Additional observations]

---
```

### Summary Report Template

```
🎯 FINAL QUALITY VALIDATION SUMMARY
====================================

SUCCESS CRITERIA:
✅ Exactly 22 unique suppliers: [PASS/FAIL]
✅ Exactly 22 products (1 per supplier): [PASS/FAIL]
✅ Exactly 22 purchase orders with line items: [PASS/FAIL]
✅ Exactly 22 invoices matching POs: [PASS/FAIL]
✅ All products visible in inventory: [PASS/FAIL]
✅ Zero orphaned records: [PASS/FAIL]
✅ All relationships intact: [PASS/FAIL]
✅ System-wide visibility confirmed: [PASS/FAIL]

OVERALL STATUS: [PASS ✅ | FAIL ❌]
DATA INTEGRITY: [XX%]
TEST COVERAGE: [XX%]
SYSTEM HEALTH: [HEALTHY ✅ | ISSUES ⚠️]

SIGN-OFF: [Date] [Quality Engineer Name]
```

---

## NEXT STEPS BASED ON RESULTS

### If All Tests PASS ✅
1. Document final system state
2. Create data snapshot for future reference
3. System ready for production use
4. Schedule regular integrity checks

### If Any Tests FAIL ❌
1. Identify root cause of failure
2. Document specific failure details
3. Create remediation plan
4. Re-run affected test after fix
5. Full validation re-run after all fixes

---

**End of Comprehensive E2E Quality Validation Report**