# MantisNXT System Architecture Failure Analysis & Recovery Plan

## **🚨 EXECUTIVE SUMMARY**

**Status**: CASCADING SYSTEM FAILURE DETECTED
**Risk Level**: CRITICAL
**Impact**: Production system instability with multiple failure points
**Recovery Timeline**: Immediate action required (1-4 hours)

## **💥 ROOT CAUSE ANALYSIS**

### **Primary Failure Pattern: Architectural Inconsistency Cascade**

The system is experiencing a classic **dependency hell** scenario where multiple architectural layers are failing in sequence:

```
Database Layer (Layer 1) → Connection Layer (Layer 2) → API Layer (Layer 3) → Build Layer (Layer 4)
     ↓                        ↓                        ↓                        ↓
Schema Mismatches     →   Pool Exhaustion      →   Route Failures    →   Build Blocked
```

### **Critical Issues Identified**

#### **1. Database Connection Architecture Conflict**
- **Legacy vs Enterprise**: Two competing database connection systems
- **Pool Competition**: Multiple pool instances fighting for same connections
- **Resource Exhaustion**: 20 max connections overwhelmed by 3+ competing pools

#### **2. Build System Degradation**
- **Next.js 15 Migration Issues**: Async parameter patterns not fully implemented
- **TypeScript Compilation Failures**: Build process timing out consistently
- **Dependency Conflicts**: Version mismatches in critical packages

#### **3. Schema Evolution Problems**
- **Table Reference Errors**: APIs referencing non-existent tables
- **Missing Migration State**: Incomplete database schema transitions
- **Foreign Key Constraints**: Broken relationships between entities

## **🏗️ SYSTEM ARCHITECTURE MAPPING**

### **Current State Analysis**

```mermaid
graph TB
    A[Next.js 15 Application] --> B[Database Layer]
    B --> C[Legacy Connection Pool]
    B --> D[Enterprise Connection Manager]
    B --> E[Direct Pool from connection.ts]

    C --> F[(PostgreSQL Database)]
    D --> F
    E --> F

    A --> G[API Routes]
    G --> H[Suppliers API]
    G --> I[Inventory API]
    G --> J[Analytics API]

    F --> K[Schema Issues]
    K --> L[Missing Tables]
    K --> M[Broken References]
    K --> N[Constraint Violations]

    style F fill:#ff9999
    style K fill:#ff6666
    style B fill:#ffcc99
```

### **Failure Points Detailed**

| Layer | Component | Status | Impact | Recovery Priority |
|-------|-----------|---------|---------|-------------------|
| **Build** | Next.js Compilation | ⚠️ Timeout | Deployment blocked | 🔴 Critical |
| **API** | Route Handlers | ❌ 500 Errors | Core functions down | 🔴 Critical |
| **Database** | Connection Pools | ⚠️ Exhausted | Query failures | 🔴 Critical |
| **Schema** | Table References | ❌ Missing | Data layer broken | 🟡 High |

## **🔧 IMMEDIATE RECOVERY PLAN**

### **Phase 1: Emergency Stabilization (30 minutes)**

#### **1.1 Database Connection Unification**
```typescript
// IMMEDIATE ACTION: Standardize all imports to single connection
// Replace all instances of:
import { pool } from '@/lib/database/connection' // ✅ USE THIS
// Remove:
import { db } from '@/lib/database'              // ❌ REMOVE
import { enterpriseDb } from '@/lib/database/enterprise-connection-manager' // ❌ REMOVE
```

#### **1.2 Build System Recovery**
```bash
# Clear all caches and restart clean
rm -rf .next node_modules tsconfig.tsbuildinfo
npm install
npm run build -- --no-cache
```

#### **1.3 Critical Route Fixes**
- Fix async parameter patterns for Next.js 15 compliance
- Standardize error handling across all routes
- Remove enterprise connection manager dependencies

### **Phase 2: Architecture Consolidation (60 minutes)**

#### **2.1 Single Connection Pattern**
```typescript
// lib/database/connection.ts - KEEP THIS AS ONLY CONNECTION
export const pool = new Pool({
  host: "62.169.20.53",
  port: 6600,
  database: "nxtprod-db_001",
  user: "nxtdb_admin",
  password: "P@33w0rd-1",
  ssl: false,
  max: 15,               // Reduced from competing pools
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000  // Reasonable timeout
});
```

#### **2.2 API Route Standardization**
```typescript
// Standard pattern for ALL routes
import { pool } from '@/lib/database/connection';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const result = await pool.query('SELECT * FROM table_name');
    return NextResponse.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
```

### **Phase 3: Schema Recovery (90 minutes)**

#### **3.1 Database Health Assessment**
```bash
# Test database connectivity
curl http://localhost:3000/api/health/database

# Expected response should show:
# - All required tables exist
# - Connection pool healthy
# - No schema conflicts
```

#### **3.2 Missing Table Creation**
```sql
-- Execute if health check shows missing tables
CREATE TABLE IF NOT EXISTS organizations (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  organization_id INTEGER REFERENCES organizations(id),
  email VARCHAR(255) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### **Phase 4: System Validation (30 minutes)**

#### **4.1 Build Verification**
```bash
npm run build     # Should complete without timeout
npm run lint      # Should show no critical errors
npm run type-check # TypeScript should compile
```

#### **4.2 API Endpoint Testing**
```bash
# Core functionality tests
curl "http://localhost:3000/api/suppliers"
curl "http://localhost:3000/api/inventory/items"
curl "http://localhost:3000/api/analytics/dashboard?organizationId=1"
curl "http://localhost:3000/api/health/database"
```

## **🎯 SPECIFIC FIXES REQUIRED**

### **Critical File Modifications**

#### **1. Remove Enterprise Connection Manager Dependencies**
```bash
# Files to modify:
- src/lib/database.ts
- src/app/api/analytics/anomalies/route.ts
- src/app/api/analytics/predictions/route.ts
- src/app/api/analytics/recommendations/route.ts
- src/app/api/health/database-enterprise/route.ts
```

#### **2. Standardize Database Imports**
```typescript
// BEFORE (Multiple patterns causing conflicts)
import { enterpriseDb } from './database/enterprise-connection-manager';
import { db } from '@/lib/database';
import { pool } from '@/lib/database/connection';

// AFTER (Single pattern across all files)
import { pool } from '@/lib/database/connection';
```

#### **3. Fix Next.js 15 Async Parameters**
```typescript
// BEFORE (Next.js 14 pattern)
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { id } = params; // This fails in Next.js 15
}

// AFTER (Next.js 15 pattern)
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params; // Correct async handling
}
```

## **🛡️ PREVENTION STRATEGY**

### **Architectural Principles**

#### **1. Single Responsibility Database Layer**
- **ONE connection pool** across entire application
- **ONE import pattern** for database access
- **ONE error handling strategy** for consistency

#### **2. Fail-Safe Design Pattern**
```typescript
// Circuit breaker pattern for database queries
export async function safeQuery(query: string, params?: any[]) {
  const maxRetries = 3;
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      return await pool.query(query, params);
    } catch (error) {
      attempt++;
      if (attempt === maxRetries) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
}
```

#### **3. Build System Resilience**
```json
// next.config.js - Add build optimization
{
  "experimental": {
    "optimizeCss": true,
    "optimizePackageImports": ["lucide-react", "@radix-ui/react-*"]
  },
  "typescript": {
    "ignoreBuildErrors": false
  }
}
```

## **📊 SUCCESS METRICS**

### **Recovery Validation Checklist**

- [ ] **Build Success**: `npm run build` completes under 2 minutes
- [ ] **Database Connectivity**: Health endpoint returns 100% success rate
- [ ] **API Functionality**: All core endpoints return 200 status
- [ ] **Schema Integrity**: No missing table errors in logs
- [ ] **Connection Stability**: Pool utilization stays under 80%

### **Performance Targets**

| Metric | Current | Target | Status |
|--------|---------|---------|---------|
| Build Time | >60s (timeout) | <120s | 🔴 Failed |
| API Response | >5000ms (timeout) | <500ms | 🔴 Failed |
| DB Pool Utilization | 100% (exhausted) | <80% | 🔴 Failed |
| Error Rate | >35% | <1% | 🔴 Failed |

## **🚀 DEPLOYMENT STRATEGY**

### **Rollback Plan**
```bash
# If recovery fails, immediate rollback steps:
git checkout HEAD~1                    # Revert to last stable commit
rm -rf .next node_modules             # Clean state
npm install                           # Fresh dependencies
npm run build                         # Test build
```

### **Testing Protocol**
1. **Unit Tests**: Individual component functionality
2. **Integration Tests**: Database → API → Frontend flow
3. **Load Tests**: Connection pool under stress
4. **Recovery Tests**: Failure scenario handling

## **⏰ IMPLEMENTATION TIMELINE**

| Phase | Duration | Actions | Validation |
|-------|----------|---------|------------|
| **Emergency** | 30 min | Connection unification, build fixes | Build success |
| **Consolidation** | 60 min | Architecture cleanup, route fixes | API tests pass |
| **Schema** | 90 min | Database repairs, missing tables | Health check 100% |
| **Validation** | 30 min | End-to-end testing, monitoring | All systems green |

---

## **🎯 EXECUTIVE DECISION REQUIRED**

**RECOMMENDED ACTION**: Execute immediate recovery plan with **Phase 1 Emergency Stabilization**

**BUSINESS IMPACT**: Each hour of delay risks:
- Complete production system failure
- Data corruption from connection races
- Extended downtime during peak usage

**NEXT STEPS**:
1. Approve emergency database connection unification
2. Authorize temporary service interruption for fixes
3. Deploy monitoring for post-recovery validation

---

*Document Created: 2025-09-25*
*Classification: CRITICAL SYSTEM RECOVERY*
*Review Required: System Architecture Team*