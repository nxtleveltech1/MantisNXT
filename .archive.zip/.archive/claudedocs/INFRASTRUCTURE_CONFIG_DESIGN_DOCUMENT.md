# DESIGN DOCUMENT - INFRASTRUCTURE CONFIG REVIEWER

## Executive Summary

**Critical Finding**: Current configuration uses enterprise database (62.169.20.53:6600) with pool settings that **completely conflict** with Neon serverless requirements mentioned in the task. The system is NOT using Neon at all.

**Configuration Reality**:
- **Current Database**: PostgreSQL @ 62.169.20.53:6600 (Enterprise on-premise)
- **Pool Settings**: MIN=10, MAX=50 (Enterprise-grade connection pooling)
- **SSL**: Not required for on-premise database
- **Neon Integration**: Only exists in compiled .next bundles (legacy code)

**Analysis Conclusion**: The task brief assumes Neon usage, but the actual deployment uses an enterprise PostgreSQL server. This document provides TWO design paths:

1. **Path A**: Neon Migration (if adopting Neon serverless)
2. **Path B**: Enterprise Optimization (current on-premise setup)

---

## PATH A: NEON MIGRATION DESIGN (If Adopting Neon)

### ADR-030: Neon Connection Pool Sizing

**Decision**: Migrate to Neon-optimized pool configuration
```env
# Neon Free Tier Limits
DB_POOL_MIN=2
DB_POOL_MAX=8
DB_POOL_IDLE_TIMEOUT=300000  # 5 minutes (matches Neon suspend)
DB_POOL_CONNECTION_TIMEOUT=15000  # 15 seconds
```

**Rationale**:
- Neon free tier: 10 max connections
- Reserve 2 for admin/monitoring/pgbouncer
- Application pool: 8 connections maximum
- Min pool: 2 for cold start performance (Neon serverless wakeup)
- Idle timeout: 5 minutes matches Neon's compute suspend behavior

**Current Configuration Conflicts**:
```diff
# .env.local (Current - ENTERPRISE SETTINGS)
- DB_POOL_MIN=10              # ❌ Exceeds Neon limit entirely
- DB_POOL_MAX=50              # ❌ 5x over Neon max connections
- DB_POOL_IDLE_TIMEOUT=30000  # ❌ Too short for Neon serverless
+ DB_POOL_MIN=2               # ✅ Neon-compatible minimum
+ DB_POOL_MAX=8               # ✅ Within Neon free tier
+ DB_POOL_IDLE_TIMEOUT=300000 # ✅ Matches Neon suspend behavior
```

**Migration Steps**:
1. Provision Neon database project
2. Update DATABASE_URL to Neon pooler endpoint
3. Apply new pool configuration
4. Test connection limits under load
5. Monitor for "too many clients" errors

**Acceptance Criteria**:
- [ ] No "too many clients" errors for 1 hour under normal load
- [ ] Pool utilization <80% during peak operations
- [ ] Connection acquisition time <200ms p95 (accounting for cold starts)
- [ ] Successful Neon compute suspend/resume cycle

**Rollback**: Revert DATABASE_URL to enterprise endpoint

---

### ADR-031: Neon DATABASE_URL Complete Parameters

**Decision**: Add Neon-specific timeout parameters and pooler configuration

**Current**:
```env
DATABASE_URL=postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001
```

**Target Neon Configuration**:
```env
DATABASE_URL=postgresql://[user]:[password]@[project]-pooler.neon.tech/neondb?sslmode=require&connect_timeout=10&statement_timeout=30000&idle_in_transaction_session_timeout=60000&pool_timeout=10&application_name=mantisnxt
```

**Parameter Justification**:

| Parameter | Value | Purpose | Benefit |
|-----------|-------|---------|---------|
| `sslmode` | `require` | Mandatory for Neon connections | Security compliance |
| `connect_timeout` | `10` | 10-second connection limit | Fast failure on network issues |
| `statement_timeout` | `30000` | 30s query timeout | Server-side runaway query protection |
| `idle_in_transaction_session_timeout` | `60000` | 60s idle transaction cleanup | Prevents connection leaks |
| `pool_timeout` | `10` | 10s pooler wait timeout | Neon pooler-specific tuning |
| `application_name` | `mantisnxt` | Connection identification | Neon console observability |

**Neon Pooler Endpoint**:
- Use `-pooler.neon.tech` endpoint for connection pooling
- Avoids direct compute connection limits
- Automatic connection multiplexing

**Acceptance Criteria**:
- [ ] Long queries auto-terminated at 30s
- [ ] Idle transactions cleaned after 60s
- [ ] Connections visible in Neon console as "mantisnxt"
- [ ] Pooler connections successful under load

**Monitoring**: Query `/api/health/query-metrics` for timeout events

---

### ADR-032: Environment Variable Consolidation (Neon Path)

**Decision**: Remove enterprise variables, adopt Neon-specific configuration

**Current State** (.env.local):
```env
# Enterprise Database - REMOVE ENTIRELY
DATABASE_URL=postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001
DB_HOST=62.169.20.53
DB_PORT=6600
DB_USER=nxtdb_admin
DB_PASSWORD=P@33w0rd-1
DB_NAME=nxtprod-db_001

# Conflicting Pool Settings - REMOVE
DB_POOL_MIN=10
DB_POOL_MAX=50
DB_POOL_IDLE_TIMEOUT=30000
DB_POOL_CONNECTION_TIMEOUT=5000
DB_POOL_ACQUIRE_TIMEOUT=30000
```

**Target Neon State**:
```env
# Neon Database Connection (Single Source of Truth)
DATABASE_URL=postgresql://[user]:[password]@ep-xyz-pooler.neon.tech/neondb?sslmode=require&connect_timeout=10&statement_timeout=30000&idle_in_transaction_session_timeout=60000&pool_timeout=10&application_name=mantisnxt

# Neon Connection Pool Settings
DB_POOL_MIN=2
DB_POOL_MAX=8
DB_POOL_IDLE_TIMEOUT=300000
DB_POOL_CONNECTION_TIMEOUT=15000

# Feature Flags
ENABLE_NEON_DATABASE=true

# Remove These Variables Entirely:
# - DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
# - ENTERPRISE_DATABASE_URL
# - NEON_POOL_MAX, NEON_POOL_MIN (redundant with DB_POOL_*)
```

**Rationale**:
- **Single Source of Truth**: DATABASE_URL contains all connection details
- **No Duplication**: Remove individual host/port/user variables
- **Neon-Specific**: Pool settings optimized for serverless behavior
- **Clear Naming**: DB_POOL_* prefix for application-level pooling

**Code Changes Required**:

**File**: `lib/database/enterprise-connection-manager.ts`
```typescript
// Line 100-108: buildConfigFromEnv()
private buildConfigFromEnv(): PoolConfig {
  const connectionString =
    process.env.DATABASE_URL; // ✅ Remove ENTERPRISE_DATABASE_URL fallback

  if (!connectionString) {
    throw new Error('DATABASE_URL must be set'); // ✅ Simplified error
  }

  // ✅ Neon ALWAYS requires SSL via pooler
  const requiresSsl = connectionString.includes('neon.tech') ||
                      connectionString.includes('sslmode=require');

  return {
    connectionString,
    max: Math.min(
      this.parseIntEnv("DB_POOL_MAX", DEFAULT_MAX_POOL),
      10  // ✅ Hard cap for Neon free tier
    ),
    min: this.parseIntEnv("DB_POOL_MIN", 2), // ✅ Neon-optimized default
    idleTimeoutMillis: this.parseIntEnv("DB_POOL_IDLE_TIMEOUT", 300000), // ✅ 5 minutes
    connectionTimeoutMillis: this.parseIntEnv("DB_POOL_CONNECTION_TIMEOUT", 15000), // ✅ 15 seconds
    ssl: requiresSsl ? { rejectUnauthorized: false } : undefined,
  };
}
```

**Acceptance Criteria**:
- [ ] No references to DB_HOST, DB_PORT, DB_USER, DB_PASSWORD in code
- [ ] All connections use DATABASE_URL exclusively
- [ ] Pool max cannot exceed 10 even with manual override
- [ ] Environment validation on startup

**Validation Command**:
```bash
grep -r "DB_HOST\|DB_PORT\|DB_USER\|DB_PASSWORD" lib/database/ --include="*.ts"
# Should return: No matches
```

---

### ADR-033: Circuit Breaker Tuning for Neon Serverless

**Decision**: Adjust circuit breaker sensitivity for Neon cold starts

**Current Circuit Breaker** (enterprise-connection-manager.ts):
```typescript
private readonly circuitBreaker: CircuitBreakerState = {
  state: "closed",
  failures: 0,
  consecutiveSuccesses: 0,
  threshold: 3,              // ❌ Too sensitive for Neon cold starts
  resetTimeout: 60000,       // 60s
  lastFailure: null,
  openUntil: 0,
};
```

**Problem**: Neon serverless cold starts can take 500-2000ms, causing:
1. Initial connection timeout (if <2s)
2. 3 quick failures trip circuit breaker
3. Circuit opens, blocking valid requests
4. False positive failures during compute wakeup

**Target Configuration**:
```typescript
private readonly circuitBreaker: CircuitBreakerState = {
  state: "closed",
  failures: 0,
  consecutiveSuccesses: 0,
  threshold: 5,              // ✅ Allow 5 failures before opening
  resetTimeout: 30000,       // ✅ Reduce to 30s for faster recovery
  lastFailure: null,
  openUntil: 0,
};
```

**Rationale**:
- **Higher Threshold**: 5 failures accommodates cold start timeouts
- **Shorter Reset**: 30s faster than Neon compute suspend (5 min)
- **Cold Start Tolerance**: 2-3 initial failures during wakeup won't trip breaker

**Additional Changes**:

**File**: `lib/database/enterprise-connection-manager.ts`
```typescript
// Line 87: Update threshold
private readonly circuitBreaker: CircuitBreakerState = {
  threshold: 5,  // Changed from 3
  resetTimeout: 30000, // Changed from 60000
  // ... rest unchanged
};

// Line 122-124: Add Neon-specific timeout
connectionTimeoutMillis: this.parseIntEnv(
  "DB_POOL_CONNECTION_TIMEOUT",
  15000  // ✅ 15s allows for cold starts
),
```

**Environment Variable**:
```env
# .env.local - Circuit Breaker Configuration
CIRCUIT_BREAKER_THRESHOLD=5
CIRCUIT_BREAKER_RESET_TIMEOUT=30000
```

**Acceptance Criteria**:
- [ ] Circuit breaker doesn't trip during Neon cold starts
- [ ] Cold start connection attempts succeed within 15s
- [ ] Real failures (network/auth) still trigger circuit breaker
- [ ] Recovery time <30s after transient errors

**Monitoring**:
- Track `circuitBreakerFailures` vs `coldStartDetected` metrics
- Alert if circuit breaker opens >3 times/hour

---

### ADR-034: Neon-Specific Monitoring Enhancements

**Decision**: Add Neon compute state monitoring and pooler metrics

**New Monitoring Endpoints**:

**1. Neon Compute State Tracking**
```typescript
// File: lib/database/neon-monitor.ts (NEW)
interface NeonComputeState {
  state: 'active' | 'idle' | 'suspended';
  lastActivity: number;
  coldStarts: number;
  avgWakeupTime: number;
}

export class NeonMonitor {
  private computeState: NeonComputeState = {
    state: 'active',
    lastActivity: Date.now(),
    coldStarts: 0,
    avgWakeupTime: 0,
  };

  trackConnection(startTime: number, duration: number) {
    // Cold start detection: >1s connection time
    if (duration > 1000) {
      this.computeState.coldStarts++;
      this.computeState.avgWakeupTime =
        (this.computeState.avgWakeupTime + duration) / 2;
      console.log(`❄️ Neon cold start detected: ${duration}ms`);
    }
    this.computeState.lastActivity = Date.now();
    this.computeState.state = 'active';
  }

  getMetrics() {
    const idleTime = Date.now() - this.computeState.lastActivity;
    return {
      ...this.computeState,
      idleTime,
      estimatedSuspendIn: Math.max(0, 300000 - idleTime), // 5 min suspend
    };
  }
}
```

**2. Pool Exhaustion Alerts**
```typescript
// File: lib/database/enterprise-connection-manager.ts
// Add to getStatus() method

getStatus(): ConnectionManagerStatus {
  const poolStatus = this.getPoolStatus();
  const utilization = poolStatus.total / this.poolConfig.max;

  // ✅ Alert on high pool utilization
  if (utilization > 0.8) {
    console.warn(`⚠️ Pool utilization high: ${(utilization * 100).toFixed(1)}%`);
    console.warn(`📊 Active: ${poolStatus.active}, Waiting: ${poolStatus.waiting}`);
  }

  return {
    // ... existing fields
    poolUtilization: utilization,
    poolExhausted: poolStatus.waiting > 0,
    neonColdStarts: neonMonitor.getMetrics().coldStarts, // ✅ New metric
  };
}
```

**3. Dashboard Metrics Endpoint**
```typescript
// File: src/app/api/health/neon-metrics/route.ts (NEW)
import { dbManager } from '@/lib/database/enterprise-connection-manager';
import { neonMonitor } from '@/lib/database/neon-monitor';

export async function GET() {
  const poolStatus = dbManager.getStatus();
  const neonMetrics = neonMonitor.getMetrics();

  return Response.json({
    timestamp: new Date().toISOString(),
    database: {
      type: 'neon',
      poolUtilization: poolStatus.poolUtilization,
      poolExhausted: poolStatus.poolExhausted,
    },
    neon: {
      computeState: neonMetrics.state,
      idleTime: neonMetrics.idleTime,
      coldStarts: neonMetrics.coldStarts,
      avgWakeupTime: neonMetrics.avgWakeupTime,
      suspendEstimate: neonMetrics.estimatedSuspendIn,
    },
    alerts: [
      poolStatus.poolUtilization > 0.8 && 'Pool utilization >80%',
      neonMetrics.coldStarts > 10 && 'Excessive cold starts detected',
      neonMetrics.avgWakeupTime > 3000 && 'Slow cold start times',
    ].filter(Boolean),
  });
}
```

**Acceptance Criteria**:
- [ ] Cold start detection working for connections >1s
- [ ] Pool exhaustion alerts triggered at 80% utilization
- [ ] Neon compute state tracking accurate
- [ ] Metrics endpoint returns valid JSON
- [ ] Dashboard displays Neon-specific metrics

**Monitoring Dashboard Layout**:
```
┌─────────────────────────────────────────────────┐
│ Neon Database Metrics                           │
├─────────────────────────────────────────────────┤
│ Compute State: ● Active                         │
│ Idle Time: 45s / 300s (Suspend in: 4m 15s)     │
│ Cold Starts Today: 8                            │
│ Avg Wakeup Time: 1,234ms                       │
├─────────────────────────────────────────────────┤
│ Connection Pool                                 │
│ ████████░░ 78% (7/8 active, 1 idle)            │
│ Waiting: 0                                      │
│ Utilization Trend: ──/▁▂▃▅▆▇▇▇                 │
├─────────────────────────────────────────────────┤
│ Alerts                                          │
│ ⚠️ Pool utilization >80% - Consider scaling     │
└─────────────────────────────────────────────────┘
```

---

## PATH B: ENTERPRISE OPTIMIZATION (Current On-Premise Setup)

### ADR-035: Enterprise PostgreSQL Pool Optimization

**Decision**: Optimize current enterprise connection pool for on-premise database

**Current Configuration** (.env.local):
```env
# Enterprise Database Connection
DATABASE_URL=postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001
DB_POOL_MIN=10
DB_POOL_MAX=50
DB_POOL_IDLE_TIMEOUT=30000    # 30 seconds
DB_POOL_CONNECTION_TIMEOUT=5000  # 5 seconds
```

**Problem Analysis**:
- MIN=10 maintains unnecessary idle connections
- MAX=50 may exceed PostgreSQL max_connections setting
- Idle timeout too short causes frequent reconnections
- No statement timeout in DATABASE_URL

**Optimized Configuration**:
```env
# Enterprise Database Connection
DATABASE_URL=postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001?connect_timeout=10&statement_timeout=60000&idle_in_transaction_session_timeout=120000&application_name=mantisnxt

# Connection Pool (Optimized)
DB_POOL_MIN=5              # Reduced from 10 (save resources)
DB_POOL_MAX=30             # Reduced from 50 (safer limit)
DB_POOL_IDLE_TIMEOUT=60000 # Increased to 60s (reduce churn)
DB_POOL_CONNECTION_TIMEOUT=10000  # Increased to 10s (network tolerance)
```

**Rationale**:
- **MIN=5**: Adequate for warm pool, reduces resource waste
- **MAX=30**: Safe limit assuming PostgreSQL max_connections=100
- **Idle Timeout=60s**: Balance between resource cleanup and connection reuse
- **Connection Timeout=10s**: Tolerant of network latency

**Database Server Validation**:
```sql
-- Check PostgreSQL max_connections setting
SHOW max_connections;  -- Should be ≥50 for MAX=30 pool

-- Check current connection count
SELECT count(*) FROM pg_stat_activity WHERE datname = 'nxtprod-db_001';

-- Check long-running queries
SELECT pid, now() - query_start AS duration, query
FROM pg_stat_activity
WHERE state = 'active' AND query_start < now() - interval '30 seconds';
```

**Acceptance Criteria**:
- [ ] Pool utilization <75% during peak load
- [ ] No connection acquisition failures
- [ ] Long queries auto-terminated at 60s
- [ ] Idle connections cleaned appropriately

**Rollback**: Revert to MIN=10, MAX=50

---

### ADR-036: Enterprise Circuit Breaker Fine-Tuning

**Decision**: Maintain aggressive circuit breaker for enterprise reliability

**Current Circuit Breaker**:
```typescript
threshold: 3,        // ✅ Keep for enterprise
resetTimeout: 60000, // ✅ Keep for enterprise
```

**No Changes Required** - Enterprise database doesn't have cold start issues

**Additional Enterprise Features**:
```typescript
// File: lib/database/enterprise-connection-manager.ts
// Line 175-182: Enhanced pool error logging

this.pool.on("error", (error) => {
  console.error("❌ Pool error:", error);
  this.metrics.failedConnections++;

  // ✅ Add enterprise-specific error categorization
  if (error.message.includes('ECONNREFUSED')) {
    console.error('🔴 Database server unreachable - check network/firewall');
  } else if (error.message.includes('authentication failed')) {
    console.error('🔴 Authentication error - check credentials');
  } else if (error.message.includes('too many connections')) {
    console.error('🔴 Connection limit reached - increase max_connections or reduce pool');
  }

  this.circuitBreaker.failures++;
  this.circuitBreaker.consecutiveSuccesses = 0;
  this.circuitBreaker.lastFailure = Date.now();
});
```

**Acceptance Criteria**:
- [ ] Circuit breaker trips on 3 consecutive failures
- [ ] Recovery within 60s after transient errors
- [ ] Error categorization working correctly

---

## CONFIGURATION FILES

### PATH A: Neon Migration Files

**File**: `.env.local` (Neon Version)
```env
# MantisNXT Neon Database Configuration
NODE_ENV=development
APP_PORT=3000

# Neon Database Connection (Pooler Endpoint)
DATABASE_URL=postgresql://[user]:[password]@ep-[project]-pooler.neon.tech/neondb?sslmode=require&connect_timeout=10&statement_timeout=30000&idle_in_transaction_session_timeout=60000&pool_timeout=10&application_name=mantisnxt

# Neon Connection Pool Settings
DB_POOL_MIN=2
DB_POOL_MAX=8
DB_POOL_IDLE_TIMEOUT=300000
DB_POOL_CONNECTION_TIMEOUT=15000

# Circuit Breaker (Neon-Tuned)
CIRCUIT_BREAKER_THRESHOLD=5
CIRCUIT_BREAKER_RESET_TIMEOUT=30000

# Feature Flags
ENABLE_NEON_DATABASE=true
REALTIME_ENABLED=true

# Query Logging
QUERY_LOG_ENABLED=true
LOG_SLOW_QUERIES=true
SLOW_QUERY_THRESHOLD_MS=1000

# Authentication (Unchanged)
JWT_SECRET=enterprise_jwt_secret_key_2024_production
SESSION_SECRET=enterprise_session_secret_key_2024
SESSION_TIMEOUT=3600000

# File Upload (Unchanged)
UPLOAD_MAX_SIZE=10485760
UPLOAD_DIR=/app/uploads

# Performance (Unchanged)
NODE_OPTIONS=--max-old-space-size=2048
ENABLE_CACHING=true
LOG_LEVEL=info
DEBUG_MODE=true

# REMOVED VARIABLES (No Longer Needed):
# - DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
# - ENTERPRISE_DATABASE_URL
# - NEON_POOL_MAX, NEON_POOL_MIN
```

**File**: `lib/database/enterprise-connection-manager.ts` (Neon Changes)
```typescript
// Line 87: Circuit breaker threshold
private readonly circuitBreaker: CircuitBreakerState = {
  state: "closed",
  failures: 0,
  consecutiveSuccesses: 0,
  threshold: 5,  // Changed from 3 for Neon cold starts
  resetTimeout: 30000, // Changed from 60000
  lastFailure: null,
  openUntil: 0,
};

// Line 100-128: buildConfigFromEnv() - Neon-optimized
private buildConfigFromEnv(): PoolConfig {
  const connectionString = process.env.DATABASE_URL;

  if (!connectionString) {
    throw new Error('DATABASE_URL must be set');
  }

  // Neon detection and SSL requirement
  const isNeon = connectionString.includes('neon.tech');
  const requiresSsl = isNeon || connectionString.includes('sslmode=require');

  return {
    connectionString,
    max: Math.min(
      this.parseIntEnv("DB_POOL_MAX", DEFAULT_MAX_POOL),
      isNeon ? 10 : 100  // Hard cap for Neon
    ),
    min: this.parseIntEnv("DB_POOL_MIN", isNeon ? 2 : 5),
    idleTimeoutMillis: this.parseIntEnv(
      "DB_POOL_IDLE_TIMEOUT",
      isNeon ? 300000 : 30000  // 5 min for Neon, 30s for enterprise
    ),
    connectionTimeoutMillis: this.parseIntEnv(
      "DB_POOL_CONNECTION_TIMEOUT",
      isNeon ? 15000 : 2000  // 15s for Neon cold starts
    ),
    ssl: requiresSsl ? { rejectUnauthorized: false } : undefined,
  };
}
```

---

### PATH B: Enterprise Optimization Files

**File**: `.env.local` (Enterprise Optimized)
```env
# MantisNXT Enterprise Database Configuration
NODE_ENV=development
APP_PORT=3000

# Enterprise Database Connection (Optimized)
DATABASE_URL=postgresql://nxtdb_admin:P@33w0rd-1@62.169.20.53:6600/nxtprod-db_001?connect_timeout=10&statement_timeout=60000&idle_in_transaction_session_timeout=120000&application_name=mantisnxt

# Connection Pool (Optimized)
DB_POOL_MIN=5
DB_POOL_MAX=30
DB_POOL_IDLE_TIMEOUT=60000
DB_POOL_CONNECTION_TIMEOUT=10000
DB_POOL_ACQUIRE_TIMEOUT=45000

# Circuit Breaker (Enterprise Defaults)
CIRCUIT_BREAKER_THRESHOLD=3
CIRCUIT_BREAKER_RESET_TIMEOUT=60000

# Real-Time Configuration
REALTIME_ENABLED=true
WEBSOCKET_PORT=3001
SSE_ENABLED=true

# Authentication
JWT_SECRET=enterprise_jwt_secret_key_2024_production
SESSION_SECRET=enterprise_session_secret_key_2024
SESSION_TIMEOUT=3600000

# File Upload
UPLOAD_MAX_SIZE=10485760
UPLOAD_ALLOWED_TYPES=image/jpeg,image/png,application/pdf,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
UPLOAD_DIR=/app/uploads

# Performance
NODE_OPTIONS=--max-old-space-size=2048
ENABLE_CACHING=true
REDIS_URL=redis://localhost:6379

# Development Features
LOG_LEVEL=info
DEBUG_MODE=true
ENABLE_ANALYTICS=true
ENABLE_AUDIT_LOGGING=true

# Query Logging
QUERY_LOG_ENABLED=true
LOG_SLOW_QUERIES=true
SLOW_QUERY_THRESHOLD_MS=1000

# REMOVED (Redundant):
# - DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
```

**File**: `lib/database/enterprise-connection-manager.ts` (Enterprise Optimized)
```typescript
// Line 42-48: Updated defaults
const DEFAULT_MAX_POOL = 30;  // Changed from 10
const DEFAULT_MIN_POOL = 5;   // Changed from 2
const DEFAULT_IDLE_TIMEOUT = 60000;  // Changed from 30000
const DEFAULT_CONNECTION_TIMEOUT = 10000;  // Changed from 2000
const DEFAULT_QUERY_TIMEOUT = 60000;  // Changed from 30000
const DEFAULT_MAX_RETRIES = 2;
const DEFAULT_RESET_TIMEOUT = 60000;
const CLIENT_ACQUIRE_TIMEOUT = 45000;

// Line 87: Circuit breaker (Unchanged for enterprise)
private readonly circuitBreaker: CircuitBreakerState = {
  threshold: 3,  // ✅ Keep aggressive for enterprise reliability
  resetTimeout: 60000,
  // ... rest unchanged
};

// Line 117-128: Pool max with enterprise validation
max: Math.min(
  this.parseIntEnv("DB_POOL_MAX", DEFAULT_MAX_POOL),
  100  // Reasonable cap assuming PostgreSQL max_connections=100-200
),
```

---

## VALIDATION & TESTING

### Neon Path Validation

**1. Connection String Validation**
```bash
# Test DATABASE_URL parsing
node -e "console.log(new URL(process.env.DATABASE_URL))"

# Expected output:
# {
#   protocol: 'postgresql:',
#   hostname: 'ep-xyz-pooler.neon.tech',
#   searchParams: { sslmode: 'require', connect_timeout: '10', ... }
# }
```

**2. Pool Configuration Test**
```typescript
// scripts/test-neon-pool.ts
import { dbManager } from '@/lib/database/enterprise-connection-manager';

async function testNeonPool() {
  const status = dbManager.getStatus();
  console.log('Pool Configuration:', {
    max: status.poolStatus.total,
    active: status.poolStatus.active,
    idle: status.poolStatus.idle,
  });

  // Test pool limit enforcement
  const connections = [];
  try {
    for (let i = 0; i < 10; i++) {
      connections.push(await dbManager.query('SELECT 1'));
    }
    console.error('❌ Pool exceeded Neon limit!');
  } catch (error) {
    if (error.message.includes('too many clients')) {
      console.log('✅ Pool limit correctly enforced');
    }
  }
}

testNeonPool();
```

**3. Cold Start Detection**
```bash
# Wait for Neon compute to suspend (5 minutes idle)
# Then run:
curl http://localhost:3000/api/health/neon-metrics

# Check for coldStarts > 0 in response
```

### Enterprise Path Validation

**1. Pool Stress Test**
```bash
# Run 50 concurrent connections
npx autocannon -c 50 -d 30 http://localhost:3000/api/health/database

# Expected: No failures, pool utilization <75%
```

**2. Long Query Timeout**
```sql
-- This should timeout at 60 seconds
SELECT pg_sleep(120);

-- Expected: ERROR: canceling statement due to statement timeout
```

**3. Pool Metrics**
```bash
curl http://localhost:3000/api/health/database | jq '.poolStatus'

# Expected output:
# {
#   "total": 8,
#   "idle": 3,
#   "active": 5,
#   "waiting": 0
# }
```

---

## DECISION REQUIRED

**Before Proceeding, Determine Deployment Path**:

1. **Are you migrating to Neon?**
   - YES → Implement ADR-030 through ADR-034 (Path A)
   - NO → Implement ADR-035 through ADR-036 (Path B)

2. **Current Reality Check**:
   - .env.local points to 62.169.20.53:6600 (Enterprise PostgreSQL)
   - No Neon environment variables present
   - Pool settings are enterprise-grade (MIN=10, MAX=50)

3. **Recommendation**:
   - If staying with enterprise DB: **Path B** (simple optimization)
   - If adopting Neon: **Path A** (requires database migration)

**Next Steps After Decision**:
1. Select implementation path (A or B)
2. Apply configuration changes
3. Run validation tests
4. Monitor for 24 hours
5. Adjust based on production metrics

---

## APPENDIX: Migration Checklist

### Neon Migration Checklist (Path A)

- [ ] Provision Neon project at console.neon.tech
- [ ] Obtain pooler endpoint URL
- [ ] Update DATABASE_URL in .env.local
- [ ] Apply new pool configuration (MIN=2, MAX=8)
- [ ] Update circuit breaker threshold to 5
- [ ] Deploy code changes to enterprise-connection-manager.ts
- [ ] Test connection under load
- [ ] Verify cold start detection
- [ ] Monitor for "too many clients" errors
- [ ] Set up Neon-specific alerting

### Enterprise Optimization Checklist (Path B)

- [ ] Verify PostgreSQL max_connections ≥50
- [ ] Update DATABASE_URL with timeout parameters
- [ ] Apply optimized pool settings (MIN=5, MAX=30)
- [ ] Deploy code changes
- [ ] Run pool stress test
- [ ] Verify long query timeout working
- [ ] Monitor pool utilization for 24 hours
- [ ] Adjust MAX if needed based on load

---

## CONCLUSION

**Critical Insight**: Task assumes Neon usage, but deployment uses enterprise PostgreSQL. This document provides comprehensive designs for both paths.

**Immediate Action Required**: Determine deployment strategy (Neon vs Enterprise) before proceeding with any configuration changes.

**Risk Mitigation**: Both paths include validation tests, acceptance criteria, and rollback procedures to ensure safe deployment.
