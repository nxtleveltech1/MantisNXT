# Components

List major components and responsibilities.

