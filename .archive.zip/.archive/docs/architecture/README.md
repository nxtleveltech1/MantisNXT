# Architecture Shards

This folder contains sharded Architecture sections generated from `docs/architecture.md`.

