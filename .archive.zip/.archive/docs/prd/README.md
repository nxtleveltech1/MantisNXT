# PRD Shards

This folder contains sharded PRD sections generated from `docs/prd.md`.

