# Stories

Place generated user stories here. Follow status flow: Draft → Approved → InProgress → Done.

