# NXT-SPP Full Integration - Complete Documentation

**Date:** December 2024  
**Version:** 1.0.0  
**Status:** ✅ Complete

## Overview

The MantisNXT inventory management system has been fully integrated with the NXT-SPP (Supplier Inventory Portfolio) platform. This integration unifies all supplier pricelist uploads, product selection, and stock tracking into a single, streamlined workflow.

## Architecture Overview

The integrated system follows a 3-layer architecture:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   SPP LAYER     │    │   CORE LAYER    │    │  SERVE LAYER    │
│   (Staging)     │    │   (Canonical)   │    │   (Reporting)   │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ • Upload        │───▶│ • Supplier      │───▶│ • NXT SOH       │
│ • Validate      │    │ • Product       │    │ • Dashboard     │
│ • Merge         │    │ • Selection     │    │ • Analytics     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Workflow Steps

1. **Upload** → SPP (staging pricelist data)
2. **Validate** → SPP (data validation and error checking)
3. **Merge** → CORE (canonical master data)
4. **Select** → CORE (inventory selection interface)
5. **Activate** → CORE (single active selection rule)
6. **Stock** → SERVE (NXT SOH views and reporting)

## What Changed

### System Consolidation
- ✅ Consolidated supplier workflow into NXT-SPP
- ✅ Created unified data import pipeline
- ✅ Implemented single-active-selection business rule
- ✅ Integrated stock on hand with selection system
- ✅ Updated UI to guide users to NXT-SPP

### Database Schema
- ✅ Created SPP schema for staging data
- ✅ Enhanced CORE schema for canonical data
- ✅ Added SERVE schema for read-optimized views
- ✅ Implemented proper foreign key relationships
- ✅ Added performance indexes

### API Endpoints
- ✅ Created selection management endpoints
- ✅ Enhanced NXT SOH endpoint with selection validation
- ✅ Added proper error handling and caching
- ✅ Implemented pagination and filtering

## Database Schema

### SPP Schema (Staging Layer)
- `spp.pricelist_upload` - Upload metadata and status
- `spp.pricelist_row` - Individual pricelist rows

### CORE Schema (Master Data)
- `core.supplier` - Supplier master records
- `core.category` - Hierarchical category taxonomy
- `core.product` - Internal product catalog
- `core.supplier_product` - Supplier product mappings
- `core.price_history` - SCD Type 2 price tracking
- `core.inventory_selection` - Inventory selections
- `core.inventory_selected_item` - Selected items
- `core.stock_location` - Stock locations
- `core.stock_on_hand` - Stock on hand snapshots

### SERVE Schema (Reporting Layer)
- `serve.v_product_table_by_supplier` - Product catalog view
- `serve.v_selected_catalog` - Active selection view
- `serve.v_soh_by_supplier` - Stock by supplier
- `serve.v_nxt_soh` - Authoritative NXT SOH view

## API Endpoints

### Selection Management
- `GET /api/core/selections/active` - Get active selection
- `POST /api/core/selections/[id]/activate` - Activate selection
- `GET /api/core/selections/[id]/items` - Get selection items

### Stock Reporting
- `GET /api/serve/nxt-soh` - NXT Stock on Hand (selected items only)

### Pricelist Management
- `POST /api/spp/upload` - Upload pricelist
- `POST /api/spp/validate` - Validate pricelist
- `POST /api/spp/merge` - Merge pricelist to core

## User Workflows

### Workflow 1: Upload New Pricelist

1. **Access NXT-SPP Dashboard**
   - Navigate to `http://localhost:3000/nxt-spp`
   - Click "Upload Pricelist" tab

2. **Upload File**
   - Select Excel/CSV file
   - Choose supplier
   - Set currency and validity dates
   - Click "Upload"

3. **Validation**
   - System validates data automatically
   - Review validation results
   - Fix any errors if needed

4. **Merge to Core**
   - Click "Merge to Core"
   - System creates/updates supplier products
   - Price history is tracked with SCD Type 2

### Workflow 2: Create Inventory Selection

1. **Access Selection Interface**
   - Navigate to `http://localhost:3000/nxt-spp?tab=selections`
   - Click "Create New Selection"

2. **Select Products**
   - Browse available products
   - Use filters to find specific items
   - Select products to include

3. **Activate Selection**
   - Review selection summary
   - Click "Activate Selection"
   - System enforces single-active rule

### Workflow 3: View Stock Reports

1. **Access Stock Reports**
   - Navigate to `http://localhost:3000/nxt-spp?tab=stock-reports`
   - View NXT SOH dashboard

2. **Filter and Search**
   - Filter by supplier
   - Search by product name/SKU
   - Filter by location

3. **Export Data**
   - Export to Excel/CSV
   - Generate reports
   - Schedule automated reports

## Business Rules

### Single Active Selection
- **Rule**: Only one selection can have `status='active'` at a time
- **Purpose**: Ensures NXT SOH always reflects a single, consistent catalog
- **Implementation**: Database constraint + application logic
- **Conflict Resolution**: Activate new selection with `deactivate_others=true`

### Selected Items Only
- **Rule**: Stock reports show ONLY items in active selection
- **Purpose**: Prevents confusion about what's actually stocked
- **Implementation**: NXT SOH view joins with active selection
- **Fallback**: Empty results if no active selection

### Price History (SCD Type 2)
- **Rule**: Track price changes with valid_from/valid_to dates
- **Purpose**: Historical analysis and audit trail
- **Implementation**: `is_current` flag + date ranges
- **Usage**: Price change reports, cost analysis

### Supplier Product Mapping
- **Rule**: Each supplier SKU maps to internal product
- **Purpose**: Normalize product data across suppliers
- **Implementation**: `supplier_product` table with `product_id` FK
- **Fallback**: Unmapped products flagged for review

## Data Import Process

### Master Dataset Import

The system includes a comprehensive import process for the master consolidated Excel file:

1. **File Processing**
   - Reads `FINAL_MASTER_CONSOLIDATED_COMPLETE.xlsx`
   - Detects column mappings automatically
   - Groups rows by supplier

2. **Data Transformation**
   - Maps Excel columns to database schema
   - Validates required fields
   - Handles data type conversions

3. **Database Operations**
   - Creates suppliers if missing
   - Uploads pricelist data to SPP
   - Validates and merges to CORE
   - Creates default selection
   - Seeds initial stock data

### Column Mappings

The import script automatically detects column mappings:

| Excel Column | Database Field | Description |
|-------------|----------------|-------------|
| SKU, Code, Item Code | supplier_sku | Supplier's product code |
| Name, Description | name | Product name |
| Price, Unit Price | price | Product price |
| Brand, Manufacturer | brand | Product brand |
| Category, Group | category_raw | Raw category text |
| UOM, Unit | uom | Unit of measure |
| Barcode, EAN | barcode | Product barcode |

## Troubleshooting

### Common Issues

#### "No active selection" Error
**Problem**: NXT SOH reports show no data  
**Solution**: 
1. Check if any selection exists: `SELECT * FROM core.inventory_selection`
2. Create and activate a selection using the UI
3. Verify selection has items: `SELECT COUNT(*) FROM core.inventory_selected_item WHERE status='selected'`

#### Upload Validation Failures
**Problem**: Pricelist upload fails validation  
**Solution**:
1. Check validation errors in the UI
2. Fix data issues in Excel file
3. Re-upload with corrected data
4. Check column mappings are correct

#### Selection Activation Conflicts
**Problem**: Cannot activate selection - another is active  
**Solution**:
1. Use `deactivate_others=true` parameter
2. Or manually deactivate current selection first
3. Check for multiple active selections in database

#### Stock Data Not Showing
**Problem**: Stock reports are empty  
**Solution**:
1. Verify active selection exists
2. Check stock records exist: `SELECT COUNT(*) FROM core.stock_on_hand`
3. Verify stock records reference selected products
4. Check location configuration

### Data Integrity Checks

Run these queries to verify system health:

```sql
-- Check for orphaned records
SELECT COUNT(*) FROM core.inventory_selected_item isi
LEFT JOIN core.inventory_selection sel ON sel.selection_id = isi.selection_id
WHERE sel.selection_id IS NULL;

-- Check for products without prices
SELECT COUNT(*) FROM core.supplier_product sp
WHERE NOT EXISTS (
  SELECT 1 FROM core.price_history ph
  WHERE ph.supplier_product_id = sp.supplier_product_id AND ph.is_current = true
);

-- Check for multiple active selections
SELECT COUNT(*) FROM core.inventory_selection WHERE status = 'active';
```

## Maintenance

### Regular Maintenance Tasks

#### Data Cleanup
- Archive old selections monthly
- Purge old price history (keep 2 years)
- Clean up failed uploads

#### Performance Monitoring
- Monitor query performance
- Check index usage
- Optimize slow queries

#### Backup Procedures
- Daily automated backups
- Test restore procedures
- Document recovery processes

### Re-import Process

To re-import the master dataset:

1. **Backup Current Data**
   ```bash
   pg_dump $NEON_SPP_DATABASE_URL --schema=spp --schema=core > backup.sql
   ```

2. **Purge Existing Data**
   ```bash
   npm run db:purge
   ```

3. **Run Full Integration**
   ```bash
   npm run integration:full
   ```

4. **Verify Integration**
   ```bash
   npm run integration:verify
   ```

## Future Enhancements

### Planned Improvements

#### Multi-Location Support
- Enhanced location management
- Location-specific stock tracking
- Inter-location transfers

#### Automated Reorder Points
- Dynamic reorder point calculation
- Automated purchase order generation
- Supplier performance tracking

#### Price Change Alerts
- Real-time price change notifications
- Price trend analysis
- Cost impact reporting

#### Supplier Performance Analytics
- Delivery performance tracking
- Quality metrics
- Cost analysis and optimization

### Technical Improvements

#### Performance Optimization
- Query optimization
- Caching strategies
- Index tuning

#### Scalability Enhancements
- Horizontal scaling
- Load balancing
- Microservices architecture

#### Integration Capabilities
- ERP system integration
- E-commerce platform connectivity
- Third-party API integrations

## References

### Documentation Links
- [NXT-SPP README](../NXT-SPP-README.md) - API reference and technical details
- [Database Schema](../database/schema/) - Complete schema documentation
- [Type Definitions](../src/types/nxt-spp.ts) - TypeScript interfaces

### Integration Scripts
- [Full Integration Script](../scripts/run_full_integration.sh) - Complete integration process
- [Import Script](../scripts/import_master_dataset.ts) - Master dataset import
- [Verification Script](../scripts/verify_integration.ts) - Integration verification

### API Documentation
- [Selection API](../src/app/api/core/selections/) - Selection management endpoints
- [Stock API](../src/app/api/serve/nxt-soh/) - Stock reporting endpoints
- [Upload API](../src/app/api/spp/) - Pricelist upload endpoints

---

**Last Updated:** December 2024  
**Maintained By:** MantisNXT Development Team  
**Version:** 1.0.0
