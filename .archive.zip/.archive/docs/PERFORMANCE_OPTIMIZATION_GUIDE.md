# Performance Optimization Guide

This guide documents the multi-layer performance optimizations implemented across the database, API, and frontend.

## Database Optimization
- Index strategy using composite and GIN indexes for frequent filters and searches.
- Single-pass pagination using window functions instead of dual COUNT queries.
- Connection pool tuning with health signals.

See:
- `database/indexes/03_supplier_performance_indexes.sql`
- `database/indexes/04_inventory_performance_indexes.sql`
- `lib/database/enterprise-connection-manager.ts`

## Caching Strategy
- QueryCache with tiered caches: hot, realtime, dashboard, analytics.
- TTL guidance: suppliers (60s), inventory (30s), dashboard (5m).
- Invalidation via tags on mutations.

See:
- `src/lib/cache/query-cache.ts`
- `src/lib/services/UnifiedDataService.ts`

## API Performance
- Conservative response limits.
- Offset vs cursor pagination best practices.
- Performance headers for observability.

See:
- `src/app/api/inventory/route.ts`

## Frontend Optimization
- Consolidated real-time WebSocket connection via `useDashboardData`.
- Dynamic imports for heavy AI/components.
- Bundle analyzer integration.

See:
- `src/hooks/useDashboardData.ts`
- `src/components/dashboard/RealTimeDashboard.tsx`
- `next.config.js`, `package.json`

## Monitoring & Metrics
- Connection pool health exposure in health endpoint.
- Cache hit/miss metrics via `CacheManager.getCombinedStats()`.
- Slow query detection remains via enterprise manager logging.

See:
- `src/app/api/health/database/route.ts`

## Troubleshooting
- If pagination is slow, verify indexes and window-function usage.
- If stale data appears, confirm invalidation tags are called after mutations.
- For large bundles, run `npm run analyze` and address largest chunks with dynamic imports.


