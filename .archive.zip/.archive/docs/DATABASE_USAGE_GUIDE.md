# Database Usage Guide

## Quick Reference for MantisNXT Database Operations

---

## Import Pattern

**Always use the centralized import:**

```typescript
import { pool, query, withTransaction } from '@/lib/database';
```

❌ **Don't use:**
```typescript
// DEPRECATED - Will cause issues
import { query } from '@/lib/database/unified-connection';
import { pool } from '@/lib/database/enterprise-connection-manager';
```

---

## Basic Query

### Simple SELECT

```typescript
import { query } from '@/lib/database';

// Without types
const result = await query('SELECT * FROM users');
console.log(result.rows);

// With types
interface User {
  id: string;
  name: string;
  email: string;
}

const result = await query<User>('SELECT * FROM users');
const users: User[] = result.rows;
```

### Parameterized Query

```typescript
const result = await query<User>(
  'SELECT * FROM users WHERE id = $1',
  [userId]
);
```

### Query with UUID

**Important:** Always cast UUID parameters!

```typescript
// ✅ Correct - explicit UUID casting
const result = await query(
  'SELECT * FROM stock_movement WHERE supplier_product_id = $1::uuid',
  [supplierProductId]
);

// ❌ Wrong - will cause type errors
const result = await query(
  'SELECT * FROM stock_movement WHERE supplier_product_id = $1',
  [supplierProductId]
);
```

---

## Transactions

### Basic Transaction

```typescript
import { withTransaction } from '@/lib/database';

const result = await withTransaction(async (client) => {
  // All queries in this function use the same transaction

  await client.query(
    'INSERT INTO users (name, email) VALUES ($1, $2)',
    ['John Doe', 'john@example.com']
  );

  await client.query(
    'INSERT INTO audit_log (action) VALUES ($1)',
    ['user_created']
  );

  return { success: true };
});
```

### Transaction with Rollback

```typescript
try {
  await withTransaction(async (client) => {
    await client.query('UPDATE accounts SET balance = balance - $1 WHERE id = $2', [100, accountId]);
    await client.query('UPDATE accounts SET balance = balance + $1 WHERE id = $2', [100, recipientId]);

    // If any error occurs here, entire transaction rolls back
    const result = await client.query('SELECT balance FROM accounts WHERE id = $1', [accountId]);

    if (result.rows[0].balance < 0) {
      throw new Error('Insufficient funds');
    }

    return result.rows[0];
  });
} catch (error) {
  console.error('Transaction failed:', error);
  // Transaction was automatically rolled back
}
```

---

## Pool Usage

### Check Pool Status

```typescript
import { pool } from '@/lib/database';

const totalConnections = pool.totalCount;
const idleConnections = pool.idleCount;
const waitingConnections = pool.waitingCount;

console.log(`Pool: ${idleConnections}/${totalConnections} idle, ${waitingConnections} waiting`);
```

### Simple Pool Query

```typescript
import { pool } from '@/lib/database';

const result = await pool.query('SELECT NOW()');
console.log(result.rows[0].now);
```

---

## Common Patterns

### INSERT with RETURNING

```typescript
interface NewUser {
  id: string;
  name: string;
  created_at: string;
}

const result = await query<NewUser>(
  'INSERT INTO users (name, email) VALUES ($1, $2) RETURNING id, name, created_at',
  ['Jane Doe', 'jane@example.com']
);

const newUser = result.rows[0];
console.log(`Created user ${newUser.id}`);
```

### UPDATE with Row Count

```typescript
const result = await query(
  'UPDATE users SET last_login = NOW() WHERE id = $1::uuid',
  [userId]
);

if (result.rowCount === 0) {
  throw new Error('User not found');
}

console.log(`Updated ${result.rowCount} rows`);
```

### DELETE with Verification

```typescript
const result = await query(
  'DELETE FROM sessions WHERE expires_at < NOW() RETURNING session_id',
  []
);

console.log(`Cleaned up ${result.rowCount} expired sessions`);
```

---

## UUID Handling

### When to Cast

Cast to `::uuid` when:
- Comparing with UUID columns
- Inserting into UUID columns
- Using in WHERE clauses
- Using in JOIN conditions

```typescript
// ✅ Good examples
await query('SELECT * FROM products WHERE product_id = $1::uuid', [id]);
await query('INSERT INTO products (product_id, name) VALUES ($1::uuid, $2)', [uuid, name]);
await query('DELETE FROM products WHERE supplier_id = $1::uuid', [supplierId]);

// Join with UUID
await query(`
  SELECT p.*, s.name as supplier_name
  FROM products p
  JOIN suppliers s ON s.supplier_id = p.supplier_id
  WHERE p.product_id = $1::uuid
`, [productId]);
```

### Generating UUIDs

```typescript
// Let PostgreSQL generate
await query(
  'INSERT INTO products (name) VALUES ($1) RETURNING product_id',
  [name]
);

// Generate in application
import { randomUUID } from 'crypto';

const id = randomUUID();
await query(
  'INSERT INTO products (product_id, name) VALUES ($1::uuid, $2)',
  [id, name]
);
```

---

## Error Handling

### Circuit Breaker

The database includes a circuit breaker that opens when too many failures occur:

```typescript
try {
  const result = await query('SELECT * FROM users');
} catch (error) {
  if (error.message.includes('circuit breaker is open')) {
    // Database is temporarily unavailable
    // Wait and retry, or return cached data
    console.error('Database circuit breaker open - using fallback');
    return getCachedData();
  }
  throw error;
}
```

### Timeouts

Queries have default timeouts. For long-running queries:

```typescript
import { query } from '@/lib/database';

// Default timeout is 60 seconds
const result = await query('SELECT * FROM huge_table');

// For analytics or reports, consider pagination instead
const result = await query(
  'SELECT * FROM huge_table LIMIT $1 OFFSET $2',
  [100, 0]
);
```

### Connection Errors

```typescript
try {
  await query('SELECT * FROM users');
} catch (error) {
  if (error.code === 'ECONNREFUSED') {
    console.error('Database connection refused');
  } else if (error.code === '42P01') {
    console.error('Table does not exist');
  } else if (error.code === '23505') {
    console.error('Unique constraint violation');
  }
  throw error;
}
```

---

## Performance Tips

### Use Indexes

```typescript
// Slow - no index
await query('SELECT * FROM users WHERE email = $1', [email]);

// Fast - with index
await query('SELECT * FROM users WHERE email = $1', [email]);
// Requires: CREATE INDEX idx_users_email ON users(email);
```

### Limit Results

```typescript
// ❌ Bad - fetches all rows
const result = await query('SELECT * FROM products');

// ✅ Good - pagination
const result = await query(
  'SELECT * FROM products LIMIT $1 OFFSET $2',
  [pageSize, offset]
);
```

### Select Only Needed Columns

```typescript
// ❌ Bad - fetches all columns
await query('SELECT * FROM products WHERE id = $1::uuid', [id]);

// ✅ Good - only needed columns
await query(
  'SELECT id, name, price FROM products WHERE id = $1::uuid',
  [id]
);
```

### Use Transactions for Multiple Operations

```typescript
// ❌ Bad - multiple round trips
await query('INSERT INTO order_items ...');
await query('INSERT INTO order_items ...');
await query('UPDATE orders SET total = ...');

// ✅ Good - single transaction
await withTransaction(async (client) => {
  await client.query('INSERT INTO order_items ...');
  await client.query('INSERT INTO order_items ...');
  await client.query('UPDATE orders SET total = ...');
});
```

---

## Type Safety

### Define Interfaces

```typescript
interface Product {
  product_id: string;
  name: string;
  price: number;
  created_at: string;
}

interface CreateProductInput {
  name: string;
  price: number;
  supplier_id: string;
}

async function createProduct(input: CreateProductInput): Promise<Product> {
  const result = await query<Product>(
    `INSERT INTO products (name, price, supplier_id)
     VALUES ($1, $2, $3::uuid)
     RETURNING product_id, name, price, created_at`,
    [input.name, input.price, input.supplier_id]
  );

  return result.rows[0];
}
```

### Use Query Result Types

```typescript
import { QueryResultRow } from 'pg';

// Custom result type
interface CountResult extends QueryResultRow {
  count: string; // PostgreSQL COUNT returns string
}

const result = await query<CountResult>('SELECT COUNT(*) FROM users');
const count = parseInt(result.rows[0].count, 10);
```

---

## Common Mistakes

### ❌ Forgetting UUID Cast

```typescript
// WRONG - will fail with type error
await query(
  'SELECT * FROM products WHERE supplier_id = $1',
  [supplierId]
);

// CORRECT
await query(
  'SELECT * FROM products WHERE supplier_id = $1::uuid',
  [supplierId]
);
```

### ❌ Not Using Transactions

```typescript
// WRONG - if second query fails, first insert remains
await query('INSERT INTO users ...');
await query('INSERT INTO user_roles ...');

// CORRECT - both or neither
await withTransaction(async (client) => {
  await client.query('INSERT INTO users ...');
  await client.query('INSERT INTO user_roles ...');
});
```

### ❌ SQL Injection Risk

```typescript
// WRONG - SQL injection vulnerability
const name = req.query.name;
await query(`SELECT * FROM users WHERE name = '${name}'`);

// CORRECT - parameterized query
await query('SELECT * FROM users WHERE name = $1', [name]);
```

### ❌ Not Checking Row Count

```typescript
// WRONG - assumes record exists
const result = await query('SELECT * FROM users WHERE id = $1::uuid', [id]);
const user = result.rows[0]; // Could be undefined!

// CORRECT - check existence
const result = await query('SELECT * FROM users WHERE id = $1::uuid', [id]);
if (result.rowCount === 0) {
  throw new Error('User not found');
}
const user = result.rows[0];
```

---

## Testing

### Mock Database in Tests

```typescript
import { jest } from '@jest/globals';

// Mock the database module
jest.mock('@/lib/database', () => ({
  query: jest.fn(),
  withTransaction: jest.fn(),
  pool: {
    query: jest.fn(),
    totalCount: 10,
    idleCount: 8,
    waitingCount: 0
  }
}));

// In test
import { query } from '@/lib/database';

test('fetches user', async () => {
  (query as jest.Mock).mockResolvedValue({
    rows: [{ id: '123', name: 'Test User' }],
    rowCount: 1
  });

  const result = await getUserById('123');
  expect(result.name).toBe('Test User');
});
```

---

## Debugging

### Enable Query Logging

Set environment variables:

```bash
QUERY_LOG_ENABLED=true
LOG_SLOW_QUERIES=true
SLOW_QUERY_THRESHOLD_MS=1000
LOG_QUERY_TEXT=true
LOG_PARAMETERS=true
```

### Check Pool Status

```typescript
import { getPoolStatus } from '@/lib/database';

const status = getPoolStatus();
console.log('Pool status:', status);
```

### Monitor Circuit Breaker

```typescript
import { dbManager } from '@/lib/database/enterprise-connection-manager';

const status = dbManager.getStatus();
console.log('Circuit breaker state:', status.state);
console.log('Failed connections:', status.failedConnections);
console.log('Average response time:', status.avgResponseTime);
```

---

## Migration Guide

### From Old Pattern

```typescript
// OLD
import { db } from '@/lib/database/connection';
const result = await db.query('SELECT * FROM users');

// NEW
import { query } from '@/lib/database';
const result = await query('SELECT * FROM users');
```

### From Direct Pool

```typescript
// OLD
import { pool } from '@/lib/database/enterprise-connection-manager';
const result = await pool.query('SELECT * FROM users');

// NEW
import { pool } from '@/lib/database';
const result = await pool.query('SELECT * FROM users');
// OR better:
import { query } from '@/lib/database';
const result = await query('SELECT * FROM users');
```

---

## Support

**Common Issues:**
- Circuit breaker errors → Check database connectivity
- UUID type errors → Add `::uuid` casting
- Connection timeout → Check network/database status
- Type errors → Verify interface matches database schema

**Resources:**
- Database API: `src/lib/database/index.ts`
- Enterprise Manager: `lib/database/enterprise-connection-manager.ts`
- Migrations: `database/migrations/`
- Summary: `DATABASE_LAYER_FIXES_SUMMARY.md`
